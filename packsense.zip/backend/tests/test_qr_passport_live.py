import unittest
from datetime import datetime, timezone, timedelta
from app.physics.shelf_life import recompute_q10_remaining_shelf_life

class TestQrPassportLive(unittest.TestCase):
    def test_live_recompute(self):
        now = datetime.now(timezone.utc)
        batch = {"batch_id": "BATCH-TEST", "baseline_shelf_life_hours": 504.0, "optimal_temp_c": 12.0, "q10_value": 2.2}
        readings = [
            {"temp_c": 12.0, "rh_pct": 85.0, "recorded_at": (now - timedelta(hours=24)).isoformat()},
            {"temp_c": 12.0, "rh_pct": 85.0, "recorded_at": (now - timedelta(hours=12)).isoformat()}
        ]
        res = recompute_q10_remaining_shelf_life(batch, readings, current_time_iso=now.isoformat())
        self.assertTrue(475.0 <= res["remaining_shelf_life_hours"] <= 485.0)

if __name__ == "__main__":
    unittest.main()
