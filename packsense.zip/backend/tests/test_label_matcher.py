"""
Pytest/Unittest suite for Part 1 (Pack Label Matcher) and Part 2 (Multilingual i18n)
Meets requirement 7 of Part 3:
- Covers at least 5 label text variations (different units, missing thickness, unmatched material).
- Covers i18n fallback behavior (unsupported language requests fall back to English without returning blank).
"""

import unittest
from app.scanning.label_matcher import match_label_to_film, normalize, extract_thickness_number, extract_material_keyword
from app.i18n.render_template import render_template
from app.i18n.localized_field import get_localized_field
from app.i18n.languages import get_supported_languages, SUPPORTED_LANGUAGES_LIST

class TestLabelMatcherAndI18n(unittest.TestCase):

    # ----------------------------------------------------
    # PART 1: Label matcher with at least 5 text variations
    # ----------------------------------------------------

    def test_variation_1_standard_micron_spelling(self):
        """Variation 1: Standard spelling '40 micron' with polymer keyword."""
        res = match_label_to_film("LDPE 40 micron mono-layer film for produce")
        self.assertTrue(res["matched"])
        self.assertEqual(res["extracted_material"], "LDPE")
        self.assertEqual(res["extracted_thickness"], 40)
        self.assertEqual(res["film_id"], 14)
        self.assertGreaterEqual(res["match_confidence"], 75)
        self.assertIsNone(res["fallback_message"])

    def test_variation_2_micro_symbol_unit(self):
        """Variation 2: Unicode micro symbol 'µm' unit."""
        res = match_label_to_film("Low Density Polyethylene 40µm Grade A")
        self.assertTrue(res["matched"])
        self.assertEqual(res["extracted_material"], "LDPE")
        self.assertEqual(res["extracted_thickness"], 40)
        self.assertEqual(res["film_id"], 14)

    def test_variation_3_ascii_um_spelling(self):
        """Variation 3: ASCII 'um' spelling for thickness."""
        res = match_label_to_film("BOPP 20um packaging film")
        self.assertTrue(res["matched"])
        self.assertEqual(res["extracted_material"], "BOPP")
        self.assertEqual(res["extracted_thickness"], 20)

    def test_variation_4_missing_thickness(self):
        """Variation 4: Missing thickness number; matches by material."""
        res = match_label_to_film("Mono-Material PE Recyclable pouch")
        self.assertTrue(res["matched"])
        self.assertEqual(res["extracted_material"], "LDPE")
        self.assertIsNone(res["extracted_thickness"])
        self.assertIsNotNone(res["film_id"])
        self.assertGreater(res["match_confidence"], 0)

    def test_variation_5_unmatched_material(self):
        """Variation 5: Unmatched unknown material; returns fallback message, never crashes."""
        res = match_label_to_film("Mystery Unobtainium Alien Wrap 9999 micron")
        self.assertFalse(res["matched"])
        self.assertIsNone(res["film_id"])
        self.assertIsNotNone(res["fallback_message"])
        self.assertIn("Couldn't confidently match this label", res["fallback_message"])

    def test_variation_6_gauge_unit_conversion(self):
        """Variation 6: Gauge unit notation (160 gauge ≈ 40.6 micron)."""
        res = match_label_to_film("LDPE 160 gauge extrusion")
        self.assertTrue(res["matched"])
        self.assertEqual(res["extracted_material"], "LDPE")
        self.assertAlmostEqual(res["extracted_thickness"], 40.6, places=1)
        self.assertEqual(res["film_id"], 14)

    # ----------------------------------------------------
    # PART 2: i18n fallback behavior
    # ----------------------------------------------------

    def test_i18n_fallback_to_english_for_unsupported_language(self):
        """Requesting an unsupported language (e.g. 'fr', 'de') falls back cleanly to English."""
        # Test template rendering
        en_text = render_template("shap_explanation.high_respiration", "en", temp=30, x=3)
        fr_text = render_template("shap_explanation.high_respiration", "fr", temp=30, x=3)
        de_text = render_template("shap_explanation.high_respiration", "de", temp=30, x=3)
        
        self.assertIsNotNone(fr_text)
        self.assertNotEqual(fr_text, "")
        self.assertEqual(fr_text, en_text)
        self.assertEqual(de_text, en_text)
        self.assertIn("30°C", fr_text)
        self.assertIn("3x", fr_text)

    def test_i18n_fallback_never_returns_blank(self):
        """Confirm empty or unknown template key never returns blank text."""
        unknown_text = render_template("nonexistent.key.test", "hi")
        self.assertIsNotNone(unknown_text)
        self.assertNotEqual(unknown_text.strip(), "")
        self.assertEqual(unknown_text, "nonexistent.key.test")

    def test_localized_field_fallback_behavior(self):
        """get_localized_field falls back to English when language translation is missing."""
        mock_rule = {
            "rule_description": "FSSAI overall migration limit < 60 mg/kg",
            "rule_description_translations": {
                "hi": "FSSAI समग्र प्रवासन सीमा < 60 मिग्रा/किग्रा"
                # Marathi and Tamil missing in this mock
            }
        }
        # Existing Hindi translation
        hi_result = get_localized_field(mock_rule, "rule_description", lang="hi")
        self.assertIn("समग्र प्रवासन सीमा", hi_result)

        # Missing Marathi falls back to English, never blank
        mr_result = get_localized_field(mock_rule, "rule_description", lang="mr")
        self.assertEqual(mr_result, "FSSAI overall migration limit < 60 mg/kg")

        # Unsupported language 'es' falls back to English
        es_result = get_localized_field(mock_rule, "rule_description", lang="es")
        self.assertEqual(es_result, "FSSAI overall migration limit < 60 mg/kg")

    def test_supported_languages_list(self):
        """GET /api/v1/i18n/languages list contains 4 required languages."""
        langs = SUPPORTED_LANGUAGES_LIST
        codes = [l["code"] for l in langs]
        self.assertIn("en", codes)
        self.assertIn("hi", codes)
        self.assertIn("mr", codes)
        self.assertIn("ta", codes)

if __name__ == "__main__":
    unittest.main()
