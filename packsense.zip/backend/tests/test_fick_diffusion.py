import unittest
from app.physics.engine import calculate_laminate_barrier

class TestFickDiffusion(unittest.TestCase):
    def test_thickness_scaling(self):
        b1 = calculate_laminate_barrier([{"material_id": "ldpe", "thickness_um": 25}], 23.0, 50.0)
        b2 = calculate_laminate_barrier([{"material_id": "ldpe", "thickness_um": 50}], 23.0, 50.0)
        self.assertAlmostEqual(b1["otr_cc_m2_day_atm"] / 2.0, b2["otr_cc_m2_day_atm"], places=1)

if __name__ == "__main__":
    unittest.main()
