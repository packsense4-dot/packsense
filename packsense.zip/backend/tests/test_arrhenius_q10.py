import unittest
from app.physics.shelf_life import shelf_life_temperature_q10

class TestArrheniusQ10(unittest.TestCase):
    def test_q10_shelf_life(self):
        baseline = 504.0
        q10 = 2.2
        sl_plus10 = shelf_life_temperature_q10(baseline, 22.0, 12.0, q10)
        self.assertAlmostEqual(sl_plus10, baseline / 2.2, places=2)

if __name__ == "__main__":
    unittest.main()
