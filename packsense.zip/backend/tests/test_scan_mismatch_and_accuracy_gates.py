"""
Part B.3 & Part D Backend Contract & Accuracy-Gates Test Suite:
Verifies all four Part A fixes and Part B defense-in-depth protections:
1. Two different fixture images (Tomato vs Banana) through /ripeness/scan return two distinct, accurate food_detected values (no caching conflation).
2. /scan/analyze cache key hashes the FULL normalized input payload via SHA-256 (never conflating different requests from the same user).
3. Low-confidence detection returns status="needs_input" with top N ranked candidate foods (never silently defaulting to first DB row).
4. scan_session_id is echoed end-to-end on both /ripeness/scan and /scan/analyze and logged server-side.
5. Captured photo thumbnail reference is preserved in the scan report.
"""

import unittest
from app.ml.inference import run_ripeness_inference
from app.scan.resolver import resolve_scan_input
from app.scan.orchestrator import (
    analyze_scan_request,
    compute_analyze_cache_key,
    get_scan_trace_logs,
)


class TestScanMismatchAndAccuracyGates(unittest.TestCase):

    def test_part_b3_two_different_images_return_two_different_foods(self):
        """
        Part B.3 Contract Test:
        Feed the ripeness model two clearly different fixture images (a tomato photo and a banana photo)
        in the same test run, and assert the two food_detected values differ and are each correct.
        """
        tomato_fixture_payload = {
            "scan_session_id": "test-session-tomato-001",
            "commodity_id": "auto",
            "image_base64": "data:image/svg+xml;utf8,<svg><!-- fixture:roma_tomato_red_fruit --></svg>",
            "r_mean": 218.0,
            "g_mean": 58.0,
            "b_mean": 42.0,
            "browning_pct": 2.0,
        }
        banana_fixture_payload = {
            "scan_session_id": "test-session-banana-002",
            "commodity_id": "auto",
            "image_base64": "data:image/svg+xml;utf8,<svg><!-- fixture:cavendish_banana_yellow_fruit --></svg>",
            "r_mean": 238.0,
            "g_mean": 215.0,
            "b_mean": 52.0,
            "browning_pct": 4.0,
        }

        res_tomato = run_ripeness_inference(tomato_fixture_payload)
        res_banana = run_ripeness_inference(banana_fixture_payload)

        self.assertNotEqual(res_tomato["food_detected"], res_banana["food_detected"])
        self.assertEqual(res_tomato["food_detected"], "tomato")
        self.assertEqual(res_banana["food_detected"], "banana")
        self.assertNotEqual(res_tomato["image_sha256"], res_banana["image_sha256"])
        self.assertEqual(res_tomato["scan_session_id"], "test-session-tomato-001")
        self.assertEqual(res_banana["scan_session_id"], "test-session-banana-002")

    def test_part_a1_analyze_cache_key_hashes_full_normalized_payload(self):
        """
        Part A.1:
        Confirm /scan/analyze cache key is sha256(json.dumps(payload, sort_keys=True))
        and never conflates two different requests from the same user_id.
        """
        req_tomato = {
            "user_id": 1,
            "food_id": "roma_tomato",
            "storage_temp_c": 12,
            "ambient_rh_pct": 90,
            "scan_session_id": "sess-101",
            "captured_image": "data:image/png;base64,TOMATO_THUMBNAIL_BYTES",
        }
        req_banana = {
            "user_id": 1,
            "food_id": "cavendish_banana",
            "storage_temp_c": 14,
            "ambient_rh_pct": 90,
            "scan_session_id": "sess-102",
            "captured_image": "data:image/png;base64,BANANA_THUMBNAIL_BYTES",
        }

        key_1 = compute_analyze_cache_key(req_tomato)
        key_2 = compute_analyze_cache_key(req_banana)
        self.assertNotEqual(key_1, key_2)

        report_1 = analyze_scan_request(req_tomato)
        report_2 = analyze_scan_request(req_banana)

        self.assertEqual(report_1["input"]["data"]["food"]["id"], "roma_tomato")
        self.assertEqual(report_2["input"]["data"]["food"]["id"], "cavendish_banana")
        self.assertEqual(report_1["scan_session_id"], "sess-101")
        self.assertEqual(report_2["scan_session_id"], "sess-102")
        self.assertEqual(
            report_1["input"]["data"]["captured_image"],
            "data:image/png;base64,TOMATO_THUMBNAIL_BYTES",
        )
        self.assertEqual(
            report_2["input"]["data"]["captured_image"],
            "data:image/png;base64,BANANA_THUMBNAIL_BYTES",
        )

    def test_part_a4_low_confidence_returns_needs_input_with_candidates(self):
        """
        Part A.4:
        When confidence is below threshold (< 0.75) and user_confirmed_food is False,
        both /ripeness/scan and resolver return status="needs_input" with ranked candidates,
        never silently substituting a default food.
        """
        ambiguous_scan = run_ripeness_inference(
            {
                "scan_session_id": "sess-low-conf-003",
                "commodity_id": "auto",
                "r_mean": 120.0,
                "g_mean": 122.0,
                "b_mean": 118.0,
                "simulate_low_confidence": True,
            }
        )
        self.assertEqual(ambiguous_scan["status"], "needs_input")
        self.assertIsNone(ambiguous_scan["food_detected"])
        self.assertTrue(len(ambiguous_scan["candidates"]) >= 3)

        resolved = resolve_scan_input(
            {
                "scan_session_id": "sess-low-conf-003",
                "food_id": "alphonso_mango",
                "confidence": 0.52,
                "user_confirmed_food": False,
                "candidates": ambiguous_scan["candidates"],
            }
        )
        self.assertEqual(resolved["status"], "needs_input")
        self.assertTrue(resolved["needs_input"])
        self.assertIsNone(resolved["food"])
        self.assertTrue(len(resolved["candidates"]) >= 3)

    def test_part_b2_scan_session_id_logged_server_side(self):
        """
        Part B.2 & D.5:
        Verify scan_session_id is logged server-side and retrievable from trace logs.
        """
        target_session_id = "trace-verify-session-999"
        analyze_scan_request(
            {
                "scan_session_id": target_session_id,
                "food_id": "roma_tomato",
                "user_confirmed_food": True,
            }
        )
        logs = get_scan_trace_logs()
        matching = [entry for entry in logs if entry.get("scan_session_id") == target_session_id]
        self.assertTrue(len(matching) >= 1)
        self.assertEqual(matching[-1]["food_id"], "roma_tomato")


if __name__ == "__main__":
    unittest.main()
