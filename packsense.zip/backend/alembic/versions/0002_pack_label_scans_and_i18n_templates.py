"""pack_label_scans and i18n_templates migrations

Revision ID: 0002_pack_label_scans_and_i18n_templates
Revises: 0001_initial
Create Date: 2026-09-27 10:45:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = '0002_pack_label_scans_and_i18n_templates'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # 1. pack_label_scans table
    op.create_table(
        'pack_label_scans',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('raw_text', sa.Text(), nullable=False),
        sa.Column('extracted_material', sa.String(length=60), nullable=True),
        sa.Column('extracted_thickness', sa.Numeric(precision=6, scale=2), nullable=True),
        sa.Column('matched_film_id', sa.Integer(), sa.ForeignKey('films.id'), nullable=True),
        sa.Column('match_confidence', sa.SmallInteger(), server_default='0', nullable=True),
        sa.Column('was_accepted_by_user', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), server_default=sa.func.now(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    # 2. i18n_templates table
    op.create_table(
        'i18n_templates',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('template_key', sa.String(length=80), nullable=False),
        sa.Column('language_code', sa.String(length=10), nullable=False),
        sa.Column('template_text', sa.Text(), nullable=False),
        sa.Column('needs_translation_review', sa.Boolean(), server_default='true', nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('template_key', 'language_code', name='uq_i18n_template_key_lang')
    )

    # 3. _translations JSONB sibling columns
    op.add_column('compliance_rules', sa.Column('rule_description_translations', JSONB, nullable=True))
    op.add_column('rural_alternatives', sa.Column('limitation_notes_translations', JSONB, nullable=True))
    op.add_column('gov_district_packaging_stats', sa.Column('common_packaging_gap_translations', JSONB, nullable=True))

def downgrade():
    op.drop_column('gov_district_packaging_stats', 'common_packaging_gap_translations')
    op.drop_column('rural_alternatives', 'limitation_notes_translations')
    op.drop_column('compliance_rules', 'rule_description_translations')
    op.drop_table('i18n_templates')
    op.drop_table('pack_label_scans')
