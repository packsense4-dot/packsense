# PackSense Backend

Deterministic physics simulation, multi-objective packaging optimization, and cold-chain compliance API.
Zero LLM or external AI API calls in the runtime execution path.

## Architecture
- **Framework**: FastAPI (Python 3.11+)
- **Database**: PostgreSQL 15 + PostGIS for spatial converter matching
- **Physics Engine**: ASTM D3985, ASTM F1249, Michaelis-Menten respiration, Baranyi/Labuza isotherms, Arrhenius/Q10 kinetics
- **Surrogate Model**: Offline NSGA-II calibrated polynomial surface + SHAP attribution
- **Ripeness Vision**: MobileNetV3 ONNX classification pipeline
- **Hardware Telemetry**: BLE GATT temperature logger ingestion with live Q10 recomputation

## Quickstart
```bash
docker-compose up --build
```
API documentation available at `http://localhost:8000/docs`.
