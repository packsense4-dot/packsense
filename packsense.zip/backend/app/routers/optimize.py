"""
Router 4: NSGA-II Packaging Optimizer (Section 7)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.optimizer.nsga2 import run_nsga2_optimization

router = APIRouter(tags=["Optimize"])

@router.post("/optimize")
@router.post("/optimize/packaging")
def optimize(payload: Dict[str, Any] = Body(...)):
    return run_nsga2_optimization(payload)
