"""
Router 17: Low-Cost Rural Mode & Mandi Postharvest (Feature #17)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import recommend_rural_mode

router = APIRouter(prefix="/rural-mode", tags=["Rural Mode"])

@router.post("/recommend")
def rural_mode(payload: Dict[str, Any] = Body(...)):
    return recommend_rural_mode(payload)
