"""
Router 5: FSSAI Compliance & SHAP Attribution (Section 7)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.optimizer.compliance import evaluate_film_compliance
from app.compliance import compute_shap_feature_attribution

router = APIRouter(tags=["Compliance & Explainability"])

@router.post("/compliance/audit")
def audit_compliance(payload: Dict[str, Any] = Body(...)):
    return evaluate_film_compliance(payload)

@router.post("/shap/attribution")
def shap_attribution(payload: Dict[str, Any] = Body(...)):
    return compute_shap_feature_attribution(
        base_days=14.0,
        predicted_days=float(payload.get("predicted_days", 21.0)),
        temp_c=float(payload.get("temp_c", 12.0)),
        otr=float(payload.get("otr", 35.0)),
        wvtr=float(payload.get("wvtr", 2.0)),
        o2_pct=float(payload.get("o2_pct", 3.0)),
        co2_pct=float(payload.get("co2_pct", 5.0)),
        thickness_um=50.0
    )
