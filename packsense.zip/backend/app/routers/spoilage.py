"""
Router 10: Spoilage Autopsy Diagnostic (Feature #10)
"""
from fastapi import APIRouter, Body, Query
from typing import Dict, Any, Optional
from app.physics.features_suite import diagnose_spoilage_autopsy
from app.physics.multilingual import localize_spoilage_diagnosis

router = APIRouter(tags=["Spoilage"])

@router.post("/spoilage/diagnose")
@router.post("/spoilage-autopsy")
def diagnose_spoilage(
    payload: Dict[str, Any] = Body(...),
    lang: Optional[str] = Query(None)
):
    target_lang = lang or payload.get("lang") or payload.get("language") or "en"
    result = diagnose_spoilage_autopsy(payload)
    return localize_spoilage_diagnosis(result, str(target_lang).lower())
