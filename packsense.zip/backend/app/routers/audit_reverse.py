"""
Router 9: Reverse Pack Auditor (Feature #9)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import perform_reverse_pack_audit

router = APIRouter(tags=["Audit"])

@router.post("/audit/reverse")
@router.post("/audit")
def audit_reverse(payload: Dict[str, Any] = Body(...)):
    return perform_reverse_pack_audit(payload)
