"""
Router 24: Pack Label Scan & OCR Film Matching Endpoint (Section 1 & 12, Part A.1 & B.2)
Matches OCR-extracted label text to a known film in the database with continuous improvement.
Excluded from caching entirely (Part A.1). Echoes scan_session_id (Part B.2).
"""

from fastapi import APIRouter, Body, Query, Header, Response
from typing import Dict, Any, Optional
from app.scanning.label_matcher import match_label_to_film, record_user_feedback, get_scans_summary
from app.scan.orchestrator import record_scan_trace

router = APIRouter(tags=["Pack Label Scan"])


@router.post("/pack-label/scan")
@router.post("/label-scan")
@router.post("/pack-label-scan")
def scan_pack_label(
    response: Response,
    payload: Dict[str, Any] = Body(...),
    lang: Optional[str] = Query(None),
    x_scan_session_id: Optional[str] = Header(default=None),
):
    # Part A.1: Explicitly exclude /pack-label/scan from caching
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"

    scan_session_id = (
        payload.get("scan_session_id")
        or payload.get("scan_id")
        or x_scan_session_id
        or "unassigned"
    )

    raw_text = (
        payload.get("raw_text")
        or payload.get("ocr_text")
        or payload.get("label_text")
        or payload.get("text")
        or "BOPP 20 micron / Met-BOPP 18 micron / CPP 30 micron High Barrier Snack Web FSSAI Approved"
    )
    target_lang = lang or payload.get("lang") or payload.get("language") or "en"
    user_id = payload.get("user_id")
    was_accepted_by_user = payload.get("was_accepted_by_user")

    res = match_label_to_film(
        raw_text=str(raw_text),
        lang=str(target_lang).lower(),
        user_id=user_id,
        was_accepted_by_user=was_accepted_by_user,
    )
    res["scan_session_id"] = scan_session_id
    response.headers["X-Scan-Session-Id"] = str(scan_session_id)

    record_scan_trace(
        scan_session_id=scan_session_id,
        endpoint="/api/v1/pack-label/scan",
        food_id=None,
        status=res.get("status", "ok"),
        extra={"matched": res.get("matched"), "film_id": res.get("film_id")},
    )
    return res


@router.post("/pack-label/feedback")
def submit_label_feedback(payload: Dict[str, Any] = Body(...)):
    """Section 1.5: Continuous improvement feedback loop."""
    scan_id = payload.get("scan_id", 1)
    was_accepted = payload.get("was_accepted_by_user", True)
    override_film_id = payload.get("override_film_id")
    notes = payload.get("notes")
    return record_user_feedback(scan_id, was_accepted, override_film_id, notes)


@router.get("/pack-label/scans")
def list_pack_label_scans():
    """Section 1.5: Review summary of label scans for quarterly review."""
    return get_scans_summary()
