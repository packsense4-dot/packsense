"""
Router 20: Bluetooth BLE Hardware Logger Ingestion (Section 8.3 & Feature #19)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.routers.qr import QR_BATCHES_STORE, READINGS_STORE
from app.physics.shelf_life import recompute_q10_remaining_shelf_life
from datetime import datetime

router = APIRouter(tags=["BLE Logger"])

@router.post("/qr/{batch_id}/logger-reading")
def ingest_reading(batch_id: str, payload: Dict[str, Any] = Body(...)):
    temp = float(payload.get("temp_c", 12.0))
    rh = float(payload.get("rh_pct", payload.get("rh_percent", 85.0)))
    rec_time = payload.get("recorded_at", datetime.utcnow().isoformat())
    
    reading = {"device_id": payload.get("device_id", "BLE-901"), "temp_c": temp, "rh_pct": rh, "recorded_at": rec_time}
    if batch_id not in READINGS_STORE:
        READINGS_STORE[batch_id] = []
    READINGS_STORE[batch_id].append(reading)

    batch = QR_BATCHES_STORE.get(batch_id, QR_BATCHES_STORE["BATCH-TEST-001"])
    status = recompute_q10_remaining_shelf_life(batch, READINGS_STORE[batch_id])

    return {
        "status": "INGESTED",
        "batch_id": batch_id,
        "temp_c": temp,
        "rh_pct": rh,
        "remaining_shelf_life_hours": status["remaining_shelf_life_hours"],
        "remaining_shelf_life_days": status["remaining_shelf_life_days"],
        "total_readings": len(READINGS_STORE[batch_id]),
        "authoritative_source": "BLE Hardware Temperature History (Q10 Kinetics)"
    }

@router.get("/qr/{batch_id}/logger-history")
def logger_history(batch_id: str):
    batch = QR_BATCHES_STORE.get(batch_id, QR_BATCHES_STORE["BATCH-TEST-001"])
    readings = READINGS_STORE.get(batch_id, READINGS_STORE["BATCH-TEST-001"])
    status = recompute_q10_remaining_shelf_life(batch, readings)
    return {
        "batch_id": batch_id,
        "readings": readings,
        "total_readings": len(readings),
        "remaining_shelf_life_hours": status["remaining_shelf_life_hours"],
        "quality_grade": status["quality_grade"],
        "authoritative_source": status["authoritative_source"]
    }
