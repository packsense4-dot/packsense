"""
Router 16: Rupee Impact & Food Waste Calculator (Feature #16)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import calculate_rupee_impact

router = APIRouter(prefix="/rupee-impact", tags=["Rupee Impact"])

@router.post("")
@router.post("/calculate")
def rupee_impact(payload: Dict[str, Any] = Body(...)):
    return calculate_rupee_impact(payload)
