"""
Router 3: Digital Twin Simulation (Section 6)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.engine import calculate_laminate_barrier, simulate_shelf_life
from app.db.seeds import FOODS_SEED_DATA

router = APIRouter(tags=["Simulate"])

@router.post("/simulate")
@router.post("/simulate/shelf-life")
def simulate(payload: Dict[str, Any] = Body(...)):
    food_id = payload.get("food_id", "alphonso_mango")
    food = next((f for f in FOODS_SEED_DATA if f.get("id") == food_id), FOODS_SEED_DATA[0])
    layers = payload.get("layers", [{"material_id": "ldpe", "thickness_um": 50}])
    conds = payload.get("conditions", {"storage_temp_c": 12.0, "ambient_rh_percent": 85.0})
    
    barrier = calculate_laminate_barrier(layers, conds.get("storage_temp_c", 12.0), conds.get("ambient_rh_percent", 85.0))
    res = simulate_shelf_life(food, barrier, {"package_type": "pillow_pouch", "length_mm": 200, "width_mm": 150, "net_weight_g": 250}, conds)
    return res
