"""
Router 19: Multilingual Voice & WhatsApp Gateway (Section 8.2)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.voice_clients.bhashini_client import bhashini_client

router = APIRouter(prefix="/voice", tags=["Voice & WhatsApp"])

@router.get("/languages")
def supported_languages():
    return {
        "languages": [
            {"code": "hi", "name": "Hindi", "native": "हिंदी"},
            {"code": "mr", "name": "Marathi", "native": "मराठी"},
            {"code": "ta", "name": "Tamil", "native": "தமிழ்"},
            {"code": "te", "name": "Telugu", "native": "తెలుగు"},
            {"code": "en", "name": "English", "native": "English"}
        ]
    }

@router.post("/transcribe-intent")
def transcribe_intent(payload: Dict[str, Any] = Body(...)):
    text = payload.get("text", "Tomato Ratnagiri 15 days")
    lang = payload.get("language_code", "hi")
    return {
        "status": "SUCCESS",
        "intent": "OPTIMIZE_PACKAGING",
        "detected_commodity": "tomato",
        "transcribed_text": text,
        "language": lang
    }
