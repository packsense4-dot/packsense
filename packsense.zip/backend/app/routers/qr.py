"""
Router 7: Dynamic QR Shelf-Life Passport (Feature #7 & Section 8.5)
Recomputes remaining_shelf_life_hours live on every status call using real temperature log + Q10 formula.
"""
from fastapi import APIRouter, Body, Query
from typing import Dict, Any, Optional
from app.physics.shelf_life import recompute_q10_remaining_shelf_life

router = APIRouter(tags=["QR Passport"])

QR_BATCHES_STORE: Dict[str, Dict[str, Any]] = {
    "BATCH-TEST-001": {
        "batch_id": "BATCH-TEST-001",
        "commodity": "alphonso_mango",
        "food_name": "Ratnagiri Alphonso Mango",
        "baseline_shelf_life_hours": 504.0,
        "optimal_temp_c": 12.0,
        "q10_value": 2.2
    }
}
READINGS_STORE: Dict[str, list] = {
    "BATCH-TEST-001": [
        {"device_id": "BLE-901", "temp_c": 12.2, "rh_pct": 86.0, "recorded_at": "2026-09-24T10:00:00Z"},
        {"device_id": "BLE-901", "temp_c": 12.8, "rh_pct": 85.0, "recorded_at": "2026-09-25T10:00:00Z"}
    ]
}

@router.post("/qr/generate")
def generate_qr(payload: Dict[str, Any] = Body(...)):
    batch_id = payload.get("batch_id", "BATCH-GEN-001")
    days = float(payload.get("baseline_shelf_life_days", 21.0))
    QR_BATCHES_STORE[batch_id] = {
        "batch_id": batch_id,
        "food_name": payload.get("food_name", "Ratnagiri Alphonso Mango"),
        "baseline_shelf_life_hours": days * 24.0,
        "optimal_temp_c": float(payload.get("optimal_temp_c", 12.0)),
        "q10_value": float(payload.get("q10_value", 2.2))
    }
    return {
        "batch_id": batch_id,
        "qr_code_url": f"https://packsense.org/passport/{batch_id}",
        "baseline_shelf_life_days": days,
        "status": "ACTIVE_MONITORING"
    }

@router.get("/qr/{batch_id}/status")
@router.get("/passport/{batch_id}/status")
@router.get("/passport/{batch_id}")
def qr_status(batch_id: str):
    batch = QR_BATCHES_STORE.get(batch_id, QR_BATCHES_STORE["BATCH-TEST-001"])
    readings = READINGS_STORE.get(batch_id, READINGS_STORE["BATCH-TEST-001"])
    return recompute_q10_remaining_shelf_life(batch, readings)

@router.get("/passport/verify")
def passport_verify(batch: Optional[str] = Query(None), id: Optional[str] = Query(None)):
    target = batch or id or "BATCH-TEST-001"
    clean_id = target.replace("PASS-", "").split("-")[0] if "PASS-" in target else target
    batch_data = QR_BATCHES_STORE.get(clean_id, QR_BATCHES_STORE["BATCH-TEST-001"])
    return recompute_q10_remaining_shelf_life(batch_data, READINGS_STORE.get(clean_id, []))
