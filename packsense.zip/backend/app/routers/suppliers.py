"""
Router 8: PostGIS Nearest Converter Matching (Section 8.1)
"""
from fastapi import APIRouter, Query
from app.geo.supplier_matcher import find_suppliers_within_radius

router = APIRouter(prefix="/suppliers", tags=["Suppliers"])

@router.get("")
@router.get("/match")
def match_suppliers(lat: float = Query(18.5204), lng: float = Query(73.8567), radius_km: float = Query(500.0), film_id: str = Query("all")):
    matches = find_suppliers_within_radius(lat=lat, lng=lng, radius_km=radius_km, film_id=film_id)
    return {
        "status": "SUCCESS",
        "matched_converters_count": len(matches),
        "suppliers": matches,
        "spatial_predicate": f"ST_DWithin(suppliers.location, ST_MakePoint({lng},{lat})::geography, {int(radius_km*1000)})"
    }
