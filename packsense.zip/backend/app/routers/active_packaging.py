"""
Router 11: Active Packaging Advisor (Feature #11)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import recommend_active_packaging

router = APIRouter(prefix="/active-packaging", tags=["Active Packaging"])

@router.post("/recommend")
def active_pack(payload: Dict[str, Any] = Body(...)):
    return recommend_active_packaging(payload)
