"""
Router 6: Ripeness CNN Inference & Retraining (Section 9 & Part A.1 / B.2)
Excluded from caching entirely (Part A.1). Echoes scan_session_id (Part B.2).
"""
from fastapi import APIRouter, Body, Header, Response
from typing import Dict, Any, Optional
from app.ml.inference import run_ripeness_inference
from app.workers.retrain_ripeness import log_ripeness_user_feedback

router = APIRouter(prefix="/ripeness", tags=["Ripeness"])


@router.post("/scan")
def scan_ripeness(
    response: Response,
    payload: Dict[str, Any] = Body(...),
    x_scan_session_id: Optional[str] = Header(default=None),
):
    # Part A.1: Never cache image-based endpoints
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"

    if x_scan_session_id and not payload.get("scan_session_id"):
        payload = {**payload, "scan_session_id": x_scan_session_id}

    result = run_ripeness_inference(payload)
    if result.get("scan_session_id"):
        response.headers["X-Scan-Session-Id"] = str(result["scan_session_id"])
    return result


@router.post("/feedback")
def feedback_ripeness(payload: Dict[str, Any] = Body(...)):
    return log_ripeness_user_feedback(payload)


@router.get("/samples")
def ripeness_samples():
    return {
        "samples": [
            {"commodity": "tomato", "stage": "breaker", "r": 210, "g": 65, "b": 45},
            {"commodity": "banana", "stage": "ripe", "r": 235, "g": 215, "b": 50},
            {"commodity": "alphonso_mango", "stage": "ripe", "r": 240, "g": 165, "b": 35}
        ]
    }
