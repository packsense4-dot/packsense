"""
Router 14: Geometric Right-Sizing Engine (Feature #14)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import calculate_right_sizing

router = APIRouter(prefix="/right-sizing", tags=["Right-Sizing"])

@router.post("")
@router.post("/calculate")
def right_size(payload: Dict[str, Any] = Body(...)):
    return calculate_right_sizing(payload)
