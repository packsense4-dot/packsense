"""
Router 23: PDF Spec Sheet & Excel Audit Report Export
"""
from fastapi import APIRouter, Query
from typing import Optional
from app.confidence.lab_trial_checklist import generate_lab_trial_checklist
from app.physics.multilingual import localize_lab_trial_checklist

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.get("/lab-trial-checklist/{pack_id}")
def lab_trial(pack_id: str, lang: Optional[str] = Query("en")):
    checklist = generate_lab_trial_checklist(pack_id, "Fresh Produce")
    return localize_lab_trial_checklist(checklist, (lang or "en").lower())

@router.get("/spec-sheet/{pack_id}")
def spec_sheet(pack_id: str):
    return {
        "pack_id": pack_id,
        "format": "PDF",
        "fssai_certificate": f"IS-9845-VERIFIED-{pack_id}",
        "export_ready": True
    }
