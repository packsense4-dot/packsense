"""
Router 25: Multilingual Localization Gateway (Hindi, Marathi, Tamil, English)
Provides domain-specific translation, reference texts, and language configurations.
"""

from fastapi import APIRouter, Body, Query
from typing import Dict, Any, Optional, List, Union
from app.physics.multilingual import (
    SUPPORTED_LANGUAGES,
    translate_phrase,
    get_multilingual_reference_text
)
from app.i18n.render_template import render_template

router = APIRouter(prefix="/i18n", tags=["Multilingual"])

SUPPORTED_LANGUAGES_LIST: List[Dict[str, str]] = [
    {"code": "en", "name": "English"},
    {"code": "hi", "name": "हिंदी"},
    {"code": "mr", "name": "मराठी"},
    {"code": "ta", "name": "தமிழ்"}
]

@router.get("/languages")
def get_languages(format: str = Query("default")):
    if format == "list":
        return SUPPORTED_LANGUAGES_LIST
    return {
        "status": "SUCCESS",
        "supported_languages": SUPPORTED_LANGUAGES,
        "languages": SUPPORTED_LANGUAGES_LIST,
        "default_language": "en"
    }

@router.post("/translate")
def translate_content(payload: Dict[str, Any] = Body(...)):
    text = payload.get("text", "")
    target_lang = payload.get("target_language") or payload.get("lang") or "hi"
    translated = translate_phrase(str(text), str(target_lang).lower())
    return {
        "original_text": text,
        "target_language": target_lang,
        "translated_text": translated
    }

@router.post("/render-template")
def render_template_endpoint(
    payload: Dict[str, Any] = Body(...),
    lang: Optional[str] = Query(None)
):
    template_key = payload.get("template_key", "")
    target_lang = lang or payload.get("lang") or "en"
    variables = payload.get("variables", {})
    rendered = render_template(template_key, lang=target_lang, **variables)
    return {
        "template_key": template_key,
        "language": target_lang,
        "rendered_text": rendered
    }

@router.get("/reference-text")
def get_reference_text(
    category: str = Query("fssai_standards"),
    lang: str = Query("en")
):
    return get_multilingual_reference_text(category=category, lang=lang.lower())
