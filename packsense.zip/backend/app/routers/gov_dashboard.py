"""
Router 21: MoFPI National Dashboard (Section 8.7)
"""
from fastapi import APIRouter
from app.workers.aggregate_gov_stats import aggregate_district_packaging_stats, get_district_stat

router = APIRouter(prefix="/gov/dashboard", tags=["Government"])

@router.get("/summary")
def gov_summary():
    return aggregate_district_packaging_stats()

@router.get("/district/{district_id}")
def gov_district(district_id: str):
    return {
        "district": get_district_stat(district_id),
        "reporting_agency": "Ministry of Food Processing Industries (MoFPI) PMFME Directorate"
    }
