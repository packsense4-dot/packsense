"""
Router 15: Secondary Packaging & McKee BCT Sizing (Feature #15)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import calculate_secondary_packaging

router = APIRouter(prefix="/secondary-packaging", tags=["Secondary Packaging"])

@router.post("")
@router.post("/recommend")
def secondary_pack(payload: Dict[str, Any] = Body(...)):
    return calculate_secondary_packaging(payload)
