"""
Router 13: Mixed-Load Transport Compatibility (Feature #13)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import check_mixed_load_compatibility

router = APIRouter(prefix="/mixed-load", tags=["Mixed-Load"])

@router.post("/check")
def mixed_load(payload: Dict[str, Any] = Body(...)):
    return check_mixed_load_compatibility(payload)
