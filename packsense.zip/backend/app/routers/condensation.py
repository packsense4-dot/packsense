"""
Router 12: Condensation & Dew-Point Risk (Feature #12)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import evaluate_condensation_risk

router = APIRouter(prefix="/condensation", tags=["Condensation"])

@router.post("/risk")
def condensation(payload: Dict[str, Any] = Body(...)):
    return evaluate_condensation_risk(payload)
