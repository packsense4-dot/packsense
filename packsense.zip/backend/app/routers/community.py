"""
Router 18: Community Learning Loop & Residual Calibration (Feature #18)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.features_suite import log_community_outcome, get_community_regional_accuracy, retrain_surrogate_model_job

router = APIRouter(prefix="/community", tags=["Community"])

@router.post("/log-outcome")
@router.post("/feedback")
def log_outcome(payload: Dict[str, Any] = Body(...)):
    return log_community_outcome(payload)

@router.get("/regional-accuracy")
@router.get("/learnings")
def regional_accuracy():
    return get_community_regional_accuracy()

@router.post("/retrain-worker")
def retrain_worker():
    return retrain_surrogate_model_job()
