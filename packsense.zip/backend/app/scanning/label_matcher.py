"""
PackSense Scanning Engine — Label Matcher (Section 1.2 & 1.5)
Pure string parsing + database lookup (Zero LLM in runtime path).
Implements the exact logic and schema specified in Part 1: Pack Label Scan.
"""

import re
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from app.db.seeds import FILMS_SEED_DATA
from app.scanning.schemas import LabelMatchResult

# Persistent in-memory / SQL simulation store for pack_label_scans table
PACK_LABEL_SCANS_STORE: List[Dict[str, Any]] = []

# Fixed keyword map matching films.material_type values seeded in Section 5
MATERIAL_KEYWORD_MAP: Dict[str, List[str]] = {
    "LDPE": [r"\bldpe\b", r"\blow\s*density\s*polyethylene\b", r"\bpe-?ld\b", r"\bmono-?pe\b", r"\bpe\b", r"\bpolyethylene\b", r"#4\b"],
    "HDPE": [r"\bhdpe\b", r"\bhigh\s*density\s*polyethylene\b", r"\bpe-?hd\b", r"#2\b"],
    "BOPP": [r"\bbopp\b", r"\bbiaxially\s*oriented\s*polypropylene\b"],
    "CPP": [r"\bcpp\b", r"\bcast\s*polypropylene\b"],
    "PP": [r"\bpp\b", r"\bpolypropylene\b", r"#5\b"],
    "PET": [r"\bpet\b", r"\bbopet\b", r"\bpolyester\b", r"#1\b"],
    "PLA": [r"\bpla\b", r"\bpolylactic\s*acid\b", r"\bbopla\b"],
    "PBAT": [r"\bpbat\b", r"\bpolybutyrate\b", r"\becoflex\b"],
    "Bio-PBS": [r"\bbio-?pbs\b", r"\bpolybutylene\s*succinate\b"],
    "EVOH": [r"\bevoh\b", r"\bethylene\s*vinyl\s*alcohol\b"],
    "metallized": [r"\bmet-?bopp\b", r"\bmet-?pe\b", r"\bmetall?ized\b", r"\balumini[sz]ed\b"],
    "foil": [r"\balu-?foil\b", r"\baluminum\s*foil\b", r"\baluminium\s*foil\b", r"\bfoil\b"],
    "paper": [r"\bpaper\b", r"\bkraft\b", r"\bcellulose\b"]
}

def normalize(raw_text: str) -> str:
    """Lowercase, strip punctuation, unit normalization (micron/µm/um -> micron)."""
    text = (raw_text or "").lower()
    # Replace unit attached directly to number (e.g. 40µm, 20um) or separated by space
    text = re.sub(r"(\d+(?:\.\d+)?)\s*(µm|um|microns|mic)\b", r"\1 micron", text)
    text = re.sub(r"\b(µm|um|microns|mic)\b", "micron", text)
    text = re.sub(r"[^\w\s\.\-\/]", " ", text)
    return " ".join(text.split())

def extract_material_keyword(normalized: str) -> Optional[str]:
    """Regex/keyword match against known material_type values."""
    for mat_name, patterns in MATERIAL_KEYWORD_MAP.items():
        if any(re.search(pat, normalized, re.IGNORECASE) for pat in patterns):
            return mat_name
    return None

def extract_thickness_number(normalized: str) -> Optional[float]:
    """Regex for 'NN micron' / 'NN µm'."""
    match = re.search(r"(\d+(?:\.\d+)?)\s*micron", normalized)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            pass
    gauge_match = re.search(r"(\d+(?:\.\d+)?)\s*gauge", normalized)
    if gauge_match:
        try:
            return round(float(gauge_match.group(1)) * 0.254, 1)
        except ValueError:
            pass
    return None

def query_films(material_type: Optional[str], thickness_range: Optional[Tuple[float, float]]) -> List[Dict[str, Any]]:
    """Queries films table matching material_type and thickness window (±5 micron)."""
    candidates = []
    for idx, film in enumerate(FILMS_SEED_DATA):
        film_copy = dict(film)
        film_id = film_copy.get("id", idx + 1)
        film_copy["id"] = film_id
        
        film_mat = (film_copy.get("material_type") or "").upper()
        film_name = (film_copy.get("name") or "").upper()
        film_thick = float(film_copy.get("thickness_micron", 50.0))

        # Check material match
        mat_match = False
        if material_type:
            mat_upper = material_type.upper()
            if mat_upper in film_mat or mat_upper in film_name:
                mat_match = True
            elif mat_upper == "LDPE" and ("MONO-PE" in film_mat or "MONO-LDPE" in film_mat or "PE" in film_mat or "LDPE" in film_name):
                mat_match = True
            elif mat_upper == "PP" and ("MONO-PP" in film_mat or "BOPP" in film_mat or "CPP" in film_mat):
                mat_match = True
            elif mat_upper == "METALLIZED" and ("MET-" in film_mat or "METALLIZED" in film_name or "MET" in film_name):
                mat_match = True
        else:
            mat_match = True

        if not mat_match:
            continue

        # Check thickness window
        if thickness_range:
            min_t, max_t = thickness_range
            if not (min_t <= film_thick <= max_t):
                continue

        candidates.append(film_copy)
    return candidates

def rank_by_closeness(candidates: List[Dict[str, Any]], extracted_thickness: Optional[float]) -> Dict[str, Any]:
    """Ranks candidate films by closeness to extracted thickness."""
    if not extracted_thickness or not candidates:
        return candidates[0]
    return min(candidates, key=lambda f: abs(float(f.get("thickness_micron", 50.0)) - extracted_thickness))

def compute_match_confidence(extracted_material: Optional[str], extracted_thickness: Optional[float], best_film: Dict[str, Any]) -> int:
    """0-100 deterministic confidence score based on material exactness and thickness proximity."""
    score = 0
    if extracted_material:
        film_mat = (best_film.get("material_type") or "").upper()
        film_name = (best_film.get("name") or "").upper()
        if extracted_material.upper() in film_mat or extracted_material.upper() in film_name:
            score += 55
        else:
            score += 40
    else:
        score += 20

    if extracted_thickness is not None:
        film_thick = float(best_film.get("thickness_micron", 50.0))
        diff = abs(film_thick - extracted_thickness)
        if diff <= 0.5:
            score += 33
        elif diff <= 2.0:
            score += 28
        elif diff <= 5.0:
            score += 24
        elif diff <= 10.0:
            score += 15
        else:
            score += 5
    else:
        score += 15

    return min(99, max(20, score))

def match_label_to_film(
    raw_text: str,
    lang: str = "en",
    user_id: Optional[int] = None,
    was_accepted_by_user: Optional[bool] = None
) -> Dict[str, Any]:
    """
    Main entry point for POST /api/v1/pack-label/scan per Section 1.2:
    Pure string parsing + database lookup (no LLM).
    Writes every scan into pack_label_scans table (Section 1.3 & 1.5).
    """
    normalized = normalize(raw_text)
    extracted_material = extract_material_keyword(normalized)
    extracted_thickness = extract_thickness_number(normalized)

    # Query films table with tolerance window (extracted_thickness - 5, extracted_thickness + 5)
    candidates = []
    if extracted_thickness is not None:
        candidates = query_films(material_type=extracted_material, thickness_range=(extracted_thickness - 5, extracted_thickness + 5))
    
    # Fallback to broader material query if empty
    if not candidates and extracted_material:
        candidates = query_films(material_type=extracted_material, thickness_range=None)
    
    if not candidates:
        fallback_msg = "Couldn't confidently match this label — please select your film manually."
        scan_id = len(PACK_LABEL_SCANS_STORE) + 1
        record = {
            "id": scan_id,
            "user_id": user_id,
            "raw_text": raw_text,
            "extracted_material": extracted_material,
            "extracted_thickness": extracted_thickness,
            "matched_film_id": None,
            "match_confidence": 0,
            "was_accepted_by_user": was_accepted_by_user,
            "created_at": datetime.utcnow().isoformat()
        }
        PACK_LABEL_SCANS_STORE.append(record)
        return {
            "matched": False,
            "film_id": None,
            "film_name": None,
            "extracted_material": extracted_material,
            "extracted_thickness": extracted_thickness,
            "match_confidence": 0,
            "fallback_message": fallback_msg,
            "reason": "no_close_match",
            "status": "NO_MATCH",
            "confidence_score": 0.0,
            "explanation": fallback_msg,
            "language": lang,
            "scan_record_id": scan_id
        }

    best = rank_by_closeness(candidates, extracted_thickness)
    match_confidence = compute_match_confidence(extracted_material, extracted_thickness, best)
    film_id = best.get("id") or 14
    film_name = best.get("name")

    # Section 1.3: Record scan to pack_label_scans
    scan_id = len(PACK_LABEL_SCANS_STORE) + 1
    scan_record = {
        "id": scan_id,
        "user_id": user_id,
        "raw_text": raw_text,
        "extracted_material": extracted_material,
        "extracted_thickness": extracted_thickness,
        "matched_film_id": film_id,
        "match_confidence": match_confidence,
        "was_accepted_by_user": was_accepted_by_user,
        "created_at": datetime.utcnow().isoformat()
    }
    PACK_LABEL_SCANS_STORE.append(scan_record)

    # Multilingual explanation
    recyclability_score = best.get("recyclability_score", 90)
    is_circular = recyclability_score >= 85
    pwm_status = "PWM 2022 Class A Compliant (Mono-Material Stream)" if is_circular else "PWM 2022 Multi-Material (Non-Recyclable EPR Penalty)"

    explanation_en = (
        f"Label OCR identified film as '{film_name}' with {match_confidence}% deterministic confidence. "
        f"Barrier properties: OTR {best.get('otr_cc_m2_day')} cc/m²·day, WVTR {best.get('wvtr_g_m2_day')} g/m²·day. "
        f"Recyclability score: {recyclability_score}/100 ({pwm_status})."
    )

    explanations = {
        "en": explanation_en,
        "hi": (
            f"व्याख्या: लेबल स्कैन द्वारा फिल्म की पहचान '{film_name}' के रूप में {match_confidence}% सटीकता से हुई। "
            f"बैरियर क्षमता: OTR {best.get('otr_cc_m2_day')} cc/m²·दिन, WVTR {best.get('wvtr_g_m2_day')} g/m²·दिन। "
            f"पुनर्चक्रण स्कोर: {recyclability_score}/100 ({pwm_status})।"
        ),
        "mr": (
            f"स्पष्टीकरण / व्याख्या: लेबल स्कॅननुसार पॅकेजिंग फिल्म '{film_name}' म्हणून {match_confidence}% अचूकतेने ओळखली गेली. "
            f"अडथळा क्षमता: OTR {best.get('otr_cc_m2_day')} cc/m²·दिवस, WVTR {best_get('wvtr_g_m2_day') if 'best_get' in locals() else best.get('wvtr_g_m2_day')} g/m²·दिवस. "
            f"पुनर्वापर गुणसंख्या: {recyclability_score}/१०० ({pwm_status})."
        ),
        "ta": (
            f"விளக்கம்: லேபிள் ஸ்கேன் மூலம் பேக்கேஜிங் பிலிம் '{film_name}' என {match_confidence}% துல்லியத்துடன் அடையாளம் காணப்பட்டது. "
            f"தடுப்பு பண்புகள்: OTR {best.get('otr_cc_m2_day')} cc/m²·நாள், WVTR {best.get('wvtr_g_m2_day')} g/m²·நாள். "
            f"மறுசுழற்சி மதிப்பீடு: {recyclability_score}/100 ({pwm_status})."
        )
    }

    selected_explanation = explanations.get(lang, explanation_en)

    return {
        # Section 1.2 exact response schema
        "matched": True,
        "film_id": film_id,
        "film_name": film_name,
        "extracted_material": extracted_material,
        "extracted_thickness": int(extracted_thickness) if extracted_thickness and extracted_thickness.is_integer() else extracted_thickness,
        "match_confidence": match_confidence,
        "fallback_message": None,

        # Extended backwards-compatible metadata
        "status": "SUCCESS",
        "confidence_score": round(match_confidence / 100.0, 2),
        "input_ocr_text": raw_text,
        "matched_film": best,
        "regulatory_compliance": {
            "fssai_status": "COMPLIANT per IS 9845 Overall Migration Limits" if best.get("food_contact_approved") else "NON-COMPLIANT",
            "pwm_rules_status": pwm_status,
            "single_use_ban_status": "Exempt: Engineered primary food packaging"
        },
        "sustainable_alternatives": [],
        "explanation": selected_explanation,
        "language": lang if lang in ["en", "hi", "mr", "ta"] else "en",
        "scan_record_id": scan_id
    }

def record_user_feedback(scan_id: int, was_accepted: bool, override_film_id: Optional[int] = None, notes: Optional[str] = None) -> Dict[str, Any]:
    """Section 1.5: Records whether user accepted or overrode the match."""
    for scan in PACK_LABEL_SCANS_STORE:
        if scan["id"] == scan_id:
            scan["was_accepted_by_user"] = was_accepted
            scan["override_film_id"] = override_film_id
            scan["feedback_notes"] = notes
            scan["feedback_recorded_at"] = datetime.utcnow().isoformat()
            return {"status": "RECORDED", "scan_id": scan_id, "was_accepted_by_user": was_accepted}
    return {"status": "NOT_FOUND", "scan_id": scan_id}

def get_scans_summary() -> Dict[str, Any]:
    """Section 1.5: Review summary of label scans for quarterly review."""
    total = len(PACK_LABEL_SCANS_STORE)
    accepted = sum(1 for s in PACK_LABEL_SCANS_STORE if s.get("was_accepted_by_user") is True)
    overridden = sum(1 for s in PACK_LABEL_SCANS_STORE if s.get("was_accepted_by_user") is False)
    low_confidence = [s for s in PACK_LABEL_SCANS_STORE if s.get("match_confidence", 0) < 70]
    return {
        "total_scans": total,
        "accepted_count": accepted,
        "overridden_count": overridden,
        "acceptance_rate_pct": round((accepted / max(1, accepted + overridden)) * 100, 1),
        "low_confidence_scans_count": len(low_confidence),
        "recent_scans": PACK_LABEL_SCANS_STORE[-10:]
    }
