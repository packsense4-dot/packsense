"""
PackSense Scanning Module (Section 1 & 12)
"""
