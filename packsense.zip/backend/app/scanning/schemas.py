"""
PackSense Pack Label Scan Schemas (Section 1.4)
Pydantic models for OCR-extracted label parsing and deterministic film matching.
"""

from typing import Optional, Dict, Any, List

try:
    from pydantic import BaseModel, Field
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        def dict(self):
            return self.__dict__
    def Field(default=None, **kwargs):
        return default

class PackLabelScanRequest(BaseModel):
    raw_text: Optional[str] = Field(None, description="OCR-extracted label text string from packaging photograph")
    ocr_text: Optional[str] = Field(None, description="Alternative field for OCR-extracted text")
    label_text: Optional[str] = Field(None, description="Alternative field for label text")
    text: Optional[str] = Field(None, description="Alternative field for raw text")
    lang: Optional[str] = Field("en", description="Target language code (en, hi, mr, ta)")
    user_id: Optional[int] = Field(None, description="Optional user ID for tracking scan history")
    was_accepted_by_user: Optional[bool] = Field(None, description="Did client report user kept this match?")

class PackLabelFeedbackRequest(BaseModel):
    scan_id: int = Field(..., description="ID of the pack_label_scans record")
    was_accepted_by_user: bool = Field(..., description="Whether user accepted or overrode the match")
    override_film_id: Optional[int] = Field(None, description="Manual film ID selected by user if overridden")
    notes: Optional[str] = Field(None, description="Optional diagnostic notes")

class LabelMatchResult(BaseModel):
    matched: bool = Field(..., description="Whether a close deterministic film match was found")
    film_id: Optional[int] = Field(None, description="Matched film primary key ID in films table")
    film_name: Optional[str] = Field(None, description="Full title of the matched packaging film")
    extracted_material: Optional[str] = Field(None, description="Normalized polymer keyword (e.g. LDPE, BOPP, PET)")
    extracted_thickness: Optional[float] = Field(None, description="Parsed thickness in microns")
    match_confidence: int = Field(0, description="Deterministic confidence score (0-100)")
    fallback_message: Optional[str] = Field(None, description="Guidance message if match was unsuccessful")
    
    # Backwards compatibility and extended metadata fields
    status: Optional[str] = "SUCCESS"
    confidence_score: Optional[float] = None
    input_ocr_text: Optional[str] = None
    matched_film: Optional[Dict[str, Any]] = None
    regulatory_compliance: Optional[Dict[str, Any]] = None
    sustainable_alternatives: Optional[List[Dict[str, Any]]] = None
    explanation: Optional[str] = None
    language: Optional[str] = "en"
    scan_record_id: Optional[int] = None
