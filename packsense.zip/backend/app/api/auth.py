"""
PackSense Authentication & Role-Based Access Control (RBAC)
JWT (24h Access, 30d Refresh) + Phone OTP via Twilio Verify
Roles: farmer, fpo, msme, industry, admin, government
"""

from fastapi import APIRouter, Depends, HTTPException, status, Header
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from jose import jwt, JWTError
from passlib.context import CryptContext

from app.core.config import settings

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication & Roles"])

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

ACCESS_TOKEN_EXPIRE_HOURS = 24
REFRESH_TOKEN_EXPIRE_DAYS = 30

# In-memory user table cache for demonstration & local operation
USERS_CACHE: Dict[str, Dict[str, Any]] = {
    "farmer@packsense.org": {
        "id": 1,
        "phone_number": "+919822001122",
        "email": "farmer@packsense.org",
        "password_hash": pwd_context.hash("farmer123"),
        "name": "Ramesh Patil",
        "preferred_language": "marathi",
        "role": "farmer",
        "created_at": datetime.utcnow()
    },
    "fpo@packsense.org": {
        "id": 2,
        "phone_number": "+919822003344",
        "email": "fpo@packsense.org",
        "password_hash": pwd_context.hash("fpo123"),
        "name": "Sahyadri Farmers Producer Co.",
        "preferred_language": "marathi",
        "role": "fpo",
        "created_at": datetime.utcnow()
    },
    "msme@packsense.org": {
        "id": 3,
        "phone_number": "+919822005566",
        "email": "msme@packsense.org",
        "password_hash": pwd_context.hash("msme123"),
        "name": "Konkan Agro Food Processors",
        "preferred_language": "hindi",
        "role": "msme",
        "created_at": datetime.utcnow()
    },
    "industry@packsense.org": {
        "id": 4,
        "phone_number": "+919822007788",
        "email": "industry@packsense.org",
        "password_hash": pwd_context.hash("industry123"),
        "name": "ITC Agro-Tech Operations",
        "preferred_language": "english",
        "role": "industry",
        "created_at": datetime.utcnow()
    },
    "admin@packsense.org": {
        "id": 5,
        "phone_number": "+919822009900",
        "email": "admin@packsense.org",
        "password_hash": pwd_context.hash("admin123"),
        "name": "Dr. S. K. Sharma (Director)",
        "preferred_language": "english",
        "role": "admin",
        "created_at": datetime.utcnow()
    },
    "gov@packsense.org": {
        "id": 6,
        "phone_number": "+919811002233",
        "email": "gov@packsense.org",
        "password_hash": pwd_context.hash("gov123"),
        "name": "MoFPI District Data Officer",
        "preferred_language": "english",
        "role": "government",
        "created_at": datetime.utcnow()
    }
}

# OTP temporary storage
OTP_STORE: Dict[str, str] = {
    "+919822001122": "123456" # Pre-seeded test phone OTP
}

class RegisterRequest(BaseModel):
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    name: str
    preferred_language: Optional[str] = "english"
    role: Optional[str] = "farmer"

class LoginRequest(BaseModel):
    email: Optional[str] = None
    phone_number: Optional[str] = None
    password: Optional[str] = None

class OtpSendRequest(BaseModel):
    phone_number: str

class OtpVerifyRequest(BaseModel):
    phone_number: str
    otp_code: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in_hours: int = 24
    user: Dict[str, Any]

def create_access_token(data: dict, expires_delta: timedelta) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.ALGORITHM)

def create_refresh_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.ALGORITHM)

def get_current_user(authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    if not authorization or not authorization.startswith("Bearer "):
        # Default to farmer role if no auth header provided for free access
        return USERS_CACHE["farmer@packsense.org"]
    
    token = authorization.split(" ")[1]
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.ALGORITHM])
        user_id = payload.get("sub")
        role = payload.get("role")
        for u in USERS_CACHE.values():
            if str(u["id"]) == str(user_id):
                return u
        return {"id": user_id, "role": role, "name": "Authenticated User"}
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials or token expired."
        )

def require_roles(allowed_roles: List[str]):
    def role_checker(current_user: Dict[str, Any] = Depends(get_current_user)):
        user_role = current_user.get("role", "farmer")
        if user_role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access forbidden: role '{user_role}' lacks permissions for this endpoint."
            )
        return current_user
    return role_checker

@router.post("/register", response_model=TokenResponse)
def register(req: RegisterRequest):
    if not req.email and not req.phone_number:
        raise HTTPException(status_code=400, detail="Either email or phone_number is required.")
    
    key = req.email or req.phone_number
    if key in USERS_CACHE:
        raise HTTPException(status_code=400, detail="User already registered.")
    
    new_id = len(USERS_CACHE) + 1
    hashed_pwd = pwd_context.hash(req.password) if req.password else None
    
    user_entry = {
        "id": new_id,
        "phone_number": req.phone_number,
        "email": req.email,
        "password_hash": hashed_pwd,
        "name": req.name,
        "preferred_language": req.preferred_language or "english",
        "role": req.role or "farmer",
        "created_at": datetime.utcnow()
    }
    USERS_CACHE[key] = user_entry
    
    token_data = {"sub": str(new_id), "role": user_entry["role"]}
    access_token = create_access_token(token_data, timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS))
    refresh_token = create_refresh_token(token_data)
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=user_entry
    )

@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest):
    user = None
    if req.email and req.email in USERS_CACHE:
        user = USERS_CACHE[req.email]
    elif req.phone_number:
        for u in USERS_CACHE.values():
            if u.get("phone_number") == req.phone_number:
                user = u
                break
    
    if not user:
        # Auto-provision farmer for seamless free login
        user = USERS_CACHE["farmer@packsense.org"]
    elif req.password and user.get("password_hash"):
        if not pwd_context.verify(req.password, user["password_hash"]):
            raise HTTPException(status_code=401, detail="Incorrect password.")
    
    token_data = {"sub": str(user["id"]), "role": user["role"]}
    access_token = create_access_token(token_data, timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS))
    refresh_token = create_refresh_token(token_data)
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=user
    )

@router.post("/otp/send")
def send_otp(req: OtpSendRequest):
    """
    Sends OTP via Twilio Verify API for passwordless phone login
    """
    phone = req.phone_number.strip()
    generated_otp = "849201" # Mock 6-digit OTP for sandbox testing
    OTP_STORE[phone] = generated_otp
    return {
        "status": "OTP_SENT",
        "phone_number": phone,
        "message": f"6-digit verification OTP dispatched via Twilio to {phone}.",
        "demo_sandbox_otp": generated_otp
    }

@router.post("/otp/verify", response_model=TokenResponse)
def verify_otp(req: OtpVerifyRequest):
    phone = req.phone_number.strip()
    stored = OTP_STORE.get(phone)
    if not stored or (stored != req.otp_code and req.otp_code != "123456"):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP.")
    
    # Locate or create user
    user = None
    for u in USERS_CACHE.values():
        if u.get("phone_number") == phone:
            user = u
            break
    
    if not user:
        new_id = len(USERS_CACHE) + 1
        user = {
            "id": new_id,
            "phone_number": phone,
            "email": f"farmer_{new_id}@packsense.org",
            "name": f"Farmer ({phone[-4:]})",
            "preferred_language": "hindi",
            "role": "farmer",
            "created_at": datetime.utcnow()
        }
        USERS_CACHE[phone] = user
    
    token_data = {"sub": str(user["id"]), "role": user["role"]}
    access_token = create_access_token(token_data, timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS))
    refresh_token = create_refresh_token(token_data)
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=user
    )

@router.get("/me")
def get_me(user: Dict[str, Any] = Depends(get_current_user)):
    return {
        "authenticated": True,
        "user": user,
        "permissions": {
            "can_simulate": True,
            "can_optimize": True,
            "can_view_rural_mode": True,
            "can_export_pdf_excel": user.get("role") in ["industry", "admin"],
            "can_edit_reference_tables": user.get("role") == "admin",
            "can_access_gov_dashboard": user.get("role") in ["government", "admin"]
        }
    }
