"""
FastAPI Products Endpoints (Part A.1)
- GET /api/v1/products/barcode/{code}
- POST /api/v1/products/submit
- Admin CRUD under /api/v1/admin/products (verify/reject, edit, merge)
"""

from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.products.category_mapper import map_product_to_food_category
from datetime import datetime

router = APIRouter()

def validate_barcode_check_digit(code: str) -> bool:
    """Validates EAN-13, EAN-8, UPC-A check digits."""
    if not code or not code.isdigit():
        return False
    length = len(code)
    digits = [int(c) for c in code]
    
    if length == 13: # EAN-13
        s = sum(digits[i] * (1 if i % 2 == 0 else 3) for i in range(12))
        return (10 - (s % 10)) % 10 == digits[12]
    elif length == 12: # UPC-A
        s = sum(digits[i] * (3 if i % 2 == 0 else 1) for i in range(11))
        return (10 - (s % 10)) % 10 == digits[11]
    elif length == 8: # EAN-8
        s = sum(digits[i] * (3 if i % 2 == 0 else 1) for i in range(7))
        return (10 - (s % 10)) % 10 == digits[7]
    return False

# In-memory store for demonstration / testing when DB is not actively running
PRODUCTS_MEMORY_STORE: List[Dict[str, Any]] = [
    {
        "id": 1,
        "barcode": "8901491101852",
        "name": "Lay's Classic Salted Potato Chips",
        "brand": "PepsiCo India / Frito-Lay",
        "category": "dry_snacks",
        "net_weight_g": 150.0,
        "ingredients": ["Potatoes", "Edible Vegetable Oil (Palmolein)", "Iodized Salt (1.5%)"],
        "other_info": {"shelf_life_months": 4, "fssai_lic_no": "10014064000435"},
        "image_url": "https://images.openfoodfacts.org/images/products/890/149/110/1852/front_en.jpg",
        "food_id": "potato_crisps",
        "current_film_id": 1,
        "verified": True,
        "source": "open_food_facts",
        "source_reference": "Open Food Facts (ODbL) - https://world.openfoodfacts.org/product/8901491101852",
        "created_at": datetime.utcnow().isoformat()
    },
    {
        "id": 2,
        "barcode": "8901262010211",
        "name": "Amul Malai Fresh Paneer",
        "brand": "Amul / GCMMF",
        "category": "dairy_cheese",
        "net_weight_g": 200.0,
        "ingredients": ["Pasteurized Milk", "Lactic Acid", "Citric Acid"],
        "other_info": {"shelf_life_days": 45, "fssai_lic_no": "10012021000071"},
        "image_url": "https://images.openfoodfacts.org/images/products/890/126/201/0211/front_en.jpg",
        "food_id": "fresh_paneer",
        "current_film_id": 2,
        "verified": True,
        "source": "open_food_facts",
        "source_reference": "Open Food Facts (ODbL) - https://world.openfoodfacts.org/product/8901262010211",
        "created_at": datetime.utcnow().isoformat()
    }
]

class ProductSubmitRequest(BaseModel):
    barcode: str = Field(..., description="EAN-13, EAN-8, or UPC-A barcode")
    name: str = Field(..., max_length=160)
    brand: Optional[str] = Field(None, max_length=120)
    category: Optional[str] = Field(None, max_length=60)
    net_weight_g: Optional[float] = None
    ingredients: Optional[List[str]] = None
    other_info: Optional[Dict[str, Any]] = None
    chosen_commodity: Optional[str] = None
    image_url: Optional[str] = None

class ProductUpdateRequest(BaseModel):
    name: Optional[str] = None
    brand: Optional[str] = None
    category: Optional[str] = None
    net_weight_g: Optional[float] = None
    ingredients: Optional[List[str]] = None
    other_info: Optional[Dict[str, Any]] = None
    food_id: Optional[str] = None
    verified: Optional[bool] = None

class MergeProductsRequest(BaseModel):
    source_id: int
    target_id: int

@router.get("/products/barcode/{code}")
def get_product_by_barcode(code: str):
    cleaned = code.strip().replace("-", "").replace(" ", "")
    if not validate_barcode_check_digit(cleaned):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"found": False, "error": "invalid_barcode", "message": "Malformed barcode or invalid check digit"}
        )

    for p in PRODUCTS_MEMORY_STORE:
        if p["barcode"] == cleaned:
            return {"found": True, "product": p}
    
    return {"found": False}

@router.post("/products/submit", status_code=status.HTTP_201_CREATED)
def submit_unknown_product(payload: ProductSubmitRequest):
    cleaned = payload.barcode.strip().replace("-", "").replace(" ", "")
    if not validate_barcode_check_digit(cleaned):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"found": False, "error": "invalid_barcode", "message": "Invalid check digit on submitted barcode"}
        )

    # Check for duplicate
    for p in PRODUCTS_MEMORY_STORE:
        if p["barcode"] == cleaned:
            return {"success": True, "product": p, "message": "Product already exists"}

    food_id = payload.chosen_commodity
    category = payload.category
    if not food_id:
        mapped = map_product_to_food_category(payload.name, payload.brand, payload.category, payload.ingredients)
        food_id = mapped["food_id"]
        if not category:
            category = mapped["category"]

    new_product = {
        "id": len(PRODUCTS_MEMORY_STORE) + 1,
        "barcode": cleaned,
        "name": payload.name.strip(),
        "brand": payload.brand.strip() if payload.brand else None,
        "category": category,
        "net_weight_g": payload.net_weight_g,
        "ingredients": payload.ingredients,
        "other_info": payload.other_info,
        "image_url": payload.image_url,
        "food_id": food_id,
        "current_film_id": None,
        "verified": False,
        "source": "user_submitted",
        "source_reference": "User submitted via mobile camera scan",
        "created_at": datetime.utcnow().isoformat()
    }
    PRODUCTS_MEMORY_STORE.append(new_product)

    return {"success": True, "product": new_product}

# Admin CRUD
@router.get("/admin/products")
def list_admin_products(verified: Optional[bool] = None, source: Optional[str] = None, search: Optional[str] = None):
    res = PRODUCTS_MEMORY_STORE
    if verified is not None:
        res = [p for p in res if p["verified"] == verified]
    if source:
        res = [p for p in res if p["source"].lower() == source.lower()]
    if search:
        s = search.lower()
        res = [p for p in res if s in p["name"].lower() or s in p["barcode"] or (p["brand"] and s in p["brand"].lower())]
    return {"total": len(res), "products": res}

@router.put("/admin/products/{product_id}")
def update_admin_product(product_id: int, payload: ProductUpdateRequest):
    for p in PRODUCTS_MEMORY_STORE:
        if p["id"] == product_id:
            if payload.name is not None: p["name"] = payload.name
            if payload.brand is not None: p["brand"] = payload.brand
            if payload.category is not None: p["category"] = payload.category
            if payload.net_weight_g is not None: p["net_weight_g"] = payload.net_weight_g
            if payload.ingredients is not None: p["ingredients"] = payload.ingredients
            if payload.other_info is not None: p["other_info"] = payload.other_info
            if payload.food_id is not None: p["food_id"] = payload.food_id
            if payload.verified is not None: p["verified"] = payload.verified
            return {"success": True, "product": p}
    raise HTTPException(status_code=404, detail="Product not found")

@router.delete("/admin/products/{product_id}")
def delete_admin_product(product_id: int):
    for idx, p in enumerate(PRODUCTS_MEMORY_STORE):
        if p["id"] == product_id:
            deleted = PRODUCTS_MEMORY_STORE.pop(idx)
            return {"success": True, "deleted_id": product_id}
    raise HTTPException(status_code=404, detail="Product not found")

@router.post("/admin/products/merge")
def merge_admin_products(payload: MergeProductsRequest):
    src_idx = next((i for i, p in enumerate(PRODUCTS_MEMORY_STORE) if p["id"] == payload.source_id), None)
    tgt_idx = next((i for i, p in enumerate(PRODUCTS_MEMORY_STORE) if p["id"] == payload.target_id), None)

    if src_idx is None or tgt_idx is None or payload.source_id == payload.target_id:
        raise HTTPException(status_code=400, detail="Invalid source or target product IDs for merge")

    src = PRODUCTS_MEMORY_STORE[src_idx]
    tgt = PRODUCTS_MEMORY_STORE[tgt_idx]

    tgt["brand"] = tgt["brand"] or src["brand"]
    tgt["category"] = tgt["category"] or src["category"]
    tgt["food_id"] = tgt["food_id"] or src["food_id"]
    tgt["verified"] = tgt["verified"] or src["verified"]
    
    # Remove duplicate source
    PRODUCTS_MEMORY_STORE.pop(src_idx)
    return {"success": True, "merged_product": tgt}
