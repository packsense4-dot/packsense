"""
PackSense Seed Data Importer & Source Citations
"""
from app.db.seeds import (
    FOODS_SEED_DATA,
    FILMS_SEED_DATA,
    CLIMATE_PROFILES_SEED_DATA,
    COMPLIANCE_RULES_SEED_DATA,
    RURAL_ALTERNATIVES_SEED_DATA,
    SECONDARY_PACKAGING_SEED_DATA
)

def get_source_reference_index():
    return {
        "foods": "ICAR Postharvest Compendium / FSSAI Food Composition Database (2024)",
        "films": "ASTM D3985 / ASTM F1249 Polymer Database (TAPPI)",
        "compliance": "FSSAI Packaging Regulations 2018 / EU Regulation 10/2011 / US FDA 21 CFR",
        "climate": "India Meteorological Department (IMD) 30-Year Agro-Climatic Normals"
    }
