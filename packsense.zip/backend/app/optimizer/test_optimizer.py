"""
PackSense Unit Test Suite for Stage C (Optimizer) & Stage D (Compliance)
Verifies:
1. Stage D Compliance pure rule-matching (FSSAI, BIS, CPCB)
2. NSGA-II candidate space generation & Pareto optimization
3. Output contains exactly 3 ranked packs (Best Life, Best Value, Greenest)
4. SHAP TreeExplainer grounded template string explanations
5. Section 7.1 deterministic confidence score calculation
6. Section 7.2 rule-generated Lab Trial Checklist
"""

import unittest
from app.optimizer.compliance import evaluate_film_compliance
from app.optimizer.confidence import (
    compute_confidence_score,
    generate_lab_trial_checklist,
    extrapolation_penalty
)
from app.optimizer.surrogate import (
    SURROGATE_MODEL,
    compute_surrogate_shap_attributions,
    generate_grounded_shap_explanation
)
from app.optimizer.nsga import run_nsga2_optimization
from app.db.seeds import FOODS_SEED_DATA, CLIMATE_PROFILES_SEED_DATA, FILMS_SEED_DATA


class TestStageCOptimizerAndStageDCompliance(unittest.TestCase):

    def test_compliance_rule_matching(self):
        """
        Verify pure rule-matching compliance engine:
        - FSSAI food-contact approval
        - CPCB single-layer minimum thickness (50 micron)
        - Heavy metals & migration limits
        """
        # Compliant 50µm PE film
        compliant_film = {
            "material_type": "Mono-LDPE",
            "thickness_micron": 50.0,
            "layer_count": 1,
            "food_contact_approved": True,
            "is_bio_alternative": False,
            "overall_migration_mg_kg": 25.0,
            "heavy_metals_ppm": 10.0
        }
        res_pass = evaluate_film_compliance(compliant_film, "fruit")
        self.assertTrue(res_pass["is_compliant"])
        self.assertEqual(res_pass["mandatory_violations_count"], 0)
        self.assertEqual(res_pass["authority_status"]["FSSAI"], "PASS")
        self.assertEqual(res_pass["authority_status"]["CPCB"], "PASS")

        # Non-compliant 25µm single layer film (violates PWM 50µm rule)
        violating_thin_film = {
            "material_type": "Mono-LDPE",
            "thickness_micron": 25.0,
            "layer_count": 1,
            "food_contact_approved": True,
            "is_bio_alternative": False
        }
        res_fail_thin = evaluate_film_compliance(violating_thin_film, "fruit")
        self.assertFalse(res_fail_thin["is_compliant"])
        self.assertTrue(res_fail_thin["mandatory_violations_count"] > 0)
        self.assertEqual(res_fail_thin["authority_status"]["CPCB"], "FAIL")

        # Non-food contact film (violates FSSAI recycled plastic / safety ban)
        non_food_film = {
            "material_type": "Mono-LDPE",
            "thickness_micron": 60.0,
            "layer_count": 1,
            "food_contact_approved": False
        }
        res_fail_contact = evaluate_film_compliance(non_food_film, "snack")
        self.assertFalse(res_fail_contact["is_compliant"])
        self.assertEqual(res_fail_contact["authority_status"]["FSSAI"], "FAIL")

    def test_confidence_score_deterministic(self):
        """
        Verify Section 7.1 exact scoring:
        score = 100
        - 25 if food.is_regression_estimated
        - 15 if film.source_reference is None
        - 10 if climate.imd_source_id is None
        - extrapolation penalty (0-30)
        """
        # Pristine data: 100 score
        food_pristine = {"name": "Ratnagiri Mango", "is_regression_estimated": False}
        film_pristine = {"name": "Virgin PP", "source_reference": "IS 10910: 2018"}
        climate_pristine = {"profile_name": "Konkan", "imd_source_id": "IMD-RATG-43110", "avg_temp_c": 28.0, "avg_rh_pct": 75.0}

        score_100 = compute_confidence_score(food_pristine, film_pristine, climate_pristine)
        self.assertEqual(score_100, 100)

        # Estimated food: -25 points
        food_est = {"name": "Estimated Tomato", "is_regression_estimated": True}
        score_75 = compute_confidence_score(food_est, film_pristine, climate_pristine)
        self.assertEqual(score_75, 75)

        # Missing film source reference: -15 points
        film_nosource = {"name": "Generic Film", "source_reference": None}
        score_60 = compute_confidence_score(food_est, film_nosource, climate_pristine)
        self.assertEqual(score_60, 60)

        # Missing IMD station ID: -10 points
        climate_noimd = {"profile_name": "Custom Zone", "imd_source_id": None, "avg_temp_c": 28.0, "avg_rh_pct": 75.0}
        score_50 = compute_confidence_score(food_est, film_nosource, climate_noimd)
        self.assertEqual(score_50, 50)

    def test_lab_trial_checklist_population(self):
        """
        Verify Section 7.2:
        When confidence_score < 70 OR is_regression_estimated = true:
        Automatically populates concrete lab_trial_checklist items.
        """
        food_est = {"name": "Gir Kesar Mango", "category": "fruit", "is_regression_estimated": True, "optimal_storage_temp_c": 12.5}
        film_datasheet = {"name": "BOPP Pouch", "source_reference": "Supplier nominal datasheet"}
        climate = {"profile_name": "Deccan", "imd_source_id": "IMD-NASH-43025", "avg_temp_c": 35.0}

        conf_score = compute_confidence_score(food_est, film_datasheet, climate) # 75 - 0 = 75, but is_regression_estimated is True
        checklist_res = generate_lab_trial_checklist(food_est, film_datasheet, climate, conf_score)

        self.assertTrue(checklist_res["lab_trial_recommended"])
        self.assertTrue(len(checklist_res["checklist"]) >= 2)
        
        # Verify concrete check item text
        check_items = [item["check_item"] for item in checklist_res["checklist"]]
        self.assertTrue(any("Verify respiration rate" in item for item in check_items))
        self.assertTrue(any("Confirm actual OTR" in item for item in check_items))

    def test_shap_explainability_grounded_template(self):
        """
        Verify TreeExplainer SHAP attribution maps to pre-written, audited templates.
        No freeform LLM generation.
        """
        features = {
            "storage_temp_c": 38.0,
            "ambient_rh_pct": 85.0,
            "respiration_vm": 45.0,
            "thickness_micron": 30.0,
            "otr_cc_m2_day": 4000.0,
            "wvtr_g_m2_day": 25.0,
            "layer_count": 1.0,
            "is_bio_alternative": 0.0,
            "pack_area_m2": 0.045
        }
        attribs = compute_surrogate_shap_attributions(features, predicted_shelf_life=12.0)
        self.assertTrue(len(attribs) > 0)
        self.assertIn("feature", attribs[0])
        self.assertIn("shap_value", attribs[0])

        explanation = generate_grounded_shap_explanation(attribs, features)
        self.assertIsInstance(explanation, str)
        self.assertTrue(len(explanation) > 15)
        # Should contain respiration or RH template content
        self.assertTrue("respiration" in explanation.lower() or "rh" in explanation.lower() or "thickness" in explanation.lower())

    def test_nsga2_three_ranked_packs_output(self):
        """
        Verify NSGA-II optimization:
        1. Employs candidate space (material × thickness × layer_count × perforation).
        2. Filters through Stage D compliance.
        3. Returns exactly 3 ranked packs: 'Best Life', 'Best Value', 'Greenest'.
        4. Each pack includes confirming exact physics run, confidence score, and lab checklist.
        """
        food = FOODS_SEED_DATA[0] # Alphonso Mango
        climate = CLIMATE_PROFILES_SEED_DATA[0] # Ratnagiri
        geom = {"area_m2": 0.045, "net_weight_kg": 0.25, "headspace_cm3": 120.0}

        opt_result = run_nsga2_optimization(food, climate, geom)

        self.assertEqual(opt_result["status"], "success")
        self.assertIn("ranked_packs", opt_result)
        ranked = opt_result["ranked_packs"]

        # EXACTLY 3 ranked packs
        self.assertEqual(len(ranked), 3)

        roles = [p["rank_label"] for p in ranked]
        self.assertEqual(roles, ["Best Life", "Best Value", "Greenest"])

        # Check required fields on each pack
        for p in ranked:
            self.assertIn("name", p)
            self.assertIn("material_type", p)
            self.assertIn("thickness_micron", p)
            self.assertIn("layer_count", p)
            self.assertIn("cost_per_pack_inr", p)
            self.assertIn("co2e_per_pack_kg", p)
            self.assertIn("recyclability_score", p)
            self.assertIn("predicted_shelf_life_days", p)
            self.assertIn("confidence_score", p)
            self.assertIn("lab_trial_recommended", p)
            self.assertIn("lab_trial_checklist", p)
            self.assertIn("explainability", p)
            self.assertIn("summary", p["explainability"])
            self.assertIn("top_feature", p["explainability"])
            self.assertEqual(p["stage_d_compliance"]["status"], "PASS")

            # Thickness must be in 15-120 range
            self.assertTrue(15 <= p["thickness_micron"] <= 120)
            # Recyclability score must be 0-100
            self.assertTrue(0 <= p["recyclability_score"] <= 100)
            # Confidence score must be 0-100
            self.assertTrue(0 <= p["confidence_score"] <= 100)


if __name__ == "__main__":
    unittest.main()
