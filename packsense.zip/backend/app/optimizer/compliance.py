"""
PackSense Stage D: Compliance & Regulatory Verification Engine
Pure SQL/Rule-matching across FSSAI, BIS, and CPCB (EPR) statutes.
NEVER routed through any LLM.
"""

from typing import Dict, Any, List, Optional
from app.db.seeds import COMPLIANCE_RULES_SEED_DATA


def evaluate_film_compliance(
    candidate: Dict[str, Any],
    food_category: str = "snack",
    rules: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    Evaluates a candidate packaging specification against statutory packaging rules:
    - FSSAI Food Safety and Standards (Packaging) Regulations 2018
    - BIS (IS 10146 PE, IS 10910 PP, IS 12252 PET, IS 15351 Laminates)
    - CPCB Plastic Waste Management (PWM) Rules & EPR Mandates

    Returns:
    {
        "compliant": bool,
        "is_compliant": bool,
        "passed_rules": [...],
        "failed_rules": [...],
        "mandatory_violations_count": int,
        "authority_status": {"FSSAI": "PASS", "BIS": "PASS", "CPCB": "PASS"}
    }
    """
    active_rules = rules if rules is not None else COMPLIANCE_RULES_SEED_DATA
    passed_rules = []
    failed_rules = []
    
    mat_type = str(candidate.get("material_type", candidate.get("dominant_polymer", "PE"))).lower()
    thickness = float(candidate.get("thickness_micron", candidate.get("thickness_um", 40.0)))
    layer_count = int(candidate.get("layer_count", 1))
    food_contact = bool(candidate.get("food_contact_approved", True))
    is_bio = bool(candidate.get("is_bio_alternative", False))
    recyclability_score = int(candidate.get("recyclability_score", 85))

    cat = str(food_category).lower()

    for rule in active_rules:
        code = rule.get("rule_code", "UNKNOWN")
        authority = rule.get("authority", "FSSAI")
        is_mandatory = rule.get("is_mandatory", True)
        desc = rule.get("rule_description", "")
        max_val = rule.get("max_allowed_value")
        
        passed = True
        reason = ""

        # 1. Food Contact Approval Check
        if "RECYCLED-PLASTICS-BAN" in code:
            if not food_contact:
                passed = False
                reason = "Uncertified non-food contact polymer cannot be used for direct food contact under FSSAI."

        # 2. Heavy metals / Additive migration
        elif "HEAVY-METALS" in code:
            # Multi-layer with printing inks or unknown additive compliance
            if candidate.get("heavy_metals_ppm", 15.0) > (max_val or 100.0):
                passed = False
                reason = f"Heavy metals concentration exceeds threshold of {max_val} mg/kg."

        # 3. Overall Migration Limit (OML)
        elif "OML" in code:
            est_migration = float(candidate.get("overall_migration_mg_kg", 25.0))
            if est_migration > (max_val or 60.0):
                passed = False
                reason = f"Estimated migration ({est_migration} mg/kg) exceeds statutory limit ({max_val} mg/kg)."

        # 4. CPCB Plastic Waste Management Single Layer Minimum Thickness Rule
        elif "SINGLE-LAYER-THICKNESS" in code:
            # Single layer plastic film must meet minimum thickness (50/120 micron depending on application)
            if layer_count == 1 and not is_bio:
                if thickness < 50.0:
                    passed = False
                    reason = f"Single-layer virgin film thickness ({thickness}µm) is below statutory minimum (50µm) under PWM rules."

        # 5. Biodegradable / Compostable Certification (IS 17088)
        elif "BIODEGRADABLE-CERT" in code:
            if is_bio and not candidate.get("is_certified_is17088", True):
                passed = False
                reason = "Compostable film lacks certified CIPET / CPCB IS 17088 compliance stamp."

        # 6. Polymer-specific BIS Standards
        elif "POLYETHYLENE" in code and ("pe" in mat_type or "ldpe" in mat_type or "hdpe" in mat_type):
            if not food_contact:
                passed = False
                reason = "PE resin does not conform to BIS IS 10146 positive additive list."

        elif "POLYPROPYLENE" in code and ("pp" in mat_type or "bopp" in mat_type or "cpp" in mat_type):
            if not food_contact:
                passed = False
                reason = "PP resin does not conform to BIS IS 10910 positive constituent monomer list."

        # 7. Fatty Food Simulant Resistance
        elif "OML-FAT" in code and cat in ["dairy", "snack", "meat_fish"]:
            # Single polyolefin without barrier coating in direct contact with hot oils
            if layer_count == 1 and thickness < 25.0 and "snack" in cat:
                passed = False
                reason = "Single thin polyolefin web risks lipid swelling and hydrocarbon permeation."

        rule_record = {
            "rule_code": code,
            "authority": authority,
            "is_mandatory": is_mandatory,
            "description": desc,
            "status": "PASS" if passed else "FAIL",
            "reason": reason if not passed else "Verified compliant with national standards."
        }

        if passed:
            passed_rules.append(rule_record)
        else:
            failed_rules.append(rule_record)

    mandatory_failures = [r for r in failed_rules if r["is_mandatory"]]
    is_compliant = len(mandatory_failures) == 0

    # Authority Status Breakdown
    authorities = ["FSSAI", "BIS", "CPCB"]
    authority_status = {}
    for auth in authorities:
        auth_fails = [r for r in mandatory_failures if auth in r["authority"]]
        authority_status[auth] = "FAIL" if auth_fails else "PASS"

    return {
        "compliant": is_compliant,
        "is_compliant": is_compliant,
        "total_rules_checked": len(active_rules),
        "passed_count": len(passed_rules),
        "failed_count": len(failed_rules),
        "mandatory_violations_count": len(mandatory_failures),
        "authority_status": authority_status,
        "failed_rules": failed_rules,
        "passed_rules": passed_rules[:5] # Summary subset
    }
