"""
PackSense Deterministic Confidence Score & Lab Trial Verification Engine
PDF Sections 7.1 & 7.2 (Honest Scope & Trust-Building Principles)

Calculates deterministic confidence_score (0–100) from explicit data-quality flags:
1. is_regression_estimated (-25)
2. source_reference is None (-15)
3. imd_source_id is None (-10)
4. extrapolation_penalty (-0 to -30 based on distance from precomputed grid)

When confidence_score < 70 OR is_regression_estimated = true:
Populates lab_trial_checklist_items with concrete, rule-generated items.
"""

import math
from typing import Dict, Any, List, Optional


def extrapolation_penalty(
    food: Any,
    film: Any,
    climate_profile: Any
) -> int:
    """
    Computes feature-space Euclidean distance from the pre-computed training grid.
    Anchor grid bounds:
    - Temperature: 10°C to 45°C
    - Relative Humidity: 20% to 90%
    - OTR: 0.5 to 15,000 cc/(m²·day·atm)
    - WVTR: 0.2 to 120 g/(m²·day)
    - Respiration Vm: 0 to 120 ml/(kg·hr)

    Returns integer penalty in range [0, 30].
    """
    def get_val(obj, key, default):
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    temp_c = float(get_val(climate_profile, "avg_temp_c", 25.0) or 25.0)
    rh_pct = float(get_val(climate_profile, "avg_rh_pct", 65.0) or 65.0)
    otr = float(get_val(film, "otr_cc_m2_day", get_val(film, "otr_cc_m2_day_atm", 100.0)) or 100.0)
    wvtr = float(get_val(film, "wvtr_g_m2_day", 5.0) or 5.0)
    vm = float(get_val(food, "respiration_vm", 20.0) or 20.0)

    penalty = 0.0

    # Temperature out-of-grid bounds check
    if temp_c < 10.0:
        penalty += (10.0 - temp_c) * 1.5
    elif temp_c > 45.0:
        penalty += (temp_c - 45.0) * 2.0

    # RH out-of-grid bounds check
    if rh_pct < 20.0:
        penalty += (20.0 - rh_pct) * 0.4
    elif rh_pct > 90.0:
        penalty += (rh_pct - 90.0) * 0.8

    # OTR extreme extrapolation
    if otr < 0.2 or otr > 20000.0:
        penalty += 8.0

    # WVTR extreme extrapolation
    if wvtr < 0.1 or wvtr > 150.0:
        penalty += 8.0

    # Respiration extreme extrapolation
    if vm > 120.0:
        penalty += 10.0

    return int(min(30, max(0, round(penalty))))


def compute_confidence_score(
    food: Any,
    film: Any,
    climate_profile: Any
) -> int:
    """
    Deterministic confidence score (0–100) per Section 7.1.
    Auditable calculation over schema data-quality flags — NOT an LLM guess.
    """
    def get_attr(obj, attr_name):
        if isinstance(obj, dict):
            return obj.get(attr_name)
        return getattr(obj, attr_name, None)

    score = 100

    # 1. Food data was regression-filled, not a direct literature/measured value
    is_food_estimated = bool(get_attr(food, "is_regression_estimated"))
    if is_food_estimated:
        score -= 25

    # 2. Film permeability data has no cited source
    film_source = get_attr(film, "source_reference")
    if not film_source:
        score -= 15

    # 3. Climate profile isn't tied to real IMD data
    imd_id = get_attr(climate_profile, "imd_source_id")
    if not imd_id:
        score -= 10

    # 4. Distance-from-training-grid penalty
    score -= extrapolation_penalty(food, film, climate_profile)

    return max(0, min(100, score))


def generate_lab_trial_checklist(
    food: Any,
    film: Any,
    climate_profile: Any,
    confidence_score: int
) -> Dict[str, Any]:
    """
    Section 7.2: When confidence_score < 70 OR is_regression_estimated = true,
    populates concrete, checkable lab trial items.
    """
    def get_attr(obj, attr_name, default=None):
        if isinstance(obj, dict):
            return obj.get(attr_name, default)
        return getattr(obj, attr_name, default)

    food_name = get_attr(food, "name", "the commodity")
    is_food_estimated = bool(get_attr(food, "is_regression_estimated", False))
    is_film_estimated = bool(get_attr(film, "is_regression_estimated", False))
    film_source = get_attr(film, "source_reference")
    imd_id = get_attr(climate_profile, "imd_source_id")
    temp_c = get_attr(climate_profile, "avg_temp_c", get_attr(food, "optimal_storage_temp_c", 12.0))

    lab_trial_recommended = (confidence_score < 70) or is_food_estimated or is_film_estimated

    checklist: List[Dict[str, str]] = []

    if not film_source or "datasheet" in str(film_source).lower() or is_film_estimated or confidence_score < 70:
        checklist.append({
            "check_item": "Confirm actual OTR of the purchased film batch with a lab test",
            "reason": "Film OTR in our database is a supplier-datasheet nominal value, not batch-tested."
        })

    if is_food_estimated or ("tomato" in str(food_name).lower() and confidence_score < 70):
        variety_text = food_name if "variety" in str(food_name).lower() else f"{food_name} variety"
        formatted_temp = int(temp_c) if float(temp_c).is_integer() else temp_c
        checklist.append({
            "check_item": f"Verify respiration rate of this specific {variety_text} at {formatted_temp}°C",
            "reason": "Respiration data for this food was regression-estimated from a similar commodity, not measured directly."
        })

    if not imd_id:
        checklist.append({
            "check_item": "Deploy Bluetooth logger for transit temperature logging",
            "reason": "Microclimate along this transport corridor lacks dedicated IMD station telemetry."
        })

    # Category-specific validation items
    cat = str(get_attr(food, "category", "")).lower()
    if cat in ["fruit", "vegetable", "fresh_produce"]:
        checklist.append({
            "check_item": "Measure internal headspace gas composition (O2/CO2) on day 3 with portable analyzer",
            "reason": "Ensure respiration equilibrium establishes without crossing safe anaerobic threshold."
        })
    elif cat in ["snack", "bakery", "spice", "grain"]:
        checklist.append({
            "check_item": "Perform moisture sorption isotherm gravimetric verification at target RH",
            "reason": "Ensure water vapor barrier prevents crispness loss or caking under high humidity."
        })

    # If score is very low, mandate seal burst verification
    if confidence_score < 60:
        checklist.append({
            "check_item": "Execute ASTM F1140 seal burst strength testing on finished pouches",
            "reason": "Ensure heat-seal parameters withstand transport vibration and pressure changes."
        })

    return {
        "lab_trial_recommended": lab_trial_recommended,
        "confidence_score": confidence_score,
        "checklist": checklist,
        "lab_trial_checklist_items": checklist
    }
