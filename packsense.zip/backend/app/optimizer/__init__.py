"""
PackSense Stage C (Optimizer) & Stage D (Compliance) Engine Package
"""

from app.optimizer.compliance import evaluate_film_compliance
from app.optimizer.confidence import (
    compute_confidence_score,
    generate_lab_trial_checklist,
    extrapolation_penalty
)
from app.optimizer.surrogate import (
    SURROGATE_MODEL,
    compute_surrogate_shap_attributions,
    generate_grounded_shap_explanation
)
from app.optimizer.nsga import run_nsga2_optimization

__all__ = [
    "evaluate_film_compliance",
    "compute_confidence_score",
    "generate_lab_trial_checklist",
    "extrapolation_penalty",
    "SURROGATE_MODEL",
    "compute_surrogate_shap_attributions",
    "generate_grounded_shap_explanation",
    "run_nsga2_optimization"
]
