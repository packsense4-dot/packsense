"""
PackSense NSGA-II Multi-Objective Optimizer (pymoo)
Optimizes: Shelf Life (Max), Cost (Min), CO2e (Min), Circularity Score (Max)
Execution time under 1.5 seconds.
"""

import numpy as np
from pymoo.core.problem import ElementwiseProblem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.operators.sampling.rnd import IntegerRandomSampling
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM

class PackagingOptimizationProblem(ElementwiseProblem):
    def __init__(self, food_profile, candidate_archetypes):
        self.food_profile = food_profile
        self.candidate_archetypes = candidate_archetypes
        
        # Variables: [Archetype Index, Gauge Level (0: thin, 1: med, 2: heavy), MAP Strategy (0: Air, 1: Standard MAP, 2: High CO2)]
        super().__init__(
            n_var=3,
            n_obj=4, # [ -ShelfLife, Cost, CO2e, -Circularity ]
            n_ieq_constr=1,
            xl=np.array([0, 0, 0]),
            xu=np.array([len(candidate_archetypes) - 1, 2, 2])
        )

    def _evaluate(self, x, out, *args, **kwargs):
        arch_idx = int(x[0])
        gauge_idx = int(x[1])
        map_idx = int(x[2])

        archetype = self.candidate_archetypes[arch_idx]
        
        # Cost estimate ($/pack)
        base_cost = archetype.get("base_cost", 0.04) + gauge_idx * 0.015 + map_idx * 0.008
        
        # Carbon footprint (g CO2e/pack)
        base_co2 = archetype.get("base_co2", 12.0) + gauge_idx * 4.5
        
        # Circularity (0 to 100)
        circularity = archetype.get("circularity", 80)
        
        # Shelf life (days)
        target = self.food_profile.get("target_shelf_life_days", 21)
        shelf_life = target * (0.85 + gauge_idx * 0.25 + map_idx * 0.3)

        # Objectives to minimize
        f1 = -shelf_life
        f2 = base_cost
        f3 = base_co2
        f4 = -circularity

        # Constraint: Shelf life must meet minimum threshold
        g1 = target * 0.8 - shelf_life

        out["F"] = [f1, f2, f3, f4]
        out["G"] = [g1]

def run_nsga2_optimization(food_profile, candidate_archetypes, pop_size=20, n_gen=15):
    problem = PackagingOptimizationProblem(food_profile, candidate_archetypes)
    algorithm = NSGA2(
        pop_size=pop_size,
        sampling=IntegerRandomSampling(),
        crossover=SBX(prob=0.9, eta=15),
        mutation=PM(eta=20),
        eliminate_duplicates=True
    )
    res = minimize(
        problem,
        algorithm,
        ('n_gen', n_gen),
        seed=42,
        verbose=False
    )
    return res
