"""
SQLAlchemy ORM Model for Commercial Products (Part A.1)
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Numeric, Text, ARRAY
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.models import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, autoincrement=True)
    barcode = Column(String(20), unique=True, index=True, nullable=False) # EAN-13 / EAN-8 / UPC-A/E as scanned
    name = Column(String(160), nullable=False)
    brand = Column(String(120), nullable=True)
    category = Column(String(60), nullable=True) # packaged-food category
    net_weight_g = Column(Numeric(10, 2), nullable=True)
    ingredients = Column(ARRAY(Text), nullable=True) # ordered list, as printed
    other_info = Column(JSONB, nullable=True) # shelf-life printed, storage note, etc.
    image_url = Column(Text, nullable=True)
    food_id = Column(Integer, ForeignKey("foods.id"), nullable=True) # link into engineering knowledge base
    current_film_id = Column(Integer, ForeignKey("films.id"), nullable=True) # if known
    verified = Column(Boolean, default=False)
    source = Column(String(40), default="user_submitted") # 'seed', 'open_food_facts', 'user_submitted', 'admin'
    source_reference = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    food = relationship("Food", foreign_keys=[food_id])
    current_film = relationship("Film", foreign_keys=[current_film_id])
