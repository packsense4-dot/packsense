"""
PackSense Digital Twin Hourly Simulation Engine
ASTM D3985 / ASTM F1249 / Michaelis-Menten Kinetics / Labuza Isotherm

Loops hour-by-hour against Indian Climate Stress Profiles (IMD open data)
Predicts exact shelf life and identifies the primary spoilage trigger.
"""

import math
from typing import Dict, Any, List, Optional
from app.physics.respiration import (
    respiration_michaelis_menten,
    temperature_dependence_q10,
    respiration_rate_at_temperature,
    steady_state_pack_atmosphere,
    steady_state_o2,
    steady_state_co2
)
from app.physics.shelf_life import (
    shelf_life_temperature_q10,
    labuza_critical_time,
    labuza_moisture_gain_step,
    calculate_equilibrium_moisture
)


def generate_climate_hourly_curve(
    avg_temp_c: float,
    max_temp_c: float,
    avg_rh_pct: float,
    cold_chain_break_hours: float = 0.0,
    total_hours: int = 720
) -> List[Dict[str, float]]:
    """
    Synthesizes realistic diurnal temp/RH curves from IMD meteorological profile.
    T(h) = T_avg + (T_max - T_avg) * sin(2*pi*(h - 9)/24)
    RH(h) = avg_rh - 12.0 * sin(2*pi*(h - 9)/24)
    Incorporates cold chain break temperature excursions if specified.
    """
    curve = []
    temp_amplitude = max_temp_c - avg_temp_c
    
    for h in range(total_hours):
        day_hour = h % 24
        # Standard diurnal phase: starting at baseline avg_temp at h=0, peaking in afternoon (h=6)
        diurnal_factor = math.sin(2.0 * math.pi * day_hour / 24.0)
        temp = avg_temp_c + temp_amplitude * diurnal_factor
        rh = avg_rh_pct - 12.0 * diurnal_factor

        # Cold chain break excursion (e.g. transit shock between hours 10 and 10+break_hours)
        if 0 < cold_chain_break_hours:
            if 10 <= day_hour < (10 + min(cold_chain_break_hours, 10.0)):
                temp += 4.5
                rh -= 5.0

        rh = max(10.0, min(98.0, rh))
        curve.append({
            "hour": h,
            "temp_c": round(temp, 2),
            "rh_pct": round(rh, 2)
        })
    return curve


def simulate_hourly_digital_twin(
    food: Dict[str, Any],
    film: Dict[str, Any],
    climate_profile: Optional[Dict[str, Any]] = None,
    geometry: Optional[Dict[str, Any]] = None,
    max_hours: int = 720
) -> Dict[str, Any]:
    """
    Executes hour-by-hour digital twin simulation:
    - Respiration kinetics: R_O2 = Vm * [O2] / (Km + [O2])
    - Temperature scaling: Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)
    - Steady-state pack atmosphere: OTR * A * (0.21 - pO2) = R_O2 * W
    - Moisture gain (dry/snack foods): ln[(Me - Mo)/(Me - Mc)] = -(WVTR * A * t) / (Wcp * b)
    - Shelf life degradation: SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)

    Returns:
    {
        "hourly": [{"hour": 0, "o2_pct": 21.0, "co2_pct": 0.03, "moisture_pct": 12.1, "temp_c": 28.5}],
        "predicted_shelf_life_hours": 187.4,
        "spoilage_trigger": "moisture_exceeded_critical"
    }
    """
    category = food.get("category", "snack").lower()
    is_respiring = category in ["fruit", "vegetable", "fresh_produce", "horticulture"]

    # Food properties
    m0 = float(food.get("moisture_pct", 12.1 if not is_respiring else 83.5))
    mc = float(food.get("critical_moisture_content", 14.5 if not is_respiring else 75.0))
    vm = float(food.get("respiration_vm", 45.0 if is_respiring else 0.0))
    km = float(food.get("respiration_km", 2.0))
    q10 = float(food.get("q10_value", 2.2))
    ref_temp = float(food.get("optimal_storage_temp_c", 12.0 if is_respiring else 22.0))
    safe_o2_min = float(food.get("safe_o2_min", 2.0))
    safe_o2_max = float(food.get("safe_o2_max", 21.0))
    safe_co2_min = float(food.get("safe_co2_min", 0.0))
    safe_co2_max = float(food.get("safe_co2_max", 8.0))
    baseline_shelf_life_days = float(food.get("target_shelf_life_days", 21.0))
    baseline_shelf_life_hours = baseline_shelf_life_days * 24.0

    # Film properties
    otr_day = float(film.get("otr_cc_m2_day", film.get("otr_cc_m2_day_atm", 25.0 if not is_respiring else 2500.0)))
    wvtr_day = float(film.get("wvtr_g_m2_day", 1.2 if not is_respiring else 15.0))
    ctr_day = float(film.get("ctr_cc_m2_day", otr_day * 4.0))

    otr_hr = otr_day / 24.0
    wvtr_hr = wvtr_day / 24.0
    ctr_hr = ctr_day / 24.0

    # Packaging geometry
    geom = geometry or {}
    area_m2 = float(geom.get("area_m2", geom.get("pack_area_m2", 0.045)))
    net_weight_kg = float(geom.get("net_weight_kg", geom.get("weight_kg", 0.20)))
    net_weight_g = net_weight_kg * 1000.0
    headspace_cm3 = float(geom.get("headspace_cm3", 120.0))

    # Dry solids weight for Labuza
    solid_fraction = (100.0 - m0) / 100.0 if m0 < 100.0 else 0.5
    wcp_dry_g = max(10.0, net_weight_g * solid_fraction)
    raw_b = float(food.get("sorption_isotherm_b", 18.0))
    b_pct = raw_b if raw_b > 1.0 else raw_b * 100.0
    b_frac = b_pct / 100.0

    # Climate profile
    clim = climate_profile or {}
    avg_temp_c = float(clim.get("avg_temp_c", 28.5))
    max_temp_c = float(clim.get("max_temp_c", avg_temp_c + 5.0))
    avg_rh_pct = float(clim.get("avg_rh_pct", 75.0))
    break_hours = float(clim.get("cold_chain_break_hours", 0.0))

    hourly_climate = generate_climate_hourly_curve(
        avg_temp_c=avg_temp_c,
        max_temp_c=max_temp_c,
        avg_rh_pct=avg_rh_pct,
        cold_chain_break_hours=break_hours,
        total_hours=max_hours
    )

    # Initial atmosphere
    initial_map = food.get("recommended_map", {})
    current_o2 = float(initial_map.get("o2_percent", 21.0))
    current_co2 = float(initial_map.get("co2_percent", 0.03))
    current_moisture = m0

    hourly_records = []
    spoilage_trigger = "max_simulation_limit"
    predicted_hours = float(max_hours)
    cumulative_senescence_fraction = 0.0

    for h in range(max_hours):
        env = hourly_climate[h]
        t_env = env["temp_c"]
        rh_env = env["rh_pct"]

        # Record start of hour
        hourly_records.append({
            "hour": h,
            "o2_pct": round(current_o2, 2),
            "co2_pct": round(current_co2, 2),
            "moisture_pct": round(current_moisture, 2),
            "temp_c": round(t_env, 1)
        })

        if not is_respiring:
            # ========================================================
            # DRY / SNACK / BAKERY / SPICE (LABUZA MOISTURE GAIN MODEL)
            # ========================================================
            me = calculate_equilibrium_moisture(rh_env, b_pct, isotherm_c=2.0)
            
            # Advance moisture by 1 hour
            next_moisture = labuza_moisture_gain_step(
                m_current=current_moisture,
                me=me,
                wvtr_per_hour=wvtr_hr,
                area=area_m2,
                wcp=wcp_dry_g,
                b=b_frac,
                dt_hours=1.0
            )

            # Check critical moisture threshold
            if next_moisture >= mc:
                # Linear interpolation for fractional hour failure
                denom = max(1e-6, next_moisture - current_moisture)
                fractional = max(0.0, min(1.0, (mc - current_moisture) / denom))
                predicted_hours = h + fractional
                spoilage_trigger = "moisture_exceeded_critical"

                # Record the final failure step
                hourly_records.append({
                    "hour": h + 1,
                    "o2_pct": round(current_o2, 2),
                    "co2_pct": round(current_co2, 2),
                    "moisture_pct": round(next_moisture, 2),
                    "temp_c": round(t_env, 1)
                })
                break

            current_moisture = next_moisture

            # Check thermal degradation
            hr_shelf_life = shelf_life_temperature_q10(baseline_shelf_life_hours, t_env, ref_temp, q10)
            cumulative_senescence_fraction += (1.0 / max(1.0, hr_shelf_life))
            if cumulative_senescence_fraction >= 1.0:
                predicted_hours = float(h + 1)
                spoilage_trigger = "thermal_rancidity_oxidation"
                break

        else:
            # ========================================================
            # RESPIRING PRODUCE (MICHAELIS-MENTEN & EQUILIBRIUM ODE)
            # ========================================================
            # Respiration rate at current temperature and internal O2
            r_o2 = respiration_rate_at_temperature(vm, km, current_o2, t_env, ref_temp, q10)
            r_co2 = 1.0 * r_o2  # RQ ~ 1.0

            # Permeation rates across film
            o2_flux_cc = otr_hr * area_m2 * (20.9 - current_o2) / 100.0
            co2_flux_cc = ctr_hr * area_m2 * (current_co2 - 0.04) / 100.0

            o2_consumed_cc = r_o2 * net_weight_kg / 24.0
            co2_produced_cc = r_co2 * net_weight_kg / 24.0

            delta_o2_pct = ((o2_flux_cc - o2_consumed_cc) / max(10.0, headspace_cm3)) * 100.0
            delta_co2_pct = ((co2_produced_cc - co2_flux_cc) / max(10.0, headspace_cm3)) * 100.0

            # Dynamic relaxation towards steady-state
            next_o2 = max(0.0, min(21.0, current_o2 + delta_o2_pct))
            next_co2 = max(0.03, current_co2 + delta_co2_pct)

            # Evapotranspiration moisture loss
            water_loss_g = wvtr_hr * area_m2 * 0.5
            current_moisture = max(0.0, current_moisture - (water_loss_g / (net_weight_g * 0.01)))

            # Check spoilage triggers
            if next_o2 <= safe_o2_min:
                predicted_hours = float(h + 1)
                spoilage_trigger = "o2_depleted_anaerobic"
                current_o2 = next_o2
                current_co2 = next_co2
                hourly_records.append({
                    "hour": h + 1,
                    "o2_pct": round(current_o2, 2),
                    "co2_pct": round(current_co2, 2),
                    "moisture_pct": round(current_moisture, 2),
                    "temp_c": round(t_env, 1)
                })
                break

            if next_co2 >= safe_co2_max:
                predicted_hours = float(h + 1)
                spoilage_trigger = "co2_toxicity"
                current_o2 = next_o2
                current_co2 = next_co2
                hourly_records.append({
                    "hour": h + 1,
                    "o2_pct": round(current_o2, 2),
                    "co2_pct": round(current_co2, 2),
                    "moisture_pct": round(current_moisture, 2),
                    "temp_c": round(t_env, 1)
                })
                break

            if current_moisture <= mc:
                predicted_hours = float(h + 1)
                spoilage_trigger = "moisture_desiccation"
                break

            # Cumulative senescence decay
            hr_shelf_life = shelf_life_temperature_q10(baseline_shelf_life_hours, t_env, ref_temp, q10)
            cumulative_senescence_fraction += (1.0 / max(1.0, hr_shelf_life))
            if cumulative_senescence_fraction >= 1.0:
                predicted_hours = float(h + 1)
                spoilage_trigger = "senescence_complete"
                break

            current_o2 = next_o2
            current_co2 = next_co2

    return {
        "hourly": hourly_records,
        "predicted_shelf_life_hours": round(predicted_hours, 1),
        "spoilage_trigger": spoilage_trigger
    }
