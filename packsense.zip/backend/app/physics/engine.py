"""
PackSense Deterministic Physics & Preservation Engine (Python 3.11+)
ASTM D3985 / ASTM F1249 / Fickian Multilayer Permeation & Michaelis-Menten Kinetics

STAGE B: PHYSICS CORE (Digital Twin) — exact formulas:
1. Respiration (Michaelis-Menten):
   R_O2 = Vm * [O2] / (Km + [O2])
2. Temperature dependence (Arrhenius/Q10):
   Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)
3. Steady-state pack atmosphere:
   OTR_film * Area * (0.21 - pO2_in) = R_O2(T, pO2_in) * Weight
   Solved numerically via scipy.optimize.brentq. Mirrored for CO2 balance.
4. Shelf life vs temperature:
   SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)
5. Moisture gain — Labuza's equation (dry/snack foods):
   ln[(Me - Mo) / (Me - Mc)] = -(WVTR * A * t) / (Wcp * b)
6. Hourly simulation output (POST /api/v1/simulate):
   Loops hour-by-hour against Climate Stress Profile's temp/RH curve.
"""

import math
from typing import List, Dict, Any, Optional

from app.physics.respiration import (
    respiration_michaelis_menten,
    temperature_dependence_q10,
    respiration_rate_at_temperature,
    steady_state_o2,
    steady_state_co2,
    steady_state_pack_atmosphere,
    brentq_solve
)
from app.physics.shelf_life import (
    shelf_life_temperature_q10,
    labuza_critical_time,
    labuza_moisture_gain_step,
    calculate_equilibrium_moisture
)
from app.physics.simulation import (
    simulate_hourly_digital_twin,
    generate_climate_hourly_curve
)

R_GAS = 8.31446261815324  # J / (mol · K)


def arrhenius_perm(ref_perm: float, ea_kj: float, t_c: float, t_ref_c: float = 23.0) -> float:
    t_k = t_c + 273.15
    t_ref_k = t_ref_c + 273.15
    ea_j = ea_kj * 1000.0
    return ref_perm * math.exp((-ea_j / R_GAS) * ((1.0 / t_k) - (1.0 / t_ref_k)))


def calculate_laminate_barrier(
    layers: List[Dict[str, Any]],
    temp_c: float = 23.0,
    ambient_rh: float = 50.0
) -> Dict[str, float]:
    """
    Multilayer Series Resistance Model:
    Total Resistance R_tot = sum(d_i / P_i)
    Transmission Rate TR = 1 / R_tot
    """
    total_thickness_um = sum(layer.get("thickness_um", layer.get("thickness_micron", 20.0)) for layer in layers)
    r_o2_total = 0.0
    r_wvtr_total = 0.0
    total_mass_gsm = 0.0

    for l in layers:
        thick_um = l.get("thickness_um", l.get("thickness_micron", 20.0))
        thick_mil = thick_um / 25.4
        density = l.get("density_g_cm3", 0.92)
        total_mass_gsm += thick_um * density

        perm_o2_ref = l.get("perm_o2", l.get("otr_cc_m2_day", 2000.0))
        perm_h2o_ref = l.get("perm_h2o", l.get("wvtr_g_m2_day", 15.0))

        # Arrhenius temperature adjustment
        p_o2_t = arrhenius_perm(perm_o2_ref, 40.0, temp_c, 23.0)
        p_wvtr_t = arrhenius_perm(perm_h2o_ref, 35.0, temp_c, 38.0)

        r_o2_total += (thick_mil / p_o2_t) if p_o2_t > 0 else 0.0
        r_wvtr_total += (thick_mil / p_wvtr_t) if p_wvtr_t > 0 else 0.0

    otr = 1.0 / r_o2_total if r_o2_total > 0 else 99999.0
    wvtr = 1.0 / r_wvtr_total if r_wvtr_total > 0 else 99999.0

    return {
        "otr_cc_m2_day_atm": round(otr, 2),
        "wvtr_g_m2_day": round(wvtr, 2),
        "total_thickness_um": round(total_thickness_um, 1),
        "total_mass_gsm": round(total_mass_gsm, 1)
    }


def simulate_shelf_life(
    food: Dict[str, Any],
    barrier: Dict[str, float],
    temp_c: float = 21.0,
    rh_percent: float = 50.0,
    package_area_m2: float = 0.05,
    max_days: int = 180
) -> Dict[str, Any]:
    """
    Finite difference Euler integration for shelf life degradation.
    """
    target_days = food.get("target_shelf_life_days", 21)
    q10 = food.get("q10", food.get("q10_value", 2.0))
    ref_temp = food.get("storage_temp_c", food.get("optimal_storage_temp_c", 4.0))

    # Temperature accelerated senescence factor via Q10
    temp_factor = math.pow(q10, (temp_c - ref_temp) / 10.0)

    # Barrier constraint factors
    otr = barrier.get("otr_cc_m2_day_atm", barrier.get("otr_cc_m2_day", 100.0))
    wvtr = barrier.get("wvtr_g_m2_day", 5.0)

    # Moisture failure estimate
    crit_moisture_days = (25.0 / (wvtr * package_area_m2)) if (wvtr > 0 and package_area_m2 > 0) else 999.0
    
    # Respiration / anaerobic threshold or microbial days
    microbial_days = (target_days / temp_factor) * (1.1 if otr < 100 else 0.8)

    predicted_days = min(max_days, max(2.0, min(crit_moisture_days, microbial_days)))

    limiting_factor = "Moisture Desiccation / Gain" if crit_moisture_days < microbial_days else "Microbial / Oxidation Kinetics"

    return {
        "predicted_shelf_life_days": round(predicted_days, 1),
        "predicted_shelf_life_hours": round(predicted_days * 24.0, 1),
        "limiting_factor": limiting_factor,
        "temperature_acceleration_factor": round(temp_factor, 2),
        "target_shelf_life_days": target_days
    }
