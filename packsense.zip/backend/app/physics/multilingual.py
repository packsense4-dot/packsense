"""
PackSense Multilingual Localization Engine (Section 4 & 8)
Supports domain-specific terminology, explanations, checklists, diagnoses,
and reference text in English (en), Hindi (hi), Marathi (mr), and Tamil (ta).
Zero external translation API in the runtime path (Pure Deterministic Dictionaries).
"""

from typing import Dict, Any, List

SUPPORTED_LANGUAGES = {
    "en": {"name": "English", "native": "English"},
    "hi": {"name": "Hindi", "native": "हिन्दी"},
    "mr": {"name": "Marathi", "native": "मराठी"},
    "ta": {"name": "Tamil", "native": "தமிழ்"}
}

# Domain Translations Dictionary
TRANSLATIONS: Dict[str, Dict[str, str]] = {
    # Spoilage Autopsy Root Causes
    "Anaerobic Microbial Fermentation / Pouch Over-Pressurization": {
        "hi": "अवायवीय सूक्ष्मजीव किण्वन / पाउच में अत्यधिक दबाव",
        "mr": "विनॉक्सी सूक्ष्मजीव किण्वन / पाऊचमधील अतिदाब फुगवटा",
        "ta": "காற்றில்லா நுண்ணுயிர் நொதித்தல் / பாக்கெட் அதிக அழுத்தம்"
    },
    "Moisture Condensation & Fungal Germination": {
        "hi": "नमी संक्षेपण (कंडेनसेशन) एवं फफूंद का अंकुरण",
        "mr": "आर्द्रता साठवण (कंडेन्सेशन) आणि बुरशीची वाढ",
        "ta": "ஈரப்பதம் ஒடுக்கம் மற்றும் பூஞ்சை முளைத்தல்"
    },
    "Polyphenol Oxidase Enzymatic Browning / Oxidation": {
        "hi": "पॉलीफेनोल ऑक्सीडेज एंजाइम द्वारा भूरापन / ऑक्सीकरण",
        "mr": "पॉलिफेनॉल ऑक्सिडेस एन्झाईममुळे काळे/तपकिरी पडणे",
        "ta": "பாலிபினால் ஆக்சிடேஸ் நொதி பழுப்பு நிறமாதல் / ஆக்ஸிஜனேற்றம்"
    },
    "Desiccation / Transpirational Weight Loss Failure": {
        "hi": "अत्यधिक शुष्कता / वाष्पोत्सर्जन से वजन में भारी गिरावट",
        "mr": "अति कोरडेपणा / बाष्पोत्सर्जनामुळे वजनात लक्षणीय घट",
        "ta": "நீர் வறட்சி / ஆவியாதல் மூலம் எடை இழப்பு தோல்வி"
    },
    "Lipid Peroxidation & Oxidative Rancidity": {
        "hi": "वसा का ऑक्सीकरण एवं दुर्गंधयुक्त खट्टापन (रैंसिडिटी)",
        "mr": "स्निग्ध पदार्थांचे ऑक्सिडीकरण आणि खवट वास",
        "ta": "கொழுப்பு பெராக்ஸைடேஷன் மற்றும் காரத்தன்மை சிதைவு"
    },

    # Corrective Film / Action Keywords
    "Micro-perforated breathable film": {
        "hi": "सूक्ष्म-छिद्रित सांस लेने योग्य फिल्म",
        "mr": "सूक्ष्म-छिद्रयुक्त हवा खेळती ठेवणारी फिल्म",
        "ta": "நுண் துளையிடப்பட்ட சுவாசிக்கக்கூடிய பிலிம்"
    },
    "Laser Micro-Perforated BOPP 30µm (60µm hole pitch 20mm)": {
        "hi": "लेजर सूक्ष्म-छिद्रित बीओपीपी 30 माइक्रोन (60µm छिद्र, 20mm दूरी)",
        "mr": "लेसर सूक्ष्म-छिद्रित बीओपीपी ३० मायक्रॉन (६० मायक्रॉन छिद्र, २० मिमी अंतर)",
        "ta": "லேசர் நுண் துளையிடப்பட்ட BOPP 30µm (60µm துளை 20mm இடைவெளி)"
    },
    "Anti-Fog Coated OPP 25µm // CPP 30µm with inner sealant masterbatch": {
        "hi": "एंटी-फॉग कोटेड ओप्प 25µm // सीप्प 30µm सीलेंट परत के साथ",
        "mr": "धुकं-रोधक (अँटी-फॉग) लेपित ओप्प २५ मायक्रॉन // सीप्प ३० मायक्रॉन",
        "ta": "பனி எதிர்ப்பு பூசப்பட்ட OPP 25µm // CPP 30µm சீலண்ட் அடுக்கு"
    },

    # Lab Trial Checklist Standards & Tests
    "Oxygen Transmission Rate (OTR)": {
        "hi": "ऑक्सीजन संचरण दर (OTR)",
        "mr": "ऑक्सिजन वहन दर (OTR)",
        "ta": "ஆக்சிஜன் பரிமாற்ற விகிதம் (OTR)"
    },
    "Water Vapor Transmission Rate (WVTR)": {
        "hi": "जलवाष्प संचरण दर (WVTR)",
        "mr": "पाण्याची वाफ वहन दर (WVTR)",
        "ta": "நீராவி பரிமாற்ற விகிதம் (WVTR)"
    },
    "Overall Migration Limit (OML)": {
        "hi": "समग्र प्रवासन सीमा (OML - रासायनिक सुरक्षा)",
        "mr": "एकूण स्थलांतर मर्यादा (OML - अन्न सुरक्षितता)",
        "ta": "ஒட்டுமொத்த இடம்பெயர்வு வரம்பு (OML)"
    },
    "Bubble Emission Seal Integrity": {
        "hi": "बबल उत्सर्जन सील अखंडता परीक्षण (लीकेज टेस्ट)",
        "mr": "बबल उत्सर्जन सील अखंडता चाचणी (गळती चाचणी)",
        "ta": "குமிழி உமிழ்வு சீல் ஒருமைப்பாடு சோதனை"
    },
    "Coulometric Detector at 23°C, 0% RH": {
        "hi": "कौलोमेट्रिक संसूचक 23°C, 0% सापेक्ष आर्द्रता पर",
        "mr": "कौलोमेट्रिक डिटेक्टर २३° से. आणि ०% आर्द्रतेवर",
        "ta": "கூலோமெட்ரிக் டிடெக்டர் 23°C, 0% RH இல்"
    },
    "Infrared Sensor at 37.8°C, 90% RH": {
        "hi": "अवरक्त (IR) सेंसर 37.8°C, 90% सापेक्ष आर्द्रता पर",
        "mr": "इन्फ्रारेड सेन्सर ३७.८° से. आणि ९०% आर्द्रतेवर",
        "ta": "அகச்சிவப்பு சென்சார் 37.8°C, 90% RH இல்"
    },
    "< 60 mg/kg food simulant A, B, C, D1": {
        "hi": "< 60 मि.ग्रा./कि.ग्रा. खाद्य सिमुलेटर A, B, C, D1 में",
        "mr": "< ६० मि.ग्रॅ./कि.ग्रॅ. अन्न सिम्युलेटर A, B, C, D1 मध्ये",
        "ta": "< 60 மிகி/கிலோ உணவு சிமுலண்ட் A, B, C, D1"
    },
    "Vacuum chamber leak detection at -20 kPa": {
        "hi": "निर्वात कक्ष (वैक्यूम चैंबर) रिसाव परीक्षण -20 kPa पर",
        "mr": "व्हॅक्यूम चेंबर गळती शोध चाचणी -२० kPa वर",
        "ta": "வெற்றிட அறை கசிவு கண்டறிதல் -20 kPa இல்"
    },
    "NABL / ISO 17025 Accredited Laboratory": {
        "hi": "एनएबीएल / आईएसओ 17025 मान्यता प्राप्त राष्ट्रीय प्रयोगशाला",
        "mr": "एनएबीएल / आयएसओ १७०२५ मान्यताप्राप्त प्रयोगशाळा",
        "ta": "NABL / ISO 17025 அங்கீகரிக்கப்பட்ட ஆய்வகம்"
    },

    # Compliance & Reference Texts
    "FSSAI Packaging Regulations 2018": {
        "hi": "एफएसएसएआई पैकेजिंग विनियम २०१८ (खाद्य संपर्क सुरक्षा)",
        "mr": "एफएसएसएआय पॅकेजिंग नियम २०१८ (अन्न संपर्क सुरक्षा)",
        "ta": "FSSAI பேக்கேஜிங் விதிமுறைகள் 2018 (உணவு தொடர்பு பாதுகாப்பு)"
    },
    "Plastic Waste Management Rules 2022 (PWM)": {
        "hi": "प्लास्टिक अपशिष्ट प्रबंधन नियम २०२२ (पुनर्चक्रण एवं ईपीआर)",
        "mr": "प्लॅस्टिक कचरा व्यवस्थापन नियम २०२२ (पुनर्वापर आणि ईपीआर)",
        "ta": "பிளாஸ்டிக் கழிவு மேலாண்மை விதிகள் 2022"
    },
    "CEFLEX Class A Recyclable Mono-Material": {
        "hi": "सेफ्लेक्स क्लास ए पुनर्चक्रण योग्य एकल-सामग्री (मोनो-पॉलीमर)",
        "mr": "सेफ्लेक्स क्लास ए पुनर्वापरयोग्य सिंगल-मटेरियल (मोनो-पीई/पीपी)",
        "ta": "CEFLEX வகுப்பு A மறுசுழற்சி செய்யக்கூடிய ஒற்றை பொருள்"
    },

    # Common Phrases
    "Shelf Life": {"hi": "शेल्फ लाइफ (भंडारण अवधि)", "mr": "शेल्फ लाइफ (साठवणूक कालावधी)", "ta": "சேமிப்பு காலம் (ஷெல்ஃப் லைஃப்)"},
    "Days": {"hi": "दिन", "mr": "दिवस", "ta": "நாட்கள்"},
    "Hours": {"hi": "घंटे", "mr": "तास", "ta": "மணிநேரம்"},
    "Storage Temperature": {"hi": "भंडारण तापमान", "mr": "साठवणूक तापमान", "ta": "சேமிப்பு வெப்பநிலை"},
    "Relative Humidity": {"hi": "सापेक्ष आर्द्रता", "mr": "सापेक्ष आर्द्रता (RH)", "ta": "ஒப்பீட்டு ஈரப்பதம்"}
}

def translate_phrase(text: str, target_lang: str) -> str:
    """Translates a recognized phrase to target language, fallback to English."""
    if not text or target_lang == "en" or target_lang not in SUPPORTED_LANGUAGES:
        return text
    match = TRANSLATIONS.get(text.strip())
    if match and target_lang in match:
        return match[target_lang]
    # Check partial substring matches
    for eng_key, lang_map in TRANSLATIONS.items():
        if eng_key.lower() in text.lower() and target_lang in lang_map:
            return lang_map[target_lang]
    return text

def localize_spoilage_diagnosis(diagnosis: Dict[str, Any], lang: str) -> Dict[str, Any]:
    """Localizes spoilage diagnosis response while preserving raw keys."""
    if lang == "en" or lang not in SUPPORTED_LANGUAGES:
        diagnosis["language"] = "en"
        return diagnosis

    loc = dict(diagnosis)
    loc["language"] = lang
    root_cause = loc.get("primary_root_cause") or loc.get("root_cause") or ""
    loc["root_cause_localized"] = translate_phrase(root_cause, lang)

    # Localize mechanism list
    if "mechanisms" in loc and isinstance(loc["mechanisms"], list):
        loc["mechanisms_localized"] = [translate_phrase(m, lang) for m in loc["mechanisms"]]

    # Localize corrective actions
    if "corrective_actions" in loc and isinstance(loc["corrective_actions"], dict):
        actions_loc = {}
        for k, v in loc["corrective_actions"].items():
            actions_loc[k] = translate_phrase(str(v), lang)
        loc["corrective_actions_localized"] = actions_loc

    return loc

def localize_lab_trial_checklist(checklist: Dict[str, Any], lang: str) -> Dict[str, Any]:
    """Localizes lab trial checklist with translated parameters and targets."""
    if lang == "en" or lang not in SUPPORTED_LANGUAGES:
        checklist["language"] = "en"
        return checklist

    loc = dict(checklist)
    loc["language"] = lang
    loc["accreditation_requirement_localized"] = translate_phrase(
        loc.get("accreditation_requirement", ""), lang
    )

    if "test_suite" in loc and isinstance(loc["test_suite"], list):
        localized_tests = []
        for test in loc["test_suite"]:
            t_copy = dict(test)
            t_copy["parameter_localized"] = translate_phrase(test.get("parameter", ""), lang)
            t_copy["target_localized"] = translate_phrase(test.get("target", ""), lang)
            localized_tests.append(t_copy)
        loc["test_suite_localized"] = localized_tests

    return loc

def get_multilingual_reference_text(category: str, lang: str = "en") -> Dict[str, Any]:
    """Returns official packaging engineering reference guidelines in chosen language."""
    references = {
        "fssai_standards": {
            "en": {
                "title": "FSSAI Food Contact Packaging Standards 2018",
                "rules": [
                    "All plastic films must conform to IS 9845 for overall migration limits (< 60 mg/kg).",
                    "Recycled plastics are prohibited from direct food contact unless specially authorized by FSSAI.",
                    "Printing inks must strictly avoid lead, toluene, and harmful solvent residues."
                ]
            },
            "hi": {
                "title": "एफएसएसएआई खाद्य संपर्क पैकेजिंग मानक २०१८",
                "rules": [
                    "सभी प्लास्टिक फिल्मों को समग्र प्रवासन सीमा (< 60 मिलीग्राम/किलोग्राम) हेतु IS 9845 का पालन करना अनिवार्य है।",
                    "एफएसएसएआई की विशेष अनुमति के बिना पुनर्चक्रित प्लास्टिक का सीधे भोजन के संपर्क में उपयोग वर्जित है।",
                    "प्रिंटिंग स्याही में लेड, टोल्यूनि और हानिकारक विलायक अवशेषों का उपयोग पूरी तरह प्रतिबंधित है।"
                ]
            },
            "mr": {
                "title": "एफएसएसएआय अन्न संपर्क पॅकेजिंग मानके २०१८",
                "rules": [
                    "सर्व प्लॅस्टिक फिल्म्ससाठी IS 9845 अंतर्गत एकूण स्थलांतर मर्यादा (< ६० मिग्रॅ/किग्रॅ) पाळणे बंधनकारक आहे.",
                    "एफएसएसएआयच्या विशेष मंजुरीशिवाय रिसायकल केलेल्या प्लास्टिकचा अन्नाशी थेट संपर्क वापरण्यास बंदी आहे.",
                    "प्रिंटिंग शाईमध्ये शिसे, टोल्यूएन आणि विषारी रासायनिक अवशेष नसावेत."
                ]
            },
            "ta": {
                "title": "FSSAI உணவு தொடர்பு பேக்கேஜிங் தரநிலைகள் 2018",
                "rules": [
                    "அனைத்து பிளாஸ்டிக் படலங்களும் ஒட்டுமொத்த இடம்பெயர்வு வரம்புகளுக்கு (< 60 மி.கி/கி.கி) IS 9845 ஐ இணங்க வேண்டும்.",
                    "FSSAI அனுமதியின்றி மறுசுழற்சி செய்யப்பட்ட பிளாஸ்டிக்கை நேரடி உணவு தொடர்புக்கு பயன்படுத்துவது தடைசெய்யப்பட்டுள்ளது.",
                    "அச்சிடும் மைகளில் ஈயம், டோலுயீன் மற்றும் நச்சு கரைப்பான் எச்சங்கள் தவிர்க்கப்பட வேண்டும்."
                ]
            }
        },
        "pwm_recycling": {
            "en": {
                "title": "Plastic Waste Management Rules 2022 (PWM) & CEFLEX",
                "rules": [
                    "Mono-material structures (Mono-PE or Mono-PP >90% polyolefin content) achieve CEFLEX Class A circularity.",
                    "Multi-material laminates with aluminum foil face higher Extended Producer Responsibility (EPR) recycling fees.",
                    "Compostable biopolymers must carry certified CPCB certificate under IS/ISO 17088."
                ]
            },
            "hi": {
                "title": "प्लास्टिक अपशिष्ट प्रबंधन नियम २०२२ एवं सेफ्लेक्स परिपत्रता",
                "rules": [
                    "एकल-सामग्री संरचनाएं (मोनो-पीई या मोनो-पीपी >९०% पॉलीओलेफिन) सेफ्लेक्स क्लास ए पुनर्चक्रण प्राप्त करती हैं।",
                    "एल्युमिनियम फॉयल वाले बहु-सामग्री लेमिनेट्स पर अधिक ईपीआर पुनर्चक्रण शुल्क लागू होता है।",
                    "कम्पोस्टेबल बायो-पॉलिमर के पास IS/ISO 17088 के तहत सीपीसीबी प्रमाण पत्र होना अनिवार्य है।"
                ]
            },
            "mr": {
                "title": "प्लॅस्टिक कचरा व्यवस्थापन नियम २०२२ आणि सेफ्लेक्स परिपत्रता",
                "rules": [
                    "मोनो-मटेरियल संरचना (मोनो-पीई किंवा मोनो-पीपी >९०% प्रमाण) सेफ्लेक्स वर्ग अ अंतर्गत १००% पुनर्वापरयोग्य ठरतात.",
                    "अ‍ॅल्युमिनियम फॉइल असलेल्या मल्टि-मटेरियल लॅमिनेट्सवर जास्त ईपीआर (विस्तारित उत्पादक जबाबदारी) कर लागू होतो.",
                    "कंपोस्टेबल बायो-पॉलिमर्ससाठी IS/ISO 17088 अंतर्गत सीपीसीबी प्रमाणपत्र असणे आवश्यक आहे."
                ]
            },
            "ta": {
                "title": "பிளாஸ்டிக் கழிவு மேலாண்மை விதிகள் 2022 மற்றும் மறுசுழற்சி",
                "rules": [
                    "ஒற்றை பொருள் கட்டமைப்புகள் (>90% பாலியோலிஃபின்) CEFLEX வகுப்பு A மறுசுழற்சியை அடைகின்றன.",
                    "அலுமினியம் படலம் கொண்ட பல அடுக்கு லேமினேட்டுகள் அதிக EPR மறுசுழற்சி கட்டணத்தை எதிர்கொள்கின்றன.",
                    "மக்கும் பயோ-பாலிமர்கள் IS/ISO 17088 இன் கீழ் CPCB சான்றிதழைப் பெற்றிருக்க வேண்டும்."
                ]
            }
        }
    }

    cat_data = references.get(category, references["fssai_standards"])
    selected_lang = lang if lang in cat_data else "en"
    return {
        "category": category,
        "language": selected_lang,
        "content": cat_data[selected_lang],
        "available_languages": list(SUPPORTED_LANGUAGES.keys())
    }
