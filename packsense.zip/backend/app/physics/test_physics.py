"""
PackSense Unit Test Suite for Physics Core (Digital Twin)
Verifies exact implementation of:
1. Respiration (Michaelis-Menten) kinetics
2. Temperature dependence (Arrhenius / Q10)
3. Steady-state pack atmosphere numerical root-solving (scipy / Brent)
4. Shelf life vs temperature scaling
5. Moisture gain (Labuza's sorption isotherm equation)
6. Hourly simulation output structure and physical accuracy
"""

import math
import unittest

from app.physics.respiration import (
    respiration_michaelis_menten,
    temperature_dependence_q10,
    respiration_rate_at_temperature,
    steady_state_o2,
    steady_state_co2,
    steady_state_pack_atmosphere,
    pure_python_brentq,
    brentq_solve
)
from app.physics.shelf_life import (
    shelf_life_temperature_q10,
    labuza_critical_time,
    labuza_moisture_gain_step,
    calculate_equilibrium_moisture
)
from app.physics.simulation import (
    simulate_hourly_digital_twin,
    generate_climate_hourly_curve
)


class TestPhysicsCoreDigitalTwin(unittest.TestCase):

    def test_respiration_michaelis_menten(self):
        """
        Formula: R_O2 = Vm * [O2] / (Km + [O2])
        """
        vm = 48.0
        km = 2.0

        # At [O2] = 0, R_O2 must be 0
        self.assertEqual(respiration_michaelis_menten(vm, 0.0, km), 0.0)

        # At [O2] = Km = 2.0, R_O2 must be Vm / 2 = 24.0
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 2.0, km), 24.0, places=5)

        # At [O2] = 6.0, R_O2 = 48 * 6 / 8 = 36.0
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 6.0, km), 36.0, places=5)

        # Asymptotic behavior at high O2
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 1000.0, km), 47.904, places=2)

    def test_temperature_dependence_q10(self):
        """
        Formula: Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)
        """
        rate_t1 = 10.0
        t1 = 15.0
        q10 = 2.0

        # At T2 = T1, Rate(T2) = Rate(T1)
        self.assertAlmostEqual(temperature_dependence_q10(rate_t1, 15.0, t1, q10), 10.0, places=5)

        # At T2 = 25.0 (+10 deg), Rate = 10.0 * 2.0^1 = 20.0
        self.assertAlmostEqual(temperature_dependence_q10(rate_t1, 25.0, t1, q10), 20.0, places=5)

        # At T2 = 35.0 (+20 deg), Rate = 10.0 * 2.0^2 = 40.0
        self.assertAlmostEqual(temperature_dependence_q10(rate_t1, 35.0, t1, q10), 40.0, places=5)

        # At T2 = 5.0 (-10 deg), Rate = 10.0 * 2.0^(-1) = 5.0
        self.assertAlmostEqual(temperature_dependence_q10(rate_t1, 5.0, t1, q10), 5.0, places=5)

    def test_steady_state_pack_atmosphere_brentq(self):
        """
        Formula:
        OTR_film * Area * (0.21 - pO2_in) = R_O2(T, pO2_in) * Weight
        Verify numerical solution via brentq satisfies the equilibrium residual.
        """
        otr_film = 1500.0  # cc / (m² · day · atm)
        area = 0.05        # m²
        weight = 0.50      # kg
        vm = 40.0          # cc / (kg · day)
        km = 0.02          # fraction
        temp_c = 20.0
        ambient_o2 = 0.21

        po2_eq = steady_state_o2(
            otr_film=otr_film,
            area=area,
            weight=weight,
            vm=vm,
            km=km,
            temp_c=temp_c,
            ref_temp_c=20.0,
            q10=2.0,
            ambient_o2=ambient_o2
        )

        # Must lie inside [0, ambient_o2]
        self.assertTrue(0.0 <= po2_eq <= ambient_o2)

        # Residual check: OTR * Area * (0.21 - po2) - R_O2 * Weight == 0
        lhs = otr_film * area * (ambient_o2 - po2_eq)
        r_o2 = (vm * po2_eq) / (km + po2_eq)
        rhs = r_o2 * weight
        self.assertAlmostEqual(lhs, rhs, delta=1e-5)

        # Mirrored CO2 balance check
        ctr_film = otr_film * 4.0
        ambient_co2 = 0.0003
        r_co2 = 1.0 * r_o2
        pco2_eq = steady_state_co2(
            ctr_film=ctr_film,
            area=area,
            weight=weight,
            r_co2=r_co2,
            ambient_co2=ambient_co2,
            max_co2_search=1.0
        )
        lhs_co2 = ctr_film * area * (pco2_eq - ambient_co2)
        rhs_co2 = r_co2 * weight
        self.assertAlmostEqual(lhs_co2, rhs_co2, delta=1e-5)

    def test_shelf_life_temperature_q10(self):
        """
        Formula: SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)
        """
        sl_t1 = 480.0  # hours (20 days)
        t1 = 10.0
        q10 = 2.0

        # Same temperature
        self.assertAlmostEqual(shelf_life_temperature_q10(sl_t1, 10.0, t1, q10), 480.0, places=5)

        # 10 degrees warmer -> shelf life halved
        self.assertAlmostEqual(shelf_life_temperature_q10(sl_t1, 20.0, t1, q10), 240.0, places=5)

        # 20 degrees warmer -> shelf life quartered
        self.assertAlmostEqual(shelf_life_temperature_q10(sl_t1, 30.0, t1, q10), 120.0, places=5)

        # 10 degrees colder -> shelf life doubled
        self.assertAlmostEqual(shelf_life_temperature_q10(sl_t1, 0.0, t1, q10), 960.0, places=5)

    def test_labuza_moisture_gain(self):
        """
        Formula: ln[(Me - Mo) / (Me - Mc)] = -(WVTR * A * t) / (Wcp * b)
        => t = (Wcp * b / (WVTR * A)) * ln[(Me - Mo) / (Me - Mc)]
        """
        m0 = 3.0    # % initial moisture in crisp snack
        mc = 6.5    # % critical moisture where crispness is lost
        me = 15.0   # % equilibrium moisture at high ambient RH
        wvtr = 0.5  # g / (m² · day)
        area = 0.04 # m²
        wcp = 100.0 # g dry snack weight
        b = 0.20    # isotherm slope (g water / g dry solids)

        expected_t = (wcp * b / (wvtr * area)) * math.log((me - m0) / (me - mc))
        actual_t = labuza_critical_time(m0, mc, me, wvtr, area, wcp, b)
        self.assertAlmostEqual(actual_t, expected_t, places=4)
        self.assertTrue(actual_t > 0.0)

        # Verify hourly incremental step converges to the same curve
        wvtr_hr = wvtr / 24.0
        m_sim = m0
        dt_hr = 1.0
        for _ in range(int(actual_t * 24)):
            m_sim = labuza_moisture_gain_step(m_sim, me, wvtr_hr, area, wcp, b, dt_hr)
        
        # After critical time, moisture should be very close to mc
        self.assertAlmostEqual(m_sim, mc, delta=0.1)

    def test_hourly_simulation_output_structure(self):
        """
        POST /api/v1/simulate digital twin verification:
        Expected return format matching specification:
        {
          "hourly": [{"hour": 0, "o2_pct": 21.0, "co2_pct": 0.03, "moisture_pct": 12.1, "temp_c": 28.5}],
          "predicted_shelf_life_hours": 187.4,
          "spoilage_trigger": "moisture_exceeded_critical"
        }
        """
        snack_food = {
            "name": "Roasted Crispy Namkeen / Sev",
            "category": "snack",
            "moisture_pct": 12.1,
            "critical_moisture_content": 14.5,
            "optimal_storage_temp_c": 25.0,
            "q10_value": 2.0,
            "target_shelf_life_days": 60.0,
            "sorption_isotherm_b": 0.18
        }
        film = {
            "name": "Perforated LDPE Polybag",
            "otr_cc_m2_day": 2500.0,
            "wvtr_g_m2_day": 34.5
        }
        climate = {
            "profile_name": "Konkan Coastal Humid (Ratnagiri Station)",
            "avg_temp_c": 28.5,
            "max_temp_c": 32.5,
            "avg_rh_pct": 82.0,
            "cold_chain_break_hours": 0.0
        }
        geom = {
            "area_m2": 0.045,
            "net_weight_kg": 0.15,
            "headspace_cm3": 120.0
        }

        result = simulate_hourly_digital_twin(
            food=snack_food,
            film=film,
            climate_profile=climate,
            geometry=geom,
            max_hours=720
        )

        # 1. Structure validations
        self.assertIn("hourly", result)
        self.assertIn("predicted_shelf_life_hours", result)
        self.assertIn("spoilage_trigger", result)

        self.assertIsInstance(result["hourly"], list)
        self.assertIsInstance(result["predicted_shelf_life_hours"], (int, float))
        self.assertIsInstance(result["spoilage_trigger"], str)

        # 2. First element validations matching exact prompt spec
        h0 = result["hourly"][0]
        self.assertEqual(h0["hour"], 0)
        self.assertEqual(h0["o2_pct"], 21.0)
        self.assertEqual(h0["co2_pct"], 0.03)
        self.assertEqual(h0["moisture_pct"], 12.1)
        self.assertEqual(h0["temp_c"], 28.5)

        # 3. Moisture trigger validation for dry snack in humid coastal zone
        self.assertEqual(result["spoilage_trigger"], "moisture_exceeded_critical")
        self.assertTrue(result["predicted_shelf_life_hours"] > 0)

    def test_hourly_simulation_respiring_produce(self):
        """
        Verify respiring produce simulation (e.g. Alphonso Mango).
        """
        mango = {
            "name": "Alphonso Mango",
            "category": "fruit",
            "moisture_pct": 83.5,
            "critical_moisture_content": 75.0,
            "respiration_vm": 48.5,
            "respiration_km": 1.8,
            "q10_value": 2.3,
            "optimal_storage_temp_c": 12.0,
            "safe_o2_min": 3.0,
            "safe_o2_max": 6.0,
            "safe_co2_min": 3.0,
            "safe_co2_max": 7.0,
            "target_shelf_life_days": 21.0
        }
        # Low permeability hermetic film causes oxygen depletion
        barrier_film = {
            "otr_cc_m2_day": 20.0,
            "wvtr_g_m2_day": 1.0
        }
        climate = {
            "avg_temp_c": 28.0,
            "max_temp_c": 32.0,
            "avg_rh_pct": 75.0
        }
        geom = {
            "area_m2": 0.05,
            "net_weight_kg": 0.50,
            "headspace_cm3": 100.0
        }

        result = simulate_hourly_digital_twin(
            food=mango,
            film=barrier_film,
            climate_profile=climate,
            geometry=geom,
            max_hours=240
        )

        self.assertIn("hourly", result)
        self.assertIn("predicted_shelf_life_hours", result)
        self.assertIn("spoilage_trigger", result)
        # Low barrier film without micro-perforations suffocates fruit
        self.assertIn(result["spoilage_trigger"], ["o2_depleted_anaerobic", "co2_toxicity", "senescence_complete"])


if __name__ == "__main__":
    unittest.main()
