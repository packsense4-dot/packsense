"""
PackSense Pack Label Scan & OCR Film Matching Engine (Section 4 & 5)
Extracts polymer layers, thicknesses, and regulatory symbols from raw label OCR text
and matches them deterministically against known films in the database.
Zero external AI / LLM runtime dependency.
"""

import re
from typing import Dict, Any, List, Optional
from app.db.seeds import FILMS_SEED_DATA

# Known Polymer Synonyms & Resin Identifiers
POLYMER_PATTERNS = {
    "bopp": [r"\bbopp\b", r"\bbiaxially\s+oriented\s+polypropylene\b", r"\bopp\b"],
    "met_bopp": [r"\bmet-?bopp\b", r"\bmetall?ized\s+bopp\b", r"\bmet-?pp\b", r"\balumini[sz]ed\s+bopp\b"],
    "bopet": [r"\bbopet\b", r"\bpet\s+film\b", r"\bpolyester\s+film\b", r"\bbiaxially\s+oriented\s+pet\b"],
    "cpp": [r"\bcpp\b", r"\bcast\s+polypropylene\b"],
    "ldpe": [r"\bldpe\b", r"\blow\s+density\s+polyethylene\b", r"\bpe-?ld\b", r"\b#4\s*ldpe\b"],
    "lldpe": [r"\blldpe\b", r"\blinear\s+low\s+density\b"],
    "hdpe": [r"\bhdpe\b", r"\bhigh\s+density\s+polyethylene\b", r"\bpe-?hd\b", r"\b#2\s*hdpe\b"],
    "evoh": [r"\bevoh\b", r"\bethylene\s+vinyl\s+alcohol\b"],
    "alu_foil": [r"\balu\b", r"\baluminum\s+foil\b", r"\baluminium\s+foil\b", r"\bfoil\s+barrier\b"],
    "pla": [r"\bpla\b", r"\bpolylactic\s+acid\b", r"\bcorn\s+starch\b"],
    "pbat": [r"\bpbat\b", r"\bpolybutyrate\b", r"\becoflex\b"],
    "bio_pbs": [r"\bbio-?pbs\b", r"\bpolybutylene\s+succinate\b"],
    "paper": [r"\bpaper\b", r"\bkraft\b", r"\bcellulose\b"]
}

# Resin Identification Codes (RIC)
RIC_CODES = {
    1: "PET (Polyethylene Terephthalate)",
    2: "HDPE (High Density Polyethylene)",
    3: "PVC (Polyvinyl Chloride)",
    4: "LDPE (Low Density Polyethylene)",
    5: "PP (Polypropylene)",
    6: "PS (Polystyrene)",
    7: "OTHER (Multilayer / Mixed Laminates)"
}

def extract_label_entities(ocr_text: str) -> Dict[str, Any]:
    """Extracts detected polymers, thicknesses, resin code, and regulatory terms from OCR text."""
    clean_text = ocr_text.lower()
    
    # 1. Detect polymers
    detected_polymers: List[str] = []
    for polymer_key, patterns in POLYMER_PATTERNS.items():
        if any(re.search(pat, clean_text) for pat in patterns):
            detected_polymers.append(polymer_key)

    # 2. Detect thickness (e.g. 20 micron, 50 um, 12 mic, 70 micron, 100 gauge)
    thickness_um: Optional[float] = None
    thickness_matches = re.findall(r"(\d+(?:\.\d+)?)\s*(?:micron|microns|mic|µm|um)", clean_text)
    if thickness_matches:
        try:
            thickness_um = float(thickness_matches[0])
        except ValueError:
            thickness_um = None
    else:
        # Check gauge (100 gauge = 25.4 um)
        gauge_match = re.findall(r"(\d+(?:\.\d+)?)\s*gauge", clean_text)
        if gauge_match:
            try:
                thickness_um = round(float(gauge_match[0]) * 0.254, 1)
            except ValueError:
                thickness_um = None

    # 3. Detect Resin Identification Code (RIC)
    ric_number: Optional[int] = None
    ric_match = re.search(r"(?:ric|recycle\s+code|plastic\s+code)\s*[:#]?\s*([1-7])", clean_text)
    if ric_match:
        ric_number = int(ric_match.group(1))
    elif "#4" in clean_text or "ldpe" in detected_polymers:
        ric_number = 4
    elif "#5" in clean_text or ("bopp" in detected_polymers and "met_bopp" not in detected_polymers and len(detected_polymers) == 1):
        ric_number = 5
    elif "#2" in clean_text or "hdpe" in detected_polymers:
        ric_number = 2
    elif "#1" in clean_text or "bopet" in detected_polymers:
        ric_number = 1
    elif len(detected_polymers) > 1:
        ric_number = 7  # Multi-material laminate

    # 4. Detect regulatory and quality phrases
    fssai_found = bool(re.search(r"\bfssai\b|lic(?:\.|\s+no)", clean_text))
    recyclable_claim = bool(re.search(r"recyclable|100%\s+recyclable|ceflex|mono-?material", clean_text))
    biodegradable_claim = bool(re.search(r"biodegradable|compostable|is\s*17088", clean_text))
    metallized_claim = "met_bopp" in detected_polymers or bool(re.search(r"metall?ized|alu-?foil|foil", clean_text))

    return {
        "detected_polymers": detected_polymers,
        "thickness_um": thickness_um,
        "ric_number": ric_number,
        "ric_name": RIC_CODES.get(ric_number, "Unknown"),
        "fssai_compliant_declaration": fssai_found,
        "recyclable_claim": recyclable_claim,
        "biodegradable_claim": biodegradable_claim,
        "metallized_claim": metallized_claim,
        "raw_text_length": len(ocr_text)
    }

def match_film_from_ocr(ocr_text: str, lang: str = "en") -> Dict[str, Any]:
    """
    Main algorithmic matcher:
    Calculates multi-attribute match scores between extracted OCR entities and FILMS_SEED_DATA.
    """
    extracted = extract_label_entities(ocr_text)
    detected_pols = extracted["detected_polymers"]
    target_thickness = extracted["thickness_um"]

    best_match: Optional[Dict[str, Any]] = None
    highest_score = 0.0

    for film in FILMS_SEED_DATA:
        score = 0.0
        film_name_lower = film["name"].lower()
        film_mat_lower = film.get("material_type", "").lower()
        film_thickness = float(film.get("thickness_micron", 50.0))

        # 1. Polymer keyword matching (up to 55 points)
        matched_keywords = 0
        for pol in detected_pols:
            if pol.replace("_", "") in film_name_lower.replace("-", "").replace("_", "") or \
               pol.replace("_", "") in film_mat_lower.replace("-", "").replace("_", ""):
                matched_keywords += 1

        if detected_pols:
            polymer_ratio = matched_keywords / max(1, len(detected_pols))
            score += polymer_ratio * 55.0
        else:
            # Fallback if no specific polymer acronym found, try common words
            if "pe" in film_mat_lower and ("polyethylene" in ocr_text.lower() or "pouch" in ocr_text.lower()):
                score += 25.0
            elif "pp" in film_mat_lower and ("crisp" in ocr_text.lower() or "chip" in ocr_text.lower()):
                score += 25.0

        # 2. Thickness proximity (up to 25 points)
        if target_thickness is not None:
            thick_diff = abs(film_thickness - target_thickness)
            if thick_diff <= 2.0:
                score += 25.0
            elif thick_diff <= 10.0:
                score += 18.0
            elif thick_diff <= 25.0:
                score += 10.0
            else:
                score += 3.0
        else:
            score += 15.0  # neutral points if thickness not stamped on label

        # 3. Metallization alignment (up to 10 points)
        film_is_met = "metallized" in film_name_lower or "foil" in film_name_lower or "met-" in film_mat_lower
        if extracted["metallized_claim"] == film_is_met:
            score += 10.0

        # 4. Bio / Biodegradability alignment (up to 10 points)
        film_is_bio = film.get("is_bio_alternative", False)
        if extracted["biodegradable_claim"] == film_is_bio:
            score += 10.0

        if score > highest_score:
            highest_score = score
            best_match = film

    # If no high score, select the standard baseline Mono-Material PP or PE
    if not best_match or highest_score < 20.0:
        best_match = FILMS_SEED_DATA[3]  # Mono-Material BOPP/CPP Laminate
        confidence = 0.65
    else:
        confidence = min(0.98, round(highest_score / 100.0, 2))

    # Evaluate Plastic Waste Management & Sustainable Alternatives
    recyclability_score = best_match.get("recyclability_score", 70)
    is_circular = recyclability_score >= 85
    pwm_status = "PWM 2022 Class A Compliant (Mono-Material Stream)" if is_circular else "PWM 2022 Multi-Material (Non-Recyclable EPR Penalty)"

    sustainable_alternatives = []
    if not is_circular:
        sustainable_alternatives = [
            {
                "alternative_name": "Mono-Material PE Recyclable (HDPE 25µm // LLDPE 40µm)",
                "benefit": "100% Recyclable polyolefin stream, 95 recyclability score, lowest EPR fees.",
                "reduction_co2e_pct": 28.5
            },
            {
                "alternative_name": "Certified Compostable Bio-PBS 25µm // PBAT 30µm",
                "benefit": "Home & industrial compostable under IS/ISO 17088, eliminates landfill plastic waste.",
                "reduction_co2e_pct": 34.0
            }
        ]

    # Generate Multilingual Explanation
    explanation_en = (
        f"Label OCR identified film as '{best_match['name']}' with {int(confidence*100)}% deterministic confidence. "
        f"Barrier properties: OTR {best_match.get('otr_cc_m2_day')} cc/m²·day, WVTR {best_match.get('wvtr_g_m2_day')} g/m²·day. "
        f"Recyclability score: {recyclability_score}/100 ({pwm_status})."
    )

    explanations = {
        "en": explanation_en,
        "hi": (
            f"व्याख्या: लेबल स्कैन द्वारा फिल्म की पहचान '{best_match['name']}' के रूप में {int(confidence*100)}% सटीकता से हुई। "
            f"बैरियर क्षमता: OTR {best_match.get('otr_cc_m2_day')} cc/m²·दिन, WVTR {best_match.get('wvtr_g_m2_day')} g/m²·दिन। "
            f"पुनर्चक्रण स्कोर: {recyclability_score}/100 ({pwm_status})।"
        ),
        "mr": (
            f"लेबल स्कॅननुसार पॅकेजिंग फिल्म '{best_match['name']}' म्हणून {int(confidence*100)}% अचूकतेने ओळखली गेली. "
            f"अडथळा क्षमता: OTR {best_match.get('otr_cc_m2_day')} cc/m²·दिवस, WVTR {best_match.get('wvtr_g_m2_day')} g/m²·दिवस. "
            f"पुनर्वापर गुणसंख्या: {recyclability_score}/१०० ({pwm_status})."
        ),
        "ta": (
            f"லேபிள் ஸ்கேன் மூலம் பேக்கேஜிங் பிலிம் '{best_match['name']}' என {int(confidence*100)}% துல்லியத்துடன் அடையாளம் காணப்பட்டது. "
            f"தடுப்பு பண்புகள்: OTR {best_match.get('otr_cc_m2_day')} cc/m²·நாள், WVTR {best_match.get('wvtr_g_m2_day')} g/m²·நாள். "
            f"மறுசுழற்சி மதிப்பீடு: {recyclability_score}/100 ({pwm_status})."
        )
    }

    selected_explanation = explanations.get(lang, explanation_en)

    return {
        "status": "SUCCESS",
        "input_ocr_text": ocr_text,
        "confidence_score": confidence,
        "extracted_entities": extracted,
        "matched_film": {
            "name": best_match["name"],
            "material_type": best_match.get("material_type"),
            "thickness_micron": best_match.get("thickness_micron"),
            "otr_cc_m2_day": best_match.get("otr_cc_m2_day"),
            "wvtr_g_m2_day": best_match.get("wvtr_g_m2_day"),
            "recyclability_score": recyclability_score,
            "cost_per_m2_inr": best_match.get("cost_per_m2_inr"),
            "food_contact_approved": best_match.get("food_contact_approved", True),
            "is_bio_alternative": best_match.get("is_bio_alternative", False),
            "material_type_detail": best_match.get("material_type_detail"),
            "source_reference": best_match.get("source_reference")
        },
        "regulatory_compliance": {
            "fssai_status": "COMPLIANT per IS 9845 Overall Migration Limits" if best_match.get("food_contact_approved") else "NON-COMPLIANT",
            "pwm_rules_status": pwm_status,
            "single_use_ban_status": "Exempt: Engineered primary food packaging"
        },
        "sustainable_alternatives": sustainable_alternatives,
        "explanation": selected_explanation,
        "language": lang if lang in ["en", "hi", "mr", "ta"] else "en"
    }
