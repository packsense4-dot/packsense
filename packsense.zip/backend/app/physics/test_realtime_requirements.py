"""
Unit tests for Non-Negotiable Real-Time Requirements:
1. Every numeric result (shelf life, cost, CO2e, gas mix, compliance pass/fail, ripeness stage)
   is computed at request time from the current database + physics engine + trained model.
2. QR Passport (#7) recomputes remaining_shelf_life_hours live on every status call
   using the real temperature log + Q10 formula (Section 6) — NOT a static countdown.
"""

import unittest
from datetime import datetime, timedelta, timezone
from app.physics.engine import (
    calculate_laminate_barrier,
    simulate_shelf_life
)
from app.physics.shelf_life import shelf_life_temperature_q10, recompute_q10_remaining_shelf_life
from app.physics.features_suite import (
    perform_reverse_pack_audit,
    calculate_right_sizing,
    calculate_rupee_impact,
    evaluate_condensation_risk
)


class TestRealTimeRequirements(unittest.TestCase):

    def test_q10_kinetics_temperature_scaling(self):
        """
        Verify Section 6 Q10 formula: Rate scales by Q10^((T2-T1)/10)
        and shelf life scales inversely: SL(T2) = SL(T1) / Q10^((T2-T1)/10)
        """
        baseline_hours = 504.0  # 21 days
        t_ref = 12.0
        q10 = 2.2

        # At reference temperature, shelf life remains baseline
        sl_at_ref = shelf_life_temperature_q10(baseline_hours, t_ref, t_ref, q10)
        self.assertAlmostEqual(sl_at_ref, baseline_hours, places=2)

        # At 10°C higher (22°C), shelf life is reduced by exactly factor of 2.2
        sl_at_plus10 = shelf_life_temperature_q10(baseline_hours, t_ref + 10.0, t_ref, q10)
        self.assertAlmostEqual(sl_at_plus10, baseline_hours / 2.2, places=2)

    def test_qr_passport_live_recompute_on_status_call(self):
        """
        Verify QR Passport (#7) recomputes remaining_shelf_life_hours live on every status call
        using real temperature log + Q10 formula — not a static countdown.
        """
        batch_id = "BATCH-TEST-LIVE-001"
        now = datetime.now(timezone.utc)

        batch_record = {
            "batch_id": batch_id,
            "commodity": "alphonso_mango",
            "food_name": "Ratnagiri Alphonso Mango",
            "baseline_shelf_life_hours": 504.0,  # 21 days
            "optimal_temp_c": 12.0,
            "q10_value": 2.2,
            "registered_at": (now - timedelta(hours=24)).isoformat()
        }

        # Scenario A: Stored at perfect optimal temperature 12.0°C for 24 hours (2 pings, 12h apart)
        readings_a = [
            {"device_id": "BLE-01", "temp_c": 12.0, "rh_pct": 85.0, "recorded_at": (now - timedelta(hours=24)).isoformat()},
            {"device_id": "BLE-01", "temp_c": 12.0, "rh_pct": 85.0, "recorded_at": (now - timedelta(hours=12)).isoformat()}
        ]

        status_a = recompute_q10_remaining_shelf_life(batch_record, readings_a, current_time_iso=now.isoformat())
        self.assertIn("remaining_shelf_life_hours", status_a)
        self.assertIn("accumulated_degradation_hours", status_a)
        # Should have degraded roughly 24 hours (accel = 1.0)
        self.assertTrue(475.0 <= status_a["remaining_shelf_life_hours"] <= 485.0)
        self.assertEqual(status_a["excursions_detected"], 0)
        self.assertEqual(status_a["quality_grade"], "Grade A (Export)")

        # Scenario B: High thermal abuse (excursion at 25°C)
        readings_b = list(readings_a) + [{
            "device_id": "BLE-01",
            "temp_c": 25.0,  # 13°C above optimal! Accel factor = 2.2^(1.3) ≈ 2.78x
            "rh_pct": 70.0,
            "recorded_at": (now - timedelta(hours=4)).isoformat()
        }]

        status_b = recompute_q10_remaining_shelf_life(batch_record, readings_b, current_time_iso=now.isoformat())
        # Accelerated degradation must result in significantly lower remaining shelf life
        self.assertLess(status_b["remaining_shelf_life_hours"], status_a["remaining_shelf_life_hours"])
        self.assertGreater(status_b["accumulated_degradation_hours"], status_a["accumulated_degradation_hours"])
        self.assertGreater(status_b["excursions_detected"], 0)
        self.assertLess(status_b["cold_chain_compliance_score"], status_a["cold_chain_compliance_score"])

    def test_request_time_physics_distinct_computations(self):
        """
        Verify that changing inputs (temperature, material thickness, package dimensions)
        dynamically recomputes shelf life, OTR, and barrier properties at request time.
        """
        # Test 1: Barrier permeation depends on thickness and temperature
        b1 = calculate_laminate_barrier([{"material_id": "ldpe", "thickness_um": 25}], temp_c=23.0, ambient_rh=50.0)
        b2 = calculate_laminate_barrier([{"material_id": "ldpe", "thickness_um": 50}], temp_c=23.0, ambient_rh=50.0)
        b3 = calculate_laminate_barrier([{"material_id": "ldpe", "thickness_um": 25}], temp_c=35.0, ambient_rh=50.0)

        # Doubling thickness halves OTR and WVTR (inverse linear Fickian diffusion)
        self.assertAlmostEqual(b1["otr_cc_m2_day_atm"] / 2.0, b2["otr_cc_m2_day_atm"], places=1)
        # Increasing temperature increases permeation (Arrhenius permeation)
        self.assertGreater(b3["otr_cc_m2_day_atm"], b1["otr_cc_m2_day_atm"])

        # Test 2: Rupee impact dynamically calculated from parameters, not hardcoded
        impact_cheap = calculate_rupee_impact({
            "weight_kg": 1000,
            "price_per_kg": 20.0,
            "transit_time_days": 7,
            "current_shelf_life": 5,
            "recommended_shelf_life": 15,
            "extra_pack_cost": 2.0,
            "packs_per_tonne": 1000
        })
        impact_expensive = calculate_rupee_impact({
            "weight_kg": 1000,
            "price_per_kg": 100.0,  # 5x higher value produce
            "transit_time_days": 7,
            "current_shelf_life": 5,
            "recommended_shelf_life": 15,
            "extra_pack_cost": 2.0,
            "packs_per_tonne": 1000
        })

        self.assertGreater(impact_expensive["net_gain_per_tonne"], impact_cheap["net_gain_per_tonne"])
        self.assertIn("formula", impact_cheap)


if __name__ == "__main__":
    unittest.main()
