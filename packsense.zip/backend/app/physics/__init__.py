"""
PackSense Physics Core (Digital Twin) Engine Package
ASTM D3985 / ASTM F1249 / Michaelis-Menten Kinetics / Labuza Isotherm
"""

from app.physics.respiration import (
    respiration_michaelis_menten,
    temperature_dependence_q10,
    respiration_rate_at_temperature,
    steady_state_o2,
    steady_state_co2,
    steady_state_pack_atmosphere,
    brentq_solve
)

from app.physics.shelf_life import (
    shelf_life_temperature_q10,
    labuza_critical_time,
    labuza_moisture_gain_step,
    calculate_equilibrium_moisture
)

from app.physics.simulation import (
    simulate_hourly_digital_twin,
    generate_climate_hourly_curve
)

__all__ = [
    "respiration_michaelis_menten",
    "temperature_dependence_q10",
    "respiration_rate_at_temperature",
    "steady_state_o2",
    "steady_state_co2",
    "steady_state_pack_atmosphere",
    "brentq_solve",
    "shelf_life_temperature_q10",
    "labuza_critical_time",
    "labuza_moisture_gain_step",
    "calculate_equilibrium_moisture",
    "simulate_hourly_digital_twin",
    "generate_climate_hourly_curve"
]
