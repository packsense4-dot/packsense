"""
PackSense Respiration & Steady-State Atmospheric Kinetics Module
ASTM / Postharvest Physiology Standards (Michaelis-Menten & Arrhenius / Q10)

Exact Formulas:
1. Respiration (Michaelis-Menten):
   R_O2 = Vm * [O2] / (Km + [O2])

2. Temperature dependence (Arrhenius / Q10):
   Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)

3. Steady-state pack atmosphere:
   OTR_film * Area * (0.21 - pO2_in) = R_O2(T, pO2_in) * Weight
   Solved numerically via scipy.optimize.brentq (with Dekker-Brent pure-Python fallback).
   Mirrored for CO2 balance:
   CTR_film * Area * (pCO2_in - pCO2_out) = R_CO2(T, pO2_in) * Weight
"""

import math
from typing import Callable, Dict, Any, Optional

# Attempt to import scipy's brentq; provide pure-Python Dekker-Brent fallback if unavailable
try:
    from scipy.optimize import brentq as scipy_brentq
except ImportError:
    scipy_brentq = None


def pure_python_brentq(f: Callable[[float], float], a: float, b: float, xtol: float = 1e-8, maxiter: int = 100) -> float:
    """
    Pure-Python implementation of Brent's method (Dekker-Brent algorithm)
    for root finding on a bracket [a, b] where f(a) * f(b) <= 0.
    """
    fa = f(a)
    fb = f(b)

    if fa == 0.0:
        return a
    if fb == 0.0:
        return b
    if fa * fb > 0.0:
        raise ValueError(f"Root is not bracketed: f({a})={fa}, f({b})={fb}")

    if abs(fa) < abs(fb):
        a, b = b, a
        fa, fb = fb, fa

    c = a
    fc = fa
    mflag = True
    d = 0.0

    for _ in range(maxiter):
        if abs(fb) < xtol:
            return b

        if fa != fc and fb != fc:
            # Inverse quadratic interpolation
            s = (a * fb * fc) / ((fa - fb) * (fa - fc)) + \
                (b * fa * fc) / ((fb - fa) * (fb - fc)) + \
                (c * fa * fb) / ((fc - fa) * (fc - fb))
        else:
            # Secant method
            s = b - fb * (b - a) / (fb - fa)

        # Condition checks for bisection fallback
        cond1 = not ((3 * a + b) / 4 < s < b if a < b else b < s < (3 * a + b) / 4)
        cond2 = mflag and abs(s - b) >= abs(b - c) / 2
        cond3 = (not mflag) and abs(s - b) >= abs(c - d) / 2
        cond4 = mflag and abs(b - c) < xtol
        cond5 = (not mflag) and abs(c - d) < xtol

        if cond1 or cond2 or cond3 or cond4 or cond5:
            s = (a + b) / 2.0
            mflag = True
        else:
            mflag = False

        fs = f(s)
        d = c
        c = b
        fc = fb

        if fa * fs < 0:
            b = s
            fb = fs
        else:
            a = s
            fa = fs

        if abs(fa) < abs(fb):
            a, b = b, a
            fa, fb = fb, fa

        if abs(b - a) < xtol:
            return b

    return b


def brentq_solve(f: Callable[[float], float], a: float, b: float, xtol: float = 1e-8, maxiter: int = 100) -> float:
    """
    Finds a root of f in [a, b] using scipy.optimize.brentq when available,
    falling back seamlessly to pure_python_brentq.
    """
    if scipy_brentq is not None:
        try:
            return float(scipy_brentq(f, a, b, xtol=xtol, maxiter=maxiter))
        except Exception:
            return pure_python_brentq(f, a, b, xtol=xtol, maxiter=maxiter)
    return pure_python_brentq(f, a, b, xtol=xtol, maxiter=maxiter)


def respiration_michaelis_menten(vm: float, o2: float, km: float) -> float:
    """
    Respiration (Michaelis-Menten kinetics):
    R_O2 = Vm * [O2] / (Km + [O2])

    Parameters:
        vm: Maximum respiration rate (e.g. ml / (kg · hr) or cc / (kg · day))
        o2: Oxygen concentration (% or partial pressure fraction)
        km: Michaelis-Menten constant (same units as o2)

    Returns:
        R_O2: Respiration rate at given oxygen concentration
    """
    if o2 <= 0.0:
        return 0.0
    return (vm * o2) / (km + o2)


def temperature_dependence_q10(rate_t1: float, t2: float, t1: float, q10: float) -> float:
    """
    Temperature dependence (Arrhenius/Q10):
    Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)

    Parameters:
        rate_t1: Respiration rate or kinetic reaction rate at reference temperature T1
        t2: Target storage temperature (°C)
        t1: Reference baseline temperature (°C)
        q10: Temperature quotient (typically 1.8 - 2.5)

    Returns:
        Rate(T2): Rate scaled to target temperature
    """
    delta_t = (t2 - t1) / 10.0
    return rate_t1 * (q10 ** delta_t)


def respiration_rate_at_temperature(
    vm: float,
    km: float,
    o2: float,
    temp_c: float,
    ref_temp_c: float = 20.0,
    q10: float = 2.0
) -> float:
    """
    Combined Michaelis-Menten and Q10 temperature-dependent respiration rate:
    R_O2(T, [O2]) = [Vm * [O2] / (Km + [O2])] * Q10 ^ ((T - T_ref) / 10)
    """
    base_rate = respiration_michaelis_menten(vm, o2, km)
    return temperature_dependence_q10(base_rate, temp_c, ref_temp_c, q10)


def steady_state_o2(
    otr_film: float,
    area: float,
    weight: float,
    vm: float,
    km: float,
    temp_c: float,
    ref_temp_c: float = 20.0,
    q10: float = 2.0,
    ambient_o2: float = 0.21
) -> float:
    """
    Steady-state pack atmosphere oxygen balance:
    OTR_film * Area * (ambient_o2 - pO2_in) = R_O2(T, pO2_in) * Weight

    Solved numerically via scipy.optimize.brentq.

    Parameters:
        otr_film: Film Oxygen Transmission Rate (same time units as Vm, e.g. cc/(m²·day) or cc/(m²·hr))
        area: Package surface area in m²
        weight: Produce weight in kg
        vm: Maximum produce respiration rate Vm
        km: Michaelis-Menten constant Km (in same scale as ambient_o2)
        temp_c: Storage temperature in °C
        ref_temp_c: Reference temperature for Vm (default 20.0°C)
        q10: Temperature coefficient Q10
        ambient_o2: External oxygen concentration (0.21 for fraction or 21.0 for percent)

    Returns:
        pO2_in: Internal equilibrium oxygen partial pressure / percentage
    """
    if otr_film <= 0.0 or area <= 0.0 or weight <= 0.0:
        return 0.0

    # Temperature factor
    temp_factor = q10 ** ((temp_c - ref_temp_c) / 10.0)
    vm_t = vm * temp_factor

    # Objective function: f(pO2) = OTR * Area * (ambient_o2 - pO2) - R_O2(T, pO2) * Weight
    def f_o2(po2: float) -> float:
        r_o2 = (vm_t * po2) / (km + po2) if po2 > 0 else 0.0
        permeation_in = otr_film * area * (ambient_o2 - po2)
        consumption = r_o2 * weight
        return permeation_in - consumption

    f_at_zero = f_o2(0.0)
    f_at_ambient = f_o2(ambient_o2)

    # Edge cases
    if f_at_zero <= 0.0:
        # Consumption exceeds total permeation capacity even at zero internal O2
        return 0.0
    if f_at_ambient >= 0.0:
        # Respiration is zero or negligible
        return ambient_o2

    # Brent's method on bracket [0.0, ambient_o2]
    return brentq_solve(f_o2, 0.0, ambient_o2, xtol=1e-8)


def steady_state_co2(
    ctr_film: float,
    area: float,
    weight: float,
    r_co2: float,
    ambient_co2: float = 0.0003,
    max_co2_search: float = 1.0
) -> float:
    """
    Mirrored steady-state pack atmosphere CO2 balance:
    CTR_film * Area * (pCO2_in - pCO2_out) = R_CO2(T, pO2_in) * Weight

    Solved numerically via scipy.optimize.brentq (or analytically):
    pCO2_in = pCO2_out + (R_CO2 * Weight) / (CTR_film * Area)

    Parameters:
        ctr_film: Film CO2 transmission rate
        area: Package surface area (m²)
        weight: Produce weight (kg)
        r_co2: Produce CO2 generation rate (e.g. RQ * R_O2)
        ambient_co2: Ambient CO2 concentration (0.0003 for fraction or 0.03 for percent)
        max_co2_search: Upper search bound for numerical Brent solve (1.0 for fraction or 100.0 for %)

    Returns:
        pCO2_in: Internal equilibrium CO2 level
    """
    if ctr_film <= 0.0 or area <= 0.0:
        return max_co2_search

    total_permeance = ctr_film * area
    production = r_co2 * weight

    # Objective function for numerical Brent solve
    def f_co2(pco2: float) -> float:
        permeation_out = total_permeance * (pco2 - ambient_co2)
        return permeation_out - production

    f_at_ambient = f_co2(ambient_co2)
    f_at_max = f_co2(max_co2_search)

    if f_at_ambient >= 0.0:
        return ambient_co2

    if f_at_max < 0.0:
        # Accumulation exceeds maximum transmission boundary
        return max_co2_search

    return brentq_solve(f_co2, ambient_co2, max_co2_search, xtol=1e-8)


def steady_state_pack_atmosphere(
    otr_film: float,
    ctr_film: Optional[float],
    area: float,
    weight: float,
    vm: float,
    km: float,
    temp_c: float,
    ref_temp_c: float = 20.0,
    q10: float = 2.0,
    rq: float = 1.0,
    ambient_o2_pct: float = 21.0,
    ambient_co2_pct: float = 0.03
) -> Dict[str, float]:
    """
    Computes steady-state equilibrium pack atmosphere for respiring produce.
    Returns concentrations in percent (0 to 100%).
    """
    # Film CTR is typically 3.5 - 5.0x OTR for polyolefins if not explicitly specified
    effective_ctr = ctr_film if (ctr_film is not None and ctr_film > 0) else (otr_film * 4.0)

    # Solve steady state O2 (% basis)
    eq_o2 = steady_state_o2(
        otr_film=otr_film,
        area=area,
        weight=weight,
        vm=vm,
        km=km,
        temp_c=temp_c,
        ref_temp_c=ref_temp_c,
        q10=q10,
        ambient_o2=ambient_o2_pct
    )

    # Respiration rate at equilibrium O2
    r_o2_eq = respiration_rate_at_temperature(vm, km, eq_o2, temp_c, ref_temp_c, q10)
    r_co2_eq = rq * r_o2_eq

    # Solve steady state CO2 (% basis)
    eq_co2 = steady_state_co2(
        ctr_film=effective_ctr,
        area=area,
        weight=weight,
        r_co2=r_co2_eq,
        ambient_co2=ambient_co2_pct,
        max_co2_search=100.0
    )

    return {
        "equilibrium_o2_pct": round(eq_o2, 2),
        "equilibrium_co2_pct": round(eq_co2, 2),
        "respiration_r_o2": round(r_o2_eq, 4),
        "respiration_r_co2": round(r_co2_eq, 4),
        "temp_c": round(temp_c, 1)
    }
