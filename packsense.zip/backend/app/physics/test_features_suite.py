"""
Unit tests for PackSense Features #9 to #18 backend engineering algorithms.
Zero mock data, pure deterministic execution.
"""

import unittest
from app.physics.features_suite import (
    perform_reverse_pack_audit,
    diagnose_spoilage_autopsy,
    recommend_active_packaging,
    evaluate_condensation_risk,
    check_mixed_load_compatibility,
    calculate_right_sizing,
    calculate_secondary_packaging,
    calculate_rupee_impact,
    recommend_rural_mode,
    log_community_outcome,
    get_community_regional_accuracy,
    retrain_surrogate_model_job
)


class TestFeaturesSuite(unittest.TestCase):

    def test_feature_9_reverse_audit(self):
        payload = {
            "food_id": "alphonso_mango",
            "film_thickness_micron": 40.0,
            "film_material_type": "ldpe",
            "target_shelf_life_days": 21.0
        }
        res = perform_reverse_pack_audit(payload)
        self.assertIn("predicted_shelf_life_days", res)
        self.assertIn("barrier_efficiency_score_100", res)
        self.assertIn("diagnosis", res)
        self.assertIn("confidence_score", res)
        self.assertIsNotNone(res["smallest_adjustment_to_close_gap"])

    def test_feature_10_spoilage_autopsy(self):
        payload = {
            "food_id": "tomato_hybrid",
            "observed_symptoms": ["ballooning_puffing", "fermentation_odor"]
        }
        res = diagnose_spoilage_autopsy(payload)
        self.assertIn("Anaerobic", res["primary_root_cause"])
        self.assertGreaterEqual(res["confidence_score_pct"], 80)
        self.assertIn("target_otr_cc", res["corrective_engineering_actions"])

    def test_feature_11_active_packaging(self):
        payload = {
            "food_id": "alphonso_mango",
            "pack_volume_cm3": 500.0,
            "target_shelf_life_days": 21.0,
            "film_otr_cc_m2_day_atm": 50.0,
            "film_surface_area_m2": 0.045
        }
        res = recommend_active_packaging(payload)
        self.assertGreater(res["oxygen_scavenger_capacity_cc"], 50)
        self.assertGreater(res["ethylene_scrubber_grams"], 0)
        self.assertIn("dose =", res["formula_used"])

    def test_feature_12_condensation_risk(self):
        payload = {
            "internal_temp_c": 25.0,
            "internal_rh_percent": 90.0,
            "transit_min_temp_c": 16.0
        }
        res = evaluate_condensation_risk(payload)
        self.assertAlmostEqual(res["dew_point_c"], 23.2, delta=1.0)
        self.assertEqual(res["condensation_risk_level"], "CRITICAL")
        self.assertGreater(res["risk_score_100"], 60)

    def test_feature_13_mixed_load_check(self):
        payload = {
            "food_ids": ["alphonso_mango", "spinach_hybrid"]
        }
        res = check_mixed_load_compatibility(payload)
        self.assertEqual(res["overall_compatibility"], "INCOMPATIBLE")
        self.assertGreater(len(res["incompatibilities"]), 0)
        # Ethylene issue should be flagged
        issues = [i["issue_type"] for i in res["incompatibilities"]]
        self.assertIn("ETHYLENE", issues)

    def test_feature_14_right_sizing(self):
        payload = {
            "food_id": "tomato_hybrid",
            "net_weight_g": 300.0,
            "target_shelf_life_days": 18.0
        }
        res = calculate_right_sizing(payload)
        self.assertGreater(res["optimal_thickness_micron"], 10.0)
        self.assertGreater(res["optimal_width_mm"], 50)
        self.assertGreater(res["optimal_length_mm"], 50)
        self.assertIn("Binary search", res["thickness_search_method"])

    def test_feature_15_secondary_packaging(self):
        payload = {
            "units_per_shipper_carton": 20,
            "primary_pack_weight_g": 350.0,
            "pallet_stacking_layers": 6,
            "transit_humidity_rh_percent": 85.0
        }
        res = calculate_secondary_packaging(payload)
        self.assertGreater(res["shipper_bct_kn"], 1.0)
        self.assertIn(res["recommended_flute"], ["BC_DOUBLE_WALL", "C_FLUTE"])
        self.assertGreaterEqual(res["safety_factor"], 2.0)

    def test_feature_16_rupee_impact(self):
        payload = {
            "weight_kg": 2000.0,
            "price_per_kg": 60.0,
            "transit_time_days": 4.0,
            "current_shelf_life_days": 5.0,
            "recommended_shelf_life_days": 21.0,
            "extra_pack_cost": 1.5,
            "pack_size_kg": 0.5
        }
        res = calculate_rupee_impact(payload)
        self.assertGreater(res["expected_loss_current"], res["expected_loss_recommended"])
        self.assertGreater(res["net_gain_per_tonne"], 0)
        self.assertGreater(res["roi_percent"], 0)

    def test_feature_17_rural_mode(self):
        payload = {
            "food_id": "alphonso_mango",
            "available_budget_per_kg_inr": 0.6
        }
        res = recommend_rural_mode(payload)
        self.assertIsNotNone(res["intervention_name"])
        self.assertIsNotNone(res["limitation_notes"])
        self.assertGreater(res["expected_shelf_life_days"], 5)

    def test_feature_18_community_learning(self):
        payload = {
            "region": "Maharashtra (Pune)",
            "commodity": "Alphonso Mango",
            "predicted_shelf_life_days": 21.0,
            "actual_observed_shelf_life_days": 20.0
        }
        log_res = log_community_outcome(payload)
        self.assertEqual(log_res["status"], "RECORDED")
        stats = get_community_regional_accuracy()
        self.assertGreater(stats["regional_accuracy_pct"], 80.0)
        retrain_res = retrain_surrogate_model_job()
        self.assertEqual(retrain_res["status"], "RETRAINED_SUCCESSFULLY")


if __name__ == "__main__":
    unittest.main()
