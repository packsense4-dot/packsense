"""
PackSense Rule-Based Category & Commodity Mapper (Part A.1)

Maps commercial packaged product categories, tags, brands, or ingredient text
to the nearest engineering foods row (foods.category + foods.id).

If no confident mapping exists, returns None for food_id — signaling the
analyze endpoint to return needs_input asking for a one-tap commodity choice.
"""

from typing import Optional, Dict, Any, List
import re

CATEGORY_RULES = [
    {
        "keywords": ["chips", "crisps", "potato", "wafer", "namkeen", "bhujia", "sev", "kurkure", "snack"],
        "category": "dry_snacks",
        "food_id": "potato_crisps",
        "confidence": 0.85
    },
    {
        "keywords": ["biscuit", "cookie", "cookies", "parle-g", "good day", "rusk", "crackers"],
        "category": "bakery",
        "food_id": "white_bread",
        "confidence": 0.80
    },
    {
        "keywords": ["bread", "loaf", "bun", "cake", "muffin", "pastry"],
        "category": "bakery",
        "food_id": "white_bread",
        "confidence": 0.90
    },
    {
        "keywords": ["paneer", "cottage cheese", "cheese", "cheddar", "mozzarella", "dahi", "curd", "yogurt"],
        "category": "dairy_cheese",
        "food_id": "fresh_paneer",
        "confidence": 0.90
    },
    {
        "keywords": ["milk", "chaas", "buttermilk", "lassi"],
        "category": "dairy_cheese",
        "food_id": "fresh_paneer",
        "confidence": 0.75
    },
    {
        "keywords": ["mango", "alphonso", "kesar", "dasheri", "apple", "banana", "papaya", "guava", "orange", "fruit"],
        "category": "fresh_produce",
        "food_id": "alphonso_mango",
        "confidence": 0.88
    },
    {
        "keywords": ["spinach", "palak", "methi", "coriander", "lettuce", "greens", "cabbage", "cauliflower", "broccoli"],
        "category": "fresh_produce",
        "food_id": "fresh_spinach",
        "confidence": 0.85
    },
    {
        "keywords": ["tomato puree", "puree", "paste", "sauce", "ketchup", "curry paste", "ready to eat", "gravy"],
        "category": "ready_to_eat",
        "food_id": "tomato_puree",
        "confidence": 0.85
    },
    {
        "keywords": ["beef", "mutton", "lamb", "steak", "pork", "meat"],
        "category": "fresh_meat",
        "food_id": "fresh_beef_steak",
        "confidence": 0.85
    },
    {
        "keywords": ["chicken", "turkey", "poultry"],
        "category": "poultry",
        "food_id": "chicken_breast",
        "confidence": 0.88
    },
    {
        "keywords": ["fish", "salmon", "prawn", "shrimp", "crab", "seafood"],
        "category": "seafood",
        "food_id": "salmon_fillet",
        "confidence": 0.85
    },
    {
        "keywords": ["peanut", "peanuts", "cashew", "almond", "walnut", "pistachio", "groundnut"],
        "category": "dry_snacks",
        "food_id": "roasted_peanuts",
        "confidence": 0.85
    },
    {
        "keywords": ["coffee", "tea", "chai", "espresso", "cappuccino", "nescafe"],
        "category": "coffee_tea",
        "food_id": "ground_coffee",
        "confidence": 0.90
    }
]

def map_product_to_food_category(
    name: str,
    brand: Optional[str] = None,
    category: Optional[str] = None,
    ingredients: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Rule-based mapper that maps product descriptors to nearest foods row.
    If no confident mapping exists, food_id is None.
    """
    text_parts = [name or "", brand or "", category or ""]
    if ingredients:
        text_parts.extend(ingredients)
    combined = " ".join(text_parts).lower()

    for rule in CATEGORY_RULES:
        for kw in rule["keywords"]:
            if re.search(r"\b" + re.escape(kw) + r"\b", combined):
                return {
                    "category": rule["category"],
                    "food_id": rule["food_id"],
                    "confidence": rule["confidence"],
                    "matched_rule": kw
                }

    # Low-confidence fallback: leave food_id as None (triggers needs_input in scan analyzer)
    inferred_cat = "packaged_food"
    if any(k in combined for k in ["snack", "namkeen", "sweet"]):
        inferred_cat = "dry_snacks"
    elif any(k in combined for k in ["milk", "dairy", "cream"]):
        inferred_cat = "dairy_cheese"
    elif any(k in combined for k in ["fruit", "vegetable", "fresh"]):
        inferred_cat = "fresh_produce"

    return {
        "category": inferred_cat,
        "food_id": None,
        "confidence": 0.3,
        "matched_rule": None
    }
