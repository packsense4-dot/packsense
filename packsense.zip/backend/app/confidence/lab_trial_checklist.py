"""
PackSense Lab Trial Checklist (Section 8.6)
Generates physical ASTM / IS lab trial testing protocols for packaging validation.
"""
from typing import Dict, Any, List

def generate_lab_trial_checklist(pack_id: str, food_category: str) -> Dict[str, Any]:
    tests: List[Dict[str, str]] = [
        {"standard": "ASTM D3985", "parameter": "Oxygen Transmission Rate (OTR)", "target": "Coulometric Detector at 23°C, 0% RH"},
        {"standard": "ASTM F1249", "parameter": "Water Vapor Transmission Rate (WVTR)", "target": "Infrared Sensor at 37.8°C, 90% RH"},
        {"standard": "IS 9845 / EN 1186", "parameter": "Overall Migration Limit (OML)", "target": "< 60 mg/kg food simulant A, B, C, D1"},
        {"standard": "ASTM D3078", "parameter": "Bubble Emission Seal Integrity", "target": "Vacuum chamber leak detection at -20 kPa"}
    ]
    return {
        "pack_id": pack_id,
        "food_category": food_category,
        "standards": [t["standard"] for t in tests],
        "test_suite": tests,
        "accreditation_requirement": "NABL / ISO 17025 Accredited Laboratory"
    }
