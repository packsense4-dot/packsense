"""
PackSense Deterministic Confidence Score (Section 8.5)
Strict rule-based score (0-100%) grounded in data completeness and physical variance.
"""
from typing import Dict, Any

def compute_confidence_score(food_has_respiration: bool, film_tested_astm: bool, is_temperature_monitored: bool, days_diff: float) -> Dict[str, Any]:
    score = 70.0
    deductions = []
    if food_has_respiration:
        score += 15.0
    else:
        deductions.append("Missing crop-specific respiration rates (Michaelis-Menten Vm/Km)")

    if film_tested_astm:
        score += 10.0
    else:
        deductions.append("Laminate permeability estimated from generic polymer tables")

    if is_temperature_monitored:
        score += 5.0
    else:
        deductions.append("No active BLE thermal tracking")

    return {
        "confidence_score_pct": min(100.0, max(20.0, score)),
        "rating": "HIGH" if score >= 85 else ("MODERATE" if score >= 65 else "LOW"),
        "methodology": "ASTM / ISO Empirical Verification Index",
        "deductions": deductions
    }
