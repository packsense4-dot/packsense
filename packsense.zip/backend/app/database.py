"""
PackSense Database & Session Management
SQLAlchemy engine initialization with synchronous/asynchronous session fixtures.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import settings

# Fallback to sqlite if postgresql is unavailable in local testing
try:
    engine = create_engine(settings.DATABASE_URL_SYNC, pool_pre_ping=True)
except Exception:
    engine = create_engine("sqlite:///./packsense.db", connect_args={"check_same_thread": False})

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
