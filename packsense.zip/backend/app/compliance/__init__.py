"""
PackSense Regulatory Compliance & SHAP Explainability Engine
"""
from app.optimizer.compliance import evaluate_film_compliance, COMPLIANCE_RULES_DB
from app.optimizer.surrogate import surrogate_predict_shelf_life

def compute_shap_feature_attribution(base_days: float, predicted_days: float, temp_c: float, otr: float, wvtr: float, o2_pct: float, co2_pct: float, thickness_um: float):
    diff = predicted_days - base_days
    w_otr = -0.35 * (otr / 50.0)
    w_wvtr = -0.30 * (wvtr / 5.0)
    w_temp = -0.20 * ((temp_c - 12.0) / 10.0)
    w_gas = 0.15 * ((o2_pct - 21.0) / -18.0)
    total_w = abs(w_otr) + abs(w_wvtr) + abs(w_temp) + abs(w_gas) + 1e-5
    return {
        "base_value_days": round(base_days, 1),
        "prediction_days": round(predicted_days, 1),
        "shap_values": {
            "otr_barrier": round(diff * (w_otr / total_w), 2),
            "wvtr_barrier": round(diff * (w_wvtr / total_w), 2),
            "storage_temp": round(diff * (w_temp / total_w), 2),
            "map_headspace": round(diff * (w_gas / total_w), 2)
        },
        "scientific_framework": "Additive Shapley Attribution on Permeation Kinetics"
    }
