"""
PackSense Pydantic Validation Schemas
"""
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    name: str

class UserLoginRequest(BaseModel):
    phone_or_email: str
    otp_or_password: Optional[str] = None

class FoodProfileRequest(BaseModel):
    food_id: Optional[str] = None
    custom_parameters: Optional[Dict[str, Any]] = None

class LayerInput(BaseModel):
    material_id: Optional[str] = "ldpe"
    thickness_um: float = 50.0

class SimulateRequest(BaseModel):
    food_id: Optional[str] = None
    layers: Optional[List[LayerInput]] = None
    geometry: Optional[Dict[str, Any]] = None
    conditions: Optional[Dict[str, Any]] = None
    map_gas: Optional[Dict[str, Any]] = None
    max_days: Optional[int] = 180

class OptimizeRequest(BaseModel):
    food_id: str
    target_shelf_life_days: Optional[int] = None
    budget_constraint: Optional[float] = None
    max_co2e_kg: Optional[float] = None
    min_recyclability_class: Optional[str] = None
    climate_zone_id: Optional[str] = None

class LoggerReadingRequest(BaseModel):
    device_id: str = "BLE-TEMP-001"
    temp_c: float
    rh_pct: Optional[float] = 85.0
    recorded_at: Optional[str] = None
    raw_hex: Optional[str] = None
