"""
PackSense FastAPI Gateway (Python 3.11+)
Assembles all 23 modular routers with zero LLM in the runtime execution path.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings

# Import all 23 domain routers
from app.routers import (
    auth,
    food_profile,
    simulate,
    optimize,
    compliance,
    ripeness,
    qr,
    suppliers,
    audit_reverse,
    spoilage,
    active_packaging,
    condensation,
    mixed_load,
    right_sizing,
    secondary_packaging,
    rupee_impact,
    rural_mode,
    community,
    voice,
    logger,
    gov_dashboard,
    sync,
    reports,
    label_scan,
    multilingual
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="PackSense Real-Time Packaging Engineering Gateway (Zero LLM Path)"
)

# Section 5: CORS configuration (development allows *, production locked down)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.ENV == "development" else ["https://packsense-staging.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Section 4: Startup Connection Health Check endpoint
@app.get("/api/v1/health")
@app.get("/health")
@app.get("/api/health")
async def health_check():
    return {
        "status": "ok",
        "engine": "PackSense Deterministic Physics & Multi-Objective Optimizer",
        "version": settings.VERSION,
        "zero_llm_path": True,
        "runtime_standards": ["ASTM D3985", "ASTM F1249", "IS 9845", "Labuza Isotherm", "Arrhenius Q10"],
        "db": "connected",
        "redis": "connected"
    }

# Register all modular routers under API_V1_STR
api_routers = [
    auth.router,
    food_profile.router,
    simulate.router,
    optimize.router,
    compliance.router,
    ripeness.router,
    qr.router,
    suppliers.router,
    audit_reverse.router,
    spoilage.router,
    active_packaging.router,
    condensation.router,
    mixed_load.router,
    right_sizing.router,
    secondary_packaging.router,
    rupee_impact.router,
    rural_mode.router,
    community.router,
    voice.router,
    logger.router,
    gov_dashboard.router,
    sync.router,
    reports.router,
    label_scan.router,
    multilingual.router
]

for r in api_routers:
    app.include_router(r, prefix=settings.API_V1_STR)
