-- PackSense Complete PostgreSQL 15+ & PostGIS Schema
-- All tables per Section 5.0 - 5.10 & Auth Specification

-- 5.0 EXTENSIONS
CREATE EXTENSION IF NOT EXISTS postgis;

-- AUTH & ROLES
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    phone_number VARCHAR(15) UNIQUE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100),
    preferred_language VARCHAR(20) DEFAULT 'english', -- hindi, marathi, tamil, english, etc.
    role VARCHAR(30) NOT NULL DEFAULT 'farmer', -- farmer, fpo, msme, industry, admin, government
    is_active BOOLEAN DEFAULT TRUE,
    last_login_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT now()
);

ALTER TABLE users ADD COLUMN IF NOT EXISTS email VARCHAR(255) UNIQUE NOT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) NOT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP;

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    token_hash VARCHAR(255) UNIQUE, -- store a hash of the token, not the token itself
    expires_at TIMESTAMP,
    revoked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT now()
);

-- 5.1 FOODS
CREATE TABLE IF NOT EXISTS foods (
    id SERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(40) NOT NULL, -- fruit, vegetable, dairy, bakery, snack, spice, meat_fish, grain, beverage
    moisture_pct NUMERIC(5,2),
    fat_pct NUMERIC(5,2),
    ph NUMERIC(4,2),
    water_activity NUMERIC(4,3),
    respiration_vm NUMERIC(10,4),
    respiration_km NUMERIC(10,4),
    q10_value NUMERIC(4,2),
    critical_moisture_content NUMERIC(6,3),
    safe_o2_min NUMERIC(5,2),
    safe_o2_max NUMERIC(5,2),
    safe_co2_min NUMERIC(5,2),
    safe_co2_max NUMERIC(5,2),
    optimal_storage_temp_c NUMERIC(5,2),
    is_regression_estimated BOOLEAN DEFAULT FALSE,
    source_reference VARCHAR(255),
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS food_ripeness_profiles (
    id SERIAL PRIMARY KEY,
    food_id INTEGER REFERENCES foods(id) ON DELETE CASCADE,
    ripeness_stage VARCHAR(30), -- unripe, breaker, ripe, overripe
    respiration_multiplier NUMERIC(4,2)
);

-- 5.2 FILMS
CREATE TABLE IF NOT EXISTS films (
    id SERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    material_type VARCHAR(60),
    layer_count SMALLINT DEFAULT 1,
    thickness_micron NUMERIC(6,2),
    otr_cc_m2_day NUMERIC(10,3),
    wvtr_g_m2_day NUMERIC(10,3),
    cost_per_m2_inr NUMERIC(8,2),
    co2e_per_m2_kg NUMERIC(8,4),
    recyclability_score SMALLINT,
    max_heat_seal_temp_c NUMERIC(5,2),
    food_contact_approved BOOLEAN,
    is_bio_alternative BOOLEAN DEFAULT FALSE,
    perforation_options TEXT[],
    material_type_detail VARCHAR(60), -- PBAT blends, mono-material metallized PE/PP, paper-foil-free laminates
    source_reference VARCHAR(255),
    created_at TIMESTAMP DEFAULT now()
);

-- 5.3 CLIMATE PROFILES (sourced from IMD open data)
CREATE TABLE IF NOT EXISTS climate_profiles (
    id SERIAL PRIMARY KEY,
    profile_name VARCHAR(80),
    region VARCHAR(80),
    district VARCHAR(80),
    season VARCHAR(30),
    avg_temp_c NUMERIC(5,2),
    max_temp_c NUMERIC(5,2),
    avg_rh_pct NUMERIC(5,2),
    cold_chain_break_hours NUMERIC(6,2),
    transport_mode VARCHAR(40),
    vibration_stress_level VARCHAR(20),
    imd_source_id VARCHAR(60),
    last_synced_at TIMESTAMP DEFAULT now()
);

-- 5.4 COMPLIANCE RULES
CREATE TABLE IF NOT EXISTS compliance_rules (
    id SERIAL PRIMARY KEY,
    rule_code VARCHAR(30),
    authority VARCHAR(40), -- FSSAI, BIS, CPCB
    applies_to_material VARCHAR(60),
    applies_to_food_category VARCHAR(40),
    rule_description TEXT,
    max_allowed_value NUMERIC(10,4),
    unit VARCHAR(30),
    is_mandatory BOOLEAN DEFAULT TRUE,
    source_reference VARCHAR(255)
);

-- 5.5 SUPPLIERS
CREATE TABLE IF NOT EXISTS suppliers (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(150),
    state VARCHAR(60),
    city VARCHAR(60),
    district VARCHAR(80),
    location GEOGRAPHY(POINT, 4326),
    film_ids INTEGER[],
    min_order_qty_kg NUMERIC(10,2),
    contact_phone VARCHAR(20),
    verified BOOLEAN DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_suppliers_location ON suppliers USING GIST (location);

-- 5.6 SECONDARY PACKAGING
CREATE TABLE IF NOT EXISTS secondary_packaging_options (
    id SERIAL PRIMARY KEY,
    box_grade VARCHAR(20),
    burst_strength_kpa NUMERIC(8,2),
    max_stack_height_cm NUMERIC(6,2),
    ventilation_area_pct NUMERIC(5,2),
    cost_per_box_inr NUMERIC(8,2),
    source_reference VARCHAR(255)
);

-- 5.7 RURAL ALTERNATIVES
CREATE TABLE IF NOT EXISTS rural_alternatives (
    id SERIAL PRIMARY KEY,
    material_name VARCHAR(80),
    approx_otr NUMERIC(10,3),
    approx_wvtr NUMERIC(10,3),
    cost_per_unit_inr NUMERIC(6,2),
    limitation_notes TEXT,
    suitable_food_categories TEXT[],
    source_reference VARCHAR(255)
);

-- 5.8 MIXED-LOAD COMPATIBILITY MATRIX
CREATE TABLE IF NOT EXISTS compatibility_matrix (
    id SERIAL PRIMARY KEY,
    food_category_a VARCHAR(40),
    food_category_b VARCHAR(40),
    ethylene_conflict BOOLEAN,
    odour_transfer_risk BOOLEAN,
    temp_band_overlap BOOLEAN,
    compatible BOOLEAN
);

-- 5.9 PACKS / TRANSACTIONS
CREATE TABLE IF NOT EXISTS packs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    food_id INTEGER REFERENCES foods(id),
    film_id INTEGER REFERENCES films(id),
    climate_profile_id INTEGER REFERENCES climate_profiles(id),
    weight_kg NUMERIC(8,3),
    pack_area_m2 NUMERIC(8,4),
    predicted_shelf_life_hours NUMERIC(10,2),
    cost_per_pack_inr NUMERIC(8,2),
    co2e_per_pack_kg NUMERIC(8,4),
    recyclability_score SMALLINT,
    optimizer_rank_label VARCHAR(20),
    confidence_score SMALLINT,
    lab_trial_recommended BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT now()
);

-- 5.9a LAB TRIAL CHECKLIST
CREATE TABLE IF NOT EXISTS lab_trial_checklist_items (
    id SERIAL PRIMARY KEY,
    pack_id INTEGER REFERENCES packs(id) ON DELETE CASCADE,
    check_item VARCHAR(120),
    reason TEXT,
    is_completed BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS qr_batches (
    id SERIAL PRIMARY KEY,
    pack_id INTEGER REFERENCES packs(id),
    batch_code VARCHAR(40) UNIQUE,
    packed_at TIMESTAMP,
    temp_log JSONB,
    remaining_shelf_life_hours NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT now()
);

-- 5.9b BLUETOOTH TEMPERATURE LOGGER READINGS
CREATE TABLE IF NOT EXISTS logger_readings (
    id SERIAL PRIMARY KEY,
    qr_batch_id INTEGER REFERENCES qr_batches(id) ON DELETE CASCADE,
    logger_device_id VARCHAR(60),
    reading_temp_c NUMERIC(5,2),
    reading_rh_pct NUMERIC(5,2),
    recorded_at TIMESTAMP,
    received_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_logger_readings_batch ON logger_readings(qr_batch_id, recorded_at);

CREATE TABLE IF NOT EXISTS spoilage_reports (
    id SERIAL PRIMARY KEY,
    pack_id INTEGER REFERENCES packs(id),
    symptom VARCHAR(60),
    photo_url TEXT,
    diagnosed_cause VARCHAR(80),
    prescribed_fix TEXT,
    created_at TIMESTAMP DEFAULT now()
);

-- 5.10 GOV DASHBOARD — pre-aggregated, ANONYMIZED
CREATE TABLE IF NOT EXISTS gov_district_packaging_stats (
    id SERIAL PRIMARY KEY,
    district VARCHAR(80),
    state VARCHAR(60),
    food_category VARCHAR(40),
    total_packs_recommended INTEGER,
    avg_predicted_shelf_life_hours NUMERIC(10,2),
    avg_cost_per_pack_inr NUMERIC(8,2),
    avg_co2e_per_pack_kg NUMERIC(8,4),
    common_packaging_gap TEXT,
    stat_period_start DATE,
    stat_period_end DATE,
    computed_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS community_outcomes (
    id SERIAL PRIMARY KEY,
    pack_id INTEGER REFERENCES packs(id),
    region VARCHAR(80),
    predicted_shelf_life_hours NUMERIC(10,2),
    actual_shelf_life_hours NUMERIC(10,2),
    logged_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS whatsapp_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    phone_number VARCHAR(15),
    last_intent VARCHAR(60),
    conversation_state JSONB,
    updated_at TIMESTAMP DEFAULT now()
);

-- SECTION 1.3: PACK LABEL SCANS (OCR Film Matching & Continuous Improvement)
CREATE TABLE IF NOT EXISTS pack_label_scans (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    raw_text TEXT,
    extracted_material VARCHAR(60),
    extracted_thickness NUMERIC(6,2),
    matched_film_id INTEGER REFERENCES films(id),
    match_confidence SMALLINT,
    was_accepted_by_user BOOLEAN, -- did the client report the user kept this match or overrode it? feeds 1.5
    created_at TIMESTAMP DEFAULT now()
);

-- PART 2: MULTILINGUAL SUPPORT (Section 2.3 & 2.4)
CREATE TABLE IF NOT EXISTS i18n_templates (
    id SERIAL PRIMARY KEY,
    template_key VARCHAR(80) NOT NULL,   -- e.g. "shap_explanation.high_respiration", "checklist.confirm_otr", "spoilage.fix.high_wvtr"
    language_code VARCHAR(10) NOT NULL,   -- 'en', 'hi', 'mr', 'ta'
    template_text TEXT NOT NULL,           -- with {placeholders} exactly matching the Python .format() keys already used in the English templates
    needs_translation_review BOOLEAN DEFAULT TRUE,
    UNIQUE (template_key, language_code)
);

-- Section 2.4: Translated reference content sibling JSONB columns
ALTER TABLE compliance_rules ADD COLUMN IF NOT EXISTS rule_description_translations JSONB;
-- shape: {"hi": "...", "mr": "...", "ta": "..."}, English stays in the existing rule_description column

ALTER TABLE rural_alternatives ADD COLUMN IF NOT EXISTS limitation_notes_translations JSONB;
ALTER TABLE gov_district_packaging_stats ADD COLUMN IF NOT EXISTS common_packaging_gap_translations JSONB;


