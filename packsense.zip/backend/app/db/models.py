"""
PackSense SQLAlchemy 2.0 ORM Models
Maps 100% of Section 5 database schema and Section 4 Auth & Roles.
"""

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime,
    ForeignKey, Numeric, Text, ARRAY, SmallInteger, Date,
    UniqueConstraint
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base, relationship
from geoalchemy2 import Geography
from datetime import datetime

Base = declarative_base()

# AUTH & ROLES
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    phone_number = Column(String(15), unique=True, index=True, nullable=True)
    email = Column(String(120), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=True)
    name = Column(String(100), nullable=True)
    preferred_language = Column(String(20), default="english")
    role = Column(String(30), nullable=False, default="farmer") # farmer, fpo, msme, industry, admin, government
    created_at = Column(DateTime, default=datetime.utcnow)

    packs = relationship("Pack", back_populates="user")
    whatsapp_sessions = relationship("WhatsAppSession", back_populates="user")

# 5.1 FOODS
class Food(Base):
    __tablename__ = "foods"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(120), nullable=False, index=True)
    category = Column(String(40), nullable=False) # fruit, vegetable, dairy, bakery, snack, spice, meat_fish, grain, beverage
    moisture_pct = Column(Numeric(5, 2))
    fat_pct = Column(Numeric(5, 2))
    ph = Column(Numeric(4, 2))
    water_activity = Column(Numeric(4, 3))
    respiration_vm = Column(Numeric(10, 4), nullable=True)
    respiration_km = Column(Numeric(10, 4), nullable=True)
    q10_value = Column(Numeric(4, 2), nullable=True)
    critical_moisture_content = Column(Numeric(6, 3), nullable=True)
    safe_o2_min = Column(Numeric(5, 2), nullable=True)
    safe_o2_max = Column(Numeric(5, 2), nullable=True)
    safe_co2_min = Column(Numeric(5, 2), nullable=True)
    safe_co2_max = Column(Numeric(5, 2), nullable=True)
    optimal_storage_temp_c = Column(Numeric(5, 2), nullable=True)
    is_regression_estimated = Column(Boolean, default=False)
    source_reference = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    ripeness_profiles = relationship("FoodRipenessProfile", back_populates="food")
    packs = relationship("Pack", back_populates="food")

class FoodRipenessProfile(Base):
    __tablename__ = "food_ripeness_profiles"

    id = Column(Integer, primary_key=True, autoincrement=True)
    food_id = Column(Integer, ForeignKey("foods.id", ondelete="CASCADE"), nullable=False)
    ripeness_stage = Column(String(30)) # unripe, breaker, ripe, overripe
    respiration_multiplier = Column(Numeric(4, 2), default=1.0)

    food = relationship("Food", back_populates="ripeness_profiles")

# 5.2 FILMS
class Film(Base):
    __tablename__ = "films"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(120), nullable=False)
    material_type = Column(String(60))
    layer_count = Column(SmallInteger, default=1)
    thickness_micron = Column(Numeric(6, 2))
    otr_cc_m2_day = Column(Numeric(10, 3))
    wvtr_g_m2_day = Column(Numeric(10, 3))
    cost_per_m2_inr = Column(Numeric(8, 2))
    co2e_per_m2_kg = Column(Numeric(8, 4))
    recyclability_score = Column(SmallInteger)
    max_heat_seal_temp_c = Column(Numeric(5, 2))
    food_contact_approved = Column(Boolean, default=True)
    is_bio_alternative = Column(Boolean, default=False)
    perforation_options = Column(ARRAY(Text), nullable=True)
    material_type_detail = Column(String(60)) # PBAT blends, mono-material metallized PE/PP, paper-foil-free laminates
    source_reference = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    packs = relationship("Pack", back_populates="film")

# 5.3 CLIMATE PROFILES
class ClimateProfile(Base):
    __tablename__ = "climate_profiles"

    id = Column(Integer, primary_key=True, autoincrement=True)
    profile_name = Column(String(80), nullable=False)
    region = Column(String(80))
    district = Column(String(80), index=True)
    season = Column(String(30))
    avg_temp_c = Column(Numeric(5, 2))
    max_temp_c = Column(Numeric(5, 2))
    avg_rh_pct = Column(Numeric(5, 2))
    cold_chain_break_hours = Column(Numeric(6, 2))
    transport_mode = Column(String(40))
    vibration_stress_level = Column(String(20))
    imd_source_id = Column(String(60))
    last_synced_at = Column(DateTime, default=datetime.utcnow)

    packs = relationship("Pack", back_populates="climate_profile")

# 5.4 COMPLIANCE RULES
class ComplianceRule(Base):
    __tablename__ = "compliance_rules"

    id = Column(Integer, primary_key=True, autoincrement=True)
    rule_code = Column(String(30), unique=True, index=True)
    authority = Column(String(40)) # FSSAI, BIS, CPCB
    applies_to_material = Column(String(60))
    applies_to_food_category = Column(String(40))
    rule_description = Column(Text)
    rule_description_translations = Column(JSONB, default=dict)
    max_allowed_value = Column(Numeric(10, 4))
    unit = Column(String(30))
    is_mandatory = Column(Boolean, default=True)
    source_reference = Column(String(255))

# 5.5 SUPPLIERS
class Supplier(Base):
    __tablename__ = "suppliers"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(150), nullable=False)
    state = Column(String(60))
    city = Column(String(60))
    district = Column(String(80))
    location = Column(Geography(geometry_type="POINT", srid=4326))
    film_ids = Column(ARRAY(Integer), nullable=True)
    min_order_qty_kg = Column(Numeric(10, 2))
    contact_phone = Column(String(20))
    verified = Column(Boolean, default=False)

# 5.6 SECONDARY PACKAGING
class SecondaryPackagingOption(Base):
    __tablename__ = "secondary_packaging_options"

    id = Column(Integer, primary_key=True, autoincrement=True)
    box_grade = Column(String(20))
    burst_strength_kpa = Column(Numeric(8, 2))
    max_stack_height_cm = Column(Numeric(6, 2))
    ventilation_area_pct = Column(Numeric(5, 2))
    cost_per_box_inr = Column(Numeric(8, 2))
    source_reference = Column(String(255))

# 5.7 RURAL ALTERNATIVES
class RuralAlternative(Base):
    __tablename__ = "rural_alternatives"

    id = Column(Integer, primary_key=True, autoincrement=True)
    material_name = Column(String(80), nullable=False)
    approx_otr = Column(Numeric(10, 3))
    approx_wvtr = Column(Numeric(10, 3))
    cost_per_unit_inr = Column(Numeric(6, 2))
    limitation_notes = Column(Text)
    limitation_notes_translations = Column(JSONB, default=dict)
    suitable_food_categories = Column(ARRAY(Text))
    source_reference = Column(String(255))

# 5.8 MIXED-LOAD COMPATIBILITY MATRIX
class CompatibilityMatrix(Base):
    __tablename__ = "compatibility_matrix"

    id = Column(Integer, primary_key=True, autoincrement=True)
    food_category_a = Column(String(40), index=True)
    food_category_b = Column(String(40), index=True)
    ethylene_conflict = Column(Boolean, default=False)
    odour_transfer_risk = Column(Boolean, default=False)
    temp_band_overlap = Column(Boolean, default=True)
    compatible = Column(Boolean, default=True)

# 5.9 PACKS & TRANSACTIONS
class Pack(Base):
    __tablename__ = "packs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    food_id = Column(Integer, ForeignKey("foods.id"))
    film_id = Column(Integer, ForeignKey("films.id"))
    climate_profile_id = Column(Integer, ForeignKey("climate_profiles.id"))
    weight_kg = Column(Numeric(8, 3))
    pack_area_m2 = Column(Numeric(8, 4))
    predicted_shelf_life_hours = Column(Numeric(10, 2))
    cost_per_pack_inr = Column(Numeric(8, 2))
    co2e_per_pack_kg = Column(Numeric(8, 4))
    recyclability_score = Column(SmallInteger)
    optimizer_rank_label = Column(String(20)) # Best Life / Best Value / Greenest
    confidence_score = Column(SmallInteger) # 0-100
    lab_trial_recommended = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="packs")
    food = relationship("Food", back_populates="packs")
    film = relationship("Film", back_populates="packs")
    climate_profile = relationship("ClimateProfile", back_populates="packs")
    lab_trial_checklist = relationship("LabTrialChecklistItem", back_populates="pack", cascade="all, delete-orphan")
    qr_batches = relationship("QRBatch", back_populates="pack")
    spoilage_reports = relationship("SpoilageReport", back_populates="pack")
    community_outcomes = relationship("CommunityOutcome", back_populates="pack")

class LabTrialChecklistItem(Base):
    __tablename__ = "lab_trial_checklist_items"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pack_id = Column(Integer, ForeignKey("packs.id", ondelete="CASCADE"), nullable=False)
    check_item = Column(String(120), nullable=False)
    reason = Column(Text)
    is_completed = Column(Boolean, default=False)

    pack = relationship("Pack", back_populates="lab_trial_checklist")

class QRBatch(Base):
    __tablename__ = "qr_batches"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pack_id = Column(Integer, ForeignKey("packs.id"))
    batch_code = Column(String(40), unique=True, index=True)
    packed_at = Column(DateTime, default=datetime.utcnow)
    temp_log = Column(JSONB, default=list)
    remaining_shelf_life_hours = Column(Numeric(10, 2))
    created_at = Column(DateTime, default=datetime.utcnow)

    pack = relationship("Pack", back_populates="qr_batches")
    logger_readings = relationship("LoggerReading", back_populates="qr_batch", cascade="all, delete-orphan")

class LoggerReading(Base):
    __tablename__ = "logger_readings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    qr_batch_id = Column(Integer, ForeignKey("qr_batches.id", ondelete="CASCADE"), nullable=False)
    logger_device_id = Column(String(60), index=True)
    reading_temp_c = Column(Numeric(5, 2))
    reading_rh_pct = Column(Numeric(5, 2))
    recorded_at = Column(DateTime)
    received_at = Column(DateTime, default=datetime.utcnow)

    qr_batch = relationship("QRBatch", back_populates="logger_readings")

class SpoilageReport(Base):
    __tablename__ = "spoilage_reports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pack_id = Column(Integer, ForeignKey("packs.id"))
    symptom = Column(String(60))
    photo_url = Column(Text, nullable=True)
    diagnosed_cause = Column(String(80))
    prescribed_fix = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    pack = relationship("Pack", back_populates="spoilage_reports")

# 5.10 GOV DASHBOARD & COMMUNITY
class GovDistrictPackagingStat(Base):
    __tablename__ = "gov_district_packaging_stats"

    id = Column(Integer, primary_key=True, autoincrement=True)
    district = Column(String(80), index=True)
    state = Column(String(60))
    food_category = Column(String(40))
    total_packs_recommended = Column(Integer, default=0)
    avg_predicted_shelf_life_hours = Column(Numeric(10, 2))
    avg_cost_per_pack_inr = Column(Numeric(8, 2))
    avg_co2e_per_pack_kg = Column(Numeric(8, 4))
    common_packaging_gap = Column(Text)
    common_packaging_gap_translations = Column(JSONB, default=dict)
    stat_period_start = Column(Date)
    stat_period_end = Column(Date)
    computed_at = Column(DateTime, default=datetime.utcnow)

class CommunityOutcome(Base):
    __tablename__ = "community_outcomes"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pack_id = Column(Integer, ForeignKey("packs.id"))
    region = Column(String(80), index=True)
    predicted_shelf_life_hours = Column(Numeric(10, 2))
    actual_shelf_life_hours = Column(Numeric(10, 2))
    logged_at = Column(DateTime, default=datetime.utcnow)

    pack = relationship("Pack", back_populates="community_outcomes")

class WhatsAppSession(Base):
    __tablename__ = "whatsapp_sessions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    phone_number = Column(String(15), index=True)
    last_intent = Column(String(60))
    conversation_state = Column(JSONB, default=dict)
    updated_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="whatsapp_sessions")

# SECTION 1.3: PACK LABEL SCANS
class PackLabelScan(Base):
    __tablename__ = "pack_label_scans"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    raw_text = Column(Text, nullable=False)
    extracted_material = Column(String(60), nullable=True)
    extracted_thickness = Column(Numeric(6, 2), nullable=True)
    matched_film_id = Column(Integer, ForeignKey("films.id"), nullable=True)
    match_confidence = Column(SmallInteger, default=0)
    was_accepted_by_user = Column(Boolean, nullable=True) # feeds Section 1.5 continuous improvement
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
    matched_film = relationship("Film")

# PART 2: MULTILINGUAL SUPPORT (Section 2.3)
class I18nTemplate(Base):
    __tablename__ = "i18n_templates"

    id = Column(Integer, primary_key=True, autoincrement=True)
    template_key = Column(String(80), nullable=False)
    language_code = Column(String(10), nullable=False) # 'en', 'hi', 'mr', 'ta'
    template_text = Column(Text, nullable=False)
    needs_translation_review = Column(Boolean, default=True)

    __table_args__ = (
        UniqueConstraint("template_key", "language_code", name="uq_i18n_template_key_lang"),
    )

