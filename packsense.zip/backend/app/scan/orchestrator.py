"""
PackSense Scan Orchestrator & Full-Payload Cache Key Hashing (Part A.1, A.4, B.2)
"""

import hashlib
import json
import logging
import time
from typing import Dict, Any, Optional
from app.scan.resolver import resolve_scan_input

logger = logging.getLogger("packsense.scan.orchestrator")

# In-memory cache keyed strictly by full normalized payload SHA-256 (Part A.1)
_ANALYZE_CACHE: Dict[str, Dict[str, Any]] = {}
_SCAN_TRACE_LOGS: list = []


def compute_analyze_cache_key(payload: Dict[str, Any]) -> str:
    """
    Part A.1 Requirement:
    For /scan/analyze, the cache key MUST be a hash of the full normalized input payload:
    hashlib.sha256(json.dumps(payload, sort_keys=True).encode('utf-8')).hexdigest()
    Never just user_id + endpoint_name or user_id + food_id alone.
    """
    # Normalize payload while excluding volatile transport-only IDs if needed,
    # or include all structured domain fields sorted deterministically.
    normalized = {
        k: v
        for k, v in payload.items()
        if k not in ("scan_session_id", "scan_id", "captured_image", "captured_image_data_url")
    }
    serialized = json.dumps(normalized, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def record_scan_trace(
    scan_session_id: Optional[str],
    endpoint: str,
    food_id: Optional[str],
    status: str,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "scan_session_id": scan_session_id or "unassigned",
        "endpoint": endpoint,
        "food_id": food_id,
        "status": status,
        **(extra or {}),
    }
    _SCAN_TRACE_LOGS.append(entry)
    if len(_SCAN_TRACE_LOGS) > 200:
        _SCAN_TRACE_LOGS.pop(0)
    logger.info(
        "[ScanTrace] scan_session_id=%s endpoint=%s food_id=%s status=%s",
        entry["scan_session_id"],
        endpoint,
        food_id,
        status,
    )
    return entry


def get_scan_trace_logs() -> list:
    return list(_SCAN_TRACE_LOGS)


def analyze_scan_request(payload: Dict[str, Any], use_cache: bool = True) -> Dict[str, Any]:
    """
    Orchestrates /api/v1/scan/analyze:
    1. Resolves input via resolve_scan_input (Part A.4 - returns needs_input on low confidence).
    2. Computes full normalized SHA-256 cache key (Part A.1).
    3. Echoes scan_session_id and captured photo thumbnail reference (Part B.1 & B.2).
    """
    scan_session_id = payload.get("scan_session_id") or payload.get("scan_id") or f"scan-{int(time.time() * 1000)}"
    resolution = resolve_scan_input(payload)

    if resolution["needs_input"] or not resolution["food"]:
        record_scan_trace(
            scan_session_id=scan_session_id,
            endpoint="/api/v1/scan/analyze",
            food_id=None,
            status="needs_input",
            extra={"reason": resolution.get("reason")},
        )
        return {
            "status": "needs_input",
            "scan_session_id": scan_session_id,
            "reason": resolution.get("reason", "needs_input"),
            "missing": resolution.get("missing", ["food_id"]),
            "candidates": resolution.get("candidates", []),
            "suggested_foods": resolution.get("suggested_foods", []),
            "input": {
                "status": "needs_input",
                "data": {
                    "source": resolution["source"],
                    "food": None,
                    "scan_session_id": scan_session_id,
                    "captured_image": payload.get("captured_image") or payload.get("captured_image_data_url"),
                },
            },
        }

    food = resolution["food"]
    cache_key = compute_analyze_cache_key({**payload, "food_id": food["id"]})

    if use_cache and cache_key in _ANALYZE_CACHE:
        cached = json.loads(json.dumps(_ANALYZE_CACHE[cache_key]))
        # Always bind the current request's scan_session_id and captured_image (Part B.1 & B.2)
        cached["scan_session_id"] = scan_session_id
        cached["cache_key_sha256"] = cache_key
        cached["input"]["data"]["scan_session_id"] = scan_session_id
        if payload.get("captured_image") or payload.get("captured_image_data_url"):
            cached["input"]["data"]["captured_image"] = (
                payload.get("captured_image") or payload.get("captured_image_data_url")
            )
        record_scan_trace(
            scan_session_id=scan_session_id,
            endpoint="/api/v1/scan/analyze",
            food_id=food["id"],
            status="ok_cached",
            extra={"cache_key_sha256": cache_key},
        )
        return cached

    storage_temp_c = float(payload.get("storage_temp_c") or food["storage_temp_c"])
    ambient_rh_pct = float(payload.get("ambient_rh_pct") or food["optimal_rh_pct"])
    base_days = float(food["target_shelf_life_days"])
    q10 = 2.2
    temp_accel = q10 ** ((storage_temp_c - float(food["storage_temp_c"])) / 10.0)
    expected_days = max(1, round(base_days / temp_accel))

    result = {
        "status": "complete",
        "scan_session_id": scan_session_id,
        "cache_key_sha256": cache_key,
        "input": {
            "status": "ok",
            "data": {
                "source": resolution["source"],
                "food": {
                    "id": food["id"],
                    "name": food["name"],
                    "category": food["category"],
                },
                "ripeness": payload.get("ripeness_stage") or "breaker",
                "scan_session_id": scan_session_id,
                "captured_image": payload.get("captured_image") or payload.get("captured_image_data_url"),
            },
        },
        "food_profile": {
            "status": "ok",
            "data": food,
        },
        "twin": {
            "status": "ok",
            "data": {
                "storage_temp_c": storage_temp_c,
                "ambient_rh_pct": ambient_rh_pct,
                "shelf_life": {
                    "low_days": max(1, round(expected_days * 0.82)),
                    "expected_days": expected_days,
                    "high_days": max(2, round(expected_days * 1.22)),
                },
            },
        },
    }

    if use_cache:
        _ANALYZE_CACHE[cache_key] = json.loads(json.dumps(result))

    record_scan_trace(
        scan_session_id=scan_session_id,
        endpoint="/api/v1/scan/analyze",
        food_id=food["id"],
        status="complete",
        extra={"cache_key_sha256": cache_key},
    )
    return result
