"""
PackSense Scan Input Resolver (Part A.4 & Part B.1)
Resolves food commodity from ripeness scan, voice intent, manual pick, or pack label OCR.
CRITICAL RULE (Part A.4):
Never silently fall back to an arbitrary or "first" foods row on low confidence or missing input.
Confidence below threshold -> status: "needs_input" with top N candidate foods ranked by model confidence.
"""

import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger("packsense.scan.resolver")

CONFIDENCE_THRESHOLD = 0.75

KNOWN_FOODS_CATALOG: Dict[str, Dict[str, Any]] = {
    "roma_tomato": {
        "id": "roma_tomato",
        "Aliases": ["tomato", "roma_tomato", "tamatar", "hybrid_tomato"],
        "name": "Roma Tomato (Hybrid)",
        "category": "fresh_produce",
        "storage_temp_c": 12.0,
        "optimal_rh_pct": 90.0,
        "target_shelf_life_days": 14,
    },
    "cavendish_banana": {
        "id": "cavendish_banana",
        "Aliases": ["banana", "cavendish_banana", "kela", "robusta_banana"],
        "name": "Cavendish Banana",
        "category": "fresh_produce",
        "storage_temp_c": 14.0,
        "optimal_rh_pct": 90.0,
        "target_shelf_life_days": 21,
    },
    "alphonso_mango": {
        "id": "alphonso_mango",
        "Aliases": ["mango", "alphonso_mango", "aam", "ratnagiri_mango"],
        "name": "Alphonso Mango (Ratnagiri GI)",
        "category": "fresh_produce",
        "storage_temp_c": 12.0,
        "optimal_rh_pct": 85.0,
        "target_shelf_life_days": 28,
    },
    "shimla_apple": {
        "id": "shimla_apple",
        "Aliases": ["apple", "shimla_apple", "seb"],
        "name": "Shimla Royal Delicious Apple",
        "category": "fresh_produce",
        "storage_temp_c": 2.0,
        "optimal_rh_pct": 90.0,
        "target_shelf_life_days": 90,
    },
    "nashik_red_onion": {
        "id": "nashik_red_onion",
        "Aliases": ["onion", "nashik_red_onion", "pyaz", "red_onion"],
        "name": "Nashik Red Onion",
        "category": "fresh_produce",
        "storage_temp_c": 25.0,
        "optimal_rh_pct": 65.0,
        "target_shelf_life_days": 60,
    },
    "table_grapes_nashik": {
        "id": "table_grapes_nashik",
        "Aliases": ["grapes", "grape", "table_grapes_nashik", "angoor"],
        "name": "Nashik Thompson Seedless Grapes",
        "category": "fresh_produce",
        "storage_temp_c": 2.0,
        "optimal_rh_pct": 92.0,
        "target_shelf_life_days": 45,
    },
    "fresh_paneer_block": {
        "id": "fresh_paneer_block",
        "Aliases": ["paneer", "fresh_paneer_block", "malai_paneer"],
        "name": "Fresh Malai Paneer Block",
        "category": "dairy_cheese",
        "storage_temp_c": 4.0,
        "optimal_rh_pct": 80.0,
        "target_shelf_life_days": 21,
    },
    "potato_crisps": {
        "id": "potato_crisps",
        "Aliases": ["potato_crisps", "crisps", "chips"],
        "name": "Farm-Processed Potato Crisps",
        "category": "dry_snacks",
        "storage_temp_c": 25.0,
        "optimal_rh_pct": 50.0,
        "target_shelf_life_days": 120,
    },
}


def lookup_food(food_key: Optional[str]) -> Optional[Dict[str, Any]]:
    if not food_key:
        return None
    norm = str(food_key).strip().lower().replace(" ", "_")
    if norm in KNOWN_FOODS_CATALOG:
        return KNOWN_FOODS_CATALOG[norm]
    for entry in KNOWN_FOODS_CATALOG.values():
        if norm in entry["Aliases"]:
            return entry
    return None


def resolve_scan_input(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Part A.4 Audit & Fix:
    Resolves food from payload.
    If confidence < CONFIDENCE_THRESHOLD (and user_confirmed_food is not True)
    OR if food_id cannot be matched, returns status="needs_input" with ranked candidate foods.
    NEVER silently substitutes a default food.
    """
    scan_session_id = payload.get("scan_session_id") or payload.get("scan_id")
    source = payload.get("source") or "ripeness"
    confidence = payload.get("confidence")
    user_confirmed = bool(payload.get("user_confirmed_food", False))
    candidates_in = payload.get("candidates") or []

    # Check if low confidence from vision model without explicit user confirmation
    if confidence is not None and float(confidence) < CONFIDENCE_THRESHOLD and not user_confirmed:
        ranked_candidates = _build_ranked_candidates(candidates_in, payload.get("food_id"))
        logger.info(
            "[Resolver] scan_session_id=%s status=needs_input reason=low_confidence (%.2f < %.2f)",
            scan_session_id,
            float(confidence),
            CONFIDENCE_THRESHOLD,
        )
        return {
            "status": "needs_input",
            "needs_input": True,
            "reason": "low_confidence",
            "missing": ["food_id"],
            "food": None,
            "source": source,
            "scan_session_id": scan_session_id,
            "candidates": ranked_candidates,
            "suggested_foods": ranked_candidates,
        }

    # Resolve explicit food_id
    food_id = payload.get("food_id") or payload.get("food_detected")
    food = lookup_food(food_id)

    # Fallback to label_raw_text keyword matching if provided
    if not food and payload.get("label_raw_text"):
        raw_lower = str(payload["label_raw_text"]).lower()
        for entry in KNOWN_FOODS_CATALOG.values():
            if any(alias in raw_lower for alias in entry["Aliases"]):
                food = entry
                source = "pack_label"
                break

    if not food:
        ranked_candidates = _build_ranked_candidates(candidates_in, None)
        logger.info(
            "[Resolver] scan_session_id=%s status=needs_input reason=unmatched_food food_id=%s",
            scan_session_id,
            food_id,
        )
        return {
            "status": "needs_input",
            "needs_input": True,
            "reason": "unmatched_or_missing_food",
            "missing": ["food_id"],
            "food": None,
            "source": source,
            "scan_session_id": scan_session_id,
            "candidates": ranked_candidates,
            "suggested_foods": ranked_candidates,
        }

    return {
        "status": "ok",
        "needs_input": False,
        "food": food,
        "source": source,
        "scan_session_id": scan_session_id,
        "candidates": _build_ranked_candidates(candidates_in, food["id"]),
    }


def _build_ranked_candidates(
    candidates_in: List[Dict[str, Any]], primary_hint: Optional[str]
) -> List[Dict[str, Any]]:
    if candidates_in and isinstance(candidates_in, list):
        sorted_cands = sorted(
            candidates_in, key=lambda x: float(x.get("confidence", 0.0)), reverse=True
        )
        return sorted_cands[:5]

    default_list = []
    if primary_hint:
        matched = lookup_food(primary_hint)
        if matched:
            default_list.append(
                {
                    "id": matched["id"],
                    "food_id": matched["id"],
                    "name": matched["name"],
                    "category": matched["category"],
                    "confidence": 0.55,
                }
            )
    for key, item in KNOWN_FOODS_CATALOG.items():
        if not any(c["id"] == key for c in default_list):
            default_list.append(
                {
                    "id": item["id"],
                    "food_id": item["id"],
                    "name": item["name"],
                    "category": item["category"],
                    "confidence": round(max(0.15, 0.50 - len(default_list) * 0.08), 2),
                }
            )
    return default_list[:5]
