from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "PackSense"
    VERSION: str = "2.6.0"
    API_V1_STR: str = "/api/v1"
    ENV: str = "development"
    
    # Database & Cache
    DATABASE_URL: str = "postgresql+asyncpg://packsense:packsense@db:5432/packsense"
    DATABASE_URL_SYNC: str = "postgresql://packsense:packsense@db:5432/packsense"
    REDIS_URL: str = "redis://redis:6379/0"
    CELERY_BROKER_URL: str = "redis://redis:6379/0"
    
    # JWT Authentication
    JWT_SECRET_KEY: str = "packsense_engineering_secret_key_2026_super_secure_random_64_char"
    JWT_SECRET: Optional[str] = None
    JWT_ALGORITHM: str = "HS256"
    ALGORITHM: Optional[str] = None
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    
    # Twilio (WhatsApp, SMS & Twilio Verify OTP)
    TWILIO_ACCOUNT_SID: Optional[str] = None
    TWILIO_AUTH_TOKEN: Optional[str] = None
    TWILIO_WHATSAPP_FROM: str = "whatsapp:+14155238886"
    TWILIO_SMS_FROM: Optional[str] = None
    TWILIO_VERIFY_SERVICE_SID: Optional[str] = None
    
    # Bhashini Multilingual Speech & Translation API
    BHASHINI_API_KEY: Optional[str] = None
    BHASHINI_USER_ID: Optional[str] = None
    BHASHINI_INFERENCE_URL: Optional[str] = None
    
    # IMD climate data (Section 8.5)
    IMD_DATA_API_KEY: Optional[str] = None

    class Config:
        case_sensitive = True
        env_file = ".env"
        extra = "allow"

    @property
    def resolved_jwt_secret(self) -> str:
        return self.JWT_SECRET or self.JWT_SECRET_KEY

    @property
    def resolved_algorithm(self) -> str:
        return self.ALGORITHM or self.JWT_ALGORITHM

settings = Settings()
