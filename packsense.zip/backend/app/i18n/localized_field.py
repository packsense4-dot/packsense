"""
PackSense Localized Field Helper (Part 2 Section 2.4)
Picks row.field_translations.get(lang, row.field).
Falls back to the English column if translation is missing for that language,
so the API never returns a blank field.
"""

from typing import Any, Optional, Dict

def get_localized_field(
    row_or_dict: Any,
    field_name: str,
    lang: str = "en",
    fallback_default: str = ""
) -> str:
    """
    Extracts localized string from a DB model or dictionary.
    Looks for `{field_name}_translations` JSONB dictionary.
    Falls back to `row.{field_name}` (English column) if missing.
    Never returns blank text if English value exists.
    """
    clean_lang = (lang or "en").strip().lower()
    base_val = ""
    translations = None

    if isinstance(row_or_dict, dict):
        base_val = str(row_or_dict.get(field_name) or "")
        translations = row_or_dict.get(f"{field_name}_translations")
    else:
        base_val = str(getattr(row_or_dict, field_name, None) or "")
        translations = getattr(row_or_dict, f"{field_name}_translations", None)

    if clean_lang != "en" and isinstance(translations, dict):
        trans_val = translations.get(clean_lang)
        if trans_val and str(trans_val).strip():
            return str(trans_val).strip()

    return base_val.strip() if base_val.strip() else fallback_default
