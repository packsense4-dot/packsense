"""
PackSense Template Rendering Engine (Part 2 Section 2.3)
Looks up template by (template_key, requested_language, fallback='en')
and performs template_text.format(**variables).
Never returns blank text — missing translations always fall back to English.
"""

import os
import csv
from typing import Dict, Any, Optional

# Cache of templates: (template_key, language_code) -> template_text
I18N_TEMPLATES_CACHE: Dict[tuple, str] = {}

def load_templates():
    """Loads templates from seed CSV into memory cache."""
    if I18N_TEMPLATES_CACHE:
        return
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "..", "seed", "i18n_templates_seed.csv"),
        os.path.join(os.path.dirname(__file__), "..", "seed", "i18n_templates_seed.csv"),
        os.path.join(os.getcwd(), "seed", "i18n_templates_seed.csv"),
        "/app/applet/packsense-backend/seed/i18n_templates_seed.csv",
        "/packsense-backend/seed/i18n_templates_seed.csv"
    ]
    csv_file = None
    for p in possible_paths:
        if os.path.exists(p):
            csv_file = p
            break
    if not csv_file:
        return

    with open(csv_file, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = row.get("template_key", "").strip()
            lang = row.get("language_code", "").strip().lower()
            text = row.get("template_text", "").strip()
            if key and lang:
                I18N_TEMPLATES_CACHE[(key, lang)] = text

class SafeFormatter(dict):
    """Fallback for missing format variables to keep {var} placeholder rather than crash."""
    def __missing__(self, key):
        return f"{{{key}}}"

def render_template(template_key: str, lang: str = "en", **variables) -> str:
    """
    Renders template for given key and language.
    Falls back to 'en' if requested language is missing.
    Falls back to template_key if template not found in cache.
    Never returns blank text.
    """
    load_templates()
    clean_lang = (lang or "en").strip().lower()
    
    # 1. Lookup in requested language
    template_text = I18N_TEMPLATES_CACHE.get((template_key, clean_lang))
    
    # 2. Fallback to English
    if not template_text and clean_lang != "en":
        template_text = I18N_TEMPLATES_CACHE.get((template_key, "en"))
    
    # 3. Ultimate fallback
    if not template_text:
        return template_key
    
    # 4. Safe string format
    try:
        return template_text.format_map(SafeFormatter(**variables))
    except Exception:
        # Fallback to plain replace if format_map fails
        out = template_text
        for k, v in variables.items():
            out = out.replace(f"{{{k}}}", str(v))
        return out
