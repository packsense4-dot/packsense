"""
PackSense Multilingual i18n Package (Part 2)
Provides template rendering, localized model fields, and language catalog.
"""
from app.i18n.render_template import render_template
from app.i18n.localized_field import get_localized_field
from app.i18n.languages import router as languages_router, get_supported_languages

__all__ = ["render_template", "get_localized_field", "languages_router", "get_supported_languages"]
