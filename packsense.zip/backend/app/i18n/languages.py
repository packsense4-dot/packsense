"""
PackSense Supported Languages Endpoint (Part 2 Section 2.5)
GET /api/v1/i18n/languages
Returns the list of currently supported language codes and display names:
[{"code": "en", "name": "English"}, {"code": "hi", "name": "हिंदी"}, {"code": "mr", "name": "मराठी"}, {"code": "ta", "name": "தமிழ்"}]
"""

from fastapi import APIRouter, Query
from typing import List, Dict, Any, Union

router = APIRouter(prefix="/i18n", tags=["Multilingual"])

SUPPORTED_LANGUAGES_LIST: List[Dict[str, str]] = [
    {"code": "en", "name": "English"},
    {"code": "hi", "name": "हिंदी"},
    {"code": "mr", "name": "मराठी"},
    {"code": "ta", "name": "தமிழ்"}
]

SUPPORTED_LANGUAGES_DICT: Dict[str, Dict[str, str]] = {
    "en": {"code": "en", "name": "English", "native": "English"},
    "hi": {"code": "hi", "name": "Hindi", "native": "हिंदी"},
    "mr": {"code": "mr", "name": "Marathi", "native": "मराठी"},
    "ta": {"code": "ta", "name": "Tamil", "native": "தமிழ்"}
}

def get_supported_languages(as_list: bool = False) -> Union[List[Dict[str, str]], Dict[str, Any]]:
    if as_list:
        return SUPPORTED_LANGUAGES_LIST
    return {
        "status": "SUCCESS",
        "supported_languages": SUPPORTED_LANGUAGES_DICT,
        "languages": SUPPORTED_LANGUAGES_LIST,
        "default_language": "en"
    }

@router.get("/languages")
def list_languages(format: str = Query("dict")) -> Any:
    """Returns supported languages for client-side language pickers."""
    if format == "list":
        return SUPPORTED_LANGUAGES_LIST
    return get_supported_languages(as_list=False)
