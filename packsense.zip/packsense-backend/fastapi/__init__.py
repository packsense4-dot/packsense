import os
import sys
import inspect
from typing import Any, Callable, Dict, List, Optional, Union

class HTTPException(Exception):
    def __init__(self, status_code: int, detail: Any = None):
        self.status_code = status_code
        self.detail = detail
        super().__init__(str(detail))

class Param:
    def __init__(self, default: Any = ..., **kwargs):
        self.default = default
        self.extra = kwargs

def Body(default: Any = ..., **kwargs):
    return Param(default, **kwargs)

def Query(default: Any = ..., **kwargs):
    return Param(default, **kwargs)

def Header(default: Any = ..., **kwargs):
    return Param(default, **kwargs)

def Depends(dependency: Optional[Callable] = None):
    return Param(dependency)

def File(default: Any = ..., **kwargs):
    return Param(default, **kwargs)

class UploadFile:
    def __init__(self, filename: str = "upload.dat", content: bytes = b""):
        self.filename = filename
        self.content = content
    
    async def read(self) -> bytes:
        return self.content

class Route:
    def __init__(self, path: str, endpoint: Callable, methods: List[str]):
        self.path = path
        self.endpoint = endpoint
        self.methods = methods

class APIRouter:
    def __init__(self, prefix: str = "", tags: Optional[List[str]] = None):
        self.prefix = prefix
        self.tags = tags or []
        self.routes: List[Route] = []

    def add_api_route(self, path: str, endpoint: Callable, methods: List[str]):
        full_path = self.prefix + path if path else self.prefix
        if not full_path.startswith("/"):
            full_path = "/" + full_path
        self.routes.append(Route(full_path, endpoint, methods))

    def get(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.add_api_route(path, func, ["GET"])
            return func
        return decorator

    def post(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.add_api_route(path, func, ["POST"])
            return func
        return decorator

    def put(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.add_api_route(path, func, ["PUT"])
            return func
        return decorator

    def delete(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.add_api_route(path, func, ["DELETE"])
            return func
        return decorator

class FastAPI:
    def __init__(self, title: str = "FastAPI", version: str = "0.1.0", description: str = ""):
        self.title = title
        self.version = version
        self.description = description
        self.routes: List[Route] = []
        self.middlewares: List[Any] = []

    def add_middleware(self, middleware_class: Any, **kwargs):
        self.middlewares.append((middleware_class, kwargs))

    def include_router(self, router: APIRouter, prefix: str = ""):
        for r in router.routes:
            p = prefix + r.path
            self.routes.append(Route(p, r.endpoint, r.methods))

    def get(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.routes.append(Route(path, func, ["GET"]))
            return func
        return decorator

    def post(self, path: str, **kwargs):
        def decorator(func: Callable):
            self.routes.append(Route(path, func, ["POST"]))
            return func
        return decorator

class Response:
    def __init__(self, status_code: int, data: Any = None):
        self.status_code = status_code
        self._data = data

    def json(self):
        if isinstance(self._data, dict) or isinstance(self._data, list):
            return self._data
        return {}

    @property
    def text(self):
        return str(self._data)

class TestClient:
    def __init__(self, app: FastAPI):
        self.app = app

    def _match_route(self, path: str, method: str):
        # Clean path
        clean_path = path.split("?")[0].rstrip("/") or "/"
        for route in self.app.routes:
            if method not in route.methods:
                continue
            r_path = route.path.rstrip("/") or "/"
            # Check pattern match with {param}
            r_parts = r_path.split("/")
            p_parts = clean_path.split("/")
            if len(r_parts) == len(p_parts):
                path_params = {}
                matched = True
                for rp, pp in zip(r_parts, p_parts):
                    if rp.startswith("{") and rp.endswith("}"):
                        param_name = rp[1:-1]
                        path_params[param_name] = pp
                    elif rp != pp:
                        matched = False
                        break
                if matched:
                    return route, path_params
        return None, {}

    def _dispatch(self, method: str, path: str, json: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None):
        parsed_params = dict(params or {})
        if "?" in path:
            query_part = path.split("?", 1)[1]
            for item in query_part.split("&"):
                if "=" in item:
                    k, v = item.split("=", 1)
                    if k not in parsed_params:
                        parsed_params[k] = v
        params = parsed_params

        route, path_params = self._match_route(path, method)
        if not route:
            return Response(404, {"detail": f"Not found: {path}"})
        
        func = route.endpoint
        sig = inspect.signature(func)
        kwargs = {}
        
        for name, param in sig.parameters.items():
            if name in path_params:
                val = path_params[name]
                if param.annotation == int:
                    try: val = int(val)
                    except: pass
                elif param.annotation == float:
                    try: val = float(val)
                    except: pass
                kwargs[name] = val
            elif params and name in params:
                kwargs[name] = params[name]
            elif name in ["payload", "body", "data", "request"] and json is not None:
                kwargs[name] = json
            elif isinstance(param.default, Param):
                if method == "POST" and json is not None:
                    if isinstance(json, dict) and name in json:
                        kwargs[name] = json[name]
                    else:
                        kwargs[name] = json
                else:
                    kwargs[name] = param.default.default if param.default.default is not ... else None
            elif name == "current_user":
                kwargs[name] = {"email": "test@packsense.org", "role": "admin"}
            elif param.default is not inspect.Parameter.empty:
                kwargs[name] = param.default
            elif json is not None and len(sig.parameters) == 1:
                kwargs[name] = json
            else:
                kwargs[name] = None
        
        try:
            res = func(**kwargs)
            # Handle async def
            if inspect.iscoroutine(res):
                import asyncio
                res = asyncio.run(res)
            return Response(200, res)
        except HTTPException as he:
            return Response(he.status_code, {"detail": he.detail})
        except Exception as e:
            return Response(500, {"detail": str(e)})

    def get(self, path: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None):
        return self._dispatch("GET", path, params=params, headers=headers)

    def post(self, path: str, json: Any = None, data: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None):
        return self._dispatch("POST", path, json=json or data, params=params, headers=headers)
