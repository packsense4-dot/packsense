# PackSense Backend

Deterministic physics simulation, multi-objective packaging optimization, and cold-chain compliance gateway.
**Zero external LLM API calls in the runtime execution path.**

---

## 1. Architecture Overview
- **Framework**: FastAPI (Python 3.11+) modular router architecture
- **Database**: PostgreSQL 15 + PostGIS for spatial converter & supplier matching (ST_DWithin queries)
- **Physics Core (Section 6)**:
  - Fickian multi-layer laminate permeation solver (ASTM D3985 OTR / ASTM F1249 WVTR)
  - Michaelis-Menten enzyme produce respiration ($R_{O_2}, R_{CO_2}$)
  - Arrhenius & $Q_{10}$ dynamic temperature kinetics ($Rate(T) = Rate(T_0) \cdot Q_{10}^{(T - T_0)/10}$)
  - Steady-state MAP numerical root-finding (mass balance permeation = respiration)
  - Labuza critical moisture sorption isotherm equation
- **Multi-Objective Optimizer (Section 7)**:
  - NSGA-II non-dominated Pareto ranking (Shelf Life, Cost, $CO_2e$, Circularity)
  - Sub-millisecond surrogate queries with grounded SHAP explainability
- **Ripeness Vision Engine (Section 9)**:
  - MobileNetV3-Small transfer learning ONNX inference pipeline
  - Lookups into `food_ripeness_profiles` feeding real-time respiration multipliers
- **Hardware Telemetry (Section 8.3 & 8.5)**:
  - Bluetooth Low Energy (BLE) temperature logger ingestion
  - Real-time $Q_{10}$ dynamic shelf-life passport recomputation on every status call

---

## 2. Setup & Installation

### Option A: One-Command Docker Setup (Recommended)
Brings up API + PostgreSQL (PostGIS) + Redis + Celery worker, runs Alembic migrations, and seeds cited engineering data automatically:

```bash
# 1. Copy environment variables template
cp .env.example .env

# 2. Build and run containers
docker-compose up --build
```
The API is available at `http://localhost:8000` and interactive OpenAPI documentation at `http://localhost:8000/docs`.

### Option B: Local Python Development
```bash
# 1. Create and activate virtual environment
python3.11 -m venv .venv
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
cp .env.example .env
# Edit .env with your PostgreSQL, Redis, and secret keys

# 4. Run migrations and database seeding
alembic upgrade head
python -m app.seed.seed_data

# 5. Start development server
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## 3. Adding Real Bhashini Credentials (Section 8.2)
PackSense natively integrates with Government of India's **National Language Translation Mission (NLTM) Bhashini ULCA API** for Indian vernacular speech input and synthesis across 9 languages (Hindi, Marathi, Tamil, Telugu, Kannada, Gujarati, Bengali, Punjabi, English).

1. Register for API credentials at [Bhashini ULCA Portal](https://bhashini.gov.in/ulca).
2. Generate your API key and User ID under your institutional account.
3. Open `.env` and configure:
```env
BHASHINI_API_KEY="your_bhashini_api_key_here"
BHASHINI_USER_ID="your_bhashini_user_id_here"
BHASHINI_INFERENCE_URL="https://dhruva-api.bhashini.gov.in/services/inference/pipeline"
```
4. Restart the API container/server. When credentials are provided, speech synthesis and ASR route through Bhashini. If blank or unreachable, the local `faster-whisper` and pre-synthesized vernacular engines automatically handle offline fallback with zero downtime.

---

## 4. How to Train the MobileNetV3 Ripeness Model (Section 9)

PackSense includes the complete dataset curation and transfer learning pipeline:

### Step 1: Prepare Datasets
Download the public datasets referenced in Section 9.1:
- Fruits-360 (Kaggle)
- PlantVillage Open Foliar Dataset (Penn State)
- Mango Ripeness Dataset (Mendeley Data / iBEAN)

Run the normalization script to map categories to PackSense's 4-stage schema (`unripe`, `breaker`, `ripe`, `overripe`):
```bash
python scripts/prepare_ripeness_dataset.py \
  --data_dir ./data/raw \
  --output_dir ./data/processed_ripeness
```

### Step 2: Run Transfer Learning & ONNX Export
Fine-tune MobileNetV3-Small with data augmentations simulating Indian farm camera conditions and export the production `.onnx` model:
```bash
python -m app.ml.train_ripeness_model \
  --data_dir ./data/processed_ripeness \
  --epochs 20 \
  --batch_size 32 \
  --output_onnx app/ml/models/ripeness_v1.onnx
```
*Note*: If `ripeness_v1.onnx` is not present, the app automatically runs in spectrophotometric calibration mode, returning exact stage multipliers without crashing.

---

## 5. Running the Test Suite (Section 6 & Endpoints)

The test suite validates every physics formula independently and every API endpoint router:

```bash
# Run full test suite with PYTHONPATH set:
PYTHONPATH=. python3 -m unittest discover -s tests -p "test_*.py"

# Or with pytest:
pytest tests/ -v
```

The test suite includes 44 deterministic tests covering:
- Respiration Michaelis-Menten kinetics (`test_michaelis_menten.py`)
- Arrhenius / $Q_{10}$ temperature scaling (`test_arrhenius_q10.py`)
- Fickian diffusion & layer barrier calculations (`test_fick_diffusion.py`)
- Labuza moisture gain isotherm (`test_labuza_moisture.py`)
- Dew-point & condensation risk (`test_condensation.py`)
- Spoilage autopsy & failure mechanisms (`test_spoilage_baranyi.py`)
- Geometric right-sizing & thickness binary search (`test_right_sizing.py`)
- Live QR Passport $Q_{10}$ dynamic recomputation (`test_qr_passport_live.py`)
- All 23 endpoint routers (`test_endpoint_*.py`)

