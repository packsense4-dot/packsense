import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointSuppliers(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_get_suppliers(self):
        res = self.client.get("/api/v1/suppliers")
        self.assertEqual(res.status_code, 200)

    def test_match_suppliers(self):
        res = self.client.get("/api/v1/suppliers/match", params={"film_type": "Mono-PE", "lat": 18.5204, "lon": 73.8567})
        self.assertEqual(res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
