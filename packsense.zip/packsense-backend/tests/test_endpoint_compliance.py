import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointCompliance(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_compliance_audit(self):
        payload = {
            "film_material": "Mono-PE",
            "thickness_micron": 50.0,
            "layer_count": 1,
            "food_contact_approved": True,
            "food_category": "fresh_produce"
        }
        res = self.client.post("/api/v1/compliance/audit", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("compliant", data)

if __name__ == "__main__":
    unittest.main()
