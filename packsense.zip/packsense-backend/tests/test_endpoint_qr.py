import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointQr(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_qr_generate_and_status(self):
        gen_res = self.client.post("/api/v1/qr/generate", json={
            "commodity": "alphonso_mango",
            "batch_id": "BATCH-UNIT-01",
            "baseline_shelf_life_days": 21.0,
            "optimal_temp_c": 12.0
        })
        self.assertEqual(gen_res.status_code, 200)

        status_res = self.client.get("/api/v1/qr/BATCH-UNIT-01/status")
        self.assertEqual(status_res.status_code, 200)
        data = status_res.json()
        self.assertIn("remaining_shelf_life_hours", data)

if __name__ == "__main__":
    unittest.main()
