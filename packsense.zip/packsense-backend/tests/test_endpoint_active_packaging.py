import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointActivePackaging(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_active_packaging_recommend(self):
        payload = {
            "food_id": "alphonso_mango",
            "pack_volume_liters": 2.5,
            "target_shelf_life_days": 28.0,
            "scavenger_type": "ethylene"
        }
        res = self.client.post("/api/v1/active-packaging/recommend", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("oxygen_scavenger_capacity_cc" in data or "ethylene_scrubber_grams" in data or "formula_used" in data)

if __name__ == "__main__":
    unittest.main()
