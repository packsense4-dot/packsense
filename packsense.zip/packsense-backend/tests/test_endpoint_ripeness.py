import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointRipeness(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_ripeness_scan(self):
        payload = {
            "commodity": "alphonso_mango",
            "image_base64": "mock_test_image_base64_string",
            "current_temp_c": 15.0
        }
        res = self.client.post("/api/v1/ripeness/scan", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("ripeness_stage", data)

    def test_ripeness_samples(self):
        res = self.client.get("/api/v1/ripeness/samples")
        self.assertEqual(res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
