import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointReports(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_spec_sheet_report(self):
        res = self.client.get("/api/v1/reports/spec-sheet/PACK-TEST-001")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("fssai_certificate", data)

    def test_lab_trial_checklist_report(self):
        res = self.client.get("/api/v1/reports/lab-trial-checklist/PACK-TEST-001")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("test_suite", data)

if __name__ == "__main__":
    unittest.main()
