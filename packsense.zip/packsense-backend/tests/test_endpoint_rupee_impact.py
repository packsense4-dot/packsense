import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointRupeeImpact(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_rupee_impact_roi(self):
        payload = {
            "commodity": "alphonso_mango",
            "annual_volume_kg": 50000,
            "current_loss_pct": 22.0,
            "target_loss_pct": 8.0,
            "pack_cost_current_rs": 4.5,
            "pack_cost_proposed_rs": 6.8
        }
        res = self.client.post("/api/v1/rupee-impact/calculate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("net_annual_financial_gain_inr" in data or "roi_percent" in data)

if __name__ == "__main__":
    unittest.main()
