import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointSync(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_sync_pull(self):
        res = self.client.get("/api/v1/sync/pull")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("foods_count" in data or "films_count" in data or "status" in data)

    def test_sync_push(self):
        payload = {
            "offline_logs": [{"batch_id": "BATCH-OFF-1", "temp_c": 13.0, "timestamp": "2026-09-26T10:00:00Z"}]
        }
        res = self.client.post("/api/v1/sync/push", json=payload)
        self.assertEqual(res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
