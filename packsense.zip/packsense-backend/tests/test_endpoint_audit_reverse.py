import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointAuditReverse(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_reverse_audit(self):
        payload = {
            "current_film_material": "7-layer PE/EVOH/PA/Tie/LDPE",
            "current_thickness_um": 80.0,
            "annual_packs": 500000,
            "cost_per_m2_rs": 18.5,
            "food_id": "tomato_hybrid"
        }
        res = self.client.post("/api/v1/audit/reverse", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("barrier_efficiency_score_100" in data or "engineering_diagnosis" in data or "recommended_adjustment" in data)

if __name__ == "__main__":
    unittest.main()
