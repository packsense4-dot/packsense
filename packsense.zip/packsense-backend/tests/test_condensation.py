import unittest
from app.physics.features_suite import evaluate_condensation_risk

class TestCondensationPhysics(unittest.TestCase):
    def test_condensation_dew_point_evaluation(self):
        # High moisture scenario with cold transit dip below dew point
        payload_risk = {
            "internal_temp_c": 25.0,
            "internal_rh_percent": 90.0,
            "transit_min_temp_c": 15.0
        }
        res_risk = evaluate_condensation_risk(payload_risk)
        self.assertIn("dew_point_c", res_risk)
        self.assertIn("risk_level", res_risk)
        self.assertEqual(res_risk["risk_level"], "CRITICAL")

        # Dry produce at 20C, 25% RH with minimal cold swing
        payload_safe = {
            "internal_temp_c": 20.0,
            "internal_rh_percent": 25.0,
            "transit_min_temp_c": 18.0
        }
        res_safe = evaluate_condensation_risk(payload_safe)
        self.assertIn(res_safe["risk_level"], ["LOW", "NEGLIGIBLE"])

if __name__ == "__main__":
    unittest.main()
