import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointSimulate(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_simulate_shelf_life(self):
        payload = {
            "food_id": "alphonso_mango",
            "film_layers": [{"material_id": "ldpe", "thickness_um": 50}],
            "storage_temp_c": 12.0,
            "ambient_rh": 65.0
        }
        res = self.client.post("/api/v1/simulate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("predicted_shelf_life_days" in data or "predicted_days" in data)

if __name__ == "__main__":
    unittest.main()
