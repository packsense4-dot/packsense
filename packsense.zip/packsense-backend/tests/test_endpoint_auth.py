import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointAuth(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_login_farmer(self):
        res = self.client.post("/api/v1/auth/login", json={"email": "farmer@packsense.org", "password": "password123"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("access_token", data)
        self.assertEqual(data["role"], "farmer")

    def test_login_admin(self):
        res = self.client.post("/api/v1/auth/login", json={"email": "admin@packsense.org", "password": "password123"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["role"], "admin")

if __name__ == "__main__":
    unittest.main()
