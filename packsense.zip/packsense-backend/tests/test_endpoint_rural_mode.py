import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointRuralMode(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_rural_mode_recommendations(self):
        payload = {
            "commodity": "alphonso_mango",
            "region": "Konkan",
            "storage_context": "evaporative_cooling_chamber"
        }
        res = self.client.post("/api/v1/rural-mode/recommend", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("intervention_name" in data or "operational_protocol" in data or "alternatives" in data)

if __name__ == "__main__":
    unittest.main()
