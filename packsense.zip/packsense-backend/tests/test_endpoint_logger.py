import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointLogger(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_logger_reading_ingest(self):
        payload = {
            "device_id": "BLE-TAG-8821",
            "temp_c": 12.8,
            "rh_pct": 86.0
        }
        res = self.client.post("/api/v1/qr/BATCH-TEST-001/logger-reading", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("status" in data or "reading" in data or "readings_count" in data or "batch_id" in data)

if __name__ == "__main__":
    unittest.main()
