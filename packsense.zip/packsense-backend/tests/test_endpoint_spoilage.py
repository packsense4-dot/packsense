import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointSpoilage(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_spoilage_diagnose(self):
        payload = {
            "commodity": "alphonso_mango",
            "storage_temp_c": 26.0,
            "observed_symptoms": ["ballooning", "odor"]
        }
        res = self.client.post("/api/v1/spoilage/diagnose", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("primary_root_cause" in data or "root_cause" in data)

if __name__ == "__main__":
    unittest.main()
