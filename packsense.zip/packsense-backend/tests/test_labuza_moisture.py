import unittest
from app.physics.shelf_life import (
    labuza_critical_time,
    labuza_moisture_gain_step,
    calculate_equilibrium_moisture
)

class TestLabuzaMoisture(unittest.TestCase):
    def test_labuza_critical_time(self):
        """
        Labuza shelf life formula for moisture-sensitive dry food:
        t = (Wcp * b / (WVTR * A)) * ln[(Me - Mo) / (Me - Mc)]
        """
        m0 = 3.5  # 3.5%
        mc = 6.5  # 6.5% critical threshold
        me = 12.0 # 12.0% equilibrium
        wvtr = 1.5 # g / (m2 * day)
        area = 0.045 # m2
        wcp = 200.0 # 200g dry solids
        b = 0.12 # isotherm slope

        days = labuza_critical_time(m0, mc, me, wvtr, area, wcp, b)
        self.assertGreater(days, 0)
        self.assertTrue(10.0 < days < 500.0)

    def test_labuza_step_moisture_gain(self):
        """
        Verifies incremental moisture transfer over hourly dt
        """
        m_next = labuza_moisture_gain_step(
            m_current=3.5,
            me=12.0,
            wvtr_per_hour=1.5 / 24.0,
            area=0.045,
            wcp=200.0,
            b=0.12,
            dt_hours=1.0
        )
        self.assertGreater(m_next, 3.5)
        self.assertLess(m_next, 12.0)

if __name__ == "__main__":
    unittest.main()
