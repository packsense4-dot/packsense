import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointCommunity(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_community_learnings(self):
        res = self.client.get("/api/v1/community/learnings")
        self.assertEqual(res.status_code, 200)

    def test_community_regional_accuracy(self):
        res = self.client.get("/api/v1/community/regional-accuracy")
        self.assertEqual(res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
