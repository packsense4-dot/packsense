import unittest
from app.physics.respiration import (
    respiration_michaelis_menten,
    respiration_rate_at_temperature,
    temperature_dependence_q10,
    steady_state_pack_atmosphere
)

class TestMichaelisMenten(unittest.TestCase):
    def test_respiration_michaelis_menten_kinetics(self):
        vm = 48.0
        km = 2.0
        self.assertEqual(respiration_michaelis_menten(vm, 0.0, km), 0.0)
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 2.0, km), 24.0, places=5)
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 6.0, km), 36.0, places=5)
        self.assertAlmostEqual(respiration_michaelis_menten(vm, 1000.0, km), 47.904, places=2)

    def test_temperature_dependence_q10(self):
        r1 = 15.0
        q10 = 2.5
        r2 = temperature_dependence_q10(r1, 20.0, 10.0, q10)
        self.assertAlmostEqual(r2, 15.0 * 2.5, places=5)
        r0 = temperature_dependence_q10(r1, 0.0, 10.0, q10)
        self.assertAlmostEqual(r0, 15.0 / 2.5, places=5)

    def test_steady_state_numerical_pack_atmosphere(self):
        res = steady_state_pack_atmosphere(
            otr_film=3500.0,
            ctr_film=12000.0,
            area=0.045,
            weight=1.0,
            vm=35.0,
            km=2.5,
            temp_c=12.0,
            ref_temp_c=12.0,
            q10=2.2,
            rq=0.9
        )
        self.assertIn("equilibrium_o2_pct", res)
        self.assertIn("equilibrium_co2_pct", res)
        self.assertTrue(0.0 < res["equilibrium_o2_pct"] <= 21.0)
        self.assertTrue(res["equilibrium_co2_pct"] >= 0.0)

if __name__ == "__main__":
    unittest.main()
