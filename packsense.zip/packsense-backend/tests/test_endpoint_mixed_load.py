import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointMixedLoad(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_mixed_load_check(self):
        payload = {
            "commodities": ["alphonso_mango", "banana_robusta"],
            "transit_temp_c": 13.0,
            "duration_days": 4
        }
        res = self.client.post("/api/v1/mixed-load/check", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("overall_compatibility" in data or "incompatibilities" in data)

if __name__ == "__main__":
    unittest.main()
