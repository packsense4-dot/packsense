import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointVoice(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_voice_languages(self):
        res = self.client.get("/api/v1/voice/languages")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(len(data) > 0)

    def test_voice_transcribe_intent(self):
        payload = {
            "transcription": "Ratnagiri Alphonso Mango 21 days 12 degrees",
            "language": "en"
        }
        res = self.client.post("/api/v1/voice/transcribe-intent", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("intent", data)

if __name__ == "__main__":
    unittest.main()
