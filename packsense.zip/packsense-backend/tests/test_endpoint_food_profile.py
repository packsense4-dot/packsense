import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointFoodProfile(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_list_foods(self):
        res = self.client.get("/api/v1/foods")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(isinstance(data, list) or "foods" in data)

    def test_get_single_food(self):
        res = self.client.get("/api/v1/foods/alphonso_mango")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("name", data)

if __name__ == "__main__":
    unittest.main()
