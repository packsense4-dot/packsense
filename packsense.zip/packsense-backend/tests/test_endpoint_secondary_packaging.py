import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointSecondaryPackaging(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_secondary_packaging(self):
        payload = {
            "primary_packs_count": 24,
            "primary_pack_weight_g": 500.0,
            "box_type": "cfb_5ply",
            "stack_height": 5
        }
        res = self.client.post("/api/v1/secondary-packaging/recommend", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("box_compression_test_bct_kn" in data or "shipper_bct_kn" in data)

if __name__ == "__main__":
    unittest.main()
