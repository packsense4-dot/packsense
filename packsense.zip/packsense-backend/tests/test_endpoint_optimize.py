import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointOptimize(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_run_optimization(self):
        payload = {
            "food": {"name": "Ratnagiri Alphonso Mango", "target_shelf_life_days": 21, "category": "fruit"},
            "storage_temp_c": 15.0,
            "ambient_rh_pct": 65.0
        }
        res = self.client.post("/api/v1/optimize", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("ranked_packs" in data or "pareto_frontier_count" in data or "pareto_front" in data)

if __name__ == "__main__":
    unittest.main()
