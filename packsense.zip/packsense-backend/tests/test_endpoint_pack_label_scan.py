import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointPackLabelScan(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_pack_label_scan_bopp_met_pouch(self):
        payload = {
            "ocr_text": "BOPP 20 micron / Met-BOPP 18 micron / CPP 30 micron High Barrier Snack Web FSSAI Approved",
            "lang": "en"
        }
        res = self.client.post("/api/v1/pack-label/scan", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("status"), "SUCCESS")
        self.assertIn("matched_film", data)
        self.assertIn("name", data["matched_film"])
        self.assertTrue(data.get("confidence_score", 0) > 0.5)
        self.assertIn("explanation", data)

    def test_pack_label_scan_mono_pe_hindi(self):
        payload = {
            "ocr_text": "Mono-Material PE Recyclable LDPE 40 um #4 RIC CEFLEX Class A",
            "lang": "hi"
        }
        res = self.client.post("/api/v1/label-scan", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("status"), "SUCCESS")
        self.assertEqual(data.get("language"), "hi")
        self.assertIn("व्याख्या", str(data["explanation"]) + " " + data["explanation"])

    def test_pack_label_scan_marathi_and_tamil(self):
        payload_mr = {
            "ocr_text": "Bio-PBS 25 micron / PBAT 30 micron Compostable IS 17088",
            "lang": "mr"
        }
        res_mr = self.client.post("/api/v1/pack-label/scan", json=payload_mr)
        self.assertEqual(res_mr.status_code, 200)
        self.assertEqual(res_mr.json().get("language"), "mr")

        payload_ta = {
            "ocr_text": "Cast Polypropylene CPP 30 micron",
            "lang": "ta"
        }
        res_ta = self.client.post("/api/v1/pack-label/scan", json=payload_ta)
        self.assertEqual(res_ta.status_code, 200)
        self.assertEqual(res_ta.json().get("language"), "ta")

if __name__ == "__main__":
    unittest.main()
