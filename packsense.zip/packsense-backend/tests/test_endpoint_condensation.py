import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointCondensation(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_condensation_risk(self):
        payload = {
            "internal_temp_c": 25.0,
            "internal_rh_percent": 90.0,
            "transit_min_temp_c": 12.0
        }
        res = self.client.post("/api/v1/condensation/risk", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("risk_level", data)

if __name__ == "__main__":
    unittest.main()
