import unittest
from app.physics.features_suite import diagnose_spoilage_autopsy

class TestSpoilageAutopsy(unittest.TestCase):
    def test_anaerobic_fermentation_diagnosis(self):
        payload = {
            "commodity": "alphonso_mango",
            "storage_temp_c": 28.0,
            "observed_symptoms": ["ballooning", "sour odor", "pouch distension"]
        }
        res = diagnose_spoilage_autopsy(payload)
        self.assertIn("primary_root_cause", res)
        self.assertIn("Anaerobic", res["primary_root_cause"])
        self.assertTrue(res["confidence_score_pct"] >= 90)
        self.assertTrue(len(res["failure_mechanisms"]) > 0)
        self.assertIn("target_otr_cc", res["corrective_engineering_actions"])

    def test_mold_condensation_diagnosis(self):
        payload = {
            "commodity": "alphonso_mango",
            "storage_temp_c": 15.0,
            "observed_symptoms": ["mold growth", "sweat droplets inside pouch"]
        }
        res = diagnose_spoilage_autopsy(payload)
        self.assertIn("primary_root_cause", res)
        self.assertTrue("Moisture" in res["primary_root_cause"] or "Fungal" in res["primary_root_cause"])
        self.assertTrue(len(res["contributing_stress_factors"]) > 0)

if __name__ == "__main__":
    unittest.main()
