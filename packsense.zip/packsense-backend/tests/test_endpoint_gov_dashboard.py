import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointGovDashboard(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_gov_dashboard_summary(self):
        res = self.client.get("/api/v1/gov/dashboard/summary")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue("total_batches_tracked" in data or "districts" in data or "mofpi_stats" in data or "total_postharvest_loss_reduced_tons" in data)

    def test_gov_dashboard_district(self):
        res = self.client.get("/api/v1/gov/dashboard/district/ratnagiri")
        self.assertEqual(res.status_code, 200)

if __name__ == "__main__":
    unittest.main()
