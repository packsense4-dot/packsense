import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointMultilingual(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_get_languages(self):
        res = self.client.get("/api/v1/i18n/languages")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("status"), "SUCCESS")
        self.assertIn("hi", data["supported_languages"])
        self.assertIn("mr", data["supported_languages"])
        self.assertIn("ta", data["supported_languages"])
        self.assertIn("en", data["supported_languages"])

    def test_translate_phrase(self):
        payload = {
            "text": "Oxygen Transmission Rate (OTR)",
            "lang": "hi"
        }
        res = self.client.post("/api/v1/i18n/translate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("ऑक्सीजन", data["translated_text"])

    def test_reference_text_marathi(self):
        res = self.client.get("/api/v1/i18n/reference-text?category=fssai_standards&lang=mr")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("language"), "mr")
        self.assertIn("content", data)
        self.assertIn("title", data["content"])

    def test_spoilage_multilingual_tamil(self):
        payload = {
            "commodity": "alphonso_mango",
            "storage_temp_c": 26.0,
            "observed_symptoms": ["ballooning", "odor"],
            "lang": "ta"
        }
        res = self.client.post("/api/v1/spoilage/diagnose", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("language"), "ta")
        self.assertIn("root_cause_localized", data)

    def test_lab_trial_checklist_multilingual_hindi(self):
        res = self.client.get("/api/v1/reports/lab-trial-checklist/PACK-TEST-001?lang=hi")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data.get("language"), "hi")
        self.assertIn("test_suite", data)
        self.assertIn("test_suite_localized", data)

if __name__ == "__main__":
    unittest.main()
