import unittest
from app.physics.features_suite import calculate_right_sizing

class TestRightSizingPhysics(unittest.TestCase):
    def test_geometric_and_thickness_right_sizing(self):
        payload = {
            "commodity": "tomato_hybrid",
            "net_weight_g": 500.0,
            "target_shelf_life_days": 18.0,
            "material": "ldpe"
        }
        res = calculate_right_sizing(payload)
        self.assertIn("optimal_thickness_micron", res)
        self.assertTrue(res["optimal_thickness_micron"] > 0)
        self.assertIn("optimal_width_mm", res)
        self.assertIn("optimal_length_mm", res)
        self.assertTrue(res["optimal_width_mm"] > 0)
        self.assertTrue(res["optimal_length_mm"] > 0)
        self.assertAlmostEqual(res["optimal_length_mm"] / res["optimal_width_mm"], 1.4, delta=0.2)

if __name__ == "__main__":
    unittest.main()
