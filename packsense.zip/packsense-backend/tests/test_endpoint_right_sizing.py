import unittest
from app.main import app
from fastapi.testclient import TestClient

class TestEndpointRightSizing(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_right_sizing_calculation(self):
        payload = {
            "commodity": "tomato_hybrid",
            "net_weight_g": 500.0,
            "target_shelf_life_days": 18.0,
            "material": "ldpe"
        }
        res = self.client.post("/api/v1/right-sizing/calculate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("optimal_thickness_micron", data)
        self.assertIn("optimal_width_mm", data)

if __name__ == "__main__":
    unittest.main()
