"""
Router 6: Ripeness CNN Inference & Retraining (Section 9)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.ml.inference import run_ripeness_inference
from app.workers.retrain_ripeness import log_ripeness_user_feedback

router = APIRouter(prefix="/ripeness", tags=["Ripeness"])

@router.post("/scan")
def scan_ripeness(payload: Dict[str, Any] = Body(...)):
    return run_ripeness_inference(payload)

@router.post("/feedback")
def feedback_ripeness(payload: Dict[str, Any] = Body(...)):
    return log_ripeness_user_feedback(payload)

@router.get("/samples")
def ripeness_samples():
    return {
        "samples": [
            {"commodity": "tomato", "stage": "breaker", "r": 210, "g": 140, "b": 60},
            {"commodity": "alphonso_mango", "stage": "ripe", "r": 230, "g": 185, "b": 45}
        ]
    }
