"""
Router 3: Digital Twin Simulation (Section 6)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.physics.engine import calculate_laminate_barrier, simulate_shelf_life
from app.db.seeds import FOODS_SEED_DATA

router = APIRouter(tags=["Simulate"])

@router.post("/simulate")
@router.post("/simulate/shelf-life")
def simulate(payload: Dict[str, Any] = Body(...)):
    food_id = payload.get("food_id") or payload.get("commodity") or "alphonso_mango"
    food = next((f for f in FOODS_SEED_DATA if f.get("id") == food_id or food_id.lower().replace("_", " ") in f.get("name", "").lower()), FOODS_SEED_DATA[0])
    layers = payload.get("layers") or payload.get("film_layers") or [{"material_id": "ldpe", "thickness_um": 50}]
    conds = payload.get("conditions") or {}
    
    storage_temp_c = float(conds.get("storage_temp_c") or payload.get("storage_temp_c") or 12.0)
    ambient_rh = float(conds.get("ambient_rh_percent") or payload.get("ambient_rh") or payload.get("ambient_rh_pct") or 85.0)
    package_area = float(payload.get("package_area_m2") or 0.05)
    
    barrier = calculate_laminate_barrier(layers, storage_temp_c, ambient_rh)
    res = simulate_shelf_life(food, barrier, temp_c=storage_temp_c, rh_percent=ambient_rh, package_area_m2=package_area)
    return res
