"""
Router 2: Food Profile (Section 5.1)
"""
from fastapi import APIRouter, Body, HTTPException
from typing import Dict, Any
from app.db.seeds import FOODS_SEED_DATA

router = APIRouter(tags=["Food Profile"])

@router.get("/foods")
def list_foods():
    return {"count": len(FOODS_SEED_DATA), "foods": FOODS_SEED_DATA}

@router.get("/foods/{food_id}")
def get_food(food_id: str):
    clean_id = food_id.lower().replace("_", " ")
    for f in FOODS_SEED_DATA:
        name_lower = f.get("name", "").lower()
        if f.get("id") == food_id or clean_id in name_lower or name_lower in clean_id:
            return f
    raise HTTPException(status_code=404, detail="Food not found")

@router.post("/food-profile")
def food_profile(payload: Dict[str, Any] = Body(...)):
    food_id = payload.get("food_id", "alphonso_mango")
    for f in FOODS_SEED_DATA:
        if f.get("id") == food_id:
            return {"food_profile": f, "confidence_score_pct": 96.0}
    return {"food_profile": FOODS_SEED_DATA[0], "confidence_score_pct": 90.0}
