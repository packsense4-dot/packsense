"""
Router 4: NSGA-II Packaging Optimizer (Section 7)
"""
from fastapi import APIRouter, Body
from typing import Dict, Any
from app.optimizer.nsga import run_nsga2_optimization
from app.db.seeds import FOODS_SEED_DATA, CLIMATE_PROFILES_SEED_DATA

router = APIRouter(tags=["Optimize"])

@router.post("/optimize")
@router.post("/optimize/packaging")
def optimize(payload: Dict[str, Any] = Body(...)):
    food = payload.get("food") or payload.get("food_profile") or FOODS_SEED_DATA[0]
    climate = payload.get("climate") or payload.get("climate_profile") or CLIMATE_PROFILES_SEED_DATA[0]
    geometry = payload.get("geometry") or {"area_m2": 0.045, "volume_cm3": 850.0}
    preferences = payload.get("preferences") or {}
    rules = payload.get("compliance_rules")
    return run_nsga2_optimization(food, climate, geometry, preferences, rules)
