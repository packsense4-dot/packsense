"""
PackSense Shelf-Life Kinetics & Moisture Transport Module
Food Physics & Packaging Engineering (Labuza Isotherm & Q10 Senescence)

Exact Formulas:
1. Shelf life vs temperature:
   SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)

2. Moisture gain — Labuza's equation (dry/snack foods):
   ln[(Me - Mo) / (Me - Mc)] = -(WVTR * A * t) / (Wcp * b)
"""

import math
from typing import Dict, Any, Optional


def shelf_life_temperature_q10(sl_t1: float, t2: float, t1: float, q10: float) -> float:
    """
    Shelf life vs temperature:
    SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)

    Parameters:
        sl_t1: Baseline shelf life at reference temperature T1 (hours or days)
        t2: Actual storage temperature (°C)
        t1: Reference baseline temperature (°C)
        q10: Temperature quotient Q10 (typically 1.8 - 2.5)

    Returns:
        SL(T2): Accelerated / decelerated shelf life at T2
    """
    delta_t = (t2 - t1) / 10.0
    divisor = q10 ** delta_t
    if divisor <= 0.0:
        return 0.0
    return sl_t1 / divisor


def labuza_critical_time(
    m0: float,
    mc: float,
    me: float,
    wvtr: float,
    area: float,
    wcp: float,
    b: float
) -> float:
    """
    Solves Labuza's equation for critical storage time t (days or hours):
    ln[(Me - Mo) / (Me - Mc)] = -(WVTR * A * t) / (Wcp * b)

    => t = (Wcp * b / (WVTR * A)) * ln[(Me - Mo) / (Me - Mc)]

    Parameters:
        m0: Initial product moisture content (% dry basis, g water / 100g dry solids)
        mc: Critical failure moisture content (% dry basis, e.g. crispness loss threshold)
        me: Equilibrium moisture content at ambient relative humidity (% dry basis)
        wvtr: Water Vapor Transmission Rate (per time unit, e.g. g / (m² · day) or g / (m² · hr))
        area: Package surface area (m²)
        wcp: Product dry solids mass (g or kg, matching WVTR units)
        b: Slope of the moisture sorption isotherm in the linear region (dM / daw, % dry basis)

    Returns:
        t: Time to reach critical moisture content Mc (same time units as WVTR)
    """
    if wvtr <= 0.0 or area <= 0.0:
        return float('inf')

    # If product is already at or above critical moisture
    if m0 >= mc:
        return 0.0

    # If driving force (Me - Mc) is non-positive, equilibrium moisture is below critical
    numerator = me - m0
    denominator = me - mc

    if denominator <= 0.0 or numerator <= 0.0:
        # Product will never exceed critical moisture in this ambient environment
        return float('inf')

    log_ratio = math.log(numerator / denominator)
    time_critical = (wcp * b / (wvtr * area)) * log_ratio
    return max(0.0, time_critical)


def labuza_moisture_gain_step(
    m_current: float,
    me: float,
    wvtr_per_hour: float,
    area: float,
    wcp: float,
    b: float,
    dt_hours: float = 1.0
) -> float:
    """
    Advances product moisture content by time step dt_hours using Labuza's differential relation:
    (Me - M(t + dt)) / (Me - M(t)) = exp(-(WVTR * A * dt) / (Wcp * b))

    => M(t + dt) = Me - (Me - M(t)) * exp(-(WVTR * A * dt) / (Wcp * b))

    Parameters:
        m_current: Current moisture content (% dry basis)
        me: Ambient equilibrium moisture content (% dry basis)
        wvtr_per_hour: Hourly WVTR of the packaging film (g / (m² · hr))
        area: Package surface area (m²)
        wcp: Product dry mass (g)
        b: Sorption isotherm slope (dM / daw)
        dt_hours: Duration of the step in hours (default 1.0)

    Returns:
        m_next: Moisture content after step (% dry basis)
    """
    if wcp <= 0.0 or b <= 0.0 or area <= 0.0 or wvtr_per_hour <= 0.0:
        return m_current

    exponent = -(wvtr_per_hour * area * dt_hours) / (wcp * b)
    m_next = me - (me - m_current) * math.exp(exponent)
    return m_next


def calculate_equilibrium_moisture(rh_pct: float, isotherm_b: float, isotherm_c: float = 0.0) -> float:
    """
    Approximates equilibrium moisture content Me from ambient RH:
    Me = c + b * (RH / 100)
    """
    aw = max(0.0, min(1.0, rh_pct / 100.0))
    return isotherm_c + (isotherm_b * aw)


def recompute_q10_remaining_shelf_life(
    batch: Dict[str, Any],
    readings: list,
    current_time_iso: Optional[str] = None
) -> Dict[str, Any]:
    """
    Section 6 & 8.5: Recomputes remaining_shelf_life_hours live on every status call
    using the real temperature log + Q10 formula (Section 6) — NOT a static countdown.
    Formula: Rate(T) = Rate(T_opt) * Q10 ^ ((T - T_opt) / 10)
    Degradation: sum(dt_hours * Q10 ^ ((T - T_opt) / 10))
    Remaining: max(0.0, baseline_shelf_life_hours - degradation)
    """
    from datetime import datetime, timezone

    batch_id = batch.get("batch_id", "BATCH-001")
    opt_temp = float(batch.get("optimal_temp_c", 12.0))
    q10 = float(batch.get("q10_value", 2.2))
    baseline_hours = float(batch.get("baseline_shelf_life_hours", float(batch.get("baseline_shelf_life_days", 21.0)) * 24.0))

    total_degradation_hours = 0.0
    excursions = 0
    excursion_thresh = max(opt_temp + 3.0, 15.0)

    if readings:
        parsed_readings = []
        for r in readings:
            ts_str = r.get("recorded_at") or r.get("timestamp")
            if not ts_str:
                dt_obj = datetime.now(timezone.utc)
            else:
                try:
                    dt_obj = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
                    if dt_obj.tzinfo is None:
                        dt_obj = dt_obj.replace(tzinfo=timezone.utc)
                except Exception:
                    dt_obj = datetime.now(timezone.utc)
            parsed_readings.append({
                "dt": dt_obj,
                "temp_c": float(r.get("temp_c", opt_temp)),
                "rh_pct": float(r.get("rh_pct", r.get("rh_percent", 85.0))),
                "device_id": r.get("device_id", "BLE-LOG-901"),
                "raw": r
            })
        parsed_readings.sort(key=lambda x: x["dt"])

        for i, pt in enumerate(parsed_readings):
            t = pt["temp_c"]
            if t > excursion_thresh:
                excursions += 1

            if i < len(parsed_readings) - 1:
                diff_sec = (parsed_readings[i + 1]["dt"] - pt["dt"]).total_seconds()
                dt_hours = max(0.05, min(48.0, diff_sec / 3600.0)) if diff_sec > 0 else 1.0
            else:
                if current_time_iso:
                    try:
                        now_dt = datetime.fromisoformat(str(current_time_iso).replace("Z", "+00:00"))
                        if now_dt.tzinfo is None:
                            now_dt = now_dt.replace(tzinfo=timezone.utc)
                    except Exception:
                        now_dt = datetime.now(timezone.utc)
                else:
                    now_dt = datetime.now(timezone.utc)
                diff_sec = (now_dt - pt["dt"]).total_seconds()
                dt_hours = max(0.1, min(72.0, diff_sec / 3600.0)) if diff_sec > 0 else 1.0

            accel = q10 ** ((t - opt_temp) / 10.0)
            total_degradation_hours += dt_hours * accel

    remaining_hours = max(0.0, round(baseline_hours - total_degradation_hours, 2))
    remaining_days = round(remaining_hours / 24.0, 2)
    compliance_score = max(10, min(100, round(100 - excursions * 12 - max(0.0, (total_degradation_hours - len(readings)) * 0.5))))

    quality_grade = "Grade A (Export)"
    if remaining_hours <= 0:
        quality_grade = "Expired / Spoiled"
    elif compliance_score < 60 or remaining_days < 2.0:
        quality_grade = "Discount / Process"
    elif compliance_score < 85 or remaining_days < 5.0:
        quality_grade = "Grade B (Domestic APMC)"

    return {
        "batch_id": batch_id,
        "passport_id": f"PASS-{batch_id}",
        "food_name": batch.get("food_name", "Agricultural Consignment"),
        "commodity": batch.get("commodity", "alphonso_mango"),
        "baseline_shelf_life_hours": baseline_hours,
        "baseline_shelf_life_days": round(baseline_hours / 24.0, 1),
        "remaining_shelf_life_hours": remaining_hours,
        "remaining_shelf_life_days": remaining_days,
        "adjusted_remaining_days": int(round(remaining_days)),
        "accumulated_degradation_hours": round(total_degradation_hours, 2),
        "optimal_temp_c": opt_temp,
        "q10_value": q10,
        "excursions_detected": excursions,
        "cold_chain_compliance_score": compliance_score,
        "quality_grade": quality_grade,
        "is_expired": remaining_hours <= 0,
        "total_logged_readings": len(readings),
        "status_call_timestamp": current_time_iso or datetime.utcnow().isoformat(),
        "readings": readings,
        "kinetics_formula": "remaining_shelf_life_hours = max(0, baseline_shelf_life_hours - sum(dt_i * Q10^((T_i - T_opt)/10)))",
        "authoritative_source": "Deterministic Q10 Kinetics Live Recompute (Section 6 & 8.5)",
        "qr_verification_url": f"https://packsense.org/passport/{batch_id}"
    }
