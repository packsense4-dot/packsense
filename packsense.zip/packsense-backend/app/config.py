"""
PackSense Configuration Module
Pydantic-settings loading .env with zero-LLM architecture and security defaults.
"""
import os
from typing import Optional

try:
    from pydantic_settings import BaseSettings
    class BaseSettingsClass(BaseSettings):
        class Config:
            case_sensitive = True
            env_file = ".env"
            extra = "allow"
except ImportError:
    class BaseSettingsClass:
        def __init__(self, **kwargs):
            for k, v in self.__class__.__dict__.items():
                if not k.startswith("_") and not callable(v) and not isinstance(v, property):
                    env_val = os.environ.get(k)
                    if env_val is not None:
                        setattr(self, k, env_val)
                    else:
                        setattr(self, k, v)
            for k, v in kwargs.items():
                setattr(self, k, v)

class Settings(BaseSettingsClass):
    PROJECT_NAME: str = "PackSense Backend"
    VERSION: str = "2.6.0"
    API_V1_STR: str = "/api/v1"
    ENV: str = "development"
    
    # Database & Cache
    DATABASE_URL: str = "postgresql+asyncpg://packsense:packsense@localhost:5432/packsense"
    DATABASE_URL_SYNC: str = "postgresql://packsense:packsense@localhost:5432/packsense"
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    
    # JWT Authentication (Email + Password only, no SMS/Twilio/WhatsApp per spec)
    JWT_SECRET_KEY: str = "packsense_engineering_secret_key_2026_super_secure_random_64_char"
    JWT_SECRET: Optional[str] = None
    JWT_ALGORITHM: str = "HS256"
    ALGORITHM: Optional[str] = None
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7 # 7 days
    
    # Bhashini Multilingual Speech & Translation API
    BHASHINI_API_KEY: Optional[str] = None
    BHASHINI_USER_ID: Optional[str] = None
    BHASHINI_INFERENCE_URL: Optional[str] = None
    
    # IMD climate data (Section 8.4)
    IMD_DATA_API_KEY: Optional[str] = None

    @property
    def resolved_jwt_secret(self) -> str:
        return self.JWT_SECRET or self.JWT_SECRET_KEY

    @property
    def resolved_algorithm(self) -> str:
        return self.ALGORITHM or self.JWT_ALGORITHM

settings = Settings()

