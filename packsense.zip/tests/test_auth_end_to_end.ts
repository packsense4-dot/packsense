import assert from 'assert';
import bcrypt from 'bcryptjs';
import {
  initDatabase,
  getDatabase,
  findUserByEmail,
  findUserById,
  insertUser,
  hashPassword,
  verifyPassword,
  storeRefreshToken,
  findRefreshTokenRecord,
  revokeRefreshToken,
  sanitizeUser
} from '../src/engine/database.ts';
import { signJwtToken, verifyJwtToken } from '../src/engine/jwtService.ts';

async function testAuthSuite() {
  console.log('--- RUNNING PACKSENSE AUTH & DB TEST SUITE ---');

  const db = initDatabase();
  assert(db.users !== undefined, 'Database users must be initialized');
  assert(Array.isArray(db.refresh_tokens), 'Refresh tokens table must exist');

  // Test 1: Password hashing & verification
  console.log('[Test 1] Testing bcrypt password hashing & verification...');
  const testPass = 'SecurePass2026!';
  const hash = hashPassword(testPass);
  assert(verifyPassword(testPass, hash) === true, 'Bcrypt verification must succeed for correct password');
  assert(verifyPassword('WrongPass', hash) === false, 'Bcrypt verification must fail for incorrect password');
  console.log('✓ Test 1 Passed: Password hashing works with standard bcrypt.');

  // Test 2: User registration validation & insertion
  console.log('[Test 2] Testing user creation and role restrictions...');
  const testEmail = `farmer_${Date.now()}@packsense.org`;
  const newUser = insertUser({
    email: testEmail,
    password: 'FarmerPassword123!',
    name: 'Suresh Patil',
    role: 'farmer',
    organization: 'Sahyadri Farmers Co-op'
  });

  assert(newUser.id > 0, 'New user must receive an ID');
  assert(newUser.email === testEmail.toLowerCase(), 'Email must be saved in lowercase');
  assert(verifyPassword('FarmerPassword123!', newUser.password_hash), 'Stored hash must verify against password');

  // Verify duplicate email prevention
  let dupThrew = false;
  try {
    insertUser({
      email: testEmail,
      password: 'AnotherPassword123!',
      name: 'Duplicate Suresh',
      role: 'farmer'
    });
  } catch (err: any) {
    dupThrew = true;
    assert(err.code === 'duplicate_email', 'Expected duplicate_email error code');
  }
  assert(dupThrew, 'Duplicate email registration must be rejected with duplicate_email error');
  console.log('✓ Test 2 Passed: User creation & duplicate email protection verified.');

  // Test 3: JWT token generation and verification
  console.log('[Test 3] Testing JWT access and refresh token lifecycle...');
  const accessPayload = { sub: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name };
  const accessToken = signJwtToken(accessPayload, 86400);
  const verifiedAccess = verifyJwtToken(accessToken);
  assert(verifiedAccess.valid === true && !!verifiedAccess.payload, 'Generated access token must verify successfully');
  assert(verifiedAccess.payload?.sub === newUser.id, 'Sub must match user ID');
  assert(verifiedAccess.payload?.role === 'farmer', 'Role must match farmer');

  const refreshPayload = { sub: newUser.id, type: 'refresh' };
  const refreshToken = signJwtToken(refreshPayload, 86400 * 30);
  const rec = storeRefreshToken(newUser.id, refreshToken);
  assert(rec.revoked === false, 'New refresh token must not be revoked');

  const lookupRec = findRefreshTokenRecord(refreshToken);
  assert(lookupRec !== undefined && lookupRec.user_id === newUser.id, 'Stored refresh token record must be found');

  revokeRefreshToken(refreshToken);
  const revokedRec = findRefreshTokenRecord(refreshToken);
  assert(revokedRec !== undefined && revokedRec.revoked === true, 'Revoked token must be marked as revoked');
  console.log('✓ Test 3 Passed: JWT tokens signed, verified, stored, and revoked properly.');

  // Test 4: Sanitize user (no password_hash in response)
  console.log('[Test 4] Testing user serialization security...');
  const sanitized = sanitizeUser(newUser);
  assert((sanitized as any).password_hash === undefined, 'Sanitized user must NEVER contain password_hash');
  assert(sanitized.email === newUser.email, 'Sanitized user must contain email');
  assert(sanitized.role === newUser.role, 'Sanitized user must contain role');
  console.log('✓ Test 4 Passed: Plaintext and hashed passwords are never exposed in user objects.');

  console.log('\n--- ALL AUTH & DB TESTS PASSED SUCCESSFULLY! ---');
}

testAuthSuite().catch(err => {
  console.error('Test suite failed:', err);
  process.exit(1);
});
