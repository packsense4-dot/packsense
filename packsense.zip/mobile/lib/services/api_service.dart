import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api/v1';

  // 1. Pack Label Scan (Part 1 Section 1.2)
  static Future<Map<String, dynamic>> scanPackLabel(String rawText, {String lang = 'en'}) async {
    final uri = Uri.parse('$baseUrl/pack-label/scan?lang=$lang');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'raw_text': rawText}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Failed to scan pack label: ${response.statusCode}');
  }

  // 2. Multilingual Languages (Part 2 Section 2.5)
  static Future<List<Map<String, String>>> getSupportedLanguages() async {
    final uri = Uri.parse('$baseUrl/i18n/languages?format=list');
    final response = await http.get(uri);
    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((e) => Map<String, String>.from(e)).toList();
    }
    return [
      {'code': 'en', 'name': 'English'},
      {'code': 'hi', 'name': 'हिंदी'},
      {'code': 'mr', 'name': 'मराठी'},
      {'code': 'ta', 'name': 'தமிழ்'}
    ];
  }

  // 3. Render Template (Part 2 Section 2.3)
  static Future<String> renderTemplate(String templateKey, String lang, Map<String, dynamic> vars) async {
    final uri = Uri.parse('$baseUrl/i18n/render-template');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'template_key': templateKey,
        'lang': lang,
        'variables': vars,
      }),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['rendered_text'] ?? templateKey;
    }
    return templateKey;
  }

  // 4. Reverse Pack Audit
  static Future<Map<String, dynamic>> performReverseAudit({
    required String foodId,
    required String filmType,
    required double thicknessMicron,
  }) async {
    final uri = Uri.parse('$baseUrl/audit/reverse');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'food_id': foodId,
        'film_material_type': filmType,
        'film_thickness_micron': thicknessMicron,
      }),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Audit failed');
  }

  // 5. Spoilage Diagnosis (Section 10 #10)
  static Future<Map<String, dynamic>> diagnoseSpoilage({
    required String commodity,
    required double storageTempC,
    required List<String> symptoms,
    String lang = 'en',
  }) async {
    final uri = Uri.parse('$baseUrl/spoilage/diagnose?lang=$lang');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'commodity': commodity,
        'storage_temp_c': storageTempC,
        'observed_symptoms': symptoms,
        'lang': lang,
      }),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Diagnosis failed');
  }

  // 6. Voice ASR Transcription (Section 8.2 Bhashini ASR)
  // Note: Voice input transcribes directly into a form field or triggers a specific action;
  // it NEVER opens a chat conversation.
  static Future<Map<String, dynamic>> transcribeVoice({
    required String audioBase64,
    String language = 'hi',
  }) async {
    final uri = Uri.parse('$baseUrl/voice/asr');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'audio_base64': audioBase64,
        'language': language,
      }),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Voice ASR failed');
  }

  // 7. Deterministic Simulation Execution (Section 6 & Section 10 #3)
  static Future<Map<String, dynamic>> simulateShelfLife(Map<String, dynamic> payload) async {
    final uri = Uri.parse('$baseUrl/simulate');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Simulation failed');
  }

  // 8. Multi-Objective Optimization (Section 7 & Section 10 #4)
  static Future<Map<String, dynamic>> optimizePackaging(Map<String, dynamic> payload) async {
    final uri = Uri.parse('$baseUrl/optimize');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Optimization failed');
  }

  // 9. QR Traceability Passport (Section 10 #16)
  static Future<Map<String, dynamic>> getQrPassport(String batchId) async {
    final uri = Uri.parse('$baseUrl/qr/passport/$batchId');
    final response = await http.get(uri);
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('QR Passport fetch failed');
  }

  // 10. Rural Mode Alternatives (Section 10 #17)
  static Future<List<dynamic>> getRuralAlternatives({String category = 'fresh_produce', String lang = 'en'}) async {
    final uri = Uri.parse('$baseUrl/rural/alternatives?category=$category&lang=$lang');
    final response = await http.get(uri);
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Rural alternatives fetch failed');
  }

  // 11. Offline-First Sync Gateway (Section 8.4)
  static Future<Map<String, dynamic>> pushOfflineSync(List<Map<String, dynamic>> transactions) async {
    final uri = Uri.parse('$baseUrl/sync/push');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'transactions': transactions}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception('Offline sync failed');
  }
}
