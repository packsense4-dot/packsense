import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class CommunityLoopScreen extends StatelessWidget {
  const CommunityLoopScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #18: Community Validation Loop')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'VALIDATED TRIALS',
                    value: '1,280',
                    unit: 'field trials recorded',
                    accentColor: AppColors.primaryEmerald,
                    badgeText: 'EMPIRICAL',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'MODEL ACCURACY',
                    value: '94.2',
                    unit: '% agreement with lab',
                    accentColor: AppColors.secondarySky,
                    badgeText: 'CONFIRMED',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            const Text('RECENT REGIONAL FIELD VALIDATIONS', style: AppTypography.statLabel),
            const SizedBox(height: 8),

            _trialCard('Nashik Grapes FPO (Maharashtra)', 'Mono-PE 40µm + SO2 pad', 'Actual shelf life: 28d vs simulated 26d (+7.6% gain). Zero berry drop.'),
            _trialCard('Ratnagiri Mango Growers Co-op', 'Micro-perforated bio-LDPE', 'Condensation eliminated completely across 1,500 km reefer transit.'),
            _trialCard('Malwa Potato Chips MSME (MP)', 'BOPP / Met-BOPP / CPP', 'Crispness maintained through monsoon 90% RH with zero sogginess.'),
          ],
        ),
      ),
    );
  }

  Widget _trialCard(String title, String pack, String result) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppColors.textPrimary)),
              const Icon(Icons.verified, size: 14, color: AppColors.primaryEmerald),
            ],
          ),
          const SizedBox(height: 2),
          Text(pack, style: const TextStyle(fontFamily: AppTypography.monoFamily, fontSize: 10, color: AppColors.secondarySky)),
          const SizedBox(height: 4),
          Text(result, style: AppTypography.body.copyWith(fontSize: 10)),
        ],
      ),
    );
  }
}
