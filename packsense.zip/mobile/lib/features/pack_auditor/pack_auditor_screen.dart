import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class PackAuditorScreen extends StatefulWidget {
  const PackAuditorScreen({Key? key}) : super(key: key);

  @override
  State<PackAuditorScreen> createState() => _PackAuditorScreenState();
}

class _PackAuditorScreenState extends State<PackAuditorScreen> {
  int _viewTab = 0; // 0: Film Auditor, 1: Barrier Gap Analysis, 2: Optimization
  final _ocrTextCtrl = TextEditingController(text: 'LDPE 40 MICRON FOOD GRADE IS 9845 COMPLIANT');
  String _matchedFilm = 'LDPE 40 micron mono-layer';
  double _currentShelfLife = 24.0;
  double _achievableShelfLife = 150.0;
  double _mismatchFactor = 6.2;
  bool _isAuditing = false;

  void _runAudit() {
    setState(() => _isAuditing = true);
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _isAuditing = false;
          _matchedFilm = 'LDPE 40 micron mono-layer (ASTM D3985)';
          _currentShelfLife = 24.0;
          _achievableShelfLife = 150.0;
          _mismatchFactor = 6.2;
        });
      }
    });
  }

  @override
  void dispose() {
    _ocrTextCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Pack Auditor (Reverse Engineering)'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['Film Audit', 'Barrier Gap', 'Remediation'],
              selectedIndex: _viewTab,
              onTabSelected: (idx) => setState(() => _viewTab = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('OCR SPECIFICATION PARSER', style: AppTypography.statLabel),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _ocrTextCtrl,
                    style: const TextStyle(fontFamily: AppTypography.monoFamily, fontSize: 12),
                    decoration: const InputDecoration(
                      labelText: 'Pouch Spec Sheet Text / OCR Scan',
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      minimumSize: const Size.fromHeight(44),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: _isAuditing ? null : _runAudit,
                    icon: const Icon(Icons.search, size: 18),
                    label: Text(_isAuditing ? 'Auditing Barrier...' : 'Run Reverse Audit'),
                  ),
                ],
              ),
            ),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('MATCHED SUBSTRATE & BARRIER GAP', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  Text(
                    _matchedFilm,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: NumericStatCard(
                          label: 'CURRENT LIFE',
                          value: '${_currentShelfLife.toInt()}',
                          unit: 'DAYS',
                          accentColor: AppColors.danger,
                          badgeText: 'SUB-OPTIMAL',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'ACHIEVABLE LIFE',
                          value: '${_achievableShelfLife.toInt()}',
                          unit: 'DAYS',
                          accentColor: AppColors.success,
                          badgeText: 'WITH BARRIER',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: NumericStatCard(
                          label: 'PERMEABILITY MISMATCH',
                          value: '${_mismatchFactor}x',
                          unit: 'Over-Permeation',
                          accentColor: AppColors.warning,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'FSSAI AUDIT',
                          value: 'PASS',
                          unit: 'IS 9845 Clean',
                          accentColor: AppColors.primary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
