import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/auth/auth_repository.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/profile_menu_row.dart';
import '../../core/widgets/info_bar.dart';

/// Section 5.10: Learn Tab Hub Screen
/// Hub screen with ProfileMenuRow-style entries:
/// - Low-Cost Rural Options (Feature #17)
/// - Why Is It Spoiling? (Feature #10, Spoilage Autopsy)
/// - Active Packaging Guide (Feature #11)
/// - Packaging Tips (general education)
/// - Regional Accuracy (Feature #18, role-gated for fpo/msme/industry)
class LearnScreen extends ConsumerWidget {
  const LearnScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final showRegionalAccuracy = [UserRole.fpo, UserRole.msme, UserRole.industry, UserRole.admin]
        .contains(authState.role);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Learn & Packaging Hub',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const InfoBar(
              text: 'Browse technical knowledge base, rural storage alternatives, and failure diagnostics.',
              icon: Icons.school_outlined,
            ),
            const SizedBox(height: 14),

            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.border),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x040F172A),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  ProfileMenuRow(
                    icon: Icons.water_drop_outlined,
                    label: 'Low-Cost Rural Storage (ZECC)',
                    subtitle: 'Evaporative cooling, jute & bio alternatives',
                    onTap: () => context.push('/rural-mode'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.border),
                  ProfileMenuRow(
                    icon: Icons.biotech_outlined,
                    label: 'Why Is It Spoiling? (Spoilage Autopsy)',
                    subtitle: 'Symptom diagnostic for mold, oxidation, sogginess',
                    onTap: () => context.push('/spoilage-autopsy'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.border),
                  ProfileMenuRow(
                    icon: Icons.shield_outlined,
                    label: 'Active Packaging Advisor',
                    subtitle: 'Oxygen scavengers, moisture pads, ethylene scrubbers',
                    onTap: () => context.push('/active-packaging'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.border),
                  ProfileMenuRow(
                    icon: Icons.lightbulb_outline_rounded,
                    label: 'Packaging Fundamentals & FSSAI Guide',
                    subtitle: 'OTR vs WVTR, IS 9845 migration, PWM 2022',
                    onTap: () {
                      _showFundamentalsModal(context);
                    },
                  ),
                  if (showRegionalAccuracy) ...[
                    const Divider(height: 1, indent: 64, color: AppColors.border),
                    ProfileMenuRow(
                      icon: Icons.query_stats_rounded,
                      label: 'Regional Prediction Accuracy',
                      subtitle: 'Community Learning Loop model verification',
                      onTap: () => context.push('/community-loop'),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFundamentalsModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        expand: false,
        builder: (_, scroll) => SingleChildScrollView(
          controller: scroll,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Packaging Engineering Principles',
                style: TextStyle(fontFamily: 'Poppins', fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 12),
              Text(
                '1. Oxygen Transmission Rate (OTR):\n'
                'Measured in cc/m²·day. High oxygen ingress triggers rapid lipid rancidity in fried snacks, nuts, and oil-rich produce.\n\n'
                '2. Water Vapor Transmission Rate (WVTR):\n'
                'Measured in g/m²·day. Essential for monsoon and tropical storage to keep internal moisture below critical sogginess thresholds (typically 4.5%).\n\n'
                '3. FSSAI IS 9845 Standard:\n'
                'Limits total chemical migration into simulants (water, 3% acetic acid, heptane) to under 10 mg/dm².',
                style: TextStyle(fontFamily: 'Inter', fontSize: 13, color: AppColors.textSecondary, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
