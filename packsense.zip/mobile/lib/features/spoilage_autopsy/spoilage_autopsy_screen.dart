import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class SpoilageAutopsyScreen extends StatefulWidget {
  const SpoilageAutopsyScreen({Key? key}) : super(key: key);

  @override
  State<SpoilageAutopsyScreen> createState() => _SpoilageAutopsyScreenState();
}

class _SpoilageAutopsyScreenState extends State<SpoilageAutopsyScreen> {
  final List<String> _selectedSymptoms = ['condensation', 'fermentation_odor'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #10: Spoilage Autopsy')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('OBSERVED FAILURE SYMPTOMS', style: AppTypography.statLabel),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      _symptomChip('condensation', 'Liquid Droplets / Fog'),
                      _symptomChip('fermentation_odor', 'Ethanol / Fermentation Odor'),
                      _symptomChip('pouch_ballooning', 'Pouch Ballooning (CO2)'),
                      _symptomChip('mold_growth', 'Visible Fungal Spores'),
                      _symptomChip('texture_loss', 'Sogginess / Crispness Loss'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'PRIMARY ROOT CAUSE',
                    value: 'ANAEROBIC',
                    unit: 'O2 < 0.5% depletion',
                    accentColor: AppColors.dangerRose,
                    badgeText: 'FERMENTATION',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'SECONDARY FACTOR',
                    value: 'CONDENSE',
                    unit: 'dew-point crossing',
                    accentColor: AppColors.warningAmber,
                    badgeText: 'FREE WATER',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.primaryEmerald.withOpacity(0.4)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('PRESCRIBED REMEDIATION (SECTION 10 #10)', style: AppTypography.statLabel),
                  SizedBox(height: 8),
                  Text(
                    '1. Switch from impermeable LDPE to laser micro-perforated film (450 holes/m², 80 µm diameter) to restore aerobic respiration equilibrium.\n\n'
                    '2. Apply internal anti-fog coating (glycerol monooleate) to spread condensed droplets into a transparent sheet, preventing fungal spore germination.\n\n'
                    '3. Pre-cool produce to 12°C before hermetic heat sealing to minimize vapor pressure differential.',
                    style: AppTypography.body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _symptomChip(String key, String label) {
    final isSelected = _selectedSymptoms.contains(key);
    return FilterChip(
      selected: isSelected,
      label: Text(label, style: TextStyle(fontSize: 11, color: isSelected ? Colors.white : AppColors.textSecondary)),
      selectedColor: AppColors.dangerRose.withOpacity(0.3),
      backgroundColor: AppColors.surfaceCard,
      side: BorderSide(color: isSelected ? AppColors.dangerRose : AppColors.border),
      onSelected: (val) {
        setState(() {
          if (val) _selectedSymptoms.add(key);
          else _selectedSymptoms.remove(key);
        });
      },
    );
  }
}
