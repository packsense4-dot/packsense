import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/api/dio_client.dart';
import '../../core/api/endpoints.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/primary_button.dart';

/// Section 4: Startup Connection Health Check Screen
/// - Calls /api/v1/health with 5-second timeout on startup
/// - If reachable -> proceeds to normal auth/onboarding routing
/// - If unreachable -> shows non-alarming fallback screen with "Retry" and "Continue Offline"
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  bool _isChecking = true;
  bool _isUnreachable = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _runHealthCheck();
  }

  Future<void> _runHealthCheck() async {
    setState(() {
      _isChecking = true;
      _isUnreachable = false;
      _errorMessage = '';
    });

    try {
      final response = await dio
          .get(Endpoints.health)
          .timeout(const Duration(seconds: 5));

      final isHealthy = response.statusCode == 200 &&
          (response.data['status'] == 'ok' || response.data['status'] == 'healthy');

      if (isHealthy) {
        if (!mounted) return;
        // Proceed to normal auth check routing
        _proceedToApp();
      } else {
        _setUnreachable('Server returned unexpected status code: ${response.statusCode}');
      }
    } catch (e) {
      _setUnreachable('Cannot establish handshake with backend gateway.');
    }
  }

  void _setUnreachable(String reason) {
    if (!mounted) return;
    setState(() {
      _isChecking = false;
      _isUnreachable = true;
      _errorMessage = reason;
    });
  }

  void _proceedToApp() {
    final authState = ref.read(authStateProvider);
    if (authState.isAuthenticated) {
      context.go('/home');
    } else {
      context.go('/onboarding');
    }
  }

  void _continueOffline() {
    // Route into app offline mode using cached local sqflite data
    context.go('/home');
  }

  @override
  Widget build(BuildContext context) {
    if (_isUnreachable) {
      return _buildUnreachableFallbackScreen();
    }

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.gradientStart, AppColors.gradientEnd],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Center Logo, Name & Tagline
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Cube/Leaf Logo Mark
                Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.16),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Stack(
                      alignment: Alignment.center,
                      children: const [
                        Icon(
                          Icons.view_in_ar_rounded,
                          color: AppColors.primary,
                          size: 48,
                        ),
                        Positioned(
                          right: 18,
                          top: 18,
                          child: Icon(
                            Icons.eco_rounded,
                            color: AppColors.success,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'PackSense AI',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Text(
                    'Smarter Packaging. Fresher Food. A Greener Future.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.white.withOpacity(0.92),
                      height: 1.3,
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                // Small subtle loading indicator
                const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2.2,
                  ),
                ),
              ],
            ),

            // Bottom White Wave Graphic & Footer Tag
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Column(
                children: [
                  CustomPaint(
                    size: const Size(double.infinity, 44),
                    painter: _WavePainter(),
                  ),
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.only(bottom: 22, top: 6),
                    alignment: Alignment.center,
                    child: const Text(
                      'Powered by AI + Physics + Sustainability',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section 4 Fallback Screen:
  /// Plain, non-alarming "Can't reach PackSense servers — check your connection"
  /// screen with a Retry button and a Continue Offline button.
  Widget _buildUnreachableFallbackScreen() {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: AppColors.warningTint,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.warning.withOpacity(0.4), width: 2),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.cloud_off_rounded,
                      color: AppColors.warning,
                      size: 40,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Can\'t reach PackSense servers',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Check your internet connection or local development backend. You can retry the connection or continue using cached offline models.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 13,
                  color: AppColors.textSecondary,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 32),

              // Primary Action: Retry Connection
              PrimaryButton(
                label: 'Retry Connection',
                icon: Icons.refresh_rounded,
                isLoading: _isChecking,
                onPressed: _runHealthCheck,
              ),
              const SizedBox(height: 12),

              // Secondary Action: Continue Offline
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryDark,
                  side: const BorderSide(color: AppColors.primary, width: 1.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: _continueOffline,
                icon: const Icon(Icons.offline_bolt_outlined, size: 18),
                label: const Text(
                  'Continue Offline (Local Cache)',
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final path = Path();
    path.moveTo(0, size.height);
    path.lineTo(0, size.height * 0.4);
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height * 0.8,
      size.width * 0.5,
      size.height * 0.4,
    );
    path.quadraticBezierTo(
      size.width * 0.75,
      0,
      size.width,
      size.height * 0.3,
    );
    path.lineTo(size.width, size.height);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
