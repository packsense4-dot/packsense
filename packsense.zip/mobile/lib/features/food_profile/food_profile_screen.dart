import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class FoodProfileScreen extends StatefulWidget {
  const FoodProfileScreen({Key? key}) : super(key: key);

  @override
  State<FoodProfileScreen> createState() => _FoodProfileScreenState();
}

class _FoodProfileScreenState extends State<FoodProfileScreen> {
  int _viewMode = 0; // 0: Profile Attributes, 1: Respiration Kinetics, 2: Secondary Scans
  String _commodity = 'Alphonso Mango';
  double _ripenessStage = 3.0; // 1-5
  double _targetStorageTemp = 13.0;
  double _respirationRate = 28.5; // mg CO2/kg·h

  void _simulateRipenessCamera() {
    setState(() {
      _ripenessStage = 4.0;
      _respirationRate = 42.0;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('MobileNetV3 Ripeness Scanner: Stage 4 (Climacteric Peak Detected)'),
        backgroundColor: AppColors.primaryDark,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Produce & Food Profile'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['Attributes', 'Respiration Kinetics', 'Secondary Scans'],
              selectedIndex: _viewMode,
              onTabSelected: (idx) => setState(() => _viewMode = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('COMMODITY SELECTION', style: AppTypography.statLabel),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: _commodity,
                    dropdownColor: AppColors.surfaceCard,
                    decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10)),
                    items: const [
                      DropdownMenuItem(value: 'Alphonso Mango', child: Text('Alphonso Mango (हापूस आंबा)')),
                      DropdownMenuItem(value: 'Potato Chips', child: Text('Potato Chips (आलू चिप्स / वेफर्स)')),
                      DropdownMenuItem(value: 'Tomato Puree', child: Text('Tomato Puree (टोमॅटो प्युरी)')),
                      DropdownMenuItem(value: 'Basmati Rice', child: Text('Basmati Rice (बासमती चावल)')),
                    ],
                    onChanged: (val) {
                      if (val != null) setState(() => _commodity = val);
                    },
                  ),
                ],
              ),
            ),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('PHYSIOLOGICAL PROPERTIES', style: AppTypography.statLabel),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: NumericStatCard(
                          label: 'RESPIRATION RATE',
                          value: '$_respirationRate',
                          unit: 'mg CO₂/kg·h',
                          accentColor: AppColors.primary,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'OPT. STORAGE TEMP',
                          value: '$_targetStorageTemp',
                          unit: '°C (Chilled)',
                          accentColor: AppColors.primaryDark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: NumericStatCard(
                          label: 'RIPENESS STAGE',
                          value: 'Stage ${_ripenessStage.toInt()}',
                          unit: 'Maturity Index',
                          accentColor: AppColors.success,
                          badgeText: 'CLIMACTERIC',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'ETHYLENE FLUX',
                          value: '1.8',
                          unit: 'µL/kg·h',
                          accentColor: AppColors.warning,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Secondary option: Ripeness Camera Scan
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('SECONDARY SENSING OPTION', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  const Text(
                    'Re-calibrate produce parameters using on-device optical computer vision.',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryDark,
                      side: const BorderSide(color: AppColors.primary),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: _simulateRipenessCamera,
                    icon: const Icon(Icons.camera_alt, color: AppColors.primary),
                    label: const Text('Launch Ripeness Camera Classifier'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
