import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/auth/auth_repository.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/profile_menu_row.dart';
import '../../core/widgets/rounded_card.dart';

/// Section 5.11: Profile Tab
/// Avatar + name + email header, ProfileMenuRow list,
/// role-conditional Admin Panel and Government Dashboard,
/// bottom decorative wave graphic with sustainability tagline.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final isAdmin = authState.role == UserRole.admin;
    final isGovOrAdmin = authState.role == UserRole.government || authState.role == UserRole.admin;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Profile & Settings',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // User Avatar + Name + Email Header
                  RoundedCard(
                    child: Row(
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          decoration: BoxDecoration(
                            color: AppColors.primaryTint,
                            shape: BoxShape.circle,
                            border: Border.all(color: AppColors.border, width: 1.5),
                          ),
                          child: const Center(
                            child: Icon(Icons.person, color: AppColors.primary, size: 28),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                authState.user?.name ?? 'Ramesh Patil',
                                style: const TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 1),
                              Text(
                                authState.user?.email ?? 'ramesh.patil@agrifpo.in',
                                style: const TextStyle(
                                  fontFamily: 'Inter',
                                  fontSize: 11,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.primaryTint,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  authState.role.displayName.toUpperCase(),
                                  style: const TextStyle(
                                    fontFamily: 'Inter',
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primaryDark,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Menu Card
                  RoundedCard(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Column(
                      children: [
                        ProfileMenuRow(
                          icon: Icons.history_rounded,
                          label: 'My Scans',
                          subtitle: 'View scanned packaging history',
                          onTap: () => context.go('/history'),
                        ),
                        const Divider(height: 1, indent: 64, color: AppColors.border),
                        ProfileMenuRow(
                          icon: Icons.description_outlined,
                          label: 'Packaging Reports',
                          subtitle: 'Past simulation PDFs & Excel exports',
                          onTap: () => context.push('/reports'),
                        ),
                        const Divider(height: 1, indent: 64, color: AppColors.border),
                        ProfileMenuRow(
                          icon: Icons.bookmark_border_rounded,
                          label: 'Saved Products & Films',
                          subtitle: 'Bookmarked laminate specifications',
                          onTap: () {},
                        ),
                        const Divider(height: 1, indent: 64, color: AppColors.border),
                        ProfileMenuRow(
                          icon: Icons.translate_rounded,
                          label: 'Settings & Language',
                          subtitle: 'English / हिंदी / मराठी / தமிழ்',
                          onTap: () => _showLanguageModal(context, ref, authState.language),
                        ),
                        const Divider(height: 1, indent: 64, color: AppColors.border),
                        ProfileMenuRow(
                          icon: Icons.help_outline_rounded,
                          label: 'Help & Support',
                          subtitle: 'Technical assistance & manual',
                          onTap: () {},
                        ),
                        const Divider(height: 1, indent: 64, color: AppColors.border),
                        ProfileMenuRow(
                          icon: Icons.info_outline_rounded,
                          label: 'About PackSense AI',
                          subtitle: 'v2.4.0 · Deterministic Physics Kernel',
                          onTap: () {},
                        ),

                        // Role-Conditional Entries (Admin & Gov)
                        if (isGovOrAdmin) ...[
                          const Divider(height: 1, indent: 64, color: AppColors.border),
                          ProfileMenuRow(
                            icon: Icons.account_balance_outlined,
                            label: 'Government Dashboard',
                            subtitle: 'District food-loss heatmaps & subsidies',
                            iconColor: AppColors.primaryDark,
                            onTap: () => context.push('/gov-dashboard'),
                          ),
                        ],
                        if (isAdmin) ...[
                          const Divider(height: 1, indent: 64, color: AppColors.border),
                          ProfileMenuRow(
                            icon: Icons.admin_panel_settings_outlined,
                            label: 'Admin Panel',
                            subtitle: 'Master materials database CRUD & logs',
                            iconColor: AppColors.danger,
                            onTap: () => context.push('/admin'),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Bottom Decorative Wave Graphic with Sustainability Tagline
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 24, bottom: 20),
              child: Column(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: const BoxDecoration(
                      color: AppColors.successTint,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.eco_rounded, color: AppColors.success, size: 20),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Smarter Packaging. Fresher Food. A Greener Future.',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showLanguageModal(BuildContext context, WidgetRef ref, String current) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Select Language', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 12),
              _buildLangTile(ctx, ref, 'en', 'English', current),
              _buildLangTile(ctx, ref, 'hi', 'हिंदी (Hindi)', current),
              _buildLangTile(ctx, ref, 'mr', 'मराठी (Marathi)', current),
              _buildLangTile(ctx, ref, 'ta', 'தமிழ் (Tamil)', current),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLangTile(BuildContext ctx, WidgetRef ref, String code, String label, String current) {
    return ListTile(
      title: Text(label, style: TextStyle(fontFamily: 'Inter', fontWeight: code == current ? FontWeight.bold : FontWeight.normal)),
      trailing: code == current ? const Icon(Icons.check, color: AppColors.primary) : null,
      onTap: () {
        ref.read(authStateProvider.notifier).switchLanguage(code);
        Navigator.pop(ctx);
      },
    );
  }
}
