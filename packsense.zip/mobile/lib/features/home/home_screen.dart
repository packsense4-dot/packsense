import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/auth/auth_repository.dart';
import '../../core/offline/connectivity_provider.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/icon_circle_badge.dart';
import '../../core/widgets/settings_grid_tile.dart';
import '../../core/widgets/gradient_hero_card.dart';
import '../../core/widgets/info_bar.dart';

/// Section 5.3: Home Screen
/// - Top row: logo/app name + notification bell
/// - "Hello, 👋 [name]" heading, "Scan a product to get started" subtitle
/// - GradientHeroCard "Scan Barcode"
/// - Secondary row of smaller scan options ("Or: Scan Ripeness · Speak · Enter Manually")
/// - 2×2 or 2×3 SettingsGridTile grid (My History, Learn, Rupee Impact, Rural ZECC, role-gated Business Tools)
/// - Slim InfoBar offline indicator when disconnected (Section 5.16)
class HomeScreen extends ConsumerWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);
    final connectivity = ref.watch(connectivityProvider);
    final isBusinessRole = [UserRole.industry, UserRole.admin, UserRole.government].contains(authState.role);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Row(
          children: const [
            IconCircleBadge(
              icon: Icons.qr_code_scanner,
              size: 32,
              iconSize: 16,
            ),
            SizedBox(width: 8),
            Text(
              'PackSense AI',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
                letterSpacing: -0.3,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded, color: AppColors.textPrimary),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Slim Offline InfoBar (Section 5.16)
            if (!connectivity.isOnline)
              const InfoBar(
                text: 'Offline — will sync when connected',
                icon: Icons.wifi_off_rounded,
                backgroundColor: AppColors.warningTint,
                iconColor: AppColors.warning,
                textColor: Color(0xFF92400E),
              ),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Greeting & Subtitle
                    Text(
                      'Hello, 👋 ${authState.user?.name ?? 'Farmer'}',
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    const Text(
                      'Scan a product to get started',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 13,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Primary Entry: GradientHeroCard "Scan Barcode" (Section 4.1)
                    GradientHeroCard(
                      icon: Icons.qr_code_scanner,
                      title: 'Scan Barcode',
                      subtitle: 'Point camera at any pouch or label to analyze film barrier specs instantly.',
                      buttonText: 'Scan Now',
                      onTap: () => context.push('/scan'),
                    ),
                    const SizedBox(height: 10),

                    // Secondary smaller row beneath: "Or: Scan Ripeness · Speak · Enter Manually"
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Or:',
                            style: TextStyle(fontFamily: 'Inter', fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                          ),
                          InkWell(
                            onTap: () => context.push('/food-profile'),
                            child: const Text(
                              'Scan Ripeness',
                              style: TextStyle(fontFamily: 'Inter', fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary),
                            ),
                          ),
                          const Text('·', style: TextStyle(color: AppColors.border)),
                          InkWell(
                            onTap: () => context.push('/food-profile'),
                            child: const Text(
                              'Speak',
                              style: TextStyle(fontFamily: 'Inter', fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary),
                            ),
                          ),
                          const Text('·', style: TextStyle(color: AppColors.border)),
                          InkWell(
                            onTap: () => context.push('/food-profile'),
                            child: const Text(
                              'Enter Manually',
                              style: TextStyle(fontFamily: 'Inter', fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Shortcuts Grid (Section 5.3: 2x2 or 2x3 grid)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text(
                          'SHORTCUTS',
                          style: TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textSecondary,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 1.45,
                      children: [
                        SettingsGridTile(
                          icon: Icons.history_rounded,
                          title: 'My History',
                          subtitle: 'Past audits & scans',
                          onTap: () => context.go('/history'),
                        ),
                        SettingsGridTile(
                          icon: Icons.menu_book_rounded,
                          title: 'Learn',
                          subtitle: 'OTR/WVTR primer',
                          onTap: () => context.go('/learn'),
                        ),
                        SettingsGridTile(
                          icon: Icons.currency_rupee,
                          title: 'Rupee Savings',
                          subtitle: 'Food waste loss ROI (₹)',
                          onTap: () => context.push('/rupee-impact'),
                        ),
                        SettingsGridTile(
                          icon: Icons.water_drop_outlined,
                          title: 'Rural ZECC',
                          subtitle: 'Zero energy cool chamber',
                          onTap: () => context.push('/rural-mode'),
                        ),
                        // Role-conditional 5th tile: Business Tools (industry/admin/gov)
                        if (isBusinessRole)
                          SettingsGridTile(
                            icon: Icons.business_center_outlined,
                            title: 'Business Tools',
                            subtitle: 'Bulk upload & aggregates',
                            onTap: () => context.push('/business-tools'),
                          ),
                        SettingsGridTile(
                          icon: Icons.help_outline_rounded,
                          title: 'Help & FAQs',
                          subtitle: 'Packaging assistance',
                          onTap: () => context.go('/learn'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
