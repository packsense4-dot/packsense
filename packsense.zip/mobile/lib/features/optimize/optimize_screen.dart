import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/segmented_tab_bar.dart';
import '../../core/widgets/icon_circle_badge.dart';
import '../../core/widgets/status_badge.dart';
import '../../core/widgets/stat_row.dart';
import '../../core/widgets/primary_button.dart';

/// Section 5.7: AI Recommendation / Optimize Results (Feature #3, Stage C+D)
/// Matches reference design's single-recommendation layout extended with
/// a SegmentedTabBar ("Best Value / Best Life / Greenest").
class OptimizeScreen extends StatefulWidget {
  const OptimizeScreen({Key? key}) : super(key: key);

  @override
  State<OptimizeScreen> createState() => _OptimizeScreenState();
}

class _OptimizeScreenState extends State<OptimizeScreen> {
  int _activeOptionTab = 0; // 0: Best Value, 1: Best Life, 2: Greenest
  bool _isChecklistExpanded = false;

  final List<Map<String, dynamic>> _paretoOptions = [
    {
      'title': 'Best Value (Pareto Optimal)',
      'material': 'Mono-Material PE 40µm MDO High-Barrier',
      'badge': 'Balanced',
      'variant': StatusBadgeVariant.success,
      'shap': 'Balances moisture barrier and cost efficiency. Recyclable under PWM 2022 mono-material guidelines with minimal thickness.',
      'otr': '2.4 cc/m²·day',
      'wvtr': '1.2 g/m²·day',
      'shelfLife': '150 Days',
      'cost': '₹11.20 / m²',
      'carbon': '1.8 kg CO₂e / kg',
      'confidence': '92% (High Confidence)',
      'labTrial': false,
    },
    {
      'title': 'Best Shelf Life',
      'material': 'BOPP 20µm / Met-BOPP 18µm / CPP 25µm',
      'badge': 'Maximum Barrier',
      'variant': StatusBadgeVariant.success,
      'shap': 'Metallized barrier layer prevents oxygen ingress, delaying lipid rancidity. Target OTR < 2.0 cc/m²·day achieved for long-haul export.',
      'otr': '1.8 cc/m²·day',
      'wvtr': '0.9 g/m²·day',
      'shelfLife': '180 Days',
      'cost': '₹14.50 / m²',
      'carbon': '2.4 kg CO₂e / kg',
      'confidence': '95% (High Confidence)',
      'labTrial': false,
    },
    {
      'title': 'Greenest Recyclable',
      'material': 'Bio-PLA / PBAT Compostable 35µm',
      'badge': 'Trade-off',
      'variant': StatusBadgeVariant.warning,
      'shap': '100% industrial compostable per IS 17088. Higher permeability shortens shelf life for moisture-sensitive products; lab trial recommended.',
      'otr': '45.0 cc/m²·day',
      'wvtr': '14.0 g/m²·day',
      'shelfLife': '45 Days',
      'cost': '₹18.00 / m²',
      'carbon': '0.8 kg CO₂e / kg',
      'confidence': '76% (Lab Trial Suggested)',
      'labTrial': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final opt = _paretoOptions[_activeOptionTab];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'AI Recommendation',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top SegmentedTabBar ("Best Value / Best Life / Greenest")
            SegmentedTabBar(
              tabs: const ['Best Value', 'Best Life', 'Greenest'],
              selectedIndex: _activeOptionTab,
              onTabSelected: (idx) => setState(() => _activeOptionTab = idx),
            ),
            const SizedBox(height: 14),

            // Product Thumbnail & Name Row
            RoundedCard(
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: AppColors.primaryTint,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Center(
                      child: Icon(Icons.lunch_dining_rounded, color: AppColors.primary, size: 28),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'Potato Crisps (150g Pouch)',
                          style: TextStyle(fontFamily: 'Poppins', fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'High lipid oxidation risk · Critical moisture 4.5%',
                          style: TextStyle(fontFamily: 'Inter', fontSize: 11, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // "Best Choice for You" IconCircleBadge + Shield + SHAP Explanation
            RoundedCard(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const IconCircleBadge(
                    icon: Icons.shield_rounded,
                    size: 42,
                    iconSize: 22,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Best Choice for You',
                          style: TextStyle(fontFamily: 'Poppins', fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          opt['shap'] as String,
                          style: const TextStyle(fontFamily: 'Inter', fontSize: 11, color: AppColors.textSecondary, height: 1.4),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // "Recommended Packaging" Card with Material Name + StatusBadge
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'RECOMMENDED PACKAGING',
                        style: TextStyle(fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                      ),
                      StatusBadge(
                        label: opt['badge'] as String,
                        variant: opt['variant'] as StatusBadgeVariant,
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    opt['material'] as String,
                    style: const TextStyle(fontFamily: 'Poppins', fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.primaryDark),
                  ),
                  const SizedBox(height: 12),

                  // StatRow List (OTR, WVTR, Shelf Life, Estimated Cost, Carbon Footprint)
                  StatRow(
                    icon: Icons.air_rounded,
                    label: 'Oxygen Transmission Rate (OTR)',
                    value: opt['otr'] as String,
                  ),
                  const Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.water_drop_rounded,
                    label: 'Water Vapor Transmission (WVTR)',
                    value: opt['wvtr'] as String,
                  ),
                  const Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.timer_outlined,
                    label: 'Shelf Life (Predicted)',
                    value: opt['shelfLife'] as String,
                  ),
                  const Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.currency_rupee,
                    label: 'Estimated Material Cost',
                    value: opt['cost'] as String,
                  ),
                  const Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.eco_rounded,
                    label: 'Carbon Footprint',
                    value: opt['carbon'] as String,
                    iconColor: AppColors.success,
                    iconBgColor: AppColors.successTint,
                  ),
                  const Divider(height: 1, color: AppColors.border),

                  // Confidence Score Row
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Prediction Confidence Score',
                          style: TextStyle(fontFamily: 'Inter', fontSize: 12, color: AppColors.textSecondary),
                        ),
                        StatusBadge(
                          label: opt['confidence'] as String,
                          variant: (opt['labTrial'] as bool) ? StatusBadgeVariant.warning : StatusBadgeVariant.success,
                        ),
                      ],
                    ),
                  ),

                  // Collapsible Lab Trial Checklist Card (when applicable)
                  if (opt['labTrial'] as bool) ...[
                    const SizedBox(height: 6),
                    GestureDetector(
                      onTap: () => setState(() => _isChecklistExpanded = !_isChecklistExpanded),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.warningTint,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.warning.withOpacity(0.3)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: const [
                                    Icon(Icons.assignment_outlined, size: 16, color: AppColors.warning),
                                    SizedBox(width: 6),
                                    Text(
                                      'Lab Trial Checklist Recommended',
                                      style: TextStyle(fontFamily: 'Inter', fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.warning),
                                    ),
                                  ],
                                ),
                                Icon(
                                  _isChecklistExpanded ? Icons.expand_less : Icons.expand_more,
                                  size: 18,
                                  color: AppColors.warning,
                                ),
                              ],
                            ),
                            if (_isChecklistExpanded) ...[
                              const SizedBox(height: 8),
                              const Text(
                                '• ASTM F88 seal peel tensile strength test\n'
                                '• ASTM D3078 bubble emission leak test\n'
                                '• Accelerated 40°C / 75% RH sensory test (14 days)',
                                style: TextStyle(fontFamily: 'Inter', fontSize: 10, color: AppColors.textPrimary, height: 1.4),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Primary Button: "View Simulation Details" -> Section 5.6
            PrimaryButton(
              label: 'View Simulation Details',
              icon: Icons.timeline_rounded,
              onPressed: () {
                context.push('/digital-twin');
              },
            ),
            const SizedBox(height: 10),

            // Link to Rupee Savings
            Center(
              child: TextButton.icon(
                onPressed: () => context.push('/rupee-impact'),
                icon: const Icon(Icons.currency_rupee, size: 14, color: AppColors.primary),
                label: const Text(
                  'Calculate Rupee Food Waste Savings',
                  style: TextStyle(fontFamily: 'Inter', fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.primary),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
