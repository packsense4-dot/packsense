import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/stat_row.dart';
import '../../core/widgets/primary_button.dart';
import '../../core/widgets/info_bar.dart';

/// Section 5.9: Rupee Impact Calculator (Feature #16)
/// Stacked comparison cards:
/// 1. "Current pack loss" plain card
/// 2. "Recommended pack loss" primaryTint-bordered card
/// 3. successTint full-width card showing the net gain in large bold green text
class RupeeImpactScreen extends StatelessWidget {
  const RupeeImpactScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Rupee Impact Calculator',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const InfoBar(
              text: 'Food loss calculations calibrated to CIPHET & MoFPI mandi commodity baseline losses.',
              icon: Icons.currency_rupee,
            ),
            const SizedBox(height: 14),

            // Card 1: Current Pack Loss (Plain card)
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'CURRENT PACKAGING (BASELINE)',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textSecondary,
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(height: 8),
                  StatRow(
                    icon: Icons.inventory_2_outlined,
                    label: 'Per-Shipment Produce Spoilage Loss',
                    value: '₹1,57,000',
                    unit: '24% loss rate',
                    iconColor: AppColors.danger,
                    iconBgColor: Color(0xFFFEE2E2),
                  ),
                  Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.receipt_long_outlined,
                    label: 'Current Material Packaging Cost',
                    value: '₹18,500',
                    unit: 'Standard Monolayer',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // Card 2: Recommended Pack Loss (primaryTint-bordered card)
            RoundedCard(
              border: Border.all(color: AppColors.primary, width: 1.5),
              backgroundColor: AppColors.surface,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'RECOMMENDED BARRIER PACKAGING',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryDark,
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(height: 8),
                  StatRow(
                    icon: Icons.verified_outlined,
                    label: 'Post-Harvest Loss with Barrier Film',
                    value: '₹14,200',
                    unit: '3.2% loss rate (-86%)',
                    iconColor: AppColors.success,
                    iconBgColor: AppColors.successTint,
                  ),
                  Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.add_card_outlined,
                    label: 'High-Barrier Laminate Investment',
                    value: '₹32,700',
                    unit: 'Tri-Laminate PE/Met-PET',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Card 3: successTint full-width card with large bold green net gain
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppColors.successTint,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.success.withOpacity(0.35), width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'NET SAVINGS PER SHIPMENT',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: AppColors.success,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    '₹1,28,600',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: AppColors.success,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Net 9.05x return on packaging investment. Payback period: 1.8 truckloads.',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF14532D),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            PrimaryButton(
              label: 'Export Financial Feasibility Sheet',
              icon: Icons.picture_as_pdf,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Exported Rupee_Impact_Feasibility.pdf'),
                    backgroundColor: AppColors.success,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
