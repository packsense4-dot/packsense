import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class MixedLoadScreen extends StatelessWidget {
  const MixedLoadScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #13: Mixed Load Compatibility')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'ETHYLENE PRODUCER',
                    value: 'MANGO',
                    unit: 'high C2H4 emission',
                    accentColor: AppColors.dangerRose,
                    badgeText: 'CLIMACTERIC',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'ETHYLENE SENSITIVE',
                    value: 'GRAPES',
                    unit: 'rapid berry shatter',
                    accentColor: AppColors.warningAmber,
                    badgeText: 'VULNERABLE',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'COMPATIBILITY VERDICT',
                    value: 'INCOMPATIBLE',
                    unit: 'do not co-load in reefer',
                    accentColor: AppColors.dangerRose,
                    badgeText: 'SEPARATE',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('CROSS-CONTAMINATION PROTOCOL', style: AppTypography.statLabel),
                  SizedBox(height: 8),
                  Text(
                    'Co-loading Alphonso Mangoes with Table Grapes in the same truck triggers rapid ripening, stalk browning, and berry drop in grapes due to airborne ethylene gas (> 1.0 ppm).\n\n'
                    'Required Action:\n'
                    '• Transport in separate refrigerated compartments.\n'
                    '• If co-loading cannot be avoided, grapes must be packed in hermetic high-barrier liners with dedicated KMnO4 ethylene scavenger sachets.',
                    style: AppTypography.body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
