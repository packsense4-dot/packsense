import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/info_bar.dart';

/// Section 4.2: Unified Scanner Screen (Scan Barcode)
/// Handles both barcode (EAN/UPC -> Product Details) and QR (PackSense QR Passport)
class ScanScreen extends StatefulWidget {
  const ScanScreen({Key? key}) : super(key: key);

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  bool _isTorchOn = false;
  String? _detectedCode;
  bool _isProcessing = false;

  void _onCodeCaptured(String code, bool isQr) {
    if (_isProcessing) return;
    setState(() {
      _isProcessing = true;
      _detectedCode = code;
    });

    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      if (isQr || code.startsWith('http') || code.contains('QR-')) {
        // QR branch -> QR Passport
        context.push('/qr-passport');
      } else {
        // Barcode branch -> Product Details
        context.push('/product-details', extra: {
          'barcode': code,
          'productName': 'Lays Classic Salted Potato Chips',
          'category': 'Snack Foods · 150g Net',
          'isVerified': true,
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Scan Barcode',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isTorchOn ? Icons.flash_on_rounded : Icons.flash_off_rounded,
              color: _isTorchOn ? AppColors.warning : Colors.white,
            ),
            onPressed: () => setState(() => _isTorchOn = !_isTorchOn),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 12),
            // Subtitle
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Position the barcode or packaging label inside the viewfinder to scan automatically.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 12,
                  color: Colors.white70,
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Viewfinder Viewport
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: AspectRatio(
                    aspectRatio: 1.0,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white24, width: 1.5),
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Viewfinder brackets
                          _buildCornerBrackets(),

                          // Animated scanning line or icon
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.qr_code_scanner,
                                size: 64,
                                color: _isProcessing ? AppColors.warning : AppColors.primary,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                _isProcessing ? 'Processing scan...' : 'Align Barcode / QR',
                                style: const TextStyle(
                                  fontFamily: 'Inter',
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Live-detected barcode number readout
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              margin: const EdgeInsets.symmetric(horizontal: 24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                _detectedCode != null ? 'Detected: $_detectedCode' : 'Code: 8901491101831 (EAN-13)',
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 12,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Simulated Trigger Buttons for Demo (Barcode vs QR)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () => _onCodeCaptured('8901491101831', false),
                      icon: const Icon(Icons.barcode_reader, size: 16),
                      label: const Text('Simulate Barcode', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white24,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () => _onCodeCaptured('QR-BATCH-MH-2026-B8', true),
                      icon: const Icon(Icons.qr_code, size: 16),
                      label: const Text('Simulate QR', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Bottom InfoBar Tip
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: InfoBar(
                text: 'Make sure the barcode is clear and well lit for instant identification.',
                icon: Icons.info_outline,
                backgroundColor: Color(0xFF1E293B),
                iconColor: AppColors.primary,
                textColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCornerBrackets() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Stack(
        children: [
          // Top Left
          Positioned(
            top: 0,
            left: 0,
            child: Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                border: Border(
                  top: BorderSide(color: AppColors.primary, width: 3.5),
                  left: BorderSide(color: AppColors.primary, width: 3.5),
                ),
              ),
            ),
          ),
          // Top Right
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                border: Border(
                  top: BorderSide(color: AppColors.primary, width: 3.5),
                  right: BorderSide(color: AppColors.primary, width: 3.5),
                ),
              ),
            ),
          ),
          // Bottom Left
          Positioned(
            bottom: 0,
            left: 0,
            child: Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: AppColors.primary, width: 3.5),
                  left: BorderSide(color: AppColors.primary, width: 3.5),
                ),
              ),
            ),
          ),
          // Bottom Right
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: AppColors.primary, width: 3.5),
                  right: BorderSide(color: AppColors.primary, width: 3.5),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
