import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../core/api/dio_client.dart';

/// Part A.3, A.4, B.1, B.2: ScanState & ScanController
/// Protects against race conditions where an older, slower request overwrites a newer, faster one.
/// Cancels abandoned in-flight requests via CancelToken and verifies _activeScanId after BOTH
/// the /ripeness/scan step and the subsequent /scan/analyze step.
class ScanState {
  final String status; // 'idle' | 'analyzing' | 'needs_input' | 'report' | 'error'
  final String? scanSessionId;
  final File? capturedImage;
  final Map<String, dynamic>? report;
  final List<Map<String, dynamic>> candidates;
  final Object? error;

  const ScanState({
    required this.status,
    this.scanSessionId,
    this.capturedImage,
    this.report,
    this.candidates = const [],
    this.error,
  });

  factory ScanState.idle() => const ScanState(status: 'idle');
  factory ScanState.analyzing({required String scanSessionId, File? image}) =>
      ScanState(status: 'analyzing', scanSessionId: scanSessionId, capturedImage: image);
  factory ScanState.needsInput({
    required String scanSessionId,
    required File image,
    required List<Map<String, dynamic>> candidates,
  }) =>
      ScanState(
        status: 'needs_input',
        scanSessionId: scanSessionId,
        capturedImage: image,
        candidates: candidates,
      );
  factory ScanState.report(
    Map<String, dynamic> result, {
    required String scanSessionId,
    File? capturedImage,
  }) =>
      ScanState(
        status: 'report',
        scanSessionId: scanSessionId,
        capturedImage: capturedImage,
        report: result,
      );
  factory ScanState.error(Object err, {String? scanSessionId}) =>
      ScanState(status: 'error', scanSessionId: scanSessionId, error: err);
}

class ScanController extends Notifier<ScanState> {
  String? _activeScanId;
  CancelToken? _activeCancelToken;

  @override
  ScanState build() => ScanState.idle();

  Future<void> startScan(File image, {String? confirmedFoodId}) async {
    // 1. Cancel any previous in-flight Dio request immediately (Part A.3)
    _activeCancelToken?.cancel('Superseded by newer scan');
    final cancelToken = CancelToken();
    _activeCancelToken = cancelToken;

    // 2. Generate a unique scan_session_id and mark as the ONLY active scan we accept (Part A.3 & B.2)
    final scanId = const Uuid().v4();
    _activeScanId = scanId;
    state = ScanState.analyzing(scanSessionId: scanId, image: image);

    try {
      // Step 1: POST /api/v1/ripeness/scan (never cached - Part A.1/A.2)
      final ripenessResponse = await dio.post<Map<String, dynamic>>(
        '/ripeness/scan',
        data: {
          'scan_session_id': scanId,
          'commodity_id': confirmedFoodId ?? 'auto',
          'image_path': image.path,
        },
        options: Options(
          headers: {
            'X-Scan-Session-Id': scanId,
            'Cache-Control': 'no-store, no-cache',
          },
          extra: {'disableCache': true},
        ),
        cancelToken: cancelToken,
      );

      // Race-condition guard #1: verify no newer scan started while /ripeness/scan was in flight
      if (_activeScanId != scanId) return;

      final ripenessData = ripenessResponse.data ?? {};
      final status = ripenessData['status'] as String? ?? 'ok';
      final confidence = (ripenessData['confidence'] as num?)?.toDouble() ?? 0.0;

      // Part A.4: Low confidence returns needs_input with ranked candidate foods — never auto-pick a default food
      if ((status == 'needs_input' || status == 'low_confidence' || confidence < 0.75) &&
          confirmedFoodId == null) {
        final rawCandidates = (ripenessData['candidates'] as List<dynamic>? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        state = ScanState.needsInput(
          scanSessionId: scanId,
          image: image,
          candidates: rawCandidates,
        );
        return;
      }

      final detectedFood = confirmedFoodId ?? (ripenessData['food_detected'] as String?);
      final ripenessStage = ripenessData['ripeness_stage'] as String? ?? 'breaker';

      // Step 2: POST /api/v1/scan/analyze (with scan_session_id echoed end-to-end)
      final analyzeResponse = await dio.post<Map<String, dynamic>>(
        '/scan/analyze',
        data: {
          'scan_session_id': scanId,
          'source': 'ripeness',
          'food_id': detectedFood,
          'ripeness_stage': ripenessStage,
          'confidence': confidence,
          'user_confirmed_food': confirmedFoodId != null,
          'captured_image': image.path,
        },
        options: Options(
          headers: {'X-Scan-Session-Id': scanId},
        ),
        cancelToken: cancelToken,
      );

      // Race-condition guard #2: verify no newer scan started while /scan/analyze was in flight
      if (_activeScanId != scanId) return;

      final reportData = Map<String, dynamic>.from(analyzeResponse.data ?? {});
      reportData['scan_session_id'] = scanId;
      reportData['captured_image_path'] = image.path;

      state = ScanState.report(
        reportData,
        scanSessionId: scanId,
        capturedImage: image,
      );
    } catch (e) {
      if (_activeScanId != scanId) return;
      state = ScanState.error(e, scanSessionId: scanId);
    }
  }
}

final scanControllerProvider = NotifierProvider<ScanController, ScanState>(ScanController.new);
