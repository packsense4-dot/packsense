import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/status_badge.dart';
import '../../core/widgets/segmented_tab_bar.dart';
import '../../core/widgets/primary_button.dart';
import '../../core/widgets/info_bar.dart';

/// Section 4.3: Product Details Screen
/// Matches reference design: product image, name, category/weight subtitle,
/// StatusBadge ("Verified"), SegmentedTabBar ("Ingredients / Other Info"),
/// bulleted ingredient list, PrimaryButton "Get Packaging Recommendation".
class ProductDetailsScreen extends StatefulWidget {
  final Map<String, dynamic>? productData;

  const ProductDetailsScreen({Key? key, this.productData}) : super(key: key);

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  int _tabIndex = 0; // 0: Ingredients, 1: Other Info

  @override
  Widget build(BuildContext context) {
    final title = widget.productData?['productName'] as String? ?? 'Potato Crisps / Chips';
    final category = widget.productData?['category'] as String? ?? 'Snack Foods · 150g Net Pouch';
    final isVerified = widget.productData?['isVerified'] as bool? ?? true;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Product Details',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top Product Header Card
            RoundedCard(
              child: Column(
                children: [
                  // Product Graphic / Thumbnail
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppColors.primaryTint,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.lunch_dining_rounded,
                        size: 52,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Name & Category
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    category,
                    style: const TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 12,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Status Badge
                  StatusBadge(
                    label: isVerified ? 'Verified Product' : 'Unverified OCR Match',
                    variant: isVerified ? StatusBadgeVariant.success : StatusBadgeVariant.warning,
                    icon: isVerified ? Icons.check_circle : Icons.help_outline,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // SegmentedTabBar: "Ingredients / Other Info"
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedTabBar(
                    tabs: const ['Ingredients', 'Packaging & Nutritional Info'],
                    selectedIndex: _tabIndex,
                    onTabSelected: (idx) => setState(() => _tabIndex = idx),
                  ),
                  const SizedBox(height: 16),

                  if (_tabIndex == 0) ...[
                    // Ingredients List from OCR / Database
                    const Text(
                      'DECODED INGREDIENTS LIST',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textSecondary,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _buildIngredientItem('Potatoes (Fresh Farm Sourced)', 'High sensitivity to enzymatic browning'),
                    _buildIngredientItem('Edible Vegetable Oil (Palmolein)', 'Requires low OTR to prevent rancidity'),
                    _buildIngredientItem('Iodized Salt & Spices', 'Hygroscopic — requires strict WVTR barrier'),
                    _buildIngredientItem('Acidity Regulators (INS 330)', 'FSSAI compliant flavoring additives'),
                  ] else ...[
                    // Nutritional & Barrier Specs
                    const Text(
                      'NUTRITIONAL & SHELF SPECIFICATIONS',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textSecondary,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _buildIngredientItem('Critical Moisture Limit', '4.5% max (loss of crispiness threshold)'),
                    _buildIngredientItem('Critical Oxidation Level', '0.2 meq O₂/kg max peroxide value'),
                    _buildIngredientItem('Target Shelf Life', '180 Days at 25°C ambient'),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),

            const InfoBar(
              text: 'Identified packaging barrier needs: High moisture barrier (WVTR < 1.0) and light protection.',
              icon: Icons.shield_outlined,
            ),
            const SizedBox(height: 20),

            // Primary Button: "Get Packaging Recommendation"
            PrimaryButton(
              label: 'Get Packaging Recommendation',
              icon: Icons.auto_awesome,
              onPressed: () {
                // Route to Digital Twin / Optimizer
                context.push('/digital-twin');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIngredientItem(String name, String note) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 5),
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: AppColors.primary,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  note,
                  style: const TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
