import 'dart:io';
import 'dart:typed_data';
import 'package:uuid/uuid.dart';

/// Part A.2: Unique per-capture filenames & flushed file write before upload.
/// Prevents reusing a deterministic path (like /tmp/capture.jpg) where an older
/// frame buffer is uploaded before the new capture finishes flushing to disk.
class CameraCaptureService {
  static const Uuid _uuid = Uuid();

  /// Writes captured frame bytes to a uniquely-named temporary file and awaits
  /// full disk flush before returning the File reference for upload.
  static Future<File> saveCapturedFrame(
    Uint8List frameBytes, {
    Directory? tempDir,
  }) async {
    final dir = tempDir ?? Directory.systemTemp;
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final uniqueId = _uuid.v4();
    final filePath = '${dir.path}/packsense_capture_${timestamp}_$uniqueId.jpg';
    final file = File(filePath);

    // Explicitly flush bytes to disk and await completion before returning
    await file.writeAsBytes(frameBytes, flush: true);
    return file;
  }
}
