import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class CondensationRiskScreen extends StatelessWidget {
  const CondensationRiskScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #12: Condensation Risk Engine')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'CONDENSATION RISK',
                    value: 'HIGH',
                    unit: 'dew-point crossing',
                    accentColor: AppColors.dangerRose,
                    badgeText: 'TRIGGERED',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'DEW POINT TEMP',
                    value: '19.4',
                    unit: '°C dew point',
                    accentColor: AppColors.warningAmber,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'CRITICAL DELTA T',
                    value: '3.6',
                    unit: '°C drop required',
                    accentColor: AppColors.secondarySky,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'MAX HEADSPACE RH',
                    value: '98',
                    unit: '% RH saturation',
                    accentColor: AppColors.dangerRose,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('PSYCHROMETRIC RISK MITIGATION', style: AppTypography.statLabel),
                  SizedBox(height: 8),
                  Text(
                    'During reefer transit, temperature fluctuations exceeding 3.6°C cause internal moisture to condense onto film walls. This liquid film stimulates Botrytis and fungal spore germination.\n\n'
                    'Remediation:\n'
                    '1. Maintain continuous unbroken cold chain within ±1.5°C.\n'
                    '2. Specify anti-fog surfactant masterbatch in pouch inner sealant layer.',
                    style: AppTypography.body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
