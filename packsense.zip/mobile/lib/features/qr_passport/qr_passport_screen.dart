import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class QrPassportScreen extends StatefulWidget {
  const QrPassportScreen({Key? key}) : super(key: key);

  @override
  State<QrPassportScreen> createState() => _QrPassportScreenState();
}

class _QrPassportScreenState extends State<QrPassportScreen> {
  int _viewIndex = 0; // 0: Batch Passport, 1: Chain of Custody, 2: Verification

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Digital Product Passport (QR)'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['Batch Passport', 'Chain of Custody', 'Verification'],
              selectedIndex: _viewIndex,
              onTabSelected: (idx) => setState(() => _viewIndex = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('GS1 DIGITAL LINK IDENTIFIER', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  const Text(
                    'Batch: #MH-PUN-2026-B812',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Produce: Alphonso Mango (Export Grade A) · Pack Date: 28 Sep 2026',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 14),
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFE2EBF6), width: 1.5),
                        boxShadow: const [
                          BoxShadow(color: Color(0x0A0F172A), blurRadius: 6, offset: Offset(0, 2)),
                        ],
                      ),
                      child: const Column(
                        children: [
                          Icon(Icons.qr_code_2, size: 140, color: Color(0xFF0F172A)),
                          SizedBox(height: 6),
                          Text(
                            'https://id.packsense.org/01/08901030999/10/B812',
                            style: TextStyle(fontFamily: AppTypography.monoFamily, fontSize: 9, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('COLD CHAIN & BARRIER AUDIT READOUT', style: AppTypography.statLabel),
                  const SizedBox(height: 10),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'LAMINATE FILM',
                          value: 'BOPP/Met',
                          unit: '3-ply barrier',
                          accentColor: AppColors.primary,
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'COLD CHAIN INTEGRITY',
                          value: '99.4%',
                          unit: 'Temp in spec',
                          accentColor: AppColors.success,
                          badgeText: 'FSSAI VERIFIED',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
