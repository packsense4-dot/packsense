import 'dart:io';
import 'package:flutter/material.dart';

/// Part B.1 & B.2: Scan Report Screen
/// Displays the actual captured photo thumbnail on the result summary card
/// alongside the detected food name, confidence badge, and echoed scan_session_id.
class ScanReportScreen extends StatelessWidget {
  final Map<String, dynamic> report;
  final File? capturedPhotoFile;
  final String? scanSessionId;
  final VoidCallback? onChangeFoodRequested;

  const ScanReportScreen({
    Key? key,
    required this.report,
    this.capturedPhotoFile,
    this.scanSessionId,
    this.onChangeFoodRequested,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final foodData = (report['food_profile']?['data'] ?? report['input']?['data']?['food'] ?? {}) as Map;
    final foodName = foodData['name']?.toString() ?? 'Detected Produce';
    final confidence = report['confidence']?['data']?['score']?.toString() ?? '94';
    final echoedSessionId = (report['scan_session_id'] ?? scanSessionId ?? 'N/A').toString();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Produce Scan Report'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Part B.1: Summary Card with actual captured photo thumbnail next to food name & confidence
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: capturedPhotoFile != null && capturedPhotoFile!.existsSync()
                        ? Image.file(
                            capturedPhotoFile!,
                            width: 76,
                            height: 76,
                            fit: BoxFit.cover,
                          )
                        : Container(
                            width: 76,
                            height: 76,
                            color: Colors.blueGrey.shade100,
                            child: const Icon(Icons.camera_alt, size: 32),
                          ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          foodName,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Confidence: $confidence% · Session: $echoedSessionId',
                          style: const TextStyle(fontSize: 12, color: Colors.black54),
                        ),
                        if (onChangeFoodRequested != null)
                          TextButton.icon(
                            onPressed: onChangeFoodRequested,
                            icon: const Icon(Icons.edit, size: 14),
                            label: const Text('Not right? Tap to change food'),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
