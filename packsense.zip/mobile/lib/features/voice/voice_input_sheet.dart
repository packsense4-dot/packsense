import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';

class VoiceInputSheet extends StatefulWidget {
  final Function(String transcribedText) onResult;

  const VoiceInputSheet({Key? key, required this.onResult}) : super(key: key);

  @override
  State<VoiceInputSheet> createState() => _VoiceInputSheetState();
}

class _VoiceInputSheetState extends State<VoiceInputSheet> {
  bool _isRecording = true;
  String _statusText = 'LISTENING (BHASHINI MULTILINGUAL ASR)...';
  String _detectedText = '';

  @override
  void initState() {
    super.initState();
    // Simulate speech-to-intent transcription without chat AI
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (mounted) {
        setState(() {
          _isRecording = false;
          _statusText = 'TRANSCRIPTION COMPLETED';
          _detectedText = 'Alphonso Mango 40 micron cold storage 12C';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('VOICE-FIRST ASR ENGINE', style: AppTypography.statLabel),
                IconButton(
                  icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Center(
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isRecording ? AppColors.dangerRose.withOpacity(0.2) : AppColors.primaryEmerald.withOpacity(0.2),
                  border: Border.all(
                    color: _isRecording ? AppColors.dangerRose : AppColors.primaryEmerald,
                    width: 2,
                  ),
                ),
                child: Icon(
                  _isRecording ? Icons.mic : Icons.check,
                  size: 32,
                  color: _isRecording ? AppColors.dangerRose : AppColors.primaryEmerald,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: Text(
                _statusText,
                style: const TextStyle(
                  fontFamily: AppTypography.monoFamily,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textMuted,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_detectedText.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.surfaceCard,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppColors.primaryEmerald.withOpacity(0.4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('TRANSCRIBED ENTITIES:', style: AppTypography.statLabel),
                    const SizedBox(height: 4),
                    Text(
                      _detectedText,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryEmerald,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              onPressed: _detectedText.isEmpty
                  ? null
                  : () {
                      widget.onResult(_detectedText);
                      Navigator.pop(context);
                    },
              child: const Text('APPLY INTENT TO FORM', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
