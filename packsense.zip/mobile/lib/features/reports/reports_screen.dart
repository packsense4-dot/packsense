import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({Key? key}) : super(key: key);

  void _triggerDownload(BuildContext context, String format) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Downloaded PackSense_Report.$format to device storage'),
        backgroundColor: AppColors.primaryEmerald,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Reports & Specification Exports')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _reportTile(
            context,
            'Complete Technical Specification Sheet',
            'Full barrier calculations, layer thickness, ASTM test references, FSSAI declaration.',
            'PDF',
          ),
          _reportTile(
            context,
            'Lab-Trial Verification Checklist',
            'Pre-filled laboratory compliance verification form with ASTM D3985 & IS 9845 limits.',
            'PDF',
          ),
          _reportTile(
            context,
            'Candidate Evaluation Matrix',
            'Dense engineering spreadsheet comparing all 15 polymer film candidates.',
            'XLSX',
          ),
          _reportTile(
            context,
            'MoFPI District Food Loss Summary',
            'Agro-climatic packaging gap report with financial ROI & cold-chain remediation.',
            'CSV',
          ),
        ],
      ),
    );
  }

  Widget _reportTile(BuildContext context, String title, String desc, String format) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: AppColors.textPrimary)),
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.surfaceCard,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  side: const BorderSide(color: AppColors.secondarySky),
                ),
                onPressed: () => _triggerDownload(context, format),
                icon: const Icon(Icons.download, size: 14, color: AppColors.secondarySky),
                label: Text(format, style: const TextStyle(fontSize: 10, fontFamily: AppTypography.monoFamily, color: AppColors.secondarySky)),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(desc, style: AppTypography.body),
        ],
      ),
    );
  }
}
