import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class GovDashboardScreen extends StatefulWidget {
  const GovDashboardScreen({Key? key}) : super(key: key);

  @override
  State<GovDashboardScreen> createState() => _GovDashboardScreenState();
}

class _GovDashboardScreenState extends State<GovDashboardScreen> {
  int _tabIndex = 0; // 0: State Heatmap, 1: Scheme Subsidies, 2: Cold Chain Gaps

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('MoFPI Post-Harvest Loss Dashboard'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['Loss Heatmap', 'PM-FME Subsidies', 'Cold Chain Gaps'],
              selectedIndex: _tabIndex,
              onTabSelected: (idx) => setState(() => _tabIndex = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('NATIONAL POST-HARVEST LOSS TELEMETRY', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  const Text(
                    'District Loss Aggregations (CIPHET 2026)',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'High ambient RH and non-barrier packaging correlate with 22.4% tomato loss across 14 districts in Maharashtra and Karnataka.',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'TOTAL FOOD LOSS',
                          value: '₹92,650 Cr',
                          unit: 'National Annual Loss',
                          accentColor: AppColors.danger,
                          badgeText: 'CRITICAL',
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'PACKAGING REMEDIABLE',
                          value: '38.2%',
                          unit: 'Saveable with Barrier',
                          accentColor: AppColors.success,
                          badgeText: 'OPPORTUNITY',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'ACTIVE FPO HUBS',
                          value: '1,420',
                          unit: 'onboarded clusters',
                          accentColor: AppColors.primary,
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'ZECC CHAMBERS',
                          value: '8,450',
                          unit: 'operational units',
                          accentColor: AppColors.primaryDark,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
