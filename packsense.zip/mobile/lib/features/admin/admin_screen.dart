import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({Key? key}) : super(key: key);

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  int _tabIndex = 0; // 0: Materials DB, 1: Arrhenius Constants, 2: System Audit

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('PackSense System Administration'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['Materials DB', 'Arrhenius Constants', 'System Audit'],
              selectedIndex: _tabIndex,
              onTabSelected: (idx) => setState(() => _tabIndex = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('DETERMINISTIC PHYSICS KERNEL STATUS', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  const Text(
                    'Substrate Permeability Master Table',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '30 validated polymer substrates calibrated against ASTM D3985 and ASTM F1249 permeation cells.',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'ACTIVE POLYMERS',
                          value: '30',
                          unit: 'substrates indexed',
                          accentColor: AppColors.primary,
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'DATABASE DRIFT',
                          value: '0.00%',
                          unit: 'cryptographic sha256',
                          accentColor: AppColors.success,
                          badgeText: 'VERIFIED',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
