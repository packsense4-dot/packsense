import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/radio_select_card.dart';
import '../../core/widgets/primary_button.dart';
import '../../core/widgets/info_bar.dart';

/// Section 5.5: Indian Climate Profile (Feature #2)
/// Matches reference design: "Select your region/season" subtitle,
/// RadioSelectCard list (Summer, Monsoon, Winter, Cold Chain),
/// temp/RH ranges, single-select radio, PrimaryButton "Continue".
class ClimateProfileScreen extends StatefulWidget {
  const ClimateProfileScreen({Key? key}) : super(key: key);

  @override
  State<ClimateProfileScreen> createState() => _ClimateProfileScreenState();
}

class _ClimateProfileScreenState extends State<ClimateProfileScreen> {
  String _selectedProfile = 'monsoon';

  final List<Map<String, dynamic>> _profiles = [
    {
      'id': 'summer',
      'title': 'Summer (Hot & Dry)',
      'subtitle': '38°C–45°C · 25% RH · High thermal oxidation risk',
      'icon': Icons.wb_sunny_rounded,
      'badge': 'ACCELERATED',
    },
    {
      'id': 'monsoon',
      'title': 'Monsoon (Humid & Tropical)',
      'subtitle': '28°C–34°C · 85%–95% RH · High moisture ingress risk',
      'icon': Icons.cloudy_snowing,
      'badge': 'CRITICAL WVTR',
    },
    {
      'id': 'winter',
      'title': 'Winter (Cool & Mild)',
      'subtitle': '15°C–22°C · 45%–55% RH · Moderate shelf stability',
      'icon': Icons.ac_unit_rounded,
    },
    {
      'id': 'cold_chain',
      'title': 'Cold Chain (Reefer Logistics)',
      'subtitle': '4°C–8°C · 85% RH · Condensation & dew-point risk',
      'icon': Icons.local_shipping_rounded,
      'badge': 'COLD CHAIN',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Climate & Storage Profile',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Select your operational region and season',
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 13,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 14),

              Expanded(
                child: ListView(
                  children: _profiles.map((p) {
                    final id = p['id'] as String;
                    return RadioSelectCard(
                      icon: p['icon'] as IconData,
                      title: p['title'] as String,
                      subtitle: p['subtitle'] as String,
                      isSelected: _selectedProfile == id,
                      badgeText: p['badge'] as String?,
                      onTap: () => setState(() => _selectedProfile = id),
                    );
                  }).toList(),
                ),
              ),

              const InfoBar(
                text: 'Arrhenius activation energies are auto-adjusted to Indian meteorological IMD averages.',
                icon: Icons.thermostat_outlined,
              ),
              const SizedBox(height: 16),

              PrimaryButton(
                label: 'Continue to Simulation',
                icon: Icons.arrow_forward,
                onPressed: () {
                  context.push('/digital-twin');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
