import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class RightSizingScreen extends StatefulWidget {
  const RightSizingScreen({Key? key}) : super(key: key);

  @override
  State<RightSizingScreen> createState() => _RightSizingScreenState();
}

class _RightSizingScreenState extends State<RightSizingScreen> {
  double _productVolumeCc = 450.0;
  double _currentPouchWidthCm = 16.0;
  double _currentPouchHeightCm = 24.0;

  double get _optimizedWidthCm => 13.5;
  double get _optimizedHeightCm => 20.0;
  double get _plasticSurfaceReductionPct => 28.5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #14: Right-Sizing Headspace')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('POUCH GEOMETRY & HEADSPACE INPUT', style: AppTypography.statLabel),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('POUCH WIDTH', style: TextStyle(fontSize: 10, color: AppColors.textMuted)),
                            Text('${_currentPouchWidthCm.toInt()} cm', style: const TextStyle(fontFamily: AppTypography.monoFamily, fontWeight: FontWeight.bold, color: AppColors.secondarySky)),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('POUCH HEIGHT', style: TextStyle(fontSize: 10, color: AppColors.textMuted)),
                            Text('${_currentPouchHeightCm.toInt()} cm', style: const TextStyle(fontFamily: AppTypography.monoFamily, fontWeight: FontWeight.bold, color: AppColors.secondarySky)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: NumericStatCard(
                    label: 'PLASTIC FILM SAVED',
                    value: _plasticSurfaceReductionPct.toStringAsFixed(1),
                    unit: '% surface area',
                    accentColor: AppColors.primaryEmerald,
                    badgeText: 'LESS SLACK',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'HEADSPACE OPTIMAL',
                    value: '1.2:1',
                    unit: 'gas:solid ratio',
                    accentColor: AppColors.secondarySky,
                    badgeText: 'IDEAL MAP',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: NumericStatCard(
                    label: 'RIGHT-SIZED WIDTH',
                    value: _optimizedWidthCm.toStringAsFixed(1),
                    unit: 'cm',
                    accentColor: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'RIGHT-SIZED HEIGHT',
                    value: _optimizedHeightCm.toStringAsFixed(1),
                    unit: 'cm',
                    accentColor: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
