import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class SupplierMatchScreen extends StatelessWidget {
  const SupplierMatchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #8: Regional Supplier Matching')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'MATCHED CONVERTERS',
                    value: '12',
                    unit: 'verified suppliers',
                    accentColor: AppColors.primaryEmerald,
                    badgeText: 'WITHIN 150 KM',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'LEAST LEAD TIME',
                    value: '3.5',
                    unit: 'days to delivery',
                    accentColor: AppColors.secondarySky,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            const Text('NEARBY POSTGIS SUPPLIER DIRECTORY', style: AppTypography.statLabel),
            const SizedBox(height: 8),

            _supplierTile('Uflex Limited (Western Hub)', 'Chakan, Pune (42 km)', 'Mono-PE 40µm, BOPP/Met-BOPP', '₹11.20/m²', '98% on-time'),
            _supplierTile('Cosmo Films Converting Plant', 'Waluj, Aurangabad (110 km)', 'CPP Barrier, BOPLA Bio-films', '₹14.50/m²', '95% on-time'),
            _supplierTile('Ester Industries Polymer Depot', 'Kalyan, Thane (138 km)', 'EVOH Multi-layer, LLDPE Resin', '₹18.00/m²', '99% on-time'),
          ],
        ),
      ),
    );
  }

  Widget _supplierTile(String name, String location, String materials, String price, String score) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppColors.textPrimary)),
              Text(price, style: const TextStyle(fontFamily: AppTypography.monoFamily, fontWeight: FontWeight.bold, color: AppColors.primaryEmerald, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 2),
          Text(location, style: const TextStyle(fontSize: 10, color: AppColors.secondarySky)),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(materials, style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
              Text(score, style: const TextStyle(fontFamily: AppTypography.monoFamily, fontSize: 9, color: AppColors.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }
}
