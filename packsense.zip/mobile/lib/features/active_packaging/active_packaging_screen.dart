import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class ActivePackagingScreen extends StatelessWidget {
  const ActivePackagingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #11: Active Packaging Advisor')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'ETHYLENE ABSORBER',
                    value: '500',
                    unit: 'mg KMnO4 capacity',
                    accentColor: AppColors.primaryEmerald,
                    badgeText: 'DELAY RIPENING',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'OXYGEN SCAVENGER',
                    value: '100',
                    unit: 'cc O2 absorption',
                    accentColor: AppColors.secondarySky,
                    badgeText: 'FERROUS BASE',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'MOISTURE REGULATOR',
                    value: '55-65',
                    unit: '% RH 2-way boveda',
                    accentColor: AppColors.warningAmber,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'ESTIMATED SACHET COST',
                    value: '₹1.80',
                    unit: 'INR per pouch unit',
                    accentColor: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('ACTIVE SACHET INTEGRATION GUIDELINES', style: AppTypography.statLabel),
                  SizedBox(height: 8),
                  Text(
                    '• Ethylene Scavenger: Potassium permanganate (KMnO4) on activated alumina pellets. Oxidizes C2H4 to CO2 and H2O, preventing premature ripening of climacteric fruits.\n\n'
                    '• Oxygen Scavenger: Self-activated iron powder in breathable Tyvek pouch. Brings residual O2 below 0.1% within 24 hours of sealing.\n\n'
                    '• Food Safety: Sachet marked "DO NOT EAT" conforming to FSSAI packaging norms.',
                    style: AppTypography.body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
