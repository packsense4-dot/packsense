import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/auth/auth_repository.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailCtrl = TextEditingController(text: 'farmer@packsense.org');
  final _passCtrl = TextEditingController(text: 'password123');

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authStateProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                const Center(
                  child: Text(
                    'PACKSENSE',
                    style: TextStyle(
                      fontFamily: AppTypography.monoFamily,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                      color: AppColors.primaryEmerald,
                    ),
                  ),
                ),
                const Center(
                  child: Text(
                    'INDUSTRIAL PACKAGING CLIENT',
                    style: TextStyle(
                      fontFamily: AppTypography.monoFamily,
                      fontSize: 10,
                      letterSpacing: 1.2,
                      color: AppColors.textMuted,
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                // Form
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('OPERATOR EMAIL', style: AppTypography.statLabel),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _emailCtrl,
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                        decoration: const InputDecoration(
                          hintText: 'user@packsense.org',
                          prefixIcon: Icon(Icons.badge, size: 18, color: AppColors.textMuted),
                        ),
                      ),
                      const SizedBox(height: 16),

                      const Text('SECRET KEY / PASSWORD', style: AppTypography.statLabel),
                      const SizedBox(height: 6),
                      TextField(
                        controller: _passCtrl,
                        obscureText: true,
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                        decoration: const InputDecoration(
                          hintText: '••••••••',
                          prefixIcon: Icon(Icons.lock, size: 18, color: AppColors.textMuted),
                        ),
                      ),
                      const SizedBox(height: 20),

                      if (authState.isLoading)
                        const Center(child: CircularProgressIndicator(color: AppColors.primaryEmerald))
                      else
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryEmerald,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            minimumSize: const Size.fromHeight(48),
                          ),
                          onPressed: () async {
                            await ref.read(authStateProvider.notifier).login(
                              _emailCtrl.text.trim(),
                              _passCtrl.text.trim(),
                            );
                            if (mounted) context.go('/home');
                          },
                          child: const Text('AUTHENTICATE', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Demo role switcher
                TextButton(
                  onPressed: () => context.go('/onboarding'),
                  child: const Text(
                    'Setup Role & Language (First Run)',
                    style: TextStyle(color: AppColors.secondarySky, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
