import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/auth/auth_state_provider.dart';
import '../../core/auth/auth_repository.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/primary_button.dart';
import '../../core/widgets/icon_circle_badge.dart';
import '../../core/widgets/radio_select_card.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  String _selectedLang = 'en';
  UserRole _selectedRole = UserRole.farmer;
  int _onboardingStep = 0; // 0: Splash & Welcome, 1: Role & Language Setup

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: _onboardingStep == 0
          ? _buildSplashScreen()
          : _buildRoleSetupScreen(),
    );
  }

  /// Screen 0: Reference Design Splash Screen
  /// - App name: PackSense AI
  /// - Tagline: "Smarter Packaging. Fresher Food. A Greener Future."
  /// - Footer tag: "Powered by AI + Physics + Sustainability"
  Widget _buildSplashScreen() {
    return Column(
      children: [
        // Blue Gradient Top Hero Area
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(24, 60, 24, 36),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.gradientStart, AppColors.gradientEnd],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(32),
              bottomRight: Radius.circular(32),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Logo Icon & Chip
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.qr_code_scanner,
                        color: AppColors.primaryDark,
                        size: 30,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withOpacity(0.35)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.verified, color: Colors.white, size: 13),
                        SizedBox(width: 4),
                        Text(
                          'ISO 15105 / ASTM D3985',
                          style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              const Text(
                'PackSense AI',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Smarter Packaging. Fresher Food. A Greener Future.',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFFE0F2FE),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Deterministic shelf-life simulation, barrier optimization, and scan-first diagnostics.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.white.withOpacity(0.9),
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),

        // Body Content: White Rounded Cards on Soft Light-Blue Background
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                RoundedCard(
                  child: Row(
                    children: [
                      const IconCircleBadge(
                        icon: Icons.document_scanner,
                        size: 44,
                        iconSize: 22,
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Scan-First Film & Barrier Detection',
                              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Point camera at any pouch or packaging label for instant OTR/WVTR & FSSAI check.',
                              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                RoundedCard(
                  child: Row(
                    children: [
                      const IconCircleBadge(
                        icon: Icons.auto_graph,
                        size: 44,
                        iconSize: 22,
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Multi-Objective Physics Optimizer',
                              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Balance shelf life, material cost (₹/m²), and sustainability on the Pareto frontier.',
                              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                RoundedCard(
                  child: Row(
                    children: [
                      const IconCircleBadge(
                        icon: Icons.wifi_off,
                        backgroundColor: AppColors.successTint,
                        iconColor: AppColors.success,
                        size: 44,
                        iconSize: 22,
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Offline-Ready for Farm & Factory',
                              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Full deterministic engine runs locally without internet connectivity.',
                              style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),

                // Language quick toggle pill row
                Row(
                  children: [
                    _buildLangPill('English', 'en'),
                    const SizedBox(width: 8),
                    _buildLangPill('हिंदी', 'hi'),
                    const SizedBox(width: 8),
                    _buildLangPill('मराठी', 'mr'),
                    const SizedBox(width: 8),
                    _buildLangPill('தமிழ்', 'ta'),
                  ],
                ),
                const SizedBox(height: 20),

                // Primary CTA button
                PrimaryButton(
                  label: 'Get Started',
                  icon: Icons.arrow_forward,
                  onPressed: () {
                    setState(() => _onboardingStep = 1);
                  },
                ),

                const SizedBox(height: 16),
                // Footer Tag matching reference design
                const Center(
                  child: Text(
                    'Powered by AI + Physics + Sustainability',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Screen 1: Role Configuration
  Widget _buildRoleSetupScreen() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
                  onPressed: () => setState(() => _onboardingStep = 0),
                ),
                const SizedBox(width: 6),
                const Expanded(
                  child: Text(
                    'Select Operating Role',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                children: [
                  RadioSelectCard(
                    icon: Icons.agriculture,
                    title: 'Farmer / Grower',
                    subtitle: 'Scan-first mode: Point & scan pouch, voice queries, shelf life, ZECC evaporative advice.',
                    isSelected: _selectedRole == UserRole.farmer,
                    onTap: () => setState(() => _selectedRole = UserRole.farmer),
                    badgeText: 'SIMPLE MODE',
                  ),
                  RadioSelectCard(
                    icon: Icons.groups,
                    title: 'FPO Manager',
                    subtitle: 'Aggregated produce batching, collective film procurement, cold chain audit.',
                    isSelected: _selectedRole == UserRole.fpo,
                    onTap: () => setState(() => _selectedRole = UserRole.fpo),
                  ),
                  RadioSelectCard(
                    icon: Icons.factory,
                    title: 'MSME Food Processor',
                    subtitle: 'Seal integrity testing, FSSAI IS 9845 compliance checklist, oxygen barrier selection.',
                    isSelected: _selectedRole == UserRole.msme,
                    onTap: () => setState(() => _selectedRole = UserRole.msme),
                  ),
                  RadioSelectCard(
                    icon: Icons.engineering,
                    title: 'Packaging Engineer',
                    subtitle: 'Full Arrhenius kinetics, gas diffusion curves, Pareto multi-objective optimization suite.',
                    isSelected: _selectedRole == UserRole.industry,
                    onTap: () => setState(() => _selectedRole = UserRole.industry),
                    badgeText: 'DASHBOARD',
                  ),
                  RadioSelectCard(
                    icon: Icons.account_balance,
                    title: 'MoFPI / Ag Officer',
                    subtitle: 'District post-harvest spoilage loss heatmaps, regional packaging scheme insights.',
                    isSelected: _selectedRole == UserRole.government,
                    onTap: () => setState(() => _selectedRole = UserRole.government),
                  ),
                  RadioSelectCard(
                    icon: Icons.admin_panel_settings,
                    title: 'System Administrator',
                    subtitle: 'Materials database CRUD, Arrhenius coefficients, laboratory calibration logs.',
                    isSelected: _selectedRole == UserRole.admin,
                    onTap: () => setState(() => _selectedRole = UserRole.admin),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            PrimaryButton(
              label: 'Enter Scanner Console',
              icon: Icons.qr_code_scanner,
              onPressed: () {
                ref.read(authStateProvider.notifier).switchLanguage(_selectedLang);
                ref.read(authStateProvider.notifier).switchRole(_selectedRole);
                context.go('/home');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLangPill(String label, String code) {
    final isSelected = _selectedLang == code;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedLang = code),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected ? AppColors.primary : AppColors.border,
              width: 1,
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
              color: isSelected ? Colors.white : AppColors.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}
