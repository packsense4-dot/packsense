import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/status_badge.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final historyItems = [
      {
        'title': 'Potato Chips (150g Pouch)',
        'time': 'Today, 11:42 AM',
        'material': 'BOPP 20µm / Met-PET 12µm / LDPE 40µm',
        'shelfLife': '78 Days',
        'status': 'Verified',
        'variant': StatusBadgeVariant.success,
      },
      {
        'title': 'Alphonso Mango (4-pack Tray)',
        'time': 'Yesterday, 04:15 PM',
        'material': 'Micro-perforated LDPE 30µm',
        'shelfLife': '18 Days',
        'status': 'Optimal MAP',
        'variant': StatusBadgeVariant.success,
      },
      {
        'title': 'Tomato Puree Pouch (200g)',
        'time': '26 Sep 2026',
        'material': 'PET 12µm / Al-Foil 7µm / CPP 40µm',
        'shelfLife': '180 Days',
        'status': 'Compliant',
        'variant': StatusBadgeVariant.success,
      },
      {
        'title': 'Basmati Rice (1kg)',
        'time': '24 Sep 2026',
        'material': 'Monolayer LDPE 40µm Non-barrier',
        'shelfLife': '35 Days',
        'status': 'Moisture Risk',
        'variant': StatusBadgeVariant.danger,
      },
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(
          'Scan & Audit History',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.textPrimary),
        ),
        backgroundColor: AppColors.surface,
        elevation: 0,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(
              child: StatusBadge(
                label: '4 Audits',
                variant: StatusBadgeVariant.success,
              ),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: historyItems.length,
        itemBuilder: (context, idx) {
          final item = historyItems[idx];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x040F172A),
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(item['time'] as String, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                    StatusBadge(
                      label: item['status'] as String,
                      variant: item['variant'] as StatusBadgeVariant,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  item['title'] as String,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                ),
                const SizedBox(height: 2),
                Text(item['material'] as String, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.timer_outlined, size: 14, color: AppColors.primary),
                    const SizedBox(width: 4),
                    Text(
                      'Predicted Shelf Life: ${item['shelfLife']}',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.primaryDark),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
