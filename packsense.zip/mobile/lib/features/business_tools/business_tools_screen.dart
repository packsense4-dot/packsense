import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/primary_button.dart';
import '../../core/widgets/stat_row.dart';
import '../../core/widgets/info_bar.dart';

/// Section 5.15: Business Tools Screen (Role-conditional for industry/admin/government)
class BusinessToolsScreen extends StatelessWidget {
  const BusinessToolsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Business & Enterprise Tools',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const InfoBar(
              text: 'Enterprise batch processing, bulk SKU simulation, and supply chain telemetry.',
              icon: Icons.business_center_outlined,
            ),
            const SizedBox(height: 14),

            // Bulk Upload Tool
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BULK SKU & SPECIFICATION UPLOAD',
                    style: TextStyle(fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Upload CSV/Excel file containing multiple food SKUs to generate batch OTR/WVTR recommendations.',
                    style: TextStyle(fontFamily: 'Inter', fontSize: 12, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 12),
                  PrimaryButton(
                    label: 'Upload Product Catalog (.xlsx)',
                    icon: Icons.upload_file_rounded,
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Selected catalog_sample_50_skus.xlsx for batch simulation.'),
                          backgroundColor: AppColors.primary,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Batch Analytics Summary
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'PORTFOLIO BARRIER AUDIT SUMMARY',
                    style: TextStyle(fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                  ),
                  SizedBox(height: 8),
                  StatRow(
                    icon: Icons.inventory_2_outlined,
                    label: 'Indexed Production Batches',
                    value: '1,420 Batches',
                  ),
                  Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.eco_outlined,
                    label: 'Average Recyclability Score',
                    value: '84.2%',
                    unit: 'PWM 2022 compliant',
                  ),
                  Divider(height: 1, color: AppColors.border),
                  StatRow(
                    icon: Icons.currency_rupee,
                    label: 'Consolidated Waste Avoidance',
                    value: '₹4.82 Crores',
                    iconColor: AppColors.success,
                    iconBgColor: AppColors.successTint,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Links to Admin & Gov Dashboards
            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ADMINISTRATIVE CONTROL PANELS',
                    style: TextStyle(fontFamily: 'Inter', fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.primary,
                            side: const BorderSide(color: AppColors.primary),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          onPressed: () => context.push('/admin'),
                          icon: const Icon(Icons.admin_panel_settings, size: 16),
                          label: const Text('Admin Panel', style: TextStyle(fontFamily: 'Inter', fontSize: 12, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.primaryDark,
                            side: const BorderSide(color: AppColors.border),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          onPressed: () => context.push('/gov-dashboard'),
                          icon: const Icon(Icons.account_balance, size: 16),
                          label: const Text('Gov Heatmap', style: TextStyle(fontFamily: 'Inter', fontSize: 12, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
