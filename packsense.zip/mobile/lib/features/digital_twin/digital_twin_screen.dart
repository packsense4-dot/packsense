import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/segmented_tab_bar.dart';
import '../../core/widgets/line_chart_card.dart';
import '../../core/widgets/gas_stat_circle.dart';
import '../../core/widgets/info_bar.dart';
import '../../core/widgets/primary_button.dart';

/// Section 5.6: Digital Twin — Simulation Results (Feature #1)
/// Matches reference design:
/// - SegmentedTabBar ("Shelf Life / Gas Composition / Temperature")
/// - LineChartCard ("Predicted Shelf Life", "6 Months", Recommended vs Standard)
/// - GasStatCircle row (O2 / CO2 / N2 %)
/// - Interactive temperature slider (12°C–35°C)
/// - InfoBar ("Simulation based on Indian climate")
/// - PrimaryButton "Download Report"
class DigitalTwinScreen extends StatefulWidget {
  const DigitalTwinScreen({Key? key}) : super(key: key);

  @override
  State<DigitalTwinScreen> createState() => _DigitalTwinScreenState();
}

class _DigitalTwinScreenState extends State<DigitalTwinScreen> {
  int _activeTab = 0; // 0: Shelf Life, 1: Gas Composition, 2: Temperature
  double _temperatureC = 25.0;
  int _calculatedDays = 180; // "6 Months"

  void _onTemperatureChanged(double temp) {
    setState(() {
      _temperatureC = temp;
      // Arrhenius Q10 simulation logic: every 10°C rise halves shelf life
      final factor = (temp - 25.0) / 10.0;
      _calculatedDays = (180 / (1.0 + (factor > 0 ? factor * 1.2 : factor * 0.7))).round().clamp(14, 365);
    });
  }

  @override
  Widget build(BuildContext context) {
    final months = (_calculatedDays / 30).toStringAsFixed(0);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: const Text(
          'Simulation Results',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: AppColors.textPrimary,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // SegmentedTabBar: Shelf Life / Gas Composition / Temperature
            SegmentedTabBar(
              tabs: const ['Shelf Life', 'Gas Composition', 'Temperature'],
              selectedIndex: _activeTab,
              onTabSelected: (idx) => setState(() => _activeTab = idx),
            ),
            const SizedBox(height: 16),

            if (_activeTab == 0) ...[
              // TAB 0: Shelf Life LineChartCard
              LineChartCard(
                title: 'Predicted Shelf Life',
                statValue: '$months Months',
                statLabel: 'Optimal Chilled Range',
                recommendedSpots: const [
                  FlSpot(0, 100),
                  FlSpot(15, 92),
                  FlSpot(30, 84),
                  FlSpot(45, 75),
                  FlSpot(60, 68),
                ],
                standardSpots: const [
                  FlSpot(0, 85),
                  FlSpot(15, 60),
                  FlSpot(30, 40),
                  FlSpot(45, 20),
                  FlSpot(60, 5),
                ],
                recommendedLabel: 'Recommended Pack (Solid)',
                standardLabel: 'Standard Pack (Dashed)',
                maxY: 100,
                maxX: 60,
              ),
            ] else if (_activeTab == 1) ...[
              // TAB 1: GasStatCircle Row
              RoundedCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Gas Composition (MAP)',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Equilibrium headspace concentrations after 180 days',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 11,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    SizedBox(height: 18),
                    GasStatCircle(
                      items: [
                        GasStatItem(label: 'Oxygen (O₂)', percentage: '1.2%', color: AppColors.primary),
                        GasStatItem(label: 'Carbon Dioxide', percentage: '18.5%', color: AppColors.primaryDark),
                        GasStatItem(label: 'Nitrogen (N₂)', percentage: '80.3%', color: AppColors.success),
                      ],
                    ),
                  ],
                ),
              ),
            ] else ...[
              // TAB 2: Interactive Temperature Slider
              RoundedCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Ambient Storage Temperature',
                          style: TextStyle(fontFamily: 'Poppins', fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${_temperatureC.toStringAsFixed(1)}°C',
                          style: const TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Slider(
                      value: _temperatureC,
                      min: 12.0,
                      max: 35.0,
                      divisions: 23,
                      activeColor: AppColors.primary,
                      onChanged: _onTemperatureChanged,
                    ),
                    const SizedBox(height: 12),
                    LineChartCard(
                      title: 'Decay Curve at ${_temperatureC.toStringAsFixed(0)}°C',
                      statValue: '$_calculatedDays Days',
                      statLabel: 'Computed via Arrhenius / Crank-Nicolson',
                      recommendedSpots: [
                        const FlSpot(0, 100),
                        FlSpot(15, (_calculatedDays > 100 ? 90 : 70)),
                        FlSpot(30, (_calculatedDays > 100 ? 80 : 50)),
                        FlSpot(45, (_calculatedDays > 100 ? 70 : 30)),
                        FlSpot(60, (_calculatedDays > 100 ? 60 : 10)),
                      ],
                      standardSpots: const [
                        FlSpot(0, 80),
                        FlSpot(15, 50),
                        FlSpot(30, 25),
                        FlSpot(45, 10),
                        FlSpot(60, 2),
                      ],
                      maxY: 100,
                      maxX: 60,
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 14),

            // Bottom InfoBar Tip
            const InfoBar(
              text: 'Simulation based on Indian climate (Maharashtra / Monsoon season).',
              icon: Icons.lightbulb_outline,
            ),
            const SizedBox(height: 16),

            // Primary Button: Download Report
            PrimaryButton(
              label: 'Download Report',
              icon: Icons.download_rounded,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Downloading PackSense_Simulation_Report.pdf...'),
                    backgroundColor: AppColors.primary,
                  ),
                );
              },
            ),
            const SizedBox(height: 10),

            // Secondary link: View Optimizer 3 Options
            TextButton(
              onPressed: () => context.push('/optimize'),
              child: const Text(
                'View 3-Way Pareto Optimization →',
                style: TextStyle(fontFamily: 'Inter', fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.primary),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
