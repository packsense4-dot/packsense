import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';
import '../../core/widgets/rounded_card.dart';
import '../../core/widgets/pill_tab_bar.dart';

class RuralModeScreen extends StatefulWidget {
  const RuralModeScreen({Key? key}) : super(key: key);

  @override
  State<RuralModeScreen> createState() => _RuralModeScreenState();
}

class _RuralModeScreenState extends State<RuralModeScreen> {
  int _tabIndex = 0; // 0: ZECC Chamber, 1: Hermetic Bags, 2: Solar Dryer

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Rural Mode: Low-Cost Storage'),
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PillTabBar(
              tabs: const ['ZECC Chamber', 'Hermetic Bags', 'Solar Drying'],
              selectedIndex: _tabIndex,
              onTabSelected: (idx) => setState(() => _tabIndex = idx),
            ),
            const SizedBox(height: 14),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ZERO ENERGY COOL CHAMBER (ZECC)', style: AppTypography.statLabel),
                  const SizedBox(height: 6),
                  const Text(
                    'Evaporative Cooling with River Sand Cavity',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Built using standard red clay bricks and wet sand. Drops internal chamber temperature by 10-15°C below ambient without electricity.',
                    style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'TEMP REDUCTION',
                          value: '10-15',
                          unit: '°C evaporative drop',
                          accentColor: AppColors.primary,
                          badgeText: 'ZECC PASSIVE',
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'POWER REQUIRED',
                          value: '0',
                          unit: 'kWh (Zero Electricity)',
                          accentColor: AppColors.success,
                          badgeText: 'NO GRID',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: const [
                      Expanded(
                        child: NumericStatCard(
                          label: 'CONSTRUCTION COST',
                          value: '₹3,500',
                          unit: 'local bricks + sand',
                          accentColor: AppColors.primaryDark,
                          badgeText: 'LOW COST',
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: NumericStatCard(
                          label: 'RELATIVE HUMIDITY',
                          value: '90-95%',
                          unit: 'prevents shrinkage',
                          accentColor: AppColors.primary,
                          badgeText: 'HYDRATION',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            RoundedCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('FARM OPERATIONAL GUIDELINES', style: AppTypography.statLabel),
                  const SizedBox(height: 8),
                  const Text(
                    '1. Wet sand between brick walls twice daily (morning & evening).\n'
                    '2. Cover top with khaskhas/bamboo matting to block direct solar radiation.\n'
                    '3. Keeps tomatoes firm for 18 days vs 4 days in open ambient.',
                    style: TextStyle(fontSize: 12, color: AppColors.textPrimary, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
