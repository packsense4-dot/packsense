import 'package:flutter/material.dart';
import '../../core/theme/colors.dart';
import '../../core/theme/typography.dart';
import '../../core/widgets/numeric_stat_card.dart';

class SecondaryPackagingScreen extends StatelessWidget {
  const SecondaryPackagingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Feature #15: Secondary Packaging Corrugated Box')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'REQUIRED BURST STRENGTH',
                    value: '1750',
                    unit: 'kPa (5-Ply Kraft)',
                    accentColor: AppColors.primaryEmerald,
                    badgeText: 'MCKEE COMPLIANT',
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'VENTILATION AREA',
                    value: '7.0',
                    unit: '% sidewall venting',
                    accentColor: AppColors.secondarySky,
                    badgeText: 'COOLING FLOW',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: const [
                Expanded(
                  child: NumericStatCard(
                    label: 'MAX STACK HEIGHT',
                    value: '250',
                    unit: 'cm stack limit',
                    accentColor: AppColors.warningAmber,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: NumericStatCard(
                    label: 'EST. BOX COST',
                    value: '₹56.00',
                    unit: 'INR per corrugated carton',
                    accentColor: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('MCKEE COMPRESSION & CORRUGATED STANDARDS', style: AppTypography.statLabel),
                  SizedBox(height: 8),
                  Text(
                    'Recommended Grade: 5-Ply High-Moisture Wet Strength Kraft (Resin Treated).\n'
                    'Cold storage relative humidity (> 85% RH) weakens standard corrugated fiberboard by up to 50%. The McKee formula guarantees that stacked cartons will withstand pallet weight during 30 days of cold storage without side-wall bulge.',
                    style: AppTypography.body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
