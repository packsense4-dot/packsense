import 'package:flutter/foundation.dart';

enum UserRole {
  farmer,
  fpo,
  msme,
  industry,
  admin,
  government
}

extension UserRoleExtension on UserRole {
  bool get isSimpleMode =>
      this == UserRole.farmer || this == UserRole.fpo || this == UserRole.msme;

  String get displayName {
    switch (this) {
      case UserRole.farmer:
        return 'Farmer';
      case UserRole.fpo:
        return 'FPO Manager';
      case UserRole.msme:
        return 'MSME Processor';
      case UserRole.industry:
        return 'Industry Engineer';
      case UserRole.admin:
        return 'System Admin';
      case UserRole.government:
        return 'MoFPI Officer';
    }
  }
}

class AppState extends ChangeNotifier {
  UserRole _role = UserRole.farmer;
  String _language = 'en';
  bool _offlineMode = false;
  int _pendingSyncTransactions = 0;

  UserRole get role => _role;
  String get language => _language;
  bool get isSimpleMode => _role.isSimpleMode;
  bool get offlineMode => _offlineMode;
  int get pendingSyncTransactions => _pendingSyncTransactions;

  void setRole(UserRole newRole) {
    _role = newRole;
    notifyListeners();
  }

  void setLanguage(String langCode) {
    _language = langCode;
    notifyListeners();
  }

  void toggleOffline(bool val) {
    _offlineMode = val;
    notifyListeners();
  }

  void incrementSync() {
    _pendingSyncTransactions++;
    notifyListeners();
  }

  void clearSync() {
    _pendingSyncTransactions = 0;
    notifyListeners();
  }
}
