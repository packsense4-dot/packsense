import 'package:flutter/material.dart';
import '../theme/industrial_theme.dart';

class NumericReadout extends StatelessWidget {
  final String label;
  final String value;
  final String unit;
  final Color accentColor;
  final String? statusBadge;

  const NumericReadout({
    Key? key,
    required this.label,
    required this.value,
    required this.unit,
    this.accentColor = IndustrialTheme.primaryEmerald,
    this.statusBadge,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: IndustrialTheme.surface,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: IndustrialTheme.border, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label.toUpperCase(),
                style: const TextStyle(
                  fontSize: 10,
                  letterSpacing: 0.8,
                  fontWeight: FontWeight.w600,
                  color: IndustrialTheme.textMuted,
                ),
              ),
              if (statusBadge != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: accentColor.withOpacity(0.5)),
                  ),
                  child: Text(
                    statusBadge!,
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      color: accentColor,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontFamily: 'Courier',
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: accentColor,
                ),
              ),
              const SizedBox(width: 4),
              Text(
                unit,
                style: const TextStyle(
                  fontSize: 11,
                  fontFamily: 'Courier',
                  color: IndustrialTheme.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
