import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/app_state.dart';
import '../../theme/industrial_theme.dart';
import '../../widgets/numeric_readout.dart';
import '../../services/api_service.dart';

class SimpleHomeScreen extends StatefulWidget {
  const SimpleHomeScreen({Key? key}) : super(key: key);

  @override
  State<SimpleHomeScreen> createState() => _SimpleHomeScreenState();
}

class _SimpleHomeScreenState extends State<SimpleHomeScreen> {
  String _selectedCrop = 'Potato Chips';
  int _targetDays = 60;
  double _shelfLifeDays = 72.0;
  bool _fssaiCompliant = true;
  bool _isListening = false;
  String _voicePromptText = 'Tap mic to speak (Hindi, Marathi, Tamil, English)';
  String _scanResultText = 'LDPE 40 micron mono-layer';
  bool _isScanning = false;

  final Map<String, Map<String, String>> _i18n = {
    'en': {
      'title': 'PackSense Mobile (Simple)',
      'crop_label': 'Selected Crop / Food',
      'scan_label': '1-Tap Pack Label Scan',
      'shelf_life': 'Expected Shelf Life',
      'fssai_status': 'FSSAI Status',
      'rural_tip': 'ZECC / Hermetic Storage',
      'days': 'DAYS',
      'pass': 'COMPLIANT',
      'fail': 'NON-COMPLIANT',
      'scan_btn': 'SCAN LABEL OCR',
      'voice_btn': 'VOICE COMMAND'
    },
    'hi': {
      'title': 'पैकसेंस मोबाइल (सरल मोड)',
      'crop_label': 'चुनी गई फसल / खाद्य',
      'scan_label': '1-टैप पैक लेबल स्कैन',
      'shelf_life': 'अनुमानित शेल्फ लाइफ',
      'fssai_status': 'FSSAI स्थिति',
      'rural_tip': 'जीरो एनर्जी कूल चैंबर (ZECC)',
      'days': 'दिन',
      'pass': 'स्वीकृत (COMPLIANT)',
      'fail': 'अस्वीकृत',
      'scan_btn': 'लेबल स्कैन करें',
      'voice_btn': 'आवाज से पूछें'
    },
    'mr': {
      'title': 'पॅकसेन्स मोबाईल (शेतकरी मोड)',
      'crop_label': 'निवडलेले पीक / अन्नपदार्थ',
      'scan_label': '१-टॅप पॅक लेबल स्कॅन',
      'shelf_life': 'अपेक्षित टिकवण क्षमता',
      'fssai_status': 'FSSAI निकष',
      'rural_tip': 'झिरो एनर्जी कूल चेंबर (ZECC)',
      'days': 'दिवस',
      'pass': 'प्रमाणित (COMPLIANT)',
      'fail': 'अपात्र',
      'scan_btn': 'लेबल स्कॅन करा',
      'voice_btn': 'आवाजाने बोला'
    },
    'ta': {
      'title': 'பேக்சென்ஸ் மொபைல் (எளிய முறை)',
      'crop_label': 'தேர்ந்தெடுக்கப்பட்ட பயிர்',
      'scan_label': '1-தட்டு லேபிள் ஸ்கேன்',
      'shelf_life': 'எதிர்பார்க்கப்படும் ஆயுள்',
      'fssai_status': 'FSSAI நிலை',
      'rural_tip': 'ஜீரோ எனர்ஜி கூல் சேம்பர்',
      'days': 'நாட்கள்',
      'pass': 'அங்கீகரிக்கப்பட்டது',
      'fail': 'இணங்கவில்லை',
      'scan_btn': 'லேபிளை ஸ்கேன் செய்',
      'voice_btn': 'குரல் கட்டளை'
    }
  };

  void _triggerVoice() {
    setState(() {
      _isListening = !_isListening;
      if (_isListening) {
        _voicePromptText = 'Listening to speech via Bhashini ASR...';
      } else {
        _voicePromptText = 'Voice command processed: "Alphonso Mango 40 micron"';
        _shelfLifeDays = 21.0;
        _selectedCrop = 'Alphonso Mango';
      }
    });
  }

  Future<void> _triggerScan() async {
    setState(() => _isScanning = true);
    try {
      final res = await ApiService.scanPackLabel('LDPE 40 MICRON FOOD GRADE');
      setState(() {
        _scanResultText = res['film_name'] ?? 'LDPE 40 micron mono-layer';
        _shelfLifeDays = 64.0;
      });
    } catch (_) {
      setState(() {
        _scanResultText = 'LDPE 40 micron (offline match)';
      });
    } finally {
      setState(() => _isScanning = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    final strings = _i18n[state.language] ?? _i18n['en']!;

    return Scaffold(
      backgroundColor: IndustrialTheme.background,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(strings['title']!),
            Text(
              '${state.role.displayName.toUpperCase()} MODE · OFFLINE-READY',
              style: const TextStyle(
                fontSize: 10,
                fontFamily: 'Courier',
                color: IndustrialTheme.primaryEmerald,
              ),
            ),
          ],
        ),
        actions: [
          // Language selector
          PopupMenuButton<String>(
            icon: const Icon(Icons.language, color: IndustrialTheme.secondarySky),
            onSelected: (val) => state.setLanguage(val),
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'en', child: Text('English')),
              const PopupMenuItem(value: 'hi', child: Text('हिंदी (Hindi)')),
              const PopupMenuItem(value: 'mr', child: Text('मराठी (Marathi)')),
              const PopupMenuItem(value: 'ta', child: Text('தமிழ் (Tamil)')),
            ],
          ),
          // Role switch back to dashboard or another role
          IconButton(
            icon: const Icon(Icons.switch_account_outlined, color: IndustrialTheme.textSecondary),
            onPressed: () {
              state.setRole(UserRole.industry);
            },
            tooltip: 'Switch to Dashboard Mode',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Crop selection card with large touch targets
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      strings['crop_label']!.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 11,
                        letterSpacing: 0.8,
                        color: IndustrialTheme.textMuted,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _selectedCrop,
                            dropdownColor: IndustrialTheme.surfaceCard,
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: IndustrialTheme.surface,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                                borderSide: const BorderSide(color: IndustrialTheme.border),
                              ),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            ),
                            items: const [
                              DropdownMenuItem(value: 'Potato Chips', child: Text('Potato Chips (आलू चिप्स)')),
                              DropdownMenuItem(value: 'Alphonso Mango', child: Text('Alphonso Mango (हापूस आंबा)')),
                              DropdownMenuItem(value: 'Tomato Puree', child: Text('Tomato Puree (टोमॅटो प्युरी)')),
                              DropdownMenuItem(value: 'Basmati Rice', child: Text('Basmati Rice (बासमती चावल)')),
                            ],
                            onChanged: (val) {
                              if (val != null) setState(() => _selectedCrop = val);
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Large 1-Tap Actions: Voice & OCR Scan
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isListening ? IndustrialTheme.dangerRose : IndustrialTheme.surfaceCard,
                      foregroundColor: IndustrialTheme.textPrimary,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      side: BorderSide(
                        color: _isListening ? IndustrialTheme.dangerRose : IndustrialTheme.secondarySky,
                        width: 1.5,
                      ),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                    ),
                    onPressed: _triggerVoice,
                    icon: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      size: 26,
                      color: _isListening ? Colors.white : IndustrialTheme.secondarySky,
                    ),
                    label: Text(
                      strings['voice_btn']!,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: IndustrialTheme.surfaceCard,
                      foregroundColor: IndustrialTheme.textPrimary,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      side: const BorderSide(color: IndustrialTheme.primaryEmerald, width: 1.5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                    ),
                    onPressed: _isScanning ? null : _triggerScan,
                    icon: _isScanning
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: IndustrialTheme.primaryEmerald),
                          )
                        : const Icon(Icons.qr_code_scanner, size: 26, color: IndustrialTheme.primaryEmerald),
                    label: Text(
                      strings['scan_btn']!,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Voice feedback banner if active
            if (_isListening || _voicePromptText.contains('processed'))
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: IndustrialTheme.surfaceCard,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: IndustrialTheme.secondarySky.withOpacity(0.5)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.record_voice_over, color: IndustrialTheme.secondarySky, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _voicePromptText,
                        style: const TextStyle(fontSize: 12, color: IndustrialTheme.textPrimary),
                      ),
                    ),
                  ],
                ),
              ),
            if (_isListening || _voicePromptText.contains('processed')) const SizedBox(height: 12),

            // Scan Readout Banner
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: IndustrialTheme.surface,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: IndustrialTheme.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.document_scanner, color: IndustrialTheme.primaryEmerald, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          strings['scan_label']!.toUpperCase(),
                          style: const TextStyle(fontSize: 9, color: IndustrialTheme.textMuted, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          _scanResultText,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: IndustrialTheme.primaryEmerald),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: IndustrialTheme.primaryEmerald.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text('MATCHED', style: TextStyle(fontSize: 9, color: IndustrialTheme.primaryEmerald, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Core Numeric Readouts Grid (Engineering Style)
            Row(
              children: [
                Expanded(
                  child: NumericReadout(
                    label: strings['shelf_life']!,
                    value: _shelfLifeDays.toStringAsFixed(0),
                    unit: strings['days']!,
                    accentColor: IndustrialTheme.primaryEmerald,
                    statusBadge: 'STABLE',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: NumericReadout(
                    label: strings['fssai_status']!,
                    value: _fssaiCompliant ? strings['pass']! : strings['fail']!,
                    unit: 'IS 9845',
                    accentColor: _fssaiCompliant ? IndustrialTheme.primaryEmerald : IndustrialTheme.dangerRose,
                    statusBadge: 'CERTIFIED',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                const Expanded(
                  child: NumericReadout(
                    label: 'BARRIER OTR',
                    value: '137.5',
                    unit: 'cc/m²·day',
                    accentColor: IndustrialTheme.secondarySky,
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: NumericReadout(
                    label: 'BARRIER WVTR',
                    value: '8.0',
                    unit: 'g/m²·day',
                    accentColor: IndustrialTheme.secondarySky,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Rural Mode Alternative Recommendation Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.eco, color: IndustrialTheme.warningAmber, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          strings['rural_tip']!.toUpperCase(),
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: IndustrialTheme.warningAmber),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Zero Energy Cool Chamber (ZECC) maintains 10-15°C lower temperature via evaporative cooling with wet sand and brick chamber. Extend shelf life without electricity.',
                      style: TextStyle(fontSize: 11, color: IndustrialTheme.textSecondary, height: 1.4),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
