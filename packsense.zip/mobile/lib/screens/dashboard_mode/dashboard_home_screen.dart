import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/app_state.dart';
import '../../theme/industrial_theme.dart';
import '../../widgets/numeric_readout.dart';
import '../../services/api_service.dart';

class DashboardHomeScreen extends StatefulWidget {
  const DashboardHomeScreen({Key? key}) : super(key: key);

  @override
  State<DashboardHomeScreen> createState() => _DashboardHomeScreenState();
}

class _DashboardHomeScreenState extends State<DashboardHomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedCommodity = 'potato_crisps';
  double _storageTemp = 23.0;
  double _ambientRh = 65.0;
  String _exportFeedback = '';

  final List<Map<String, dynamic>> _films = [
    {
      'name': 'BOPP / Met-BOPP / CPP (3-ply)',
      'otr': 1.8,
      'wvtr': 0.8,
      'cost': 14.50,
      'recyclable': 'Class B',
      'shelf_life': 180,
      'status': 'PASS'
    },
    {
      'name': 'Mono-PE 40µm MDO High-Barrier',
      'otr': 2.4,
      'wvtr': 1.2,
      'cost': 11.20,
      'recyclable': 'Class A (Mono)',
      'shelf_life': 150,
      'status': 'PASS'
    },
    {
      'name': 'LDPE 40µm Mono-Layer',
      'otr': 137.5,
      'wvtr': 8.0,
      'cost': 4.80,
      'recyclable': 'Class A',
      'shelf_life': 24,
      'status': 'FAIL (Moisture)'
    },
    {
      'name': 'PLA / PBAT Compostable Bio-Film',
      'otr': 45.0,
      'wvtr': 18.0,
      'cost': 18.00,
      'recyclable': 'IS 17088',
      'shelf_life': 30,
      'status': 'MARGINAL'
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _triggerExport(String format) {
    setState(() {
      _exportFeedback = 'Generated PackSense_$format report (${DateTime.now().toIso8601String().substring(0, 19)})';
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Report exported to $format successfully'),
        backgroundColor: IndustrialTheme.primaryEmerald,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);

    return Scaffold(
      backgroundColor: IndustrialTheme.background,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('PackSense Engineering Console'),
            Text(
              '${state.role.displayName.toUpperCase()} MODE · DATA-DENSE SIMULATION',
              style: const TextStyle(
                fontSize: 10,
                fontFamily: 'Courier',
                color: IndustrialTheme.secondarySky,
              ),
            ),
          ],
        ),
        actions: [
          // Quick export actions
          IconButton(
            icon: const Icon(Icons.download, color: IndustrialTheme.textSecondary),
            tooltip: 'Export CSV',
            onPressed: () => _triggerExport('CSV'),
          ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf, color: IndustrialTheme.textSecondary),
            tooltip: 'Export PDF Report',
            onPressed: () => _triggerExport('PDF'),
          ),
          // Role switcher
          PopupMenuButton<UserRole>(
            icon: const Icon(Icons.manage_accounts, color: IndustrialTheme.warningAmber),
            onSelected: (r) => state.setRole(r),
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: UserRole.industry, child: Text('Industry Engineer')),
              const PopupMenuItem(value: UserRole.admin, child: Text('System Admin')),
              const PopupMenuItem(value: UserRole.government, child: Text('Government (MoFPI)')),
              const PopupMenuItem(value: UserRole.farmer, child: Text('Switch to Simple (Farmer)')),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: IndustrialTheme.secondarySky,
          labelColor: IndustrialTheme.secondarySky,
          unselectedLabelColor: IndustrialTheme.textMuted,
          labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Courier'),
          tabs: const [
            Tab(text: 'CANDIDATE MATRIX'),
            Tab(text: 'PHYSICS TELEMETRY'),
            Tab(text: 'GOV / DISTRICT GAPS'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: Dense Candidate Matrix
          _buildCandidateMatrixTab(),

          // Tab 2: Physics Telemetry & Arrhenius Models
          _buildPhysicsTelemetryTab(),

          // Tab 3: Government District Stats
          _buildGovDashboardTab(),
        ],
      ),
    );
  }

  Widget _buildCandidateMatrixTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Bulk actions & filter bar
          Row(
            children: [
              Expanded(
                child: Text(
                  'PARALLEL LAMINATE EVALUATION (${_films.length} CANDIDATES)',
                  style: const TextStyle(fontSize: 10, fontFamily: 'Courier', color: IndustrialTheme.textMuted, fontWeight: FontWeight.bold),
                ),
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: IndustrialTheme.surfaceCard,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  side: const BorderSide(color: IndustrialTheme.border),
                ),
                onPressed: () => _triggerExport('CSV'),
                icon: const Icon(Icons.file_download, size: 14, color: IndustrialTheme.primaryEmerald),
                label: const Text('BULK EXPORT', style: TextStyle(fontSize: 10, fontFamily: 'Courier')),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Data-Dense Table
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: MaterialStateProperty.all(IndustrialTheme.surface),
              dataRowColor: MaterialStateProperty.all(IndustrialTheme.surfaceCard),
              columnSpacing: 16,
              horizontalMargin: 12,
              columns: const [
                DataColumn(label: Text('FILM CANDIDATE', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('OTR (cc)', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('WVTR (g)', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('COST (₹/m²)', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('PWM 2022', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('SHELF LIFE', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
                DataColumn(label: Text('STATUS', style: TextStyle(fontSize: 10, color: IndustrialTheme.textMuted, fontFamily: 'Courier'))),
              ],
              rows: _films.map((f) {
                final isPass = f['status'].toString().startsWith('PASS');
                return DataRow(
                  cells: [
                    DataCell(Text(f['name'], style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: IndustrialTheme.textPrimary))),
                    DataCell(Text(f['otr'].toString(), style: const TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.secondarySky))),
                    DataCell(Text(f['wvtr'].toString(), style: const TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.secondarySky))),
                    DataCell(Text('₹${f['cost']}', style: const TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.textPrimary))),
                    DataCell(Text(f['recyclable'], style: const TextStyle(fontSize: 10, fontFamily: 'Courier', color: IndustrialTheme.textSecondary))),
                    DataCell(Text('${f['shelf_life']}d', style: const TextStyle(fontSize: 11, fontFamily: 'Courier', fontWeight: FontWeight.bold, color: IndustrialTheme.primaryEmerald))),
                    DataCell(
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: isPass ? IndustrialTheme.primaryEmerald.withOpacity(0.15) : IndustrialTheme.dangerRose.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        child: Text(
                          f['status'],
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Courier',
                            color: isPass ? IndustrialTheme.primaryEmerald : IndustrialTheme.dangerRose,
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),

          // Numeric Engineering Summary
          Row(
            children: const [
              Expanded(
                child: NumericReadout(
                  label: 'OPTIMAL RUN COST',
                  value: '11.20',
                  unit: 'INR / m²',
                  accentColor: IndustrialTheme.primaryEmerald,
                  statusBadge: 'PARETO BEST',
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: NumericReadout(
                  label: 'PLASTIC REDUCTION',
                  value: '28.5',
                  unit: '% vs 3-ply',
                  accentColor: IndustrialTheme.secondarySky,
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: NumericReadout(
                  label: 'EPR CREDIT OFFSET',
                  value: '4.80',
                  unit: '₹ / kg',
                  accentColor: IndustrialTheme.warningAmber,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPhysicsTelemetryTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: const [
              Expanded(
                child: NumericReadout(
                  label: 'ARRHENIUS RATE K(T)',
                  value: '0.048',
                  unit: 'day⁻¹ @ 23°C',
                  accentColor: IndustrialTheme.secondarySky,
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: NumericReadout(
                  label: 'Q10 COEFFICIENT',
                  value: '2.14',
                  unit: 'dimless',
                  accentColor: IndustrialTheme.primaryEmerald,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'HEADSPACE GAS COMPOSITION TRANSMISSION (FICK DIFFUSION)',
                    style: TextStyle(fontSize: 10, fontFamily: 'Courier', color: IndustrialTheme.textMuted, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 120,
                    decoration: BoxDecoration(
                      color: IndustrialTheme.surface,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: IndustrialTheme.border),
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('O2 CONCENTRATION (%)', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.secondarySky)),
                            Text('0.20% → 1.85% (Target < 2.0%)', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.primaryEmerald, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        LinearProgressIndicator(value: 0.35, backgroundColor: IndustrialTheme.border, color: IndustrialTheme.secondarySky),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('CO2 RETENTION (%)', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.warningAmber)),
                            Text('20.0% → 17.2% (Decay 0.14%/d)', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.warningAmber, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        LinearProgressIndicator(value: 0.72, backgroundColor: IndustrialTheme.border, color: IndustrialTheme.warningAmber),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGovDashboardTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'MINISTRY OF FOOD PROCESSING INDUSTRIES (MoFPI) DISTRICT GAPS',
            style: TextStyle(fontSize: 10, fontFamily: 'Courier', color: IndustrialTheme.textMuted, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),

          Row(
            children: const [
              Expanded(
                child: NumericReadout(
                  label: 'AVERAGE POSTHARVEST LOSS',
                  value: '22.4',
                  unit: '% production',
                  accentColor: IndustrialTheme.dangerRose,
                  statusBadge: 'CRITICAL',
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: NumericReadout(
                  label: 'SAVABLE LOSS VALUE',
                  value: '42.8',
                  unit: 'Crore INR / district',
                  accentColor: IndustrialTheme.primaryEmerald,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'HIGH-PRIORITY PACKAGING GAPS BY AGRO-DISTRICT',
                    style: TextStyle(fontSize: 10, fontFamily: 'Courier', color: IndustrialTheme.textMuted, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text('Ratnagiri, Maharashtra (Alphonso Mango)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                    subtitle: Text('Gap: Widespread use of non-breathable LDPE causing 28% condensation & fungal decay. Remediation: Micro-perforated bio-LDPE.', style: TextStyle(fontSize: 10, color: IndustrialTheme.textSecondary)),
                    trailing: Text('28% LOSS', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.dangerRose, fontWeight: FontWeight.bold)),
                  ),
                  Divider(color: IndustrialTheme.border),
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text('Nashik, Maharashtra (Table Grapes / Onions)', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                    subtitle: Text('Gap: Inadequate SO2 generator pads and poor top-venting in corrugated boxes during reefer delays.', style: TextStyle(fontSize: 10, color: IndustrialTheme.textSecondary)),
                    trailing: Text('19% LOSS', style: TextStyle(fontSize: 11, fontFamily: 'Courier', color: IndustrialTheme.warningAmber, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
