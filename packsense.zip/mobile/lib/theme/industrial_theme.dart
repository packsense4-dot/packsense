import 'package:flutter/material.dart';

class IndustrialTheme {
  static const Color background = Color(0xFF090D16);
  static const Color surface = Color(0xFF0F172A);
  static const Color surfaceCard = Color(0xFF1E293B);
  static const Color border = Color(0xFF334155);
  static const Color borderLight = Color(0xFF475569);

  // Status & Telemetry Accents
  static const Color primaryEmerald = Color(0xFF10B981);
  static const Color secondarySky = Color(0xFF0EA5E9);
  static const Color warningAmber = Color(0xFFF59E0B);
  static const Color dangerRose = Color(0xFFF43F5E);
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFF64748B);

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      primaryColor: primaryEmerald,
      cardColor: surfaceCard,
      colorScheme: const ColorScheme.dark(
        primary: primaryEmerald,
        secondary: secondarySky,
        surface: surface,
        error: dangerRose,
      ),
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: surface,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: textPrimary,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
      cardTheme: CardTheme(
        color: surfaceCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
          side: const BorderSide(color: border, width: 1),
        ),
      ),
    );
  }
}
