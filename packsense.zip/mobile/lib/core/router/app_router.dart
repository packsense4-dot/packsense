import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../auth/auth_state_provider.dart';
import '../auth/auth_repository.dart';
import '../widgets/bottom_nav_shell.dart';

// Screens
import '../../features/splash_onboarding/splash_screen.dart';
import '../../features/splash_onboarding/onboarding_screen.dart';
import '../../features/auth/login_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/history/history_screen.dart';
import '../../features/learn/learn_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/scan/scan_screen.dart';
import '../../features/scan/product_details_screen.dart';
import '../../features/food_profile/food_profile_screen.dart';
import '../../features/climate_profile/climate_profile_screen.dart';
import '../../features/digital_twin/digital_twin_screen.dart';
import '../../features/optimize/optimize_screen.dart';
import '../../features/pack_auditor/pack_auditor_screen.dart';
import '../../features/spoilage_autopsy/spoilage_autopsy_screen.dart';
import '../../features/active_packaging/active_packaging_screen.dart';
import '../../features/condensation_risk/condensation_risk_screen.dart';
import '../../features/mixed_load/mixed_load_screen.dart';
import '../../features/right_sizing/right_sizing_screen.dart';
import '../../features/secondary_packaging/secondary_packaging_screen.dart';
import '../../features/rupee_impact/rupee_impact_screen.dart';
import '../../features/rural_mode/rural_mode_screen.dart';
import '../../features/community_loop/community_loop_screen.dart';
import '../../features/qr_passport/qr_passport_screen.dart';
import '../../features/supplier_match/supplier_match_screen.dart';
import '../../features/reports/reports_screen.dart';
import '../../features/gov_dashboard/gov_dashboard_screen.dart';
import '../../features/admin/admin_screen.dart';
import '../../features/business_tools/business_tools_screen.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    redirect: (BuildContext context, GoRouterState state) {
      final isAuth = authState.isAuthenticated;
      final isLoggingIn = state.matchedLocation == '/login';
      final isOnboarding = state.matchedLocation == '/onboarding';
      final isSplash = state.matchedLocation == '/splash';

      if (!isAuth && !isLoggingIn && !isOnboarding && !isSplash) {
        return '/login';
      }

      // Role guards for restricted routes
      if (state.matchedLocation == '/gov-dashboard') {
        if (authState.role != UserRole.government && authState.role != UserRole.admin) {
          return '/home';
        }
      }
      if (state.matchedLocation == '/admin') {
        if (authState.role != UserRole.admin) {
          return '/home';
        }
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/login',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const LoginScreen(),
      ),

      // Persistent 4-Tab StatefulShellRoute (Home / History / Learn / Profile)
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) {
          return Scaffold(
            body: navigationShell,
            bottomNavigationBar: BottomNavShell(
              currentIndex: navigationShell.currentIndex,
              onTabSelected: (index) => navigationShell.goBranch(
                index,
                initialLocation: index == navigationShell.currentIndex,
              ),
            ),
          );
        },
        branches: [
          // Tab 0: Home (Scan-First)
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/home',
                builder: (context, state) => const HomeScreen(),
              ),
            ],
          ),
          // Tab 1: History
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/history',
                builder: (context, state) => const HistoryScreen(),
              ),
            ],
          ),
          // Tab 2: Learn
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/learn',
                builder: (context, state) => const LearnScreen(),
              ),
            ],
          ),
          // Tab 3: Profile
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/profile',
                builder: (context, state) => const ProfileScreen(),
              ),
            ],
          ),
        ],
      ),

      // Pushed Full-Screen Detail & Backend Feature Routes
      GoRoute(
        path: '/scan',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ScanScreen(),
      ),
      GoRoute(
        path: '/product-details',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => ProductDetailsScreen(
          productData: state.extra as Map<String, dynamic>?,
        ),
      ),
      GoRoute(
        path: '/climate-profile',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ClimateProfileScreen(),
      ),
      GoRoute(
        path: '/food-profile',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const FoodProfileScreen(),
      ),
      GoRoute(
        path: '/digital-twin',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const DigitalTwinScreen(),
      ),
      GoRoute(
        path: '/optimize',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const OptimizeScreen(),
      ),
      GoRoute(
        path: '/pack-auditor',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const PackAuditorScreen(),
      ),
      GoRoute(
        path: '/spoilage-autopsy',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SpoilageAutopsyScreen(),
      ),
      GoRoute(
        path: '/active-packaging',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ActivePackagingScreen(),
      ),
      GoRoute(
        path: '/condensation-risk',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CondensationRiskScreen(),
      ),
      GoRoute(
        path: '/mixed-load',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const MixedLoadScreen(),
      ),
      GoRoute(
        path: '/right-sizing',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const RightSizingScreen(),
      ),
      GoRoute(
        path: '/secondary-packaging',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SecondaryPackagingScreen(),
      ),
      GoRoute(
        path: '/rupee-impact',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const RupeeImpactScreen(),
      ),
      GoRoute(
        path: '/rural-mode',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const RuralModeScreen(),
      ),
      GoRoute(
        path: '/community-loop',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CommunityLoopScreen(),
      ),
      GoRoute(
        path: '/qr-passport',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const QrPassportScreen(),
      ),
      GoRoute(
        path: '/supplier-match',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SupplierMatchScreen(),
      ),
      GoRoute(
        path: '/reports',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ReportsScreen(),
      ),
      GoRoute(
        path: '/gov-dashboard',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const GovDashboardScreen(),
      ),
      GoRoute(
        path: '/admin',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const AdminScreen(),
      ),
      GoRoute(
        path: '/business-tools',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const BusinessToolsScreen(),
      ),
    ],
  );
});
