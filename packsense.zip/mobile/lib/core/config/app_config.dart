/// AppConfig: Environment-based configuration using Flutter's --dart-define
/// No hardcoded base URL, no bundled .env file in release builds.
class AppConfig {
  AppConfig._();

  /// API Base URL passed at build/run time:
  /// e.g. --dart-define=API_BASE_URL=http://10.0.2.2:8000
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000', // safe local-dev default for Android emulator
  );

  /// Application environment identifier: 'local', 'staging', 'production'
  /// e.g. --dart-define=APP_ENV=local
  static const String environment = String.fromEnvironment(
    'APP_ENV',
    defaultValue: 'local',
  );

  static bool get isLocal => environment == 'local';
  static bool get isStaging => environment == 'staging';
  static bool get isProduction => environment == 'production';
}
