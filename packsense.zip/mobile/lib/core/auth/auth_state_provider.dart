import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../api/dio_client.dart';
import 'auth_repository.dart';

final dioClientProvider = Provider<DioClient>((ref) => DioClient());

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final dioClient = ref.watch(dioClientProvider);
  return AuthRepository(dioClient);
});

class AuthState {
  final UserModel? user;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.user,
    this.isLoading = false,
    this.error,
  });

  bool get isAuthenticated => user != null;
  UserRole get role => user?.role ?? UserRole.farmer;
  bool get isSimpleMode => role.isSimpleMode;
  String get language => user?.preferredLanguage ?? 'en';

  AuthState copyWith({
    UserModel? user,
    bool? isLoading,
    String? error,
  }) {
    return AuthState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }
}

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _repo;

  AuthNotifier(this._repo) : super(
    AuthState(
      user: UserModel(
        id: 1,
        email: 'farmer@packsense.org',
        fullName: 'Ramesh Patil (FPO)',
        role: UserRole.farmer,
        preferredLanguage: 'en',
      ),
    ),
  );

  Future<void> login(String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final user = await _repo.login(email, password);
      state = state.copyWith(user: user, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void switchRole(UserRole newRole) {
    if (state.user != null) {
      final updatedUser = UserModel(
        id: state.user!.id,
        email: state.user!.email,
        fullName: state.user!.fullName,
        role: newRole,
        preferredLanguage: state.user!.preferredLanguage,
      );
      state = state.copyWith(user: updatedUser);
    }
  }

  void switchLanguage(String langCode) {
    if (state.user != null) {
      final updatedUser = UserModel(
        id: state.user!.id,
        email: state.user!.email,
        fullName: state.user!.fullName,
        role: state.user!.role,
        preferredLanguage: langCode,
      );
      state = state.copyWith(user: updatedUser);
    }
  }

  Future<void> logout() async {
    await _repo.logout();
    state = const AuthState();
  }
}

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final repo = ref.watch(authRepositoryProvider);
  return AuthNotifier(repo);
});
