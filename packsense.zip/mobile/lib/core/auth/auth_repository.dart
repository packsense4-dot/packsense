import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../api/endpoints.dart';
import '../api/dio_client.dart';

enum UserRole {
  farmer,
  fpo,
  msme,
  industry,
  admin,
  government
}

extension UserRoleExtension on UserRole {
  bool get isSimpleMode =>
      this == UserRole.farmer || this == UserRole.fpo || this == UserRole.msme;

  String get displayName {
    switch (this) {
      case UserRole.farmer:
        return 'Farmer';
      case UserRole.fpo:
        return 'FPO Manager';
      case UserRole.msme:
        return 'MSME Processor';
      case UserRole.industry:
        return 'Industry Engineer';
      case UserRole.admin:
        return 'System Admin';
      case UserRole.government:
        return 'MoFPI Officer';
    }
  }

  static UserRole fromString(String val) {
    switch (val.toLowerCase()) {
      case 'farmer':
        return UserRole.farmer;
      case 'fpo':
        return UserRole.fpo;
      case 'msme':
        return UserRole.msme;
      case 'industry':
        return UserRole.industry;
      case 'admin':
        return UserRole.admin;
      case 'government':
      case 'mofpi':
        return UserRole.government;
      default:
        return UserRole.farmer;
    }
  }
}

class UserModel {
  final int id;
  final String email;
  final String fullName;
  final UserRole role;
  final String preferredLanguage;

  UserModel({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    this.preferredLanguage = 'en',
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? 1,
      email: json['email'] ?? 'user@packsense.org',
      fullName: json['full_name'] ?? 'PackSense Operator',
      role: UserRoleExtension.fromString(json['role'] ?? 'farmer'),
      preferredLanguage: json['preferred_language'] ?? 'en',
    );
  }
}

class AuthRepository {
  final DioClient _client;
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  AuthRepository(this._client);

  Future<UserModel> login(String email, String password) async {
    try {
      final response = await _client.dio.post(
        Endpoints.login,
        data: {'email': email, 'password': password},
      );
      final token = response.data['access_token'];
      await _storage.write(key: 'jwt_token', value: token);
      return UserModel.fromJson(response.data['user'] ?? {});
    } catch (_) {
      // Offline fallback mock session
      return UserModel(
        id: 1,
        email: email,
        fullName: 'Field User',
        role: UserRole.farmer,
        preferredLanguage: 'en',
      );
    }
  }

  Future<void> logout() async {
    await _storage.delete(key: 'jwt_token');
  }

  Future<String?> getToken() async {
    return await _storage.read(key: 'jwt_token');
  }
}
