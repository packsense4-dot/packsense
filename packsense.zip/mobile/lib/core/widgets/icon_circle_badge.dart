import 'package:flutter/material.dart';
import '../theme/colors.dart';

/// IconCircleBadge: A colored circle (default primaryTint background, primary icon)
/// Reused behind list-rows, grid-tiles, stat-rows, and profile-menu icons.
class IconCircleBadge extends StatelessWidget {
  final IconData icon;
  final Color backgroundColor;
  final Color iconColor;
  final double size;
  final double iconSize;

  const IconCircleBadge({
    Key? key,
    required this.icon,
    this.backgroundColor = AppColors.primaryTint,
    this.iconColor = AppColors.primary,
    this.size = 40.0,
    this.iconSize = 20.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: backgroundColor,
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Icon(
          icon,
          color: iconColor,
          size: iconSize,
        ),
      ),
    );
  }
}
