import 'package:flutter/material.dart';
import '../theme/colors.dart';
import 'icon_circle_badge.dart';

/// StatRow: icon-circle + two-line text (small grey label, bold dark value)
/// Used for OTR/WVTR/Shelf Life/Cost/CO2e rows in AI Recommendation,
/// and anywhere numeric specifications are listed.
class StatRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String? unit;
  final Color? iconColor;
  final Color? iconBgColor;
  final Widget? trailing;

  const StatRow({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
    this.unit,
    this.iconColor,
    this.iconBgColor,
    this.trailing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          IconCircleBadge(
            icon: icon,
            iconColor: iconColor ?? AppColors.primary,
            backgroundColor: iconBgColor ?? AppColors.primaryTint,
            size: 38,
            iconSize: 18,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      value,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.2,
                      ),
                    ),
                    if (unit != null) ...[
                      const SizedBox(width: 4),
                      Text(
                        unit!,
                        style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}
