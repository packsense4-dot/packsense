import 'package:flutter/material.dart';
import '../theme/colors.dart';

/// InfoBar: A light-blue full-width rounded strip with an icon and small text
/// ("Simulation based on Indian climate", "Make sure the barcode is clear and well lit").
class InfoBar extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color? backgroundColor;
  final Color? iconColor;
  final Color? textColor;

  const InfoBar({
    Key? key,
    required this.text,
    this.icon = Icons.info_outline,
    this.backgroundColor,
    this.iconColor,
    this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: backgroundColor ?? AppColors.primaryTint,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: (iconColor ?? AppColors.primary).withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 16,
            color: iconColor ?? AppColors.primaryDark,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 11,
                color: textColor ?? AppColors.textPrimary,
                height: 1.3,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
