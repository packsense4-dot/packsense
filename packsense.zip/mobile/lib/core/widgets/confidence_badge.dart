import 'package:flutter/material.dart';
import '../theme/colors.dart';
import '../theme/typography.dart';

/// ConfidenceBadge conforming to Section 5 & 8.5:
/// Colored chip (green ≥85, amber 70–84, red <70) showing the confidence score.
class ConfidenceBadge extends StatelessWidget {
  final int confidenceScore; // 0 to 100
  final bool showLabel;

  const ConfidenceBadge({
    Key? key,
    required this.confidenceScore,
    this.showLabel = true,
  }) : super(key: key);

  Color get _color {
    if (confidenceScore >= 85) return AppColors.success;
    if (confidenceScore >= 70) return AppColors.warning;
    return AppColors.danger;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3.5),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _color.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.verified, size: 12, color: _color),
          const SizedBox(width: 4),
          Text(
            '$confidenceScore%',
            style: TextStyle(
              fontFamily: AppTypography.monoFamily,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: _color,
            ),
          ),
          if (showLabel) ...[
            const SizedBox(width: 4),
            Text(
              'CONFIDENCE',
              style: TextStyle(
                fontFamily: AppTypography.monoFamily,
                fontSize: 8,
                fontWeight: FontWeight.w600,
                color: _color,
              ),
            ),
          ]
        ],
      ),
    );
  }
}
