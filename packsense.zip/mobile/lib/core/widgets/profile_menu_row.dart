import 'package:flutter/material.dart';
import '../theme/colors.dart';
import 'icon_circle_badge.dart';

/// ProfileMenuRow: Icon-circle + label + trailing chevron, full-width tappable row.
/// Used throughout Profile and reusable for any settings-style list (Admin menu, Gov Dashboard menu).
class ProfileMenuRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final String? subtitle;
  final Widget? trailing;
  final Color? iconColor;
  final Color? iconBgColor;

  const ProfileMenuRow({
    Key? key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.subtitle,
    this.trailing,
    this.iconColor,
    this.iconBgColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            IconCircleBadge(
              icon: icon,
              iconColor: iconColor ?? AppColors.primary,
              backgroundColor: iconBgColor ?? AppColors.primaryTint,
              size: 38,
              iconSize: 18,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      style: const TextStyle(
                        fontSize: 10,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (trailing != null)
              trailing!
            else
              const Icon(
                Icons.chevron_right,
                size: 20,
                color: Color(0xFF94A3B8),
              ),
          ],
        ),
      ),
    );
  }
}
