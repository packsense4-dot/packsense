import 'package:flutter/material.dart';
import '../theme/colors.dart';

class GasStatItem {
  final String label;
  final String percentage;
  final Color? color;

  const GasStatItem({
    required this.label,
    required this.percentage,
    this.color,
  });
}

/// GasStatCircle: 3-up (or 2-4 up) row of circular stat chips (O2 / CO2 / N2 %)
/// Reusable for any grouped-stat display.
class GasStatCircle extends StatelessWidget {
  final List<GasStatItem> items;

  const GasStatCircle({
    Key? key,
    required this.items,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenListCenter,
      children: items.map((item) {
        final ringColor = item.color ?? AppColors.primary;
        return Expanded(
          child: Column(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: ringColor.withOpacity(0.08),
                  border: Border.all(color: ringColor.withOpacity(0.3), width: 2),
                ),
                child: Center(
                  child: Text(
                    item.percentage,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: ringColor,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item.label,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
