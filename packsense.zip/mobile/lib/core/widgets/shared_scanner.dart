import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../theme/colors.dart';

/// SharedScannerWidget: Single shared scanner component covering both
/// Barcode/Label scan (EAN/UPC) and QR Passport scan (GS1 Digital Link)
/// using mobile_scanner.
class SharedScannerWidget extends StatefulWidget {
  final ValueChanged<String> onScanned;
  final String title;
  final String instruction;
  final bool showTorch;

  const SharedScannerWidget({
    Key? key,
    required this.onScanned,
    this.title = 'Align barcode or QR within frame',
    this.instruction = 'Supports EAN-13, UPC-A, Code 128, and GS1 QR Codes',
    this.showTorch = true,
  }) : super(key: key);

  @override
  State<SharedScannerWidget> createState() => _SharedScannerWidgetState();
}

class _SharedScannerWidgetState extends State<SharedScannerWidget> {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    facing: CameraFacing.back,
    torchEnabled: false,
  );
  bool _hasDetected = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        alignment: Alignment.center,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: (capture) {
              if (_hasDetected) return;
              final List<Barcode> barcodes = capture.barcodes;
              for (final barcode in barcodes) {
                if (barcode.rawValue != null) {
                  _hasDetected = true;
                  widget.onScanned(barcode.rawValue!);
                  break;
                }
              }
            },
          ),
          // Viewport targeting overlay
          Container(
            width: 240,
            height: 150,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primary, width: 2),
              borderRadius: BorderRadius.circular(12),
              color: Colors.transparent,
            ),
          ),
          // Instruction overlay
          Positioned(
            bottom: 12,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                widget.instruction,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
          // Torch toggle
          if (widget.showTorch)
            Positioned(
              top: 10,
              right: 10,
              child: IconButton(
                color: Colors.white,
                icon: ValueListenableBuilder(
                  valueListenable: _controller.torchState,
                  builder: (context, state, child) {
                    switch (state) {
                      case TorchState.off:
                        return const Icon(Icons.flash_off, color: Colors.white, size: 20);
                      case TorchState.on:
                        return const Icon(Icons.flash_on, color: Colors.amber, size: 20);
                    }
                  },
                ),
                onPressed: () => _controller.toggleTorch(),
              ),
            ),
        ],
      ),
    );
  }
}
