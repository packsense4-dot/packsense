import 'package:flutter/material.dart';
import '../theme/colors.dart';
import '../theme/typography.dart';

/// NumericStatCard conforming to Section 5:
/// Big number + unit + label (e.g. "187 hrs" / "Predicted Shelf Life"),
/// used everywhere instead of paragraphs of text.
class NumericStatCard extends StatelessWidget {
  final String label;
  final String value;
  final String unit;
  final Color accentColor;
  final String? badgeText;
  final VoidCallback? onTap;

  const NumericStatCard({
    Key? key,
    required this.label,
    required this.value,
    required this.unit,
    this.accentColor = AppColors.primary,
    this.badgeText,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border, width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    label.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.statLabel,
                  ),
                ),
                if (badgeText != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(3),
                      border: Border.all(color: accentColor.withOpacity(0.3)),
                    ),
                    child: Text(
                      badgeText!,
                      style: TextStyle(
                        fontFamily: AppTypography.monoFamily,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        color: accentColor,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  value,
                  style: AppTypography.displayValue.copyWith(
                    color: accentColor == AppColors.primary ? AppColors.textPrimary : accentColor,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    unit,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.unitLabel,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
