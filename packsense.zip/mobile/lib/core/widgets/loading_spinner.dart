import 'package:flutter/material.dart';
import '../theme/colors.dart';
import '../theme/typography.dart';

class LoadingSpinner extends StatelessWidget {
  final String message;

  const LoadingSpinner({
    Key? key,
    this.message = 'CALCULATING MASS TRANSFER EQUATIONS...',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryEmerald),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            message.toUpperCase(),
            style: const TextStyle(
              fontFamily: AppTypography.monoFamily,
              fontSize: 10,
              letterSpacing: 0.8,
              color: AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }
}
