import 'package:flutter/material.dart';
import '../theme/colors.dart';
import '../theme/typography.dart';
import 'confidence_badge.dart';

/// ParetoOptionCard conforming to Section 5:
/// One of the 3 optimizer results:
/// - Title (Best Life / Best Value / Greenest)
/// - 4 key stats (Shelf Life, Cost, OTR, WVTR)
/// - Confidence badge (green ≥85, amber 70–84, red <70)
/// - Expandable "Why this?" SHAP explanation
/// - Compliance pass/fail chip
class ParetoOptionCard extends StatefulWidget {
  final String title;
  final String filmType;
  final double costPerM2;
  final int shelfLifeDays;
  final double otr;
  final double wvtr;
  final int confidenceScore;
  final bool isCompliant;
  final String complianceStandard;
  final String shapExplanation;
  final bool isSelected;
  final String tag;
  final VoidCallback onSelect;

  const ParetoOptionCard({
    Key? key,
    required this.title,
    required this.filmType,
    required this.costPerM2,
    required this.shelfLifeDays,
    required this.otr,
    required this.wvtr,
    required this.confidenceScore,
    this.isCompliant = true,
    this.complianceStandard = 'FSSAI IS 9845 / PWM 2022',
    this.shapExplanation = 'Target OTR matches commodity respiration rate. Barrier preserves internal CO₂/O₂ balance under ambient conditions.',
    this.isSelected = false,
    required this.tag,
    required this.onSelect,
  }) : super(key: key);

  @override
  State<ParetoOptionCard> createState() => _ParetoOptionCardState();
}

class _ParetoOptionCardState extends State<ParetoOptionCard> {
  bool _isShapExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: widget.isSelected ? AppColors.primary : AppColors.border,
          width: widget.isSelected ? 2.0 : 1.0,
        ),
        boxShadow: widget.isSelected
            ? [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                )
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: widget.onSelect,
          borderRadius: BorderRadius.circular(10),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top Tag + Compliance + Confidence
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.primaryLight.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            widget.tag.toUpperCase(),
                            style: const TextStyle(
                              fontFamily: AppTypography.monoFamily,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: AppColors.primaryDark,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2.5),
                          decoration: BoxDecoration(
                            color: (widget.isCompliant ? AppColors.success : AppColors.danger).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: (widget.isCompliant ? AppColors.success : AppColors.danger).withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            widget.isCompliant ? 'PASS' : 'FAIL',
                            style: TextStyle(
                              fontFamily: AppTypography.monoFamily,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: widget.isCompliant ? AppColors.success : AppColors.danger,
                            ),
                          ),
                        ),
                      ],
                    ),
                    ConfidenceBadge(confidenceScore: widget.confidenceScore, showLabel: false),
                  ],
                ),
                const SizedBox(height: 8),

                // Title & Film Specification
                Text(widget.title, style: AppTypography.sectionHeader),
                const SizedBox(height: 2),
                Text(
                  widget.filmType,
                  style: const TextStyle(
                    fontFamily: AppTypography.monoFamily,
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 12),

                // 4 Key Stats Grid (Shelf Life, Cost, OTR, WVTR)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    childAspectRatio: 1.4,
                    children: [
                      _buildStatColumn('SHELF LIFE', '${widget.shelfLifeDays}d', AppColors.primaryDark),
                      _buildStatColumn('EST. COST', '₹${widget.costPerM2.toStringAsFixed(1)}', AppColors.textPrimary),
                      _buildStatColumn('OTR (cc)', widget.otr.toStringAsFixed(1), AppColors.textSecondary),
                      _buildStatColumn('WVTR (g)', widget.wvtr.toStringAsFixed(1), AppColors.textSecondary),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // Expandable "Why this?" SHAP explanation
                InkWell(
                  onTap: () {
                    setState(() {
                      _isShapExpanded = !_isShapExpanded;
                    });
                  },
                  borderRadius: BorderRadius.circular(4),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Icon(
                          _isShapExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                          size: 16,
                          color: AppColors.primary,
                        ),
                        const SizedBox(width: 4),
                        const Text(
                          'Why this recommendation?',
                          style: TextStyle(
                            fontFamily: AppTypography.sansFamily,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                if (_isShapExpanded) ...[
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.shapExplanation,
                          style: AppTypography.body.copyWith(fontSize: 11, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Standard: ${widget.complianceStandard}',
                          style: const TextStyle(
                            fontFamily: AppTypography.monoFamily,
                            fontSize: 9,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatColumn(String label, String value, Color valueColor) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontFamily: AppTypography.monoFamily, fontSize: 8, color: AppColors.textMuted)),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            fontFamily: AppTypography.monoFamily,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: valueColor,
          ),
        ),
      ],
    );
  }
}
