import 'package:flutter/material.dart';
import '../theme/colors.dart';

enum StatusBadgeVariant { success, warning, danger }

/// StatusBadge: Small pill badge matching the reference design:
/// - Green (successTint bg, success text — "Verified", "Balanced", compliance pass)
/// - Amber (warningTint bg, warning text — "Lab trial suggested", low confidence)
/// - Danger (red tint bg, danger text — compliance failure)
class StatusBadge extends StatelessWidget {
  final String label;
  final StatusBadgeVariant variant;
  final IconData? icon;

  const StatusBadge({
    Key? key,
    required this.label,
    this.variant = StatusBadgeVariant.success,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;

    switch (variant) {
      case StatusBadgeVariant.success:
        bg = AppColors.successTint;
        fg = AppColors.success;
        break;
      case StatusBadgeVariant.warning:
        bg = AppColors.warningTint;
        fg = AppColors.warning;
        break;
      case StatusBadgeVariant.danger:
        bg = const Color(0xFFFEE2E2);
        fg = AppColors.danger;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: fg),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: fg,
            ),
          ),
        ],
      ),
    );
  }
}
