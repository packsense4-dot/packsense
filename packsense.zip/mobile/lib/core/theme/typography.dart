import 'package:flutter/material.dart';
import 'colors.dart';

/// AppTypography conforming to Section 2.2:
/// - Headings: Poppins, SemiBold/Bold, sizes 20–28.
/// - Body/labels: Inter, Regular/Medium, sizes 12–15.
/// - Numeric stats: Inter with tabular figures, Bold, size 16–18.
/// - Indic fallback: Noto Sans for Hindi/Marathi/Tamil glyph rendering.
class AppTypography {
  AppTypography._();

  static const String headingFamily = 'Poppins';
  static const String bodyFamily = 'Inter';
  static const List<String> fontFallback = ['Noto Sans', 'Noto Sans Devanagari', 'Noto Sans Tamil', 'Roboto'];

  // Large Hero Heading (Splash, AI Recommendation)
  static const TextStyle heroHeading = TextStyle(
    fontFamily: headingFamily,
    fontSize: 26,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
    letterSpacing: -0.5,
    fontFamilyFallback: fontFallback,
  );

  // Card & Section Heading (SemiBold/Bold, 16-20)
  static const TextStyle cardHeading = TextStyle(
    fontFamily: headingFamily,
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
    letterSpacing: -0.2,
    fontFamilyFallback: fontFallback,
  );

  // Numeric Stats with tabular figures (OTR/WVTR/Shelf Life, size 16-18)
  static const TextStyle numericStat = TextStyle(
    fontFamily: bodyFamily,
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
    fontFeatures: [FontFeature.tabularFigures()],
    letterSpacing: -0.3,
    fontFamilyFallback: fontFallback,
  );

  // Label above or below stats (Inter Regular/Medium, 10-12)
  static const TextStyle statLabel = TextStyle(
    fontFamily: bodyFamily,
    fontSize: 11,
    fontWeight: FontWeight.w600,
    color: AppColors.textSecondary,
    letterSpacing: 0.3,
    fontFamilyFallback: fontFallback,
  );

  // Body content (Inter 12-14)
  static const TextStyle body = TextStyle(
    fontFamily: bodyFamily,
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
    height: 1.4,
    fontFamilyFallback: fontFallback,
  );

  // Backward compatibility alias
  static const String monoFamily = bodyFamily;
  static const String sansFamily = bodyFamily;
  static const TextStyle displayValue = numericStat;
  static const TextStyle unitLabel = TextStyle(
    fontFamily: bodyFamily,
    fontSize: 11,
    color: AppColors.textSecondary,
    fontFeatures: [FontFeature.tabularFigures()],
  );
  static const TextStyle sectionHeader = cardHeading;
}
