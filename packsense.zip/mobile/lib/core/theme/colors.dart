import 'package:flutter/material.dart';

/// AppColors: Design system color tokens matching reference design exactly
class AppColors {
  AppColors._();

  // Gradient (splash, hero CTA cards)
  static const gradientStart = Color(0xFF1565C0); // deep blue
  static const gradientEnd   = Color(0xFF42A5F5); // lighter blue

  // Core
  static const primary       = Color(0xFF1E88E5); // buttons, active nav, links
  static const primaryDark   = Color(0xFF1565C0); // pressed state
  static const primaryTint   = Color(0xFFE8F1FD); // icon-circle backgrounds, selected card fill
  static const background    = Color(0xFFF4F8FC); // app background (soft blue-grey, NOT pure white)
  static const surface       = Color(0xFFFFFFFF); // card backgrounds
  static const textPrimary   = Color(0xFF0F1C2E); // near-black navy for headings
  static const textSecondary = Color(0xFF6B7A90); // grey for subtitles/labels
  static const success       = Color(0xFF2E9E5B); // "Verified" / "Balanced" badges, gains
  static const successTint   = Color(0xFFE3F5EA);
  static const warning       = Color(0xFFF59E0B); // low-confidence, lab-trial flags
  static const warningTint   = Color(0xFFFCF1DD);
  static const danger        = Color(0xFFDC2626); // compliance failures
  static const border        = Color(0xFFE3E9F2);

  // Surface aliases for backward compatibility
  static const surfaceCard   = surface;
  static const primaryLight  = primaryTint;

  // Blue gradient for Splash / Onboarding / Key Hero cards
  static const LinearGradient blueGradient = LinearGradient(
    colors: [gradientStart, gradientEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
