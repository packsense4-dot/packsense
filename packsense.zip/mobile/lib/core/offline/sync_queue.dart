import 'dart:convert';
import 'package:dio/dio.dart';
import '../api/endpoints.dart';
import '../api/dio_client.dart';
import 'local_db.dart';

class SyncQueue {
  final DioClient _client;

  SyncQueue(this._client);

  Future<void> enqueueTransaction({
    required String action,
    required Map<String, dynamic> payload,
  }) async {
    final db = await LocalDatabase.instance.database;
    final txId = 'tx_${DateTime.now().millisecondsSinceEpoch}_${payload.hashCode}';

    await db.insert('sync_queue', {
      'client_tx_id': txId,
      'action': action,
      'payload': jsonEncode(payload),
      'status': 'PENDING',
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<int> getPendingCount() async {
    final db = await LocalDatabase.instance.database;
    final res = await db.rawQuery("SELECT COUNT(*) as count FROM sync_queue WHERE status = 'PENDING'");
    return Sqflite.firstIntValue(res) ?? 0;
  }

  Future<bool> flushSyncQueue() async {
    final db = await LocalDatabase.instance.database;
    final pending = await db.query(
      'sync_queue',
      where: "status = 'PENDING'",
      limit: 50,
    );

    if (pending.isEmpty) return true;

    final txList = pending.map((row) => {
      'client_tx_id': row['client_tx_id'],
      'action': row['action'],
      'payload': jsonDecode(row['payload'] as String),
      'created_at': row['created_at'],
    }).toList();

    try {
      final res = await _client.dio.post(
        Endpoints.syncPush,
        data: {'transactions': txList},
      );

      if (res.statusCode == 200) {
        // Mark all flushed as synced
        final ids = pending.map((e) => e['id'] as int).toList();
        await db.update(
          'sync_queue',
          {'status': 'SYNCED'},
          where: 'id IN (${ids.join(',')})',
        );
        return true;
      }
    } catch (_) {}
    return false;
  }
}
