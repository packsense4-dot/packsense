import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LocalDatabase {
  static final LocalDatabase instance = LocalDatabase._init();
  static Database? _database;

  LocalDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('packsense_local.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    // 1. Offline Food Profiles (Section 8.8)
    await db.execute('''
      CREATE TABLE offline_foods (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT,
        resp_rate_20c REAL,
        optimal_o2_min REAL,
        optimal_o2_max REAL,
        optimal_co2_min REAL,
        optimal_co2_max REAL,
        updated_at TEXT
      )
    ''');

    // 2. Offline Film Catalog (Section 8.8)
    await db.execute('''
      CREATE TABLE offline_films (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        material_type TEXT NOT NULL,
        thickness_micron REAL,
        otr_cc_m2_day REAL,
        wvtr_g_m2_day REAL,
        cost_per_m2_inr REAL,
        updated_at TEXT
      )
    ''');

    // 3. Sync Queue (Section 8.4)
    await db.execute('''
      CREATE TABLE sync_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_tx_id TEXT UNIQUE NOT NULL,
        action TEXT NOT NULL,
        payload TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING',
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> close() async {
    final db = await instance.database;
    db.close();
  }
}
