import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../auth/auth_state_provider.dart';
import 'sync_queue.dart';

final syncQueueProvider = Provider<SyncQueue>((ref) {
  final client = ref.watch(dioClientProvider);
  return SyncQueue(client);
});

class ConnectivityState {
  final bool isOnline;
  final int pendingSyncCount;

  const ConnectivityState({
    this.isOnline = true,
    this.pendingSyncCount = 0,
  });

  ConnectivityState copyWith({
    bool? isOnline,
    int? pendingSyncCount,
  }) {
    return ConnectivityState(
      isOnline: isOnline ?? this.isOnline,
      pendingSyncCount: pendingSyncCount ?? this.pendingSyncCount,
    );
  }
}

class ConnectivityNotifier extends StateNotifier<ConnectivityState> {
  final SyncQueue _syncQueue;

  ConnectivityNotifier(this._syncQueue) : super(const ConnectivityState());

  void setOnline(bool online) {
    state = state.copyWith(isOnline: online);
    if (online) {
      triggerSync();
    }
  }

  Future<void> refreshPendingCount() async {
    final count = await _syncQueue.getPendingCount();
    state = state.copyWith(pendingSyncCount: count);
  }

  Future<void> triggerSync() async {
    await _syncQueue.flushSyncQueue();
    await refreshPendingCount();
  }
}

final connectivityProvider = StateNotifierProvider<ConnectivityNotifier, ConnectivityState>((ref) {
  final queue = ref.watch(syncQueueProvider);
  return ConnectivityNotifier(queue);
});
