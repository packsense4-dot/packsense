import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// LanguageInterceptor: Appends ?lang=<locale> and sets Accept-Language
/// according to the selected user language (en, hi, mr, ta).
class LanguageInterceptor extends Interceptor {
  final FlutterSecureStorage _storage;

  LanguageInterceptor({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    final lang = await _storage.read(key: 'user_language') ?? 'en';
    
    // Set Accept-Language header
    options.headers['Accept-Language'] = lang;

    // Append ?lang=<locale> query param if not already provided
    final query = Map<String, dynamic>.from(options.queryParameters);
    if (!query.containsKey('lang')) {
      query['lang'] = lang;
      options.queryParameters = query;
    }

    handler.next(options);
  }
}
