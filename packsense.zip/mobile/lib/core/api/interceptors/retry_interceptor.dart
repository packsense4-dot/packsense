import 'dart:async';
import 'package:dio/dio.dart';

/// RetryInterceptor: Retries transient network failures (timeouts, connection drops)
/// up to [retries] times with [retryDelay]. Does not retry 4xx client errors.
class RetryInterceptor extends Interceptor {
  final int retries;
  final Duration retryDelay;
  final Dio dio;

  RetryInterceptor({
    required this.dio,
    this.retries = 2,
    this.retryDelay = const Duration(seconds: 1),
  });

  @override
  Future<void> onError(DioException err, ErrorInterceptorHandler handler) async {
    final extra = err.requestOptions.extra;
    final currentAttempt = (extra['retry_count'] as int?) ?? 0;

    // Check if error is transient and retry count not exceeded
    if (_isTransient(err) && currentAttempt < retries) {
      extra['retry_count'] = currentAttempt + 1;
      await Future<void>.delayed(retryDelay);

      try {
        final options = Options(
          method: err.requestOptions.method,
          headers: err.requestOptions.headers,
          extra: extra,
          responseType: err.requestOptions.responseType,
          contentType: err.requestOptions.contentType,
        );

        final response = await dio.request<dynamic>(
          err.requestOptions.path,
          data: err.requestOptions.data,
          queryParameters: err.requestOptions.queryParameters,
          options: options,
        );
        return handler.resolve(response);
      } catch (retryError) {
        if (retryError is DioException) {
          return handler.next(retryError);
        }
      }
    }

    return handler.next(err);
  }

  bool _isTransient(DioException err) {
    return err.type == DioExceptionType.connectionTimeout ||
        err.type == DioExceptionType.sendTimeout ||
        err.type == DioExceptionType.receiveTimeout ||
        err.type == DioExceptionType.connectionError;
  }
}
