import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// AuthInterceptor: Attaches "Authorization: Bearer <token>" to outgoing requests
/// and handles 401 Unauthorized responses with a one-time token refresh retry (Part B.2).
class AuthInterceptor extends Interceptor {
  final FlutterSecureStorage _storage;
  final Dio? _dio;
  final Function()? _onForceLogout;

  AuthInterceptor({
    FlutterSecureStorage? storage,
    Dio? dio,
    Function()? onForceLogout,
  })  : _storage = storage ?? const FlutterSecureStorage(),
        _dio = dio,
        _onForceLogout = onForceLogout;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final token = await _storage.read(key: 'access_token');
    if (token != null && token.isNotEmpty) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  Future<bool> _tryRefreshToken() async {
    try {
      final refreshToken = await _storage.read(key: 'refresh_token');
      if (refreshToken == null || refreshToken.isEmpty) return false;

      final refreshDio = Dio();
      final res = await refreshDio.post(
        '/api/v1/auth/refresh',
        data: {'refresh_token': refreshToken},
      );

      if (res.statusCode == 200 && res.data != null) {
        final newAccess = res.data['access_token'];
        if (newAccess != null) {
          await _storage.write(key: 'access_token', value: newAccess.toString());
          return true;
        }
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    if (err.response?.statusCode == 401) {
      final isAuthEndpoint = err.requestOptions.path.contains('/auth/');
      if (!isAuthEndpoint) {
        final refreshed = await _tryRefreshToken();
        if (refreshed && _dio != null) {
          final newToken = await _storage.read(key: 'access_token');
          final opts = err.requestOptions;
          opts.headers['Authorization'] = 'Bearer $newToken';
          try {
            final clone = await _dio!.fetch(opts);
            return handler.resolve(clone);
          } catch (_) {
            // Retry failed
          }
        }
        await _storage.deleteAll();
        if (_onForceLogout != null) {
          _onForceLogout!();
        }
      }
    }
    handler.next(err);
  }
}
