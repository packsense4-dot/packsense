import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

/// LoggingInterceptor: Logs request/response in debug builds only, silent in release.
class LoggingInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    if (kDebugMode) {
      debugPrint('[DIO] -> ${options.method} ${options.uri}');
      if (options.data != null) {
        debugPrint('[DIO] Body: ${options.data}');
      }
    }
    handler.next(options);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    if (kDebugMode) {
      debugPrint('[DIO] <- ${response.statusCode} ${response.requestOptions.uri}');
    }
    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    if (kDebugMode) {
      debugPrint('[DIO] !! ${err.type} on ${err.requestOptions.uri}: ${err.message}');
    }
    handler.next(err);
  }
}
