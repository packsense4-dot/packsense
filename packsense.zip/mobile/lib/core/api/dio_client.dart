import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../config/app_config.dart';
import 'interceptors/auth_interceptor.dart';
import 'interceptors/language_interceptor.dart';
import 'interceptors/logging_interceptor.dart';
import 'interceptors/retry_interceptor.dart';

/// Section 3 & Part A.2: The Shared HTTP Client (dio_client.dart)
/// Explicitly excludes image-based endpoints (/ripeness/scan and /pack-label/scan)
/// from any HTTP caching layer so every photo scan hits the backend fresh.
final Dio dio = _createDio();

class NoImageCacheInterceptor extends Interceptor {
  static const List<String> _uncacheablePaths = [
    '/ripeness/scan',
    '/pack-label/scan',
    '/label-scan',
  ];

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    final path = options.path.toLowerCase();
    if (_uncacheablePaths.any((p) => path.contains(p))) {
      options.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
      options.headers['Pragma'] = 'no-cache';
      options.extra['disableCache'] = true;
    }
    super.onRequest(options, handler);
  }
}

Dio _createDio() {
  final client = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15), // matches backend's <1.5s target with latency headroom
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ),
  );

  client.interceptors.addAll([
    NoImageCacheInterceptor(), // Part A.2: never cache /ripeness/scan or /pack-label/scan
    AuthInterceptor(),         // attaches "Authorization: Bearer <jwt>", handles 401
    LanguageInterceptor(),     // appends ?lang=<locale> and Accept-Language
    LoggingInterceptor(),      // logs in debug builds only, silent in release
    RetryInterceptor(          // for transient network drops (2 retries, 1s delay)
      dio: client,
      retries: 2,
      retryDelay: const Duration(seconds: 1),
    ),
  ]);

  return client;
}

/// Riverpod provider for dependency injection
final dioProvider = Provider<Dio>((ref) => dio);
