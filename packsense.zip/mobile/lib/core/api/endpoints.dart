/// PackSense API Endpoints matching Backend Specification
/// Combined with dio.baseUrl to form full request URLs.
class Endpoints {
  Endpoints._();

  // Section 4: Startup Connection Health Check
  static const String health = '/api/v1/health';

  // Section 3: Auth & Identity
  static const String login = '/api/v1/auth/login';
  static const String register = '/api/v1/auth/register';
  static const String me = '/api/v1/auth/me';

  // Section 5: Food & Film Database Catalogs
  static const String foods = '/api/v1/foods';
  static const String films = '/api/v1/films';
  static const String climateNormals = '/api/v1/climate/normals';
  static const String complianceRules = '/api/v1/compliance/rules';

  // Section 6: Digital Twin Simulator
  static const String simulate = '/api/v1/simulate';
  static const String simulateHourly = '/api/v1/simulate/hourly';

  // Section 7: Multi-Objective Optimizer (Pareto)
  static const String optimize = '/api/v1/optimize';

  // Section 8.1 & Feature #8: Supplier Matching & Geo
  static const String suppliersNear = '/api/v1/suppliers/nearby';

  // Section 8.2: Voice ASR & Transcribe Intent
  static const String voiceTranscribeIntent = '/api/v1/voice/transcribe-intent';
  static const String voiceAsr = '/api/v1/voice/asr';

  // Section 8.4 & 8.8: Offline-First Sync
  static const String syncPull = '/api/v1/sync/pull';
  static const String syncPush = '/api/v1/sync/push';

  // Section 8.6 & Feature #6: Lab Trial Checklist
  static const String labTrialChecklist = '/api/v1/reports/lab-trial-checklist';

  // Section 8.7 & Feature #20: Government Dashboard
  static const String govDashboard = '/api/v1/gov/dashboard';
  static const String govDistrictStats = '/api/v1/gov/district-stats';

  // Feature #4: MobileNetV3 Ripeness Scanner
  static const String ripenessScan = '/api/v1/ripeness/scan';

  // Feature #7: QR Passport
  static const String qrPassport = '/api/v1/qr/passport';
  static String qrStatus(String batchId) => '/api/v1/qr/$batchId/status';

  // Feature #9: Pack Auditor (Reverse Mode)
  static const String auditReverse = '/api/v1/audit/reverse';

  // Feature #10: Spoilage Autopsy
  static const String spoilageDiagnose = '/api/v1/spoilage/diagnose';

  // Feature #11: Active Packaging Advisor
  static const String activePackagingRecommend = '/api/v1/active-packaging/recommend';

  // Feature #12: Condensation Risk Engine
  static const String condensationCheck = '/api/v1/condensation/check';

  // Feature #13: Mixed Load Compatibility
  static const String mixedLoadEvaluate = '/api/v1/mixed-load/evaluate';

  // Feature #14: Right-Sizing Headspace Engine
  static const String rightSizingCalculate = '/api/v1/right-sizing/calculate';

  // Feature #15: Secondary Packaging Corrugated Box
  static const String secondaryBoxRecommend = '/api/v1/secondary-packaging/recommend';

  // Feature #16: Rupee Impact & Food Waste Calculator
  static const String rupeeImpactCalculate = '/api/v1/rupee-impact/calculate';

  // Feature #17: Rural Alternatives (Low-Cost / Zero Energy)
  static const String ruralAlternatives = '/api/v1/rural/alternatives';

  // Feature #18: Community Validation Loop
  static const String communityTrials = '/api/v1/community/trials';
  static const String communityFeedback = '/api/v1/community/feedback';

  // Feature #19: BLE Datalogger Integration
  static const String dataloggerIngest = '/api/v1/datalogger/ingest';

  // Scanning Additions: Pack Label Scan
  static const String packLabelScan = '/api/v1/pack-label/scan';

  // Multilingual Support
  static const String i18nLanguages = '/api/v1/i18n/languages';
  static const String i18nRenderTemplate = '/api/v1/i18n/render-template';
}
