import 'package:flutter_test/flutter_test.dart';
import 'package:packsense_mobile/core/auth/auth_repository.dart';

void main() {
  group('PackSense Mobile Core Tests', () {
    test('UserRoleExtension correctly distinguishes Simple Mode vs Dashboard Mode', () {
      expect(UserRole.farmer.isSimpleMode, isTrue);
      expect(UserRole.fpo.isSimpleMode, isTrue);
      expect(UserRole.msme.isSimpleMode, isTrue);

      expect(UserRole.industry.isSimpleMode, isFalse);
      expect(UserRole.admin.isSimpleMode, isFalse);
      expect(UserRole.government.isSimpleMode, isFalse);
    });

    test('UserRole parsing from string handles case-insensitivity', () {
      expect(UserRoleExtension.fromString('FARMER'), UserRole.farmer);
      expect(UserRoleExtension.fromString('FPO'), UserRole.fpo);
      expect(UserRoleExtension.fromString('industry'), UserRole.industry);
      expect(UserRoleExtension.fromString('mofpi'), UserRole.government);
      expect(UserRoleExtension.fromString('admin'), UserRole.admin);
    });
  });
}
