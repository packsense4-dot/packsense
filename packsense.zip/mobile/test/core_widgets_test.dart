import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mobile/core/theme/colors.dart';
import 'package:mobile/core/widgets/icon_circle_badge.dart';
import 'package:mobile/core/widgets/settings_grid_tile.dart';
import 'package:mobile/core/widgets/status_badge.dart';
import 'package:mobile/core/widgets/segmented_tab_bar.dart';
import 'package:mobile/core/widgets/stat_row.dart';
import 'package:mobile/core/widgets/radio_select_card.dart';
import 'package:mobile/core/widgets/gas_stat_circle.dart';
import 'package:mobile/core/widgets/info_bar.dart';
import 'package:mobile/core/widgets/profile_menu_row.dart';
import 'package:mobile/core/widgets/primary_button.dart';
import 'package:mobile/core/widgets/gradient_hero_card.dart';
import 'package:mobile/core/widgets/bottom_nav_shell.dart';

void main() {
  group('Section 2.3 Core Reusable Components Tests', () {
    testWidgets('IconCircleBadge renders with correct colors and icon', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: IconCircleBadge(icon: Icons.qr_code_scanner),
          ),
        ),
      );
      expect(find.byIcon(Icons.qr_code_scanner), findsOneWidget);
    });

    testWidgets('SettingsGridTile renders title, subtitle and responds to tap', (tester) async {
      bool tapped = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SettingsGridTile(
              icon: Icons.history,
              title: 'My History',
              subtitle: 'Past scans & audits',
              onTap: () => tapped = true,
            ),
          ),
        ),
      );
      expect(find.text('My History'), findsOneWidget);
      expect(find.text('Past scans & audits'), findsOneWidget);
      await tester.tap(find.text('My History'));
      expect(tapped, isTrue);
    });

    testWidgets('StatusBadge renders success variant ("Verified") and warning variant ("Trade-off")', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: Column(
              children: [
                StatusBadge(label: 'Verified', variant: StatusBadgeVariant.success),
                StatusBadge(label: 'Trade-off', variant: StatusBadgeVariant.warning),
              ],
            ),
          ),
        ),
      );
      expect(find.text('Verified'), findsOneWidget);
      expect(find.text('Trade-off'), findsOneWidget);
    });

    testWidgets('SegmentedTabBar selects tab and triggers callback', (tester) async {
      int selected = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SegmentedTabBar(
              tabs: const ['Shelf Life', 'Gas Dynamics', 'Temperature'],
              selectedIndex: selected,
              onTabSelected: (idx) => selected = idx,
            ),
          ),
        ),
      );
      expect(find.text('Shelf Life'), findsOneWidget);
      expect(find.text('Gas Dynamics'), findsOneWidget);
      await tester.tap(find.text('Gas Dynamics'));
      expect(selected, 1);
    });

    testWidgets('StatRow renders label and bold numeric value', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: StatRow(
              icon: Icons.air,
              label: 'Oxygen Transmission Rate (OTR)',
              value: '1.2',
              unit: 'cc/m²·day',
            ),
          ),
        ),
      );
      expect(find.text('Oxygen Transmission Rate (OTR)'), findsOneWidget);
      expect(find.text('1.2'), findsOneWidget);
      expect(find.text('cc/m²·day'), findsOneWidget);
    });

    testWidgets('RadioSelectCard renders title, subtitle, radio and handles selection', (tester) async {
      bool selected = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RadioSelectCard(
              icon: Icons.wb_sunny,
              title: 'Summer (Hot & Dry)',
              subtitle: '38°C–45°C · 25% RH',
              isSelected: selected,
              onTap: () => selected = true,
            ),
          ),
        ),
      );
      expect(find.text('Summer (Hot & Dry)'), findsOneWidget);
      await tester.tap(find.text('Summer (Hot & Dry)'));
      expect(selected, isTrue);
    });

    testWidgets('GasStatCircle renders circular stat chips', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: GasStatCircle(
              items: [
                GasStatItem(label: 'Oxygen (O₂)', percentage: '1.2%'),
                GasStatItem(label: 'Carbon Dioxide (CO₂)', percentage: '18.5%'),
                GasStatItem(label: 'Nitrogen (N₂)', percentage: '80.3%'),
              ],
            ),
          ),
        ),
      );
      expect(find.text('1.2%'), findsOneWidget);
      expect(find.text('Oxygen (O₂)'), findsOneWidget);
      expect(find.text('18.5%'), findsOneWidget);
      expect(find.text('80.3%'), findsOneWidget);
    });

    testWidgets('InfoBar renders contextual tip with icon', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: InfoBar(
              text: 'Simulation based on Indian climate (Maharashtra / Monsoon).',
              icon: Icons.info_outline,
            ),
          ),
        ),
      );
      expect(find.text('Simulation based on Indian climate (Maharashtra / Monsoon).'), findsOneWidget);
    });

    testWidgets('ProfileMenuRow renders label, subtitle and chevron', (tester) async {
      bool tapped = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ProfileMenuRow(
              icon: Icons.settings,
              label: 'Settings & Language',
              subtitle: 'English / हिंदी',
              onTap: () => tapped = true,
            ),
          ),
        ),
      );
      expect(find.text('Settings & Language'), findsOneWidget);
      expect(find.text('English / हिंदी'), findsOneWidget);
      await tester.tap(find.text('Settings & Language'));
      expect(tapped, isTrue);
    });

    testWidgets('PrimaryButton renders label and triggers tap', (tester) async {
      bool pressed = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: PrimaryButton(
              label: 'Get Packaging Recommendation',
              onPressed: () => pressed = true,
            ),
          ),
        ),
      );
      expect(find.text('Get Packaging Recommendation'), findsOneWidget);
      await tester.tap(find.text('Get Packaging Recommendation'));
      expect(pressed, isTrue);
    });

    testWidgets('GradientHeroCard renders full-width CTA and responds to tap', (tester) async {
      bool tapped = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: GradientHeroCard(
              icon: Icons.qr_code_scanner,
              title: 'Scan Barcode',
              subtitle: 'Point camera at any pouch or label to analyze film barrier specs instantly.',
              buttonText: 'Scan Now',
              onTap: () => tapped = true,
            ),
          ),
        ),
      );
      expect(find.text('Scan Barcode'), findsOneWidget);
      expect(find.text('Scan Now'), findsOneWidget);
      await tester.tap(find.text('Scan Now'));
      expect(tapped, isTrue);
    });

    testWidgets('BottomNavShell renders 4 tabs: Home, History, Learn, Profile', (tester) async {
      int active = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            bottomNavigationBar: BottomNavShell(
              currentIndex: active,
              onTabSelected: (idx) => active = idx,
            ),
          ),
        ),
      );
      expect(find.text('Home'), findsOneWidget);
      expect(find.text('History'), findsOneWidget);
      expect(find.text('Learn'), findsOneWidget);
      expect(find.text('Profile'), findsOneWidget);
      await tester.tap(find.text('Learn'));
      expect(active, 2);
    });
  });
}
