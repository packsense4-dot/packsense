import 'package:flutter_test/flutter_test.dart';
import 'package:mobile/core/config/app_config.dart';
import 'package:mobile/core/api/endpoints.dart';

void main() {
  group('Connection & Environment Configuration Tests', () {
    test('AppConfig has safe default values for local development', () {
      expect(AppConfig.apiBaseUrl, isNotEmpty);
      expect(AppConfig.apiBaseUrl, equals('http://10.0.2.2:8000'));
      expect(AppConfig.environment, equals('local'));
      expect(AppConfig.isLocal, isTrue);
      expect(AppConfig.isStaging, isFalse);
      expect(AppConfig.isProduction, isFalse);
    });

    test('Endpoints contains required health and domain endpoints with relative paths', () {
      expect(Endpoints.health, equals('/api/v1/health'));
      expect(Endpoints.simulate, equals('/api/v1/simulate'));
      expect(Endpoints.optimize, equals('/api/v1/optimize'));
      expect(Endpoints.foods, equals('/api/v1/foods'));
      expect(Endpoints.films, equals('/api/v1/films'));
      expect(Endpoints.login, equals('/api/v1/auth/login'));
      expect(Endpoints.register, equals('/api/v1/auth/register'));
      expect(Endpoints.syncPull, equals('/api/v1/sync/pull'));
      expect(Endpoints.syncPush, equals('/api/v1/sync/push'));
      expect(Endpoints.packLabelScan, equals('/api/v1/pack-label/scan'));
    });

    test('QR batch status URL builder generates correct REST path', () {
      final url = Endpoints.qrStatus('MH-2026-B812');
      expect(url, equals('/api/v1/qr/MH-2026-B812/status'));
    });

    test('Startup health check status validation logic passes "ok" and "healthy"', () {
      final validPayload1 = {'status': 'ok', 'db': 'connected'};
      final validPayload2 = {'status': 'healthy', 'db': 'connected'};
      final invalidPayload = {'status': 'down'};

      expect(validPayload1['status'] == 'ok' || validPayload1['status'] == 'healthy', isTrue);
      expect(validPayload2['status'] == 'ok' || validPayload2['status'] == 'healthy', isTrue);
      expect(invalidPayload['status'] == 'ok' || invalidPayload['status'] == 'healthy', isFalse);
    });
  });
}
