import 'package:flutter_test/flutter_test.dart';
import 'package:mobile/core/auth/auth_repository.dart';

void main() {
  group('Section 7 Role-Gating Tests', () {
    test('Business Tools is visible ONLY for industry, admin, government roles', () {
      final consumerRoles = [UserRole.farmer, UserRole.fpo, UserRole.msme];
      final businessRoles = [UserRole.industry, UserRole.admin, UserRole.government];

      for (final role in consumerRoles) {
        final isBusiness = [UserRole.industry, UserRole.admin, UserRole.government].contains(role);
        expect(isBusiness, isFalse, reason: 'Role $role should NOT see Business Tools');
      }

      for (final role in businessRoles) {
        final isBusiness = [UserRole.industry, UserRole.admin, UserRole.government].contains(role);
        expect(isBusiness, isTrue, reason: 'Role $role MUST see Business Tools');
      }
    });

    test('Admin Panel is visible ONLY for admin role', () {
      for (final role in UserRole.values) {
        final isAdmin = role == UserRole.admin;
        if (role == UserRole.admin) {
          expect(isAdmin, isTrue);
        } else {
          expect(isAdmin, isFalse);
        }
      }
    });

    test('Government Dashboard is visible ONLY for admin and government roles', () {
      for (final role in UserRole.values) {
        final isGov = role == UserRole.government || role == UserRole.admin;
        if (role == UserRole.government || role == UserRole.admin) {
          expect(isGov, isTrue);
        } else {
          expect(isGov, isFalse);
        }
      }
    });
  });

  group('Section 7 Unified Scanner Branching Logic Tests', () {
    test('EAN-13 / UPC barcode routes to Product Details flow', () {
      const ean13Code = '8901491101831';
      final isQr = ean13Code.startsWith('http') || ean13Code.contains('QR-');
      expect(isQr, isFalse);
      final destination = isQr ? '/qr-passport' : '/product-details';
      expect(destination, '/product-details');
    });

    test('GS1 Digital Link / PackSense QR routes to QR Passport flow', () {
      const qrLink = 'https://id.packsense.org/01/08901030999/10/B812';
      final isQr = qrLink.startsWith('http') || qrLink.contains('QR-');
      expect(isQr, isTrue);
      final destination = isQr ? '/qr-passport' : '/product-details';
      expect(destination, '/qr-passport');
    });
  });
}
