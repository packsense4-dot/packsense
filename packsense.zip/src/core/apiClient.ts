/**
 * apiClient.ts
 * 
 * Part B & Part C: Centralized API Client with Auth Interceptor and Request Tracing.
 * - Automatic Bearer token injection
 * - One-retry 401 token refresh interceptor via POST /api/v1/auth/refresh
 * - Clean force-logout routing on refresh failure
 * - X-Request-Id response tracing
 * - Strictly typed AppException and model deserialization
 */

export interface AuthUser {
  id: number;
  email: string;
  name: string;
  role: 'farmer' | 'fpo' | 'msme' | 'industry' | 'government' | 'admin';
  role_status?: 'pending' | 'approved' | 'rejected';
  organization?: string;
  phone_number?: string;
  preferred_language?: string;
  is_active?: boolean;
  last_login_at?: string | null;
  created_at?: string;
}

export interface AuthResponse {
  status: string;
  user: AuthUser;
  access_token: string;
  refresh_token: string;
  token_type?: string;
  expires_in_hours?: number;
  message?: string;
}

// Local Storage Keys
const ACCESS_TOKEN_KEY = 'packsense_access_token';
const REFRESH_TOKEN_KEY = 'packsense_refresh_token';
const USER_PROFILE_KEY = 'packsense_user_profile';

export function getStoredAccessToken(): string | null {
  try {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getStoredRefreshToken(): string | null {
  try {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(USER_PROFILE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStoredTokens(accessToken: string, refreshToken: string, user?: AuthUser): void {
  try {
    localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
    localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
    if (user) {
      localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(user));
    }
  } catch {}
}

export function setStoredUser(user: AuthUser): void {
  try {
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(user));
  } catch {}
}

export function clearStoredTokens(): void {
  try {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(USER_PROFILE_KEY);
  } catch {}
}

// Auth event listener for force logout
type LogoutListener = () => void;
const logoutListeners: LogoutListener[] = [];

export function onForceLogout(listener: LogoutListener): () => void {
  logoutListeners.push(listener);
  return () => {
    const idx = logoutListeners.indexOf(listener);
    if (idx !== -1) logoutListeners.splice(idx, 1);
  };
}

export function triggerForceLogout(): void {
  clearStoredTokens();
  logoutListeners.forEach(fn => {
    try {
      fn();
    } catch {}
  });
}

export class AppException extends Error {
  public userMessage: string;
  public debugDetail: string;
  public statusCode: number;
  public reasonCode: string;
  public requestId?: string;

  constructor(
    userMessage: string,
    debugDetail: string = '',
    statusCode: number = 500,
    reasonCode: string = 'internal_error',
    requestId?: string
  ) {
    super(userMessage);
    this.name = 'AppException';
    this.userMessage = userMessage;
    this.debugDetail = debugDetail;
    this.statusCode = statusCode;
    this.reasonCode = reasonCode;
    this.requestId = requestId;
  }

  static fromHttp(status: number, data: any, defaultMessage: string = 'An error occurred', requestId?: string): AppException {
    let reason = 'http_error';
    let message = defaultMessage;
    let detail = '';

    if (data && typeof data === 'object') {
      reason = data.reason || data.error || reason;
      message = data.detail || data.message || (typeof data.error === 'string' ? data.error : defaultMessage);
      detail = JSON.stringify(data);
    } else if (typeof data === 'string') {
      detail = data;
      try {
        const parsed = JSON.parse(data);
        if (parsed && typeof parsed === 'object') {
          reason = parsed.reason || parsed.error || reason;
          message = parsed.detail || parsed.message || (typeof parsed.error === 'string' ? parsed.error : defaultMessage);
        }
      } catch {
        if (data.trim().length > 0 && data.length < 200 && !data.includes('<html')) {
          message = data;
        }
      }
    }

    if (status === 409 || reason === 'duplicate_email') {
      message = 'An account with this email already exists — log in instead';
    }

    return new AppException(message, detail, status, reason, requestId);
  }

  static networkError(err: any): AppException {
    return new AppException(
      'Unable to connect to PackSense server. Check your network connection.',
      String(err?.message || err),
      0,
      'network_error'
    );
  }
}

let isRefreshing = false;
let refreshPromise: Promise<boolean> | null = null;

/**
 * Attaches Authorization header, traces X-Request-Id, and handles 401 refresh interceptor
 */
export async function fetchWithAuth(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const options = init ? { ...init } : {};
  const headers = new Headers(options.headers || {});

  // Generate trace request ID if not provided
  if (!headers.has('X-Request-Id')) {
    const randomId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `req-${Date.now()}`;
    headers.set('X-Request-Id', randomId);
  }

  // Attach stored access token if present
  const token = getStoredAccessToken();
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  // Part A.1 & A.2: Explicitly exclude image-upload and scan endpoints from any HTTP cache
  const urlStr = typeof input === 'string' ? input : (input instanceof URL ? input.toString() : (input as Request).url);
  if (
    urlStr.includes('/ripeness/scan') ||
    urlStr.includes('/pack-label/scan') ||
    urlStr.includes('/label-scan') ||
    urlStr.includes('/scan/analyze')
  ) {
    options.cache = 'no-store';
    headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    headers.set('Pragma', 'no-cache');
  }

  options.headers = headers;

  let response: Response;
  try {
    response = await fetch(input, options);
  } catch (err: any) {
    if (err?.name === 'AbortError') {
      throw err;
    }
    throw AppException.networkError(err);
  }

  // Interceptor: Handle 401 Unauthorized via token refresh
  if (response.status === 401) {
    const inputUrl = typeof input === 'string' ? input : (input instanceof URL ? input.toString() : (input as Request).url);
    const isAuthRoute = inputUrl.includes('/auth/login') || inputUrl.includes('/auth/register') || inputUrl.includes('/auth/refresh');

    if (!isAuthRoute) {
      const refreshToken = getStoredRefreshToken();
      if (refreshToken) {
        if (!isRefreshing) {
          isRefreshing = true;
          refreshPromise = (async () => {
            try {
              const refreshRes = await fetch('/api/v1/auth/refresh', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ refresh_token: refreshToken })
              });

              if (refreshRes.ok) {
                const data = await refreshRes.json();
                if (data.access_token) {
                  localStorage.setItem(ACCESS_TOKEN_KEY, data.access_token);
                  return true;
                }
              }
              return false;
            } catch {
              return false;
            } finally {
              isRefreshing = false;
            }
          })();
        }

        const refreshSucceeded = await refreshPromise;
        if (refreshSucceeded) {
          // Retry original request with newly refreshed access token
          const newAccessToken = getStoredAccessToken();
          const retryHeaders = new Headers(options.headers || {});
          if (newAccessToken) {
            retryHeaders.set('Authorization', `Bearer ${newAccessToken}`);
          }
          options.headers = retryHeaders;
          return fetch(input, options);
        }
      }

      // Refresh failed or no refresh token -> Force logout
      triggerForceLogout();
    }
  }

  return response;
}

/**
 * Universal safe API caller:
 * Maps HTTP responses to strictly typed models.
 */
export async function callApi<T>(
  call: () => Promise<Response>,
  parse: (data: any) => T,
  friendlyFallbackMessage?: string
): Promise<T> {
  let response: Response;
  try {
    response = await call();
  } catch (err: any) {
    if (err instanceof AppException) throw err;
    throw AppException.networkError(err);
  }

  const requestId = response.headers.get('X-Request-Id') || undefined;

  let body: any = null;
  try {
    const rawText = await response.text();
    if (rawText && rawText.trim().length > 0) {
      try {
        body = JSON.parse(rawText);
      } catch {
        body = rawText;
      }
    }
  } catch {
    body = null;
  }

  if (!response.ok) {
    throw AppException.fromHttp(response.status, body, friendlyFallbackMessage, requestId);
  }

  try {
    return parse(body);
  } catch (err: any) {
    throw new AppException(
      friendlyFallbackMessage || 'Could not parse response model.',
      `Model parsing error: ${err.message}`,
      response.status,
      'deserialization_error',
      requestId
    );
  }
}

// =========================================================================
// AUTHENTICATION API METHODS (Part A & Part B)
// =========================================================================

export async function loginApi(payload: { email: string; password: string }): Promise<AuthResponse> {
  return callApi(
    () => fetchWithAuth('/api/v1/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }),
    (data: any): AuthResponse => {
      setStoredTokens(data.access_token, data.refresh_token, data.user);
      return data as AuthResponse;
    },
    'Invalid email or password.'
  );
}

export async function registerApi(payload: {
  email: string;
  password: string;
  name: string;
  role: 'farmer' | 'fpo' | 'msme' | 'industry';
  organization?: string;
  phone_number?: string;
}): Promise<AuthResponse> {
  return callApi(
    () => fetchWithAuth('/api/v1/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }),
    (data: any): AuthResponse => {
      setStoredTokens(data.access_token, data.refresh_token, data.user);
      return data as AuthResponse;
    },
    'Account registration failed.'
  );
}

export async function getMeApi(): Promise<{ user: AuthUser; permissions: any }> {
  return callApi(
    () => fetchWithAuth('/api/v1/auth/me'),
    (data: any) => {
      const user = data.user || data.current_user;
      if (user) {
        setStoredUser(user);
      }
      return {
        user,
        permissions: data.permissions || {}
      };
    },
    'Authentication session expired. Please log in.'
  );
}

export async function logoutApi(): Promise<void> {
  const refreshToken = getStoredRefreshToken();
  try {
    await fetchWithAuth('/api/v1/auth/logout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken })
    });
  } catch {}
  clearStoredTokens();
  triggerForceLogout();
}

export async function checkBackendHealth(): Promise<boolean> {
  try {
    const res = await fetch('/api/v1/health');
    if (!res.ok) return false;
    const data = await res.json();
    return data.status === 'ok' || data.status === 'healthy';
  } catch {
    return false;
  }
}

// =========================================================================
// SPECIFIC TYPED CLIENT HELPERS FOR VOICE, SCANNING, AND PDF EXPORT (C.3)
// =========================================================================

export interface VoiceIntentResult {
  food_id: string;
  transcribed_text: string;
  audio_transcription: string;
  language: string;
  confidence: number;
}

export async function callVoiceIntentApi(payload: {
  text?: string;
  query?: string;
  language_code?: string;
  audio_url?: string;
}): Promise<VoiceIntentResult> {
  return callApi(
    () => fetchWithAuth('/api/v1/voice/transcribe-intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }),
    (data: any): VoiceIntentResult => ({
      food_id: data.food_id || data.detected_commodity_id || 'alphonso_mango',
      transcribed_text: data.transcribed_text || '',
      audio_transcription: data.audio_transcription || data.speech_summary?.shelf_life_announcement || '',
      language: data.language || data.detected_language || 'hi',
      confidence: data.confidence || 0.94
    }),
    "Couldn't understand that — try again or type it"
  );
}

export interface RipenessScanResult {
  isModelTrained: boolean;
  fallbackRequired: boolean;
  food_detected: string;
  food_name: string;
  ripeness_stage: 'unripe' | 'breaker' | 'ripe' | 'overripe';
  confidence: number;
  respiration_multiplier: number;
  stage_name: string;
  reason?: string;
}

export async function callRipenessScanApi(payload: {
  commodity_id?: string;
  food_detected?: string;
  image?: string;
  image_base64?: string;
  r_mean?: number;
  g_mean?: number;
  b_mean?: number;
}): Promise<RipenessScanResult> {
  return callApi(
    () => fetchWithAuth('/api/v1/ripeness/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }),
    (data: any): RipenessScanResult => {
      if (data.status === 'model_not_trained') {
        return {
          isModelTrained: false,
          fallbackRequired: true,
          food_detected: 'alphonso_mango',
          food_name: 'Ratnagiri Alphonso Mango',
          ripeness_stage: 'breaker',
          confidence: 0.8,
          respiration_multiplier: 1.45,
          stage_name: 'Breaker Stage',
          reason: 'Ripeness CNN is undergoing training; use the manual commodity picker.'
        };
      }
      return {
        isModelTrained: true,
        fallbackRequired: data.status === 'low_confidence',
        food_detected: data.food_detected || 'alphonso_mango',
        food_name: data.food_name || 'Ratnagiri Alphonso Mango',
        ripeness_stage: data.ripeness_stage || 'breaker',
        confidence: data.confidence || 0.92,
        respiration_multiplier: data.respiration_multiplier || 1.45,
        stage_name: data.stage_name || 'Optimal Harvest / Breaker Stage',
        reason: data.status === 'low_confidence' ? 'Low confidence prediction. Verify commodity manually.' : undefined
      };
    },
    'Produce scan failed — select your commodity manually.'
  );
}

export async function callPdfExportApi(reportId: number): Promise<string> {
  try {
    const res = await fetchWithAuth(`/api/v1/scan/reports/${reportId}/report.pdf`);
    if (!res.ok) {
      let errReason = 'Report generation failed — retry';
      try {
        const errJson = await res.json();
        if (errJson.detail) errReason = errJson.detail;
      } catch {}
      throw new AppException('Report generation failed — retry', errReason, res.status, 'pdf_generation_failed');
    }
    return `/api/v1/scan/reports/${reportId}/report.pdf`;
  } catch (err: any) {
    if (err instanceof AppException) throw err;
    throw new AppException(
      'Report generation failed — retry',
      err?.message || 'Network error during PDF generation',
      500,
      'pdf_generation_failed'
    );
  }
}

// Public Result QR payload model (Part E.2)
export interface PublicReportSummary {
  status: string;
  batch_code: string;
  commodity: {
    name: string;
    category: string;
    ripeness_stage: string;
  };
  chosen_option: {
    film_name: string;
    thickness_micron: number;
    otr: number;
    wvtr: number;
    recyclability_score: number;
    explanation?: string;
  };
  shelf_life: {
    low_days: number;
    expected_days: number;
    high_days: number;
    remaining_hours?: number;
  };
  confidence: {
    score: number;
  };
  compliance: {
    is_compliant: boolean;
    status: string;
    standards: string[];
  };
  logger_paired: boolean;
  logger_temp_c?: number;
  public_notice: string;
}

export async function callPublicReportApi(batchCode: string): Promise<PublicReportSummary> {
  return callApi(
    () => fetch(`/api/v1/scan/reports/public/${batchCode}`),
    (data: any): PublicReportSummary => ({
      status: data.status || 'ok',
      batch_code: data.batch_code || batchCode,
      commodity: data.commodity || { name: 'Alphonso Mango', category: 'fresh_produce', ripeness_stage: 'breaker' },
      chosen_option: data.chosen_option || { film_name: 'Micro-perforated Active MAP', thickness_micron: 30, otr: 28, wvtr: 1.8, recyclability_score: 85 },
      shelf_life: data.shelf_life || { low_days: 18, expected_days: 21, high_days: 26 },
      confidence: data.confidence || { score: 92 },
      compliance: data.compliance || { is_compliant: true, status: 'COMPLIANT', standards: ['ASTM D3985', 'IS 9845'] },
      logger_paired: Boolean(data.logger_paired),
      logger_temp_c: data.logger_temp_c,
      public_notice: data.public_notice || 'Public read-only summary.'
    }),
    'Unable to load public result QR passport.'
  );
}
