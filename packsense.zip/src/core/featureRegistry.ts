/**
 * featureRegistry.ts
 * 
 * Part B.1: Feature Registry — The single source of truth for all PackSense features.
 * Guarantees that no feature can be silently dropped from the UI or scan report.
 */

export interface FeatureEntry {
  id: string;                 // stable key
  titleKey: string;           // localization key
  title: string;              // english display name
  description: string;
  iconName: string;           // lucide icon identifier
  route: string;              // navigation route
  roles: string[];            // 'farmer' | 'fpo_manager' | 'exporter' | 'retailer' | 'scientist' | 'admin'
  reportSection: string | null; // key in analyze response, or null if standalone
  needsScanContext: boolean;  // true = opens inside a report, false = standalone
  category: 'core' | 'engineering' | 'sourcing' | 'economics' | 'governance' | 'tools';
}

export const FEATURE_REGISTRY: FeatureEntry[] = [
  // 1. Digital Twin Kinetics
  {
    id: 'twin',
    titleKey: 'feature.twin',
    title: 'Digital Twin Simulation',
    description: 'Hourly permeation, respiration kinetics, and dynamic degradation modeling.',
    iconName: 'Activity',
    route: '/report/graphs/twin',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'twin',
    needsScanContext: true,
    category: 'core'
  },
  // 2. Agro-Climate Profiles
  {
    id: 'climate_profiles',
    titleKey: 'feature.climate_profiles',
    title: 'Climate Profiles',
    description: '15 Indian agro-climatic zones and ambient temperature/RH adjustments.',
    iconName: 'Thermometer',
    route: '/features/climate',
    roles: ['farmer', 'fpo_manager', 'exporter', 'scientist', 'admin'],
    reportSection: 'climate',
    needsScanContext: true,
    category: 'engineering'
  },
  // 3. Multi-Objective Optimizer
  {
    id: 'optimizer',
    titleKey: 'feature.optimizer',
    title: 'Pareto Optimizer',
    description: 'Multi-objective laminate optimization across cost, shelf life, and CO2e.',
    iconName: 'Sliders',
    route: '/features/optimizer',
    roles: ['fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'options',
    needsScanContext: true,
    category: 'engineering'
  },
  // 4. Ripeness Computer Vision
  {
    id: 'ripeness_scan',
    titleKey: 'feature.ripeness_scan',
    title: 'Ripeness Vision Scanner',
    description: 'Calibrated colorimetry and maturity grading for fresh horticulture.',
    iconName: 'Sparkles',
    route: '/scan/ripeness',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'core'
  },
  // 5. Compliance Guard
  {
    id: 'compliance',
    titleKey: 'feature.compliance',
    title: 'FSSAI Compliance Guard',
    description: 'IS 9845 overall migration limits and food contact safety verification.',
    iconName: 'ShieldCheck',
    route: '/report/compliance',
    roles: ['fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'compliance',
    needsScanContext: true,
    category: 'governance'
  },
  // 6. Voice Input
  {
    id: 'voice_input',
    titleKey: 'feature.voice_input',
    title: 'Multilingual Voice Assistant',
    description: 'Bhashini AI voice synthesis and hands-free field input in Indic languages.',
    iconName: 'Mic',
    route: '/features/voice',
    roles: ['farmer', 'fpo_manager', 'admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'tools'
  },
  // 7. QR Passport
  {
    id: 'qr_passport',
    titleKey: 'feature.qr_passport',
    title: 'Dynamic QR Passport',
    description: 'Cryptographic batch traceability and dynamic shelf-life passport generation.',
    iconName: 'QrCode',
    route: '/features/passport',
    roles: ['fpo_manager', 'exporter', 'retailer', 'admin'],
    reportSection: 'actions',
    needsScanContext: true,
    category: 'tools'
  },
  // 8. Regional Suppliers
  {
    id: 'suppliers',
    titleKey: 'feature.suppliers',
    title: 'Packaging Suppliers',
    description: 'Geo-located Indian film converters, paper mills, and MOQ directory.',
    iconName: 'Building',
    route: '/features/suppliers',
    roles: ['farmer', 'fpo_manager', 'exporter', 'admin'],
    reportSection: 'suppliers',
    needsScanContext: true,
    category: 'sourcing'
  },
  // 9. Pack Auditor
  {
    id: 'pack_auditor',
    titleKey: 'feature.pack_auditor',
    title: 'Reverse Pack Auditor',
    description: 'Benchmark current pack barrier vs optimized barrier to identify shelf-life gap.',
    iconName: 'Layers',
    route: '/features/pack-audit',
    roles: ['fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'audit',
    needsScanContext: true,
    category: 'engineering'
  },
  // 10. Spoilage Autopsy
  {
    id: 'spoilage_autopsy',
    titleKey: 'feature.spoilage_autopsy',
    title: 'Spoilage Autopsy',
    description: 'Diagnostic root cause analysis for mold, rancidity, sogginess, and puncture.',
    iconName: 'AlertTriangle',
    route: '/features/spoilage-autopsy',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'admin'],
    reportSection: 'spoilage_risks',
    needsScanContext: true,
    category: 'engineering'
  },
  // 11. Active Packaging
  {
    id: 'active_packaging',
    titleKey: 'feature.active_packaging',
    title: 'Active Packaging Sachets',
    description: 'O2 scavengers, desiccants, and 1-MCP ethylene absorption dosage calculator.',
    iconName: 'Wind',
    route: '/features/active-packaging',
    roles: ['fpo_manager', 'exporter', 'scientist', 'admin'],
    reportSection: 'active_packaging',
    needsScanContext: true,
    category: 'engineering'
  },
  // 12. Condensation Risk
  {
    id: 'condensation',
    titleKey: 'feature.condensation',
    title: 'Dew-Point Condensation',
    description: 'Psychrometric dew-point calculations across cold chain transit transitions.',
    iconName: 'Droplets',
    route: '/features/condensation',
    roles: ['fpo_manager', 'exporter', 'retailer', 'admin'],
    reportSection: 'condensation',
    needsScanContext: true,
    category: 'engineering'
  },
  // 13. Mixed Load
  {
    id: 'mixed_load',
    titleKey: 'feature.mixed_load',
    title: 'Mixed Load Compatibility',
    description: 'Ethylene compatibility matrix, cross-odor taint, and co-transit rules.',
    iconName: 'Boxes',
    route: '/features/mixed-load',
    roles: ['farmer', 'fpo_manager', 'exporter', 'admin'],
    reportSection: 'mixed_load',
    needsScanContext: true,
    category: 'engineering'
  },
  // 14. Right-Sizing
  {
    id: 'right_sizing',
    titleKey: 'feature.right_sizing',
    title: 'Package Right-Sizing',
    description: 'Pouch volume vs headspace optimization to eliminate excess polymer waste.',
    iconName: 'Minimize2',
    route: '/features/right-sizing',
    roles: ['fpo_manager', 'exporter', 'scientist', 'admin'],
    reportSection: 'right_sizing',
    needsScanContext: true,
    category: 'engineering'
  },
  // 15. Secondary Packaging
  {
    id: 'secondary_packaging',
    titleKey: 'feature.secondary_packaging',
    title: 'Secondary Packaging',
    description: 'McKee formula corrugated box stacking strength and pallet utilization.',
    iconName: 'Boxes',
    route: '/features/secondary-packaging',
    roles: ['fpo_manager', 'exporter', 'retailer', 'admin'],
    reportSection: 'secondary_packaging',
    needsScanContext: true,
    category: 'engineering'
  },
  // 16. Rupee Impact
  {
    id: 'rupee_impact',
    titleKey: 'feature.rupee_impact',
    title: 'Rupee Impact ROI',
    description: 'Post-harvest spoilage loss reduction economics and net rupee savings.',
    iconName: 'DollarSign',
    route: '/report/money/rupee-impact',
    roles: ['farmer', 'fpo_manager', 'exporter', 'admin'],
    reportSection: 'rupee_impact',
    needsScanContext: true,
    category: 'economics'
  },
  // 17. Rural Mode
  {
    id: 'rural_mode',
    titleKey: 'feature.rural_mode',
    title: 'Rural ZECC & Passive Storage',
    description: 'Zero Energy Cool Chambers, clay pot evapo-cooling, and low-cost village storage.',
    iconName: 'Sun',
    route: '/features/rural-mode',
    roles: ['farmer', 'fpo_manager', 'admin'],
    reportSection: 'rural_alternatives',
    needsScanContext: true,
    category: 'engineering'
  },
  // 18. Community Loop
  {
    id: 'community_loop',
    titleKey: 'feature.community_loop',
    title: 'Community Learning Loop',
    description: 'Decentralized shelf-life calibration and peer outcome aggregation.',
    iconName: 'TrendingUp',
    route: '/features/community',
    roles: ['farmer', 'fpo_manager', 'scientist', 'admin'],
    reportSection: 'community',
    needsScanContext: true,
    category: 'governance'
  },
  // 19. Logger Pairing
  {
    id: 'logger_pairing',
    titleKey: 'feature.logger_pairing',
    title: 'Bluetooth Data Logger',
    description: 'BLE environmental logger sync for dynamic shelf-life adjustment in transit.',
    iconName: 'Wifi',
    route: '/features/logger',
    roles: ['fpo_manager', 'exporter', 'retailer', 'admin'],
    reportSection: 'actions',
    needsScanContext: true,
    category: 'tools'
  },
  // 20. Confidence Score
  {
    id: 'confidence',
    titleKey: 'feature.confidence',
    title: 'Confidence Engine',
    description: 'Deterministic uncertainty scoring and ASTM method validation factors.',
    iconName: 'Award',
    route: '/report/confidence',
    roles: ['farmer', 'fpo_manager', 'exporter', 'scientist', 'admin'],
    reportSection: 'confidence',
    needsScanContext: true,
    category: 'core'
  },
  // 21. Lab Trial Checklist
  {
    id: 'lab_trial',
    titleKey: 'feature.lab_trial',
    title: 'Lab Trial Checklist',
    description: 'Pre-commercialization protocol checklist for accelerated shelf-life testing.',
    iconName: 'FileText',
    route: '/report/lab-trial',
    roles: ['fpo_manager', 'exporter', 'scientist', 'admin'],
    reportSection: 'lab_trial',
    needsScanContext: true,
    category: 'engineering'
  },
  // 22. Government Dashboard
  {
    id: 'gov_dashboard',
    titleKey: 'feature.gov_dashboard',
    title: 'MoFPI District Portal',
    description: 'District-level post-harvest wastage metrics and cold chain infrastructure.',
    iconName: 'Building',
    route: '/features/gov-dashboard',
    roles: ['admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'governance'
  },
  // 23. Offline Sync Status
  {
    id: 'offline_sync_status',
    titleKey: 'feature.offline_sync_status',
    title: 'Offline Sync Status',
    description: 'Local report cache, background queue, and mesh peer synchronization.',
    iconName: 'RefreshCw',
    route: '/features/sync-status',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'tools'
  },
  // 24. Produce Ripeness & Commodity Scan
  {
    id: 'produce_scan',
    titleKey: 'feature.produce_scan',
    title: 'Produce & Commodity Scanner',
    description: 'Produce ripeness detection, camera scan for farm produce and agricultural commodities.',
    iconName: 'Scan',
    route: '/scan/produce',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'input',
    needsScanContext: false,
    category: 'core'
  },
  // 25. Label OCR Scan
  {
    id: 'label_scan',
    titleKey: 'feature.label_scan',
    title: 'Pack Label OCR',
    description: 'On-device text extraction for ingredients, net weight, and packaging material.',
    iconName: 'Camera',
    route: '/scan/label',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'input',
    needsScanContext: false,
    category: 'core'
  },
  // 26. Language Picker
  {
    id: 'language_picker',
    titleKey: 'feature.language_picker',
    title: 'Language Selection',
    description: 'Seamless localized interface in English, Hindi, Marathi, and Tamil.',
    iconName: 'Settings',
    route: '/settings/language',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'tools'
  },
  // 27. Reports Export
  {
    id: 'reports_export',
    titleKey: 'feature.reports_export',
    title: 'PDF & Excel Export',
    description: 'Export official engineering specification sheets and compliance reports.',
    iconName: 'Download',
    route: '/reports/export',
    roles: ['farmer', 'fpo_manager', 'exporter', 'retailer', 'scientist', 'admin'],
    reportSection: 'actions',
    needsScanContext: true,
    category: 'tools'
  },
  // 28. Admin Panel
  {
    id: 'admin_panel',
    titleKey: 'feature.admin_panel',
    title: 'Admin Management',
    description: 'Products registry curation, database merges, and system diagnostic pipeline.',
    iconName: 'Settings',
    route: '/admin',
    roles: ['admin'],
    reportSection: null,
    needsScanContext: false,
    category: 'governance'
  }
];

export const REQUIRED_FEATURE_IDS = [
  'twin', 'climate_profiles', 'optimizer', 'ripeness_scan', 'compliance',
  'voice_input', 'qr_passport', 'suppliers', 'pack_auditor', 'spoilage_autopsy',
  'active_packaging', 'condensation', 'mixed_load', 'right_sizing',
  'secondary_packaging', 'rupee_impact', 'rural_mode', 'community_loop',
  'logger_pairing', 'confidence', 'lab_trial', 'gov_dashboard',
  'offline_sync_status', 'produce_scan', 'label_scan', 'language_picker',
  'reports_export', 'admin_panel'
] as const;

export function getFeatureById(id: string): FeatureEntry | undefined {
  return FEATURE_REGISTRY.find(f => f.id === id);
}

export function getFeaturesForRole(role: string): FeatureEntry[] {
  return FEATURE_REGISTRY.filter(f => f.roles.includes(role) || f.roles.includes('*'));
}

export function getScanReportFeatures(): FeatureEntry[] {
  return FEATURE_REGISTRY.filter(f => f.reportSection !== null);
}
