import React, { useState, useMemo } from 'react';
import { Database, Search, Filter, Thermometer, ShieldAlert, Sparkles, Layers } from 'lucide-react';
import { PackagingMaterial, MATERIALS_DATABASE } from '../engine/materialsDb.ts';

export const MaterialsMatrix: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('evoh_32');
  const [testTempC, setTestTempC] = useState<number>(23);

  const filteredMaterials = useMemo(() => {
    return MATERIALS_DATABASE.filter(m => {
      const matchSearch = m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCat = categoryFilter === 'all' || m.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [searchTerm, categoryFilter]);

  const selectedMaterial = useMemo(() => {
    return MATERIALS_DATABASE.find(m => m.id === selectedMaterialId) || MATERIALS_DATABASE[0];
  }, [selectedMaterialId]);

  // Arrhenius calculations for the selected polymer
  const arrheniusPO2 = useMemo(() => {
    const t_k = testTempC + 273.15;
    const t_ref = 23 + 273.15;
    const ep_j = selectedMaterial.ep_o2 * 1000;
    return selectedMaterial.po2_23c * Math.exp((-ep_j / 8.314) * (1 / t_k - 1 / t_ref));
  }, [selectedMaterial, testTempC]);

  const arrheniusPWVTR = useMemo(() => {
    const t_k = testTempC + 273.15;
    const t_ref = 38 + 273.15;
    const ep_j = selectedMaterial.ep_h2o * 1000;
    return selectedMaterial.pwvtr_38c * Math.exp((-ep_j / 8.314) * (1 / t_k - 1 / t_ref));
  }, [selectedMaterial, testTempC]);

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Database className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Polymer & Substrate Permeation Database
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              ASTM D3985 / ASTM F1249 calibrated intrinsic permeabilities, Arrhenius activation energies, and LCA metrics.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search polymer code or name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-white rounded-lg pl-8 pr-3 py-1.5 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none w-56"
              />
            </div>

            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none"
            >
              <option value="all">All Material Categories ({MATERIALS_DATABASE.length})</option>
              <option value="polyolefin">Polyolefins (PE / PP)</option>
              <option value="barrier_polymer">High-Barrier Resins (EVOH / PVDC)</option>
              <option value="polyester">Polyester (PET / BOPET)</option>
              <option value="polyamide">Polyamide (Nylon / BOPA)</option>
              <option value="metallized">Metallized Films (Met-PET / Met-BOPP)</option>
              <option value="foil">Aluminum Foil</option>
              <option value="biopolymer">Biopolymers (PLA / Bio-PBS)</option>
              <option value="paper">Barrier Papers</option>
            </select>
          </div>
        </div>
      </div>

      {/* Temperature Arrhenius Permeability Sandbox */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <Thermometer className="w-4 h-4 text-rose-400" />
            <span className="font-semibold text-white">
              Arrhenius Temperature Permeability Simulator: {selectedMaterial.name} ({selectedMaterial.code})
            </span>
          </div>
          <span className="font-mono text-slate-400">
            Activation Energy: O₂ = {selectedMaterial.ep_o2} kJ/mol | H₂O = {selectedMaterial.ep_h2o} kJ/mol
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center pt-1 text-xs">
          <div className="md:col-span-5 space-y-1">
            <div className="flex justify-between font-mono">
              <span className="text-slate-400">Test Temperature:</span>
              <strong className="text-white font-bold">{testTempC} °C</strong>
            </div>
            <input
              type="range"
              min="-18"
              max="50"
              value={testTempC}
              onChange={(e) => setTestTempC(Number(e.target.value))}
              className="w-full accent-rose-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>-18°C (Frozen)</span>
              <span>2°C (Chill)</span>
              <span>23°C (ASTM Standard)</span>
              <span>38°C (Tropical)</span>
            </div>
          </div>

          <div className="md:col-span-7 grid grid-cols-2 gap-3 font-mono">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">P_O2 @ {testTempC}°C:</span>
              <span className="text-emerald-400 font-bold text-sm">
                {arrheniusPO2.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-500 block">cm³·µm/(m²·day·atm)</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 block text-[10px]">P_WVTR @ {testTempC}°C:</span>
              <span className="text-sky-400 font-bold text-sm">
                {arrheniusPWVTR.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-500 block">g·µm/(m²·day)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Polymer Database Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono text-[11px] uppercase">
              <tr>
                <th className="px-4 py-3">Code / Resin</th>
                <th className="px-3 py-3">Category</th>
                <th className="px-3 py-3 text-right">Density (g/cm³)</th>
                <th className="px-3 py-3 text-right">P_O2 (23°C)</th>
                <th className="px-3 py-3 text-right">P_WVTR (38°C)</th>
                <th className="px-3 py-3 text-right">Cost ($/kg)</th>
                <th className="px-3 py-3 text-right">CO₂e (kg/kg)</th>
                <th className="px-3 py-3">Recyclability Stream</th>
                <th className="px-3 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filteredMaterials.map((mat) => {
                const isSelected = selectedMaterialId === mat.id;
                return (
                  <tr
                    key={mat.id}
                    onClick={() => setSelectedMaterialId(mat.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-slate-800/80 font-medium' : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white font-mono">{mat.code}</span>
                        <span className="text-slate-400 text-[11px]">({mat.name})</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5 truncate max-w-xs">
                        {mat.description}
                      </div>
                    </td>

                    <td className="px-3 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] uppercase font-mono bg-slate-800 text-slate-300 border border-slate-700">
                        {mat.category.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="px-3 py-3 text-right font-mono text-slate-200">
                      {mat.density.toFixed(3)}
                    </td>

                    <td className="px-3 py-3 text-right font-mono text-emerald-400 font-semibold">
                      {mat.po2_23c.toLocaleString()}
                    </td>

                    <td className="px-3 py-3 text-right font-mono text-sky-400 font-semibold">
                      {mat.pwvtr_38c.toLocaleString()}
                    </td>

                    <td className="px-3 py-3 text-right font-mono text-slate-200">
                      ${mat.cost_per_kg.toFixed(2)}
                    </td>

                    <td className="px-3 py-3 text-right font-mono text-slate-200">
                      {mat.carbon_per_kg.toFixed(2)}
                    </td>

                    <td className="px-3 py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        mat.recyclability_tier.includes('Class A')
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : mat.recyclability_tier.includes('Class B')
                          ? 'bg-blue-950 text-blue-300 border border-blue-800'
                          : mat.recyclability_tier.includes('Class C')
                          ? 'bg-lime-950 text-lime-300 border border-lime-800'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        {mat.recyclability_tier.split(' ')[0]} {mat.recycled_stream !== 'None' ? `(${mat.recycled_stream})` : ''}
                      </span>
                    </td>

                    <td className="px-3 py-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedMaterialId(mat.id);
                        }}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 font-mono text-[10px]"
                      >
                        Inspect Arrhenius
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
