/**
 * AuthScreen.tsx
 * 
 * Part B.1: Official Authentication Screens (Register & Login)
 * - Email + password authentication for all roles
 * - Role picker: 4 self-service roles only (Farmer, FPO, MSME, Industry)
 * - Government & Admin accounts require approval from Profile, never self-registered
 * - Real API round-trip via /api/v1/auth/login and /api/v1/auth/register
 * - Instant error feedback with clean userMessage
 * - Demo account quick-login for evaluation & testing
 */

import React, { useState } from 'react';
import {
  Shield,
  Lock,
  Mail,
  User,
  Building,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Eye,
  EyeOff,
  Tractor,
  Boxes,
  Factory,
  Check
} from 'lucide-react';
import { loginApi, registerApi, AuthResponse, AppException } from '../core/apiClient.ts';

interface AuthScreenProps {
  onAuthSuccess: (authData: AuthResponse) => void;
  onOpenPublicQr?: (batchCode: string) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess, onOpenPublicQr }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');

  // Login form fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Register form fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<'farmer' | 'fpo' | 'msme' | 'industry'>('farmer');
  const [regOrganization, setRegOrganization] = useState('');

  // UI state
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [duplicateEmailNotice, setDuplicateEmailNotice] = useState(false);

  // Field errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    const newErrors: Record<string, string> = {};

    if (!loginEmail.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!validateEmail(loginEmail)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!loginPassword) {
      newErrors.password = 'Password is required';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    try {
      const res = await loginApi({
        email: loginEmail.trim().toLowerCase(),
        password: loginPassword
      });
      setSuccessMessage('Login successful! Redirecting...');
      setTimeout(() => {
        onAuthSuccess(res);
      }, 300);
    } catch (err: any) {
      if (err instanceof AppException) {
        setErrorMessage(err.userMessage || 'Invalid email or password.');
      } else {
        setErrorMessage('Unable to connect to server. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    const newErrors: Record<string, string> = {};

    if (!regName.trim()) {
      newErrors.name = 'Full name is required';
    }

    if (!regEmail.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!validateEmail(regEmail)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!regPassword) {
      newErrors.password = 'Password is required';
    } else if (regPassword.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    try {
      const res = await registerApi({
        email: regEmail.trim().toLowerCase(),
        password: regPassword,
        name: regName.trim(),
        role: regRole,
        organization: regOrganization.trim() || undefined
      });
      setSuccessMessage('Account created! Logging in...');
      setTimeout(() => {
        onAuthSuccess(res);
      }, 300);
    } catch (err: any) {
      if (err instanceof AppException) {
        if (err.statusCode === 409 || err.reasonCode === 'duplicate_email' || err.userMessage?.toLowerCase().includes('already exists')) {
          setErrorMessage('An account with this email already exists — log in instead');
          setDuplicateEmailNotice(true);
        } else {
          setErrorMessage(err.userMessage || 'Registration failed. Please check your details.');
          setDuplicateEmailNotice(false);
        }
      } else {
        setErrorMessage('Registration error. Please check your network connection.');
        setDuplicateEmailNotice(false);
      }
    } finally {
      setLoading(false);
    }
  };

  const fillDemoAccount = (email: string, pass: string) => {
    setLoginEmail(email);
    setLoginPassword(pass);
    setErrors({});
    setErrorMessage(null);
    setDuplicateEmailNotice(false);
  };

  return (
    <div className="min-h-screen bg-[#F4F8FC] flex flex-col justify-between text-[#0F1C2E] p-4 sm:p-6 md:p-8">
      {/* Brand Header */}
      <div className="max-w-md w-full mx-auto pt-4 pb-6 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-[#1565C0] to-[#42A5F5] text-white shadow-lg shadow-blue-500/20 mb-3">
          <Shield className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#0F1C2E]">
          PackSense AI
        </h1>
        <p className="text-xs sm:text-sm text-[#6B7A90] mt-1 font-medium">
          Smarter Packaging. Fresher Food. A Greener Future.
        </p>
      </div>

      {/* Main Auth Card */}
      <div className="max-w-md w-full mx-auto bg-white rounded-2xl border border-[#E3E9F2] shadow-xl shadow-slate-200/50 p-6 sm:p-8">
        {/* Toggle Mode Tabs */}
        <div className="flex border border-[#E3E9F2] rounded-xl p-1 bg-[#F4F8FC] mb-6">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
              setErrors({});
              setDuplicateEmailNotice(false);
            }}
            className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-white text-[#1565C0] shadow-sm'
                : 'text-[#6B7A90] hover:text-[#0F1C2E]'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMessage(null);
              setErrors({});
              setDuplicateEmailNotice(false);
            }}
            className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
              mode === 'register'
                ? 'bg-white text-[#1565C0] shadow-sm'
                : 'text-[#6B7A90] hover:text-[#0F1C2E]'
            }`}
          >
            Register
          </button>
        </div>

        {/* Global Error Banner */}
        {errorMessage && (
          <div className="mb-5 p-3.5 bg-red-50 border border-red-200 rounded-xl flex flex-col gap-2 text-red-700 text-xs sm:text-sm">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
            {duplicateEmailNotice && (
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setLoginEmail(regEmail);
                  setErrorMessage(null);
                  setDuplicateEmailNotice(false);
                }}
                className="self-start ml-6 text-xs font-bold text-[#1565C0] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Log in with {regEmail} now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Global Success Banner */}
        {successMessage && (
          <div className="mb-5 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-emerald-700 text-xs sm:text-sm">
            <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
            <span className="leading-snug">{successMessage}</span>
          </div>
        )}

        {mode === 'login' ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={loginEmail}
                  onChange={e => setLoginEmail(e.target.value)}
                  placeholder="name@organization.org"
                  className={`w-full px-3.5 py-2.5 pl-10 rounded-xl border ${
                    errors.email ? 'border-red-500 bg-red-50/30' : 'border-[#E3E9F2] focus:border-[#1E88E5]'
                  } text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
                  disabled={loading}
                />
                <Mail className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
              </div>
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider">
                  Password
                </label>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full px-3.5 py-2.5 pl-10 pr-10 rounded-xl border ${
                    errors.password ? 'border-red-500 bg-red-50/30' : 'border-[#E3E9F2] focus:border-[#1E88E5]'
                  } text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
                  disabled={loading}
                />
                <Lock className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-[#6B7A90] hover:text-[#0F1C2E]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#1565C0] to-[#1E88E5] hover:from-[#0D47A1] hover:to-[#1565C0] text-white font-semibold text-sm shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <span>Log In to PackSense</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Quick Demo Logins Bar */}
            <div className="pt-4 border-t border-[#E3E9F2]">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#6B7A90] mb-2 text-center">
                Quick Test Login (Demo Accounts)
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => fillDemoAccount('farmer@packsense.org', 'PackSense2026!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  🌾 Farmer
                </button>
                <button
                  type="button"
                  onClick={() => fillDemoAccount('fpo@packsense.org', 'PackSense2026!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  🚜 FPO
                </button>
                <button
                  type="button"
                  onClick={() => fillDemoAccount('msme@packsense.org', 'PackSense2026!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  📦 MSME
                </button>
                <button
                  type="button"
                  onClick={() => fillDemoAccount('industry@packsense.org', 'PackSense2026!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  🏭 Industry
                </button>
                <button
                  type="button"
                  onClick={() => fillDemoAccount('admin@packsense.org', 'AdminPass123!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  ⚡ Admin
                </button>
                <button
                  type="button"
                  onClick={() => fillDemoAccount('gov@packsense.org', 'PackSense2026!')}
                  className="py-1.5 px-2 bg-[#F4F8FC] hover:bg-[#E8F1FD] text-[#1565C0] rounded-lg text-xs font-semibold border border-[#E3E9F2] transition-colors"
                >
                  🏛️ Gov MoFPI
                </button>
              </div>
            </div>
          </form>
        ) : (
          /* REGISTER FORM */
          <form onSubmit={handleRegisterSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Full Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={regName}
                  onChange={e => setRegName(e.target.value)}
                  placeholder="e.g. Ramesh Patil"
                  className={`w-full px-3.5 py-2.5 pl-10 rounded-xl border ${
                    errors.name ? 'border-red-500 bg-red-50/30' : 'border-[#E3E9F2] focus:border-[#1E88E5]'
                  } text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
                  disabled={loading}
                />
                <User className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
              </div>
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={regEmail}
                  onChange={e => setRegEmail(e.target.value)}
                  placeholder="your.email@domain.com"
                  className={`w-full px-3.5 py-2.5 pl-10 rounded-xl border ${
                    errors.email ? 'border-red-500 bg-red-50/30' : 'border-[#E3E9F2] focus:border-[#1E88E5]'
                  } text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
                  disabled={loading}
                />
                <Mail className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
              </div>
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Password (min 8 chars)
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={regPassword}
                  onChange={e => setRegPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full px-3.5 py-2.5 pl-10 rounded-xl border ${
                    errors.password ? 'border-red-500 bg-red-50/30' : 'border-[#E3E9F2] focus:border-[#1E88E5]'
                  } text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
                  disabled={loading}
                />
                <Lock className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
              </div>
              {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
            </div>

            {/* RadioSelectCard: 4 Self-Service Roles */}
            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Select Your Role
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'farmer', title: 'Farmer', icon: Tractor, desc: 'Smallholder & grower' },
                  { id: 'fpo', title: 'FPO / Co-op', icon: Boxes, desc: 'Farmer collective' },
                  { id: 'msme', title: 'MSME Processor', icon: Building, desc: 'Food processing unit' },
                  { id: 'industry', title: 'Industry / Brand', icon: Factory, desc: 'Large converter / FMCG' }
                ].map(r => {
                  const Icon = r.icon;
                  const isSelected = regRole === r.id;
                  return (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setRegRole(r.id as any)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-[#1565C0] bg-[#E8F1FD] shadow-sm'
                          : 'border-[#E3E9F2] bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-[#1565C0]' : 'text-[#6B7A90]'}`} />
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#1565C0]" />}
                      </div>
                      <div className={`text-xs font-bold ${isSelected ? 'text-[#1565C0]' : 'text-[#0F1C2E]'}`}>
                        {r.title}
                      </div>
                      <div className="text-[10px] text-[#6B7A90] leading-tight mt-0.5">
                        {r.desc}
                      </div>
                    </button>
                  );
                })}
              </div>
              <p className="text-[11px] text-[#6B7A90] mt-1.5">
                * Government and Administrator accounts require verification and can be requested from Profile after registration.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1C2E] uppercase tracking-wider mb-1.5">
                Organization / Farm Name (Optional)
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={regOrganization}
                  onChange={e => setRegOrganization(e.target.value)}
                  placeholder="e.g. Sahyadri Agri Hub"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl border border-[#E3E9F2] focus:border-[#1E88E5] text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                  disabled={loading}
                />
                <Building className="w-4 h-4 text-[#6B7A90] absolute left-3.5 top-3" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#1565C0] to-[#1E88E5] hover:from-[#0D47A1] hover:to-[#1565C0] text-white font-semibold text-sm shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Registering Account...</span>
                </>
              ) : (
                <>
                  <span>Create Account & Start</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Public Result QR Scanner Entry */}
        {onOpenPublicQr && (
          <div className="mt-6 pt-4 border-t border-[#E3E9F2] text-center">
            <button
              type="button"
              onClick={() => onOpenPublicQr('RES-1-001')}
              className="text-xs font-semibold text-[#1565C0] hover:underline inline-flex items-center gap-1.5"
            >
              <span>Scan or View a Public Product QR Passport</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* Footer Credentials Note */}
      <div className="max-w-md w-full mx-auto text-center pt-6 pb-2 text-[11px] text-[#6B7A90]">
        PackSense Packaging Engineering Suite • Powered by AI + Physics + Sustainability
        <div className="mt-1 text-[10px] text-slate-400">
          Deterministic Fick & Arrhenius Diffusion • ASTM D3985 & ASTM F1249 Certified
        </div>
      </div>
    </div>
  );
};
