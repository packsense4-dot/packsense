import React, { useState } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Sliders,
  CheckCircle2,
  AlertCircle,
  FileText,
  BarChart3,
  HelpCircle
} from 'lucide-react';
import {
  computeShapAttribution,
  runComplianceAudit,
  ShapExplanationResult,
  ComplianceCheckResult
} from '../engine/shapAndCompliance.ts';
import { FoodProduct } from '../engine/foodsDb.ts';
import { LaminateBarrierResult, LaminateLayerInput } from '../engine/physics.ts';

interface ShapAndComplianceViewerProps {
  currentFood: FoodProduct;
  barrier: LaminateBarrierResult;
  predictedDays: number;
  storageTempC: number;
  initialO2Pct: number;
  initialCO2Pct: number;
}

export const ShapAndComplianceViewer: React.FC<ShapAndComplianceViewerProps> = ({
  currentFood,
  barrier,
  predictedDays,
  storageTempC,
  initialO2Pct,
  initialCO2Pct
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'shap' | 'compliance'>('shap');

  const baseExpectedDays = Math.round(currentFood.target_shelf_life_days * 0.7);
  const shapResult: ShapExplanationResult = computeShapAttribution(
    baseExpectedDays,
    predictedDays,
    storageTempC,
    barrier.otr_cc_m2_day_atm,
    barrier.wvtr_g_m2_day,
    initialO2Pct,
    initialCO2Pct,
    barrier.total_thickness_um
  );

  const complianceResults: ComplianceCheckResult[] = runComplianceAudit(
    barrier.layers.map(l => ({ code: l.material.code, thickness_um: l.thickness_um })),
    storageTempC,
    currentFood.category
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white tracking-tight">
            Surrogate Model SHAP Attribution & Rule-Based Compliance Engine
          </h2>
        </div>
        <p className="text-xs text-slate-400 max-w-4xl leading-relaxed">
          Rule-based compliance (SQL constraints, IS 9845 migration limits, FSSAI 2018 regulations, BIS 14625) and exact SHAP (SHapley Additive exPlanations) attribution on the surrogate model. Explains exactly why the engineering system outputs this predicted shelf life without free-text generative hallucinations.
        </p>

        {/* Sub-tab Navigation */}
        <div className="flex space-x-2 pt-2 border-t border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveSubTab('shap')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeSubTab === 'shap'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>SHAP Feature Attribution Waterfall</span>
          </button>
          <button
            onClick={() => setActiveSubTab('compliance')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeSubTab === 'compliance'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>FSSAI & BIS Regulatory Audit ({complianceResults.length} Rules)</span>
          </button>
        </div>
      </div>

      {/* View 1: SHAP Waterfall */}
      {activeSubTab === 'shap' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs text-slate-400">Baseline Expected Shelf Life (E[Y]):</span>
                <span className="text-base font-bold font-mono text-white ml-2">
                  {shapResult.base_expected_value_days} Days
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400">Final Predicted Packaging Shelf Life:</span>
                <span className="text-xl font-bold font-mono text-emerald-400 ml-2">
                  {shapResult.final_predicted_days} Days
                </span>
                <span className="text-xs text-slate-400 ml-2">
                  ({shapResult.final_predicted_days >= shapResult.base_expected_value_days ? '+' : ''}
                  {shapResult.final_predicted_days - shapResult.base_expected_value_days}d delta)
                </span>
              </div>
            </div>

            {/* Waterfall bars */}
            <div className="space-y-3 pt-1">
              {shapResult.contributions.map((c, i) => {
                const isPos = c.direction === 'positive';
                return (
                  <div key={i} className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${isPos ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                        <span className="font-bold text-white text-xs">{c.feature_name}</span>
                        <span className="text-slate-400 font-mono text-[11px]">[{c.feature_value_display}]</span>
                      </div>
                      <div className="font-mono text-xs">
                        <span className={`font-bold ${isPos ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isPos ? '+' : ''}{c.shap_value_days} Days
                        </span>
                        <span className="text-slate-500 text-[10px] ml-1.5">({c.percent_impact}%)</span>
                      </div>
                    </div>

                    {/* Progress visual bar */}
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden flex">
                      <div
                        style={{ width: `${Math.max(5, c.percent_impact)}%` }}
                        className={`h-full ${isPos ? 'bg-emerald-500' : 'bg-rose-500'}`}
                      />
                    </div>

                    <p className="text-[11px] text-slate-400 italic">
                      Physics Law: {c.physical_explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* View 2: FSSAI & BIS Compliance Audit */}
      {activeSubTab === 'compliance' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Statutory Food Packaging Compliance Verification (India & Export)
            </h3>

            <div className="space-y-3 pt-1">
              {complianceResults.map((rule) => {
                const isCompliant = rule.status === 'COMPLIANT';
                return (
                  <div
                    key={rule.rule_id}
                    className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-sky-300 border border-slate-700">
                          {rule.authority}
                        </span>
                        <span className="font-bold text-white text-xs">{rule.standard_code}</span>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded font-mono font-bold text-[10px] ${
                        isCompliant
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {rule.status}
                      </span>
                    </div>

                    <p className="text-slate-300 font-medium">
                      {rule.description}
                    </p>

                    <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded border border-slate-800/80 font-mono">
                      <strong className="text-slate-300">Technical Audit:</strong> {rule.details}
                      <div className="text-slate-500 text-[10px] mt-0.5">
                        Statutory Reference: {rule.reference_clause}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
