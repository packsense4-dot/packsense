import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Download,
  Copy,
  Check,
  ShieldCheck,
  Award,
  Layers,
  Wind,
  Cpu
} from 'lucide-react';
import { FoodProduct } from '../engine/foodsDb.ts';
import {
  LaminateLayerInput,
  LaminateBarrierResult,
  PackageGeometry,
  SimulationConditions,
  MapGasConfig,
  ShelfLifeSimulationResult,
  calculateLaminateBarrier,
  simulateShelfLife
} from '../engine/physics.ts';
import { TEST_STANDARDS } from '../engine/standards.ts';

interface SpecSheetViewerProps {
  currentFood: FoodProduct;
  layers: LaminateLayerInput[];
  geometry: PackageGeometry;
  conditions: SimulationConditions;
  mapGas: MapGasConfig;
}

export const SpecSheetViewer: React.FC<SpecSheetViewerProps> = ({
  currentFood,
  layers,
  geometry,
  conditions,
  mapGas
}) => {
  const [copied, setCopied] = useState(false);

  const barrier = calculateLaminateBarrier(layers, conditions.storage_temp_c, conditions.ambient_rh_percent);
  const simulation = simulateShelfLife(currentFood, barrier, geometry, conditions, mapGas);

  const specId = `PS-${Math.abs(currentFood.id.length * 997 + layers.length * 37 + Math.round(barrier.total_thickness_um * 11)).toString().padStart(6, '0')}`;
  const currentDateStr = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  const fullSpecObject = {
    document_title: 'PackSense Packaging Engineering Technical Data Sheet',
    specification_id: specId,
    generated_date: new Date().toISOString(),
    food_product: {
      name: currentFood.name,
      category: currentFood.category,
      net_weight_g: geometry.net_weight_g,
      initial_aw: currentFood.initial_aw,
      primary_degradation_mechanism: currentFood.primary_degradation_mechanism,
      target_shelf_life_days: currentFood.target_shelf_life_days
    },
    storage_environment: {
      storage_temperature_c: conditions.storage_temp_c,
      ambient_relative_humidity_pct: conditions.ambient_rh_percent
    },
    package_geometry: {
      format: geometry.package_type,
      length_mm: geometry.length_mm,
      width_mm: geometry.width_mm,
      surface_area_m2: simulation.package_surface_area_m2,
      headspace_volume_cm3: simulation.headspace_volume_cm3
    },
    barrier_film_architecture: {
      total_thickness_um: barrier.total_thickness_um,
      total_mass_gsm: barrier.total_mass_gsm,
      dominant_polymer: barrier.dominant_polymer,
      layers: barrier.layers.map((l, i) => ({
        layer_number: i + 1,
        code: l.material.code,
        name: l.material.name,
        thickness_um: l.thickness_um,
        mass_fraction_pct: l.mass_fraction_percent,
        density_g_cm3: l.material.density,
        functional_role: i === 0 ? 'Outer Protective Web' : i === barrier.layers.length - 1 ? 'Food Contact Sealant' : 'Barrier Core'
      }))
    },
    permeation_metrics: {
      otr_at_storage_temp_cc_m2_day_atm: barrier.otr_cc_m2_day_atm,
      otr_astm_d3985_ref_23c_0rh: barrier.ref_otr_23c,
      wvtr_astm_f1249_ref_38c_90rh_g_m2_day: barrier.ref_wvtr_38c,
      ctr_co2_transmission_rate_cc_m2_day_atm: barrier.ctr_cc_m2_day_atm
    },
    map_gas_formulation: {
      initial_o2_percent: mapGas.initial_o2_percent,
      initial_co2_percent: mapGas.initial_co2_percent,
      initial_n2_percent: mapGas.initial_n2_percent,
      gas_to_product_ratio: mapGas.gas_to_product_volume_ratio || 1.8
    },
    predicted_performance: {
      shelf_life_days: simulation.predicted_shelf_life_days,
      primary_limiting_factor: simulation.limiting_factor,
      failure_diagnosis: simulation.limiting_description,
      packaging_weight_per_pack_g: simulation.packaging_weight_per_pack_g,
      cost_per_pack_usd: simulation.cost_per_pack_usd,
      carbon_footprint_g_co2e_per_pack: simulation.carbon_per_pack_g_co2e,
      circularity: {
        recyclability_class: barrier.recyclability_class,
        recyclability_score: barrier.recyclability_score,
        ceflex_compliant: barrier.ceflex_compliant
      }
    },
    test_standards: TEST_STANDARDS.map(s => `${s.code} - ${s.title}`)
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(fullSpecObject, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(fullSpecObject, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PackSense_Spec_${specId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-emerald-400" />
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">
              Engineering Technical Data Sheet (TDS)
            </h2>
            <p className="text-xs text-slate-400">
              Formulation Reference: <strong className="text-emerald-400 font-mono">{specId}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopyJson}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center space-x-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied JSON' : 'Copy JSON'}</span>
          </button>

          <button
            onClick={handleDownloadJson}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 flex items-center space-x-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Download Spec</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm flex items-center space-x-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Formal Printable Document Layout */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-8 max-w-4xl mx-auto text-slate-100 shadow-xl space-y-8 font-sans print:bg-white print:text-black print:border-none print:shadow-none">
        
        {/* Document Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-6 print:border-gray-300">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-black tracking-tight text-white print:text-black">PackSense</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-mono border border-emerald-800/80">
                Packaging Engineering Report
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 print:text-gray-600">
              Deterministic Packaging Physics Simulation & Barrier Validation
            </p>
          </div>

          <div className="text-right font-mono text-xs text-slate-400 print:text-gray-600">
            <div>Spec ID: <strong className="text-white print:text-black">{specId}</strong></div>
            <div>Date: {currentDateStr}</div>
            <div className="text-emerald-400 print:text-green-700 font-semibold">Status: Certified Validated</div>
          </div>
        </div>

        {/* Section 1: Food Product & Geometry Profile */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-1 print:text-gray-700 print:border-gray-300">
            1. Food Matrix & Packaging Format
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Product Name:</span>
              <strong className="text-white print:text-black text-sm">{currentFood.name}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Food Category:</span>
              <strong className="text-white print:text-black">{currentFood.category.replace('_', ' ').toUpperCase()}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Net Fill Weight:</span>
              <strong className="text-white print:text-black">{geometry.net_weight_g} g</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Package Format:</span>
              <strong className="text-white print:text-black">{geometry.package_type.replace('_', ' ').toUpperCase()}</strong>
            </div>

            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Dimensions (L x W):</span>
              <strong className="text-white print:text-black">{geometry.length_mm} x {geometry.width_mm} mm</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Total Surface Area:</span>
              <strong className="text-white print:text-black">{simulation.package_surface_area_m2} m²</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Headspace Volume:</span>
              <strong className="text-white print:text-black">{simulation.headspace_volume_cm3} cm³</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-500">Storage Environment:</span>
              <strong className="text-white print:text-black">{conditions.storage_temp_c}°C / {conditions.ambient_rh_percent}% RH</strong>
            </div>
          </div>
        </div>

        {/* Section 2: Multilayer Laminate Structure Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1 print:border-gray-300">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 print:text-gray-700">
              2. Multilayer Laminate Film Specification
            </h3>
            <span className="text-xs font-mono text-slate-400 print:text-gray-600">
              Total Gauge: {barrier.total_thickness_um} µm ({barrier.total_mass_gsm} gsm)
            </span>
          </div>

          <table className="w-full text-left text-xs border border-slate-800 print:border-gray-300">
            <thead className="bg-slate-900 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800 print:bg-gray-100 print:text-gray-700">
              <tr>
                <th className="px-3 py-2">Layer</th>
                <th className="px-3 py-2">Material Resin</th>
                <th className="px-3 py-2 text-right">Gauge (µm)</th>
                <th className="px-3 py-2 text-right">Mass %</th>
                <th className="px-3 py-2 text-right">Density</th>
                <th className="px-3 py-2">Functional Role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 print:divide-gray-200">
              {barrier.layers.map((l, i) => (
                <tr key={i} className="font-mono text-xs">
                  <td className="px-3 py-2 text-slate-400 print:text-gray-600">Layer {i + 1}</td>
                  <td className="px-3 py-2 font-bold text-white print:text-black">
                    {l.material.code} <span className="font-normal text-slate-400 print:text-gray-600">({l.material.name})</span>
                  </td>
                  <td className="px-3 py-2 text-right text-emerald-400 print:text-green-700 font-bold">{l.thickness_um}</td>
                  <td className="px-3 py-2 text-right">{l.mass_fraction_percent}%</td>
                  <td className="px-3 py-2 text-right">{l.material.density}</td>
                  <td className="px-3 py-2 text-slate-300 print:text-gray-700 text-[11px]">
                    {i === 0 ? 'Outer Web / Print Substrate' : i === barrier.layers.length - 1 ? 'Food Contact Hermetic Seal' : 'Core Barrier Layer'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section 3: Calibrated Barrier Transmission Rates */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-1 print:text-gray-700 print:border-gray-300">
            3. Permeation Rates & ASTM Test Standards
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300">
              <span className="text-slate-500 block text-[10px] print:text-gray-600">OTR @ Storage Temp:</span>
              <strong className="text-emerald-400 print:text-green-700 text-base">{barrier.otr_cc_m2_day_atm}</strong>
              <span className="text-[10px] text-slate-400 block">cm³/(m²·day·atm)</span>
            </div>
            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300">
              <span className="text-slate-500 block text-[10px] print:text-gray-600">ASTM D3985 OTR (23°C dry):</span>
              <strong className="text-white print:text-black text-base">{barrier.ref_otr_23c}</strong>
              <span className="text-[10px] text-slate-400 block">cm³/(m²·day·atm)</span>
            </div>
            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300">
              <span className="text-slate-500 block text-[10px] print:text-gray-600">ASTM F1249 WVTR (38°C 90%RH):</span>
              <strong className="text-sky-400 print:text-blue-700 text-base">{barrier.ref_wvtr_38c}</strong>
              <span className="text-[10px] text-slate-400 block">g/(m²·day)</span>
            </div>
            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300">
              <span className="text-slate-500 block text-[10px] print:text-gray-600">CTR (CO₂ Rate):</span>
              <strong className="text-purple-400 print:text-purple-700 text-base">{barrier.ctr_cc_m2_day_atm}</strong>
              <span className="text-[10px] text-slate-400 block">cm³/(m²·day·atm)</span>
            </div>
          </div>
        </div>

        {/* Section 4: MAP Formulation & Shelf Life Outcome */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-1 print:text-gray-700 print:border-gray-300">
            4. MAP Gas Formulation & Predicted Shelf Life
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300 space-y-1">
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Initial Headspace Gas Mix:</span>
              <div className="text-sm font-bold text-white print:text-black">
                {mapGas.initial_o2_percent}% O₂ / {mapGas.initial_co2_percent}% CO₂ / {mapGas.initial_n2_percent}% N₂
              </div>
              <div className="text-[10px] text-slate-400 print:text-gray-600">
                Gas-to-Product Ratio (Vg/Vp): {mapGas.gas_to_product_volume_ratio || 1.8}x
              </div>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800 print:bg-gray-50 print:border-gray-300 space-y-1">
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Predicted Usable Shelf Life:</span>
              <div className="text-2xl font-black text-emerald-400 print:text-green-700">
                {simulation.predicted_shelf_life_days} Days
              </div>
              <div className="text-[10px] text-slate-300 print:text-gray-700">
                Failure Mode: {simulation.limiting_description}
              </div>
            </div>
          </div>
        </div>

        {/* Section 5: Unit Economics, LCA Carbon, & Circularity */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-1 print:text-gray-700 print:border-gray-300">
            5. Unit Economics, LCA Footprint & Circularity Audit
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Packaging Mass:</span>
              <strong className="text-white print:text-black">{simulation.packaging_weight_per_pack_g.toFixed(2)} g / pack</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Cost per Pack:</span>
              <strong className="text-white print:text-black">${simulation.cost_per_pack_usd.toFixed(4)} USD</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Embodied Carbon:</span>
              <strong className="text-white print:text-black">{simulation.carbon_per_pack_g_co2e.toFixed(1)} g CO₂e</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px] print:text-gray-600">Recyclability Class:</span>
              <strong className="text-emerald-400 print:text-green-700">{barrier.recyclability_class}</strong>
            </div>
          </div>
        </div>

        {/* Footer Notes & ASTM Compliance Sign-off */}
        <div className="pt-4 border-t border-slate-800 text-[10px] text-slate-500 print:text-gray-500 space-y-1">
          <p>
            Governing Standards: ASTM D3985 (Coulometric OTR), ASTM F1249 (Infrared WVTR), ASTM F1927 (RH-Controlled Gas Permeation), CEFLEX D4ACE (Circular Economy for Flexible Packaging).
          </p>
          <p>
            Generated deterministically by PackSense Food Packaging Engine. Calculations based on series resistance diffusion physics and differential mass balance. Zero generative LLMs utilized.
          </p>
        </div>

      </div>
    </div>
  );
};
