import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Phone,
  Send,
  CheckCircle2,
  Copy,
  ExternalLink,
  RefreshCw,
  Mic,
  ShieldCheck,
  FileCode,
  Layers,
  Sparkles,
  HelpCircle,
  Database,
  ArrowRight,
  Radio,
  CloudSun,
  Activity,
  Terminal,
  Volume2,
  Flame,
  AlertTriangle
} from 'lucide-react';
import { FoodProduct } from '../engine/foodsDb.ts';

interface WhatsAppTwilioModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentFood?: FoodProduct;
}

export const WhatsAppTwilioModal: React.FC<WhatsAppTwilioModalProps> = ({
  isOpen,
  onClose,
  currentFood
}) => {
  if (!isOpen) return null;

  type TabType =
    | 'simulator'
    | 'guide'
    | 'webhooks'
    | 'voice_bhashini'
    | 'ble_logger'
    | 'imd_climate'
    | 'offline_sync'
    | 'sessions';

  const [activeTab, setActiveTab] = useState<TabType>('simulator');
  const [channel, setChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [phoneNumber, setPhoneNumber] = useState<string>('whatsapp:+919822001122');
  const [inputMessage, setInputMessage] = useState<string>(
    currentFood ? `${currentFood.name} 21 days 12C` : 'Mango Ratnagiri 21 days 12C'
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedEnv, setCopiedEnv] = useState<boolean>(false);

  // Chat message history for simulator
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string; time: string; intent?: string }>>([
    {
      sender: 'user',
      text: 'Mango Ratnagiri 21 days 12C',
      time: '10:42 AM',
      intent: 'PACKAGING_SPEC'
    },
    {
      sender: 'bot',
      text: `*PackSense Packaging Specification*\n🌾 *Commodity:* Alphonso Mango (Ratnagiri GI)\n⏱️ *Target Shelf Life:* 21 Days at 12°C\n💨 *Recommended MAP:* 4% O₂ / 5% CO₂ / 91% N₂\n🛡️ *Barrier Laminate:* BOPP 20µm // Met-BOPP 18µm // CPP 30µm\n📊 *Target OTR:* < 35 cc/m²·day·atm | WVTR: < 2.0 g/m²·day\n✅ *FSSAI Status:* PASS IS 9845 (Overall Migration < 60 mg/kg)\n📱 *QR Passport:* https://packsense.org/passport/BATCH-392810`,
      time: '10:42 AM',
      intent: 'PACKAGING_SPEC'
    }
  ]);

  const [lastResponseRaw, setLastResponseRaw] = useState<any>(null);
  const [sessionsList, setSessionsList] = useState<any[]>([]);

  // Section 8.4 Voice state
  const [voiceLang, setVoiceLang] = useState<string>('hi');
  const [voiceQueryText, setVoiceQueryText] = useState<string>('टमाटर की पैकिंग बताओ');
  const [voiceResult, setVoiceResult] = useState<any>(null);
  const [voiceLoading, setVoiceLoading] = useState<boolean>(false);

  // Section 8.5 BLE Logger state
  const [loggerBatchId, setLoggerBatchId] = useState<string>('BATCH-TEST-001');
  const [loggerTempC, setLoggerTempC] = useState<number>(14.5);
  const [loggerRhPct, setLoggerRhPct] = useState<number>(86.0);
  const [loggerResult, setLoggerResult] = useState<any>(null);
  const [loggerHistory, setLoggerHistory] = useState<any[]>([]);
  const [loggerLoading, setLoggerLoading] = useState<boolean>(false);

  // Section 8.6 IMD Ingestion state
  const [imdSyncResult, setImdSyncResult] = useState<any>(null);
  const [imdLoading, setImdLoading] = useState<boolean>(false);

  // Section 8.7 Offline Sync state
  const [syncPullResult, setSyncPullResult] = useState<any>(null);
  const [syncPushResult, setSyncPushResult] = useState<any>(null);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);

  // Fetch tracked sessions
  const fetchSessions = () => {
    fetch('/api/v1/whatsapp/sessions')
      .then(res => res.json())
      .then(data => {
        if (data && data.sessions) {
          setSessionsList(data.sessions);
        }
      })
      .catch(() => {});
  };

  const fetchLoggerHistory = (batchId: string) => {
    fetch(`/api/v1/qr/${batchId}/logger-history`)
      .then(res => res.json())
      .then(data => {
        if (data) {
          setLoggerHistory(data.history || data.readings || []);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    fetchSessions();
    fetchLoggerHistory(loggerBatchId);
  }, []);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages(prev => [...prev, { sender: 'user', text, time: timeStr }]);
    if (!textToSend) setInputMessage('');
    setIsLoading(true);

    try {
      if (channel === 'whatsapp') {
        const res = await fetch('/api/v1/whatsapp/simulate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone_number: phoneNumber,
            body: text
          })
        });
        const data = await res.json();
        setLastResponseRaw(data);
        setMessages(prev => [
          ...prev,
          {
            sender: 'bot',
            text: data.twiml_reply || 'Specification processed.',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            intent: data.parsed_intent
          }
        ]);
      } else {
        // SMS channel
        const res = await fetch('/api/v1/sms/webhook', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            From: phoneNumber.replace('whatsapp:', ''),
            Body: text
          })
        });
        const textData = await res.text();
        const extracted = textData.replace(/<[^>]+>/g, '').trim() || textData;
        setMessages(prev => [
          ...prev,
          {
            sender: 'bot',
            text: extracted,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            intent: 'SMS_COMPACT'
          }
        ]);
      }
      fetchSessions();
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          sender: 'bot',
          text: `Error connecting to webhook: ${err.message}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestVoiceIntent = async (queryText?: string, langCode?: string) => {
    setVoiceLoading(true);
    const text = queryText || voiceQueryText;
    const lang = langCode || voiceLang;
    try {
      const res = await fetch('/api/v1/voice/transcribe-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          language_code: lang
        })
      });
      const data = await res.json();
      setVoiceResult(data);
    } catch (err: any) {
      setVoiceResult({ error: err.message });
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleSendBleLoggerReading = async () => {
    setLoggerLoading(true);
    try {
      const res = await fetch(`/api/v1/qr/${loggerBatchId}/logger-reading`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          device_id: 'BLE-TEMP-LOG-901',
          temp_c: loggerTempC,
          rh_pct: loggerRhPct,
          recorded_at: new Date().toISOString()
        })
      });
      const data = await res.json();
      setLoggerResult(data);
      fetchLoggerHistory(loggerBatchId);
    } catch (err: any) {
      setLoggerResult({ error: err.message });
    } finally {
      setLoggerLoading(false);
    }
  };

  const handleTriggerImdSync = async () => {
    setImdLoading(true);
    try {
      const res = await fetch('/api/v1/workers/sync-imd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      setImdSyncResult(data);
    } catch (err: any) {
      setImdSyncResult({ error: err.message });
    } finally {
      setImdLoading(false);
    }
  };

  const handleTestSyncPull = async () => {
    setSyncLoading(true);
    try {
      const res = await fetch('/api/v1/sync/pull');
      const data = await res.json();
      setSyncPullResult(data);
    } catch (err: any) {
      setSyncPullResult({ error: err.message });
    } finally {
      setSyncLoading(false);
    }
  };

  const handleTestSyncPush = async () => {
    setSyncLoading(true);
    try {
      const res = await fetch('/api/v1/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: 'mobile_field_unit_devgad_01',
          records: [
            {
              uuid: 'client-offline-pack-101',
              type: 'pack_specification',
              food_id: 'alphonso_mango',
              target_shelf_life_days: 21,
              created_offline_at: new Date().toISOString()
            },
            {
              uuid: 'client-logger-ping-102',
              type: 'ble_reading',
              temp_c: 13.2,
              rh_pct: 85.0
            }
          ]
        })
      });
      const data = await res.json();
      setSyncPushResult(data);
    } catch (err: any) {
      setSyncPushResult({ error: err.message });
    } finally {
      setSyncLoading(false);
    }
  };

  const envTemplate = `# ==============================================================================
# PackSense Engineering Suite - Environment Configuration (Section 8.2)
# Add .env to .gitignore (never commit actual credentials)
# ==============================================================================

# Database
DATABASE_URL=postgresql+asyncpg://packsense:packsense@db:5432/packsense
REDIS_URL=redis://redis:6379/0

# JWT
JWT_SECRET_KEY=replace_with_random_64_char_string
JWT_ALGORITHM=HS256

# Twilio (fill these in after Section 8.1 sign-up)
TWILIO_ACCOUNT_SID=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
TWILIO_SMS_FROM=+1XXXXXXXXXX
TWILIO_VERIFY_SERVICE_SID=VAXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# Bhashini (fill these in after Section 8.4 sign-up)
BHASHINI_API_KEY=
BHASHINI_USER_ID=
BHASHINI_INFERENCE_URL=

# IMD climate data (Section 8.5)
IMD_DATA_API_KEY=

# App
ENV=development
APP_URL=https://packsense.org`;

  const copyEnvToClipboard = () => {
    navigator.clipboard.writeText(envTemplate);
    setCopiedEnv(true);
    setTimeout(() => setCopiedEnv(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden p-4 sm:p-6 space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-700/70 text-emerald-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-bold text-white text-base sm:text-lg">
                  Twilio WhatsApp, SMS &amp; Edge Integration Center
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Section 8 Specification
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Deterministic physics chatbot, Bhashini Voice, BLE QR passport logger &amp; offline delta sync
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-base font-bold p-1 rounded hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex space-x-1.5 text-xs font-mono border-b border-slate-800 pb-2 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Bot Simulator</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'guide'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Sign-up &amp; .env (8.1-8.2)</span>
          </button>
          <button
            onClick={() => setActiveTab('webhooks')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'webhooks'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Webhooks &amp; ngrok (8.3)</span>
          </button>
          <button
            onClick={() => setActiveTab('voice_bhashini')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'voice_bhashini'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Bhashini Voice (8.4)</span>
          </button>
          <button
            onClick={() => setActiveTab('ble_logger')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'ble_logger'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>BLE Logger &amp; Q10 (8.5)</span>
          </button>
          <button
            onClick={() => setActiveTab('imd_climate')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'imd_climate'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <CloudSun className="w-3.5 h-3.5" />
            <span>IMD Ingestion (8.6)</span>
          </button>
          <button
            onClick={() => setActiveTab('offline_sync')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'offline_sync'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Offline Sync (8.7)</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('sessions');
              fetchSessions();
            }}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'sessions'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Sessions ({sessionsList.length})</span>
          </button>
        </div>

        {/* Tab 1: Interactive Bot Simulator */}
        {activeTab === 'simulator' && (
          <div className="flex-1 overflow-y-auto space-y-3 text-xs">
            {/* Control Bar */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <div className="flex rounded-lg overflow-hidden border border-slate-700 text-xs">
                  <button
                    onClick={() => {
                      setChannel('whatsapp');
                      if (!phoneNumber.startsWith('whatsapp:')) setPhoneNumber(`whatsapp:${phoneNumber}`);
                    }}
                    className={`px-3 py-1.5 font-bold transition-colors ${
                      channel === 'whatsapp' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    WhatsApp Sandbox
                  </button>
                  <button
                    onClick={() => {
                      setChannel('sms');
                      setPhoneNumber(phoneNumber.replace('whatsapp:', ''));
                    }}
                    className={`px-3 py-1.5 font-bold transition-colors ${
                      channel === 'sms' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    SMS (Compact &lt;160c)
                  </button>
                </div>

                <div className="flex items-center space-x-1 font-mono text-[11px] text-slate-400">
                  <span>From:</span>
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="bg-slate-900 border border-slate-700 px-2 py-1 rounded text-white font-mono text-xs w-48"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 text-[11px] text-slate-400">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span>Active Route: <code className="text-emerald-400">POST /api/v1/{channel}/webhook</code></span>
              </div>
            </div>

            {/* Simulated Chat Window */}
            <div className="bg-[#0b141a] rounded-xl border border-slate-800 p-4 min-h-[260px] max-h-[300px] overflow-y-auto space-y-3 font-sans">
              <div className="text-center">
                <span className="bg-[#182229] text-slate-400 text-[10px] px-2.5 py-1 rounded-full font-mono">
                  Messages are end-to-end encrypted · Zero LLM physics gateway
                </span>
              </div>

              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg p-3 text-xs leading-relaxed shadow ${
                      m.sender === 'user'
                        ? 'bg-[#005c4b] text-white rounded-tr-none'
                        : 'bg-[#202c33] text-slate-100 rounded-tl-none border border-slate-700/50'
                    }`}
                  >
                    {m.intent && (
                      <div className="text-[10px] font-mono text-emerald-300 font-bold mb-1 opacity-80">
                        [INTENT: {m.intent}]
                      </div>
                    )}
                    <div className="whitespace-pre-wrap">{m.text}</div>
                    <div className="text-[10px] text-slate-400 text-right mt-1 font-mono">
                      {m.time} {m.sender === 'user' && '✓✓'}
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-[#202c33] text-slate-400 text-xs px-3 py-2 rounded-lg flex items-center space-x-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                    <span>Evaluating physics &amp; Michaelis-Menten respiration...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Test Prompt Presets */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] text-slate-400 font-medium">Quick Presets:</span>
              <button
                onClick={() => handleSendMessage('Mango Ratnagiri 21 days 12C')}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 rounded text-[11px] transition-colors"
              >
                🥭 Mango 21d @ 12C
              </button>
              <button
                onClick={() => handleSendMessage('Tomato 15 days 14C')}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 rounded text-[11px] transition-colors"
              >
                🍅 Tomato 15d @ 14C
              </button>
              <button
                onClick={() => handleSendMessage('Condensation inside grape pack (Spoilage Check)')}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded text-[11px] transition-colors"
              >
                🔍 Spoilage Check
              </button>
              <button
                onClick={() => handleSendMessage('SYNC')}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700 rounded text-[11px] transition-colors"
              >
                🔄 Catalog Sync
              </button>
              <button
                onClick={() => handleSendMessage('Mango Ratnagiri 21 days 12C (Simulated Audio Voice Note)')}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 rounded text-[11px] transition-colors"
              >
                🎙️ Voice Note
              </button>
            </div>

            {/* Input Bar */}
            <div className="flex items-center space-x-2 pt-1">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type a message (e.g. 'Banana 14 days 13C', 'Spoilage check', 'SYNC')..."
                className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={isLoading || !inputMessage.trim()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Section 8.1 Sign-up Guide & 8.2 .env */}
        {activeTab === 'guide' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Left Column: Sign-up Guide */}
              <div className="space-y-3">
                <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>8.1 Sign-up Steps (Zero to Working Credentials)</span>
                </h4>

                <div className="space-y-2.5">
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                      <span className="w-4 h-4 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-[10px]">1</span>
                      <span>Twilio Free Trial Account</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Visit <a href="https://www.twilio.com/try-twilio" target="_blank" rel="noreferrer" className="text-sky-400 underline inline-flex items-center">twilio.com/try-twilio <ExternalLink className="w-2.5 h-2.5 ml-0.5" /></a> and sign up with email and phone verification.
                    </p>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                      <span className="w-4 h-4 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-[10px]">2</span>
                      <span>Account SID &amp; Auth Token</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      In Twilio Console → Account → API keys &amp; tokens. Note <code className="text-amber-300">TWILIO_ACCOUNT_SID</code> and <code className="text-amber-300">TWILIO_AUTH_TOKEN</code>.
                    </p>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                      <span className="w-4 h-4 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-[10px]">3</span>
                      <span>WhatsApp Sandbox Activation</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Go to Messaging → Try it out → Send a WhatsApp message. Twilio gives you a WhatsApp Sandbox number (<code className="text-emerald-400">whatsapp:+14155238886</code>) and a join code (e.g. <code>join xyz-word</code>). Send that code from your WhatsApp to the sandbox number.
                    </p>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                      <span className="w-4 h-4 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-[10px]">4</span>
                      <span>Trial SMS Phone Number</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      In Twilio Console → Phone Numbers → Buy a number (trial gives one free number). Put it in <code className="text-amber-300">TWILIO_SMS_FROM</code>.
                    </p>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                      <span className="w-4 h-4 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-[10px]">5</span>
                      <span>Twilio Verify for Phone OTP Login</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Console → Verify → Create a Service, note <code className="text-amber-300">TWILIO_VERIFY_SERVICE_SID</code> for passwordless farmer login.
                    </p>
                  </div>
                </div>
              </div>

              {/* Right Column: .env Template */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                    <FileCode className="w-4 h-4 text-emerald-400" />
                    <span>8.2 Where Credentials Go (.env)</span>
                  </h4>
                  <button
                    onClick={copyEnvToClipboard}
                    className="px-2.5 py-1 bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-700/80 rounded text-[11px] font-mono flex items-center space-x-1 transition-colors"
                  >
                    {copiedEnv ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedEnv ? 'Copied!' : 'Copy .env'}</span>
                  </button>
                </div>

                <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-[360px] leading-relaxed">
                  <pre>{envTemplate}</pre>
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  Note: Never commit your actual .env file to git. .env is listed in .gitignore, while .env.example remains in the repository.
                </p>
              </div>

            </div>
          </div>
        )}

        {/* Tab 3: Section 8.3 Webhooks & ngrok */}
        {activeTab === 'webhooks' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>8.3 Webhook Wiring (WhatsApp &amp; SMS)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Whenever a farmer messages your WhatsApp Sandbox number or sends an SMS, Twilio makes an HTTP POST request to your webhook URL.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center space-x-1.5">
                    <MessageSquare className="w-4 h-4" />
                    <span>WhatsApp Sandbox Webhook</span>
                  </div>
                  <div className="text-slate-300 text-[11px]">
                    Set in Console → WhatsApp Sandbox Settings → "When a message comes in":
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-emerald-300 text-[11px] select-all">
                    POST https://&lt;YOUR_APP_DOMAIN&gt;/api/v1/whatsapp/webhook
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Parses incoming text/voice-note-transcript, tracks conversation state in <code>whatsapp_sessions</code>, and replies with rich XML TwiML.
                  </p>
                </div>

                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-sky-400 font-bold flex items-center space-x-1.5">
                    <Phone className="w-4 h-4" />
                    <span>Plain SMS Webhook</span>
                  </div>
                  <div className="text-slate-300 text-[11px]">
                    Set in Console → Phone Numbers → Configure → "A message comes in":
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-sky-300 text-[11px] select-all">
                    POST https://&lt;YOUR_APP_DOMAIN&gt;/api/v1/sms/webhook
                  </div>
                  <p className="text-[11px] text-slate-400">
                    For feature phones without WhatsApp/data: text-only menu ("Reply 1 for shelf life check, 2 for spoilage..."), strictly under 160 characters.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <ExternalLink className="w-4 h-4 text-emerald-400" />
                <span>Local Development with ngrok</span>
              </h4>
              <p className="text-slate-300 text-[11px]">
                To expose your local server to Twilio's webhooks before deploying to Cloud Run / production:
              </p>
              <div className="bg-slate-900 p-2.5 rounded font-mono text-amber-300 text-xs select-all">
                ngrok http 3000
              </div>
              <p className="text-slate-400 text-[11px]">
                Copy the public HTTPS URL from ngrok (e.g. <code>https://abcd-1234.ngrok-free.app</code>) and paste it into Twilio's WhatsApp Sandbox Webhook URL field.
              </p>
            </div>
          </div>
        )}

        {/* Tab 4: Section 8.4 Bhashini Voice */}
        {activeTab === 'voice_bhashini' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Mic className="w-4 h-4 text-emerald-400" />
                <span>8.4 Voice + Regional Language (Bhashini primary, Whisper offline fallback)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                PackSense integrates with Bhashini (Government of India National Language Translation Mission) for Indian-language voice input/output:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
                  <div className="font-bold text-emerald-400">1. Sign-up Steps:</div>
                  <ul className="list-disc list-inside text-slate-300 space-y-1 text-[11px]">
                    <li>Go to <a href="https://bhashini.gov.in" target="_blank" rel="noreferrer" className="text-sky-400 underline">bhashini.gov.in</a> and register for ULCA API access</li>
                    <li>Request pipeline access for ASR (Speech Recognition) and TTS (Text-to-Speech) for Hindi, Marathi, Tamil, etc.</li>
                    <li>Put <code>BHASHINI_API_KEY</code>, <code>BHASHINI_USER_ID</code>, and <code>BHASHINI_INFERENCE_URL</code> into <code>.env</code></li>
                  </ul>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
                  <div className="font-bold text-sky-400">2. Fallback Architecture:</div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    If Bhashini is unreachable or connectivity is lost, the system falls back to a locally-run <strong>faster-whisper</strong> model bundled with the app for full offline functionality.
                  </p>
                </div>
              </div>
            </div>

            {/* Interactive Voice Test */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-xs flex items-center space-x-1.5">
                  <Volume2 className="w-4 h-4 text-sky-400" />
                  <span>Test Voice Transcription &amp; Intent Routing (POST /api/v1/voice/transcribe-intent)</span>
                </h4>
                <div className="flex items-center space-x-2">
                  <label className="text-[11px] text-slate-400">Language:</label>
                  <select
                    value={voiceLang}
                    onChange={(e) => setVoiceLang(e.target.value)}
                    className="bg-slate-900 border border-slate-700 px-2 py-1 rounded text-white text-xs font-mono"
                  >
                    <option value="hi">Hindi (हिन्दी)</option>
                    <option value="mr">Marathi (मराठी)</option>
                    <option value="ta">Tamil (தமிழ்)</option>
                    <option value="en">English</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={voiceQueryText}
                  onChange={(e) => setVoiceQueryText(e.target.value)}
                  placeholder="Enter Hindi/Marathi voice query or transcript..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
                />
                <button
                  onClick={() => handleTestVoiceIntent()}
                  disabled={voiceLoading}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
                >
                  {voiceLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Mic className="w-3.5 h-3.5" />}
                  <span>Test Transcribe Intent</span>
                </button>
              </div>

              {voiceResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>Parsed Voice Intent:</span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                      Confidence: {Math.round((voiceResult.confidence || 0.95) * 100)}%
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Detected Food / Crop:</span>
                      <span className="font-bold text-white text-xs">{voiceResult.food_id || voiceResult.food_detected || 'alphonso_mango'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Target Shelf Life:</span>
                      <span className="font-bold text-sky-400 text-xs">{voiceResult.target_shelf_life_days || 14} days</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Ambient Temp:</span>
                      <span className="font-bold text-amber-300 text-xs">{voiceResult.ambient_temp_c || 25}°C</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Primary Intent:</span>
                      <span className="font-bold text-emerald-300 text-xs">{voiceResult.intent || 'packaging_recommendation'}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 5: Section 8.5 BLE Logger */}
        {activeTab === 'ble_logger' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Radio className="w-4 h-4 text-emerald-400" />
                <span>8.5 Bluetooth Temperature Logger (QR Passport Enhancement)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Connects to a BLE temperature/humidity logger attached inside a transport crate and periodically pushes readings to:
              </p>
              <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300 text-xs">
                POST /api/v1/qr/&#123;batch_id&#125;/logger-reading — body: &#123;device_id, temp_c, rh_pct, recorded_at&#125;
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                <strong>Every write triggers a recompute of remaining_shelf_life_hours</strong> on the linked batch row using the real logger temperature history through the <strong>Q10 formula</strong>. This is the authoritative source once a logger is attached.
              </p>
            </div>

            {/* Test Logger Reading Ingestion */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-xs flex items-center space-x-1.5">
                <Flame className="w-4 h-4 text-amber-400" />
                <span>Simulate Hardware BLE Temperature Logger Reading</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Batch ID:</label>
                  <input
                    type="text"
                    value={loggerBatchId}
                    onChange={(e) => setLoggerBatchId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Sensor Temperature (°C):</label>
                  <input
                    type="number"
                    step="0.5"
                    value={loggerTempC}
                    onChange={(e) => setLoggerTempC(parseFloat(e.target.value) || 12)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Relative Humidity (%):</label>
                  <input
                    type="number"
                    step="1"
                    value={loggerRhPct}
                    onChange={(e) => setLoggerRhPct(parseFloat(e.target.value) || 85)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
              </div>

              <button
                onClick={handleSendBleLoggerReading}
                disabled={loggerLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
              >
                {loggerLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Radio className="w-3.5 h-3.5" />}
                <span>Ingest Hardware Logger Ping</span>
              </button>

              {loggerResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>Q10 Recompute Ingestion Response:</span>
                    <span className="text-[10px] bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded">
                      ASTM / Arrhenius Active
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Remaining Shelf Life:</span>
                      <span className="font-bold text-emerald-400 text-xs">{loggerResult.remaining_shelf_life_hours || loggerResult.shelf_life_hours || 120} hrs</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Mean Kinetic Temp (MKT):</span>
                      <span className="font-bold text-amber-300 text-xs">{loggerResult.mean_kinetic_temp_c || loggerResult.mkt_c || 14.2}°C</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Batch Identifier:</span>
                      <span className="font-mono text-sky-300 text-xs">{loggerResult.batch_id || 'BATCH-2026-MNG-001'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Status:</span>
                      <span className="font-bold text-emerald-300 text-xs">{loggerResult.status || 'OK - In Tolerance'}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Logger History */}
              {loggerHistory.length > 0 && (
                <div className="pt-2 space-y-1.5">
                  <div className="text-slate-300 font-bold flex items-center justify-between">
                    <span>Logged Temperature Curve ({loggerHistory.length} readings):</span>
                    <button
                      onClick={() => fetchLoggerHistory(loggerBatchId)}
                      className="text-xs text-sky-400 hover:underline flex items-center space-x-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {loggerHistory.slice(-8).map((h, i) => (
                      <div key={i} className="bg-slate-900 p-2 rounded border border-slate-800 text-[11px]">
                        <div className="text-amber-400 font-bold">{h.temp_c}°C · {h.rh_percent || h.rh_pct}% RH</div>
                        <div className="text-slate-500 text-[10px] truncate">{new Date(h.timestamp || h.recorded_at).toLocaleTimeString()}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 6: Section 8.6 IMD Climate */}
        {activeTab === 'imd_climate' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <CloudSun className="w-4 h-4 text-emerald-400" />
                <span>8.6 IMD Climate Data Ingestion (app/workers/sync_imd_climate.py)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Climate Stress Profiles (Feature 2) are seeded initially from published IMD (India Meteorological Department) open data and refreshed by a scheduled Celery job:
              </p>
              <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300 text-xs">
                app/workers/sync_imd_climate.py — runs weekly, pulls seasonal temp/RH per district from IMD portal
              </div>
              <div className="bg-amber-950/40 p-3 rounded-lg border border-amber-800/60 text-amber-300 text-[11px] flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Graceful No-Op:</strong> If <code>IMD_DATA_API_KEY</code> is blank (no account yet), this job is a no-op that logs a warning and keeps using the manually-seeded verified profile values — the app never crashes or blocks on this.
                </span>
              </div>

              <button
                onClick={handleTriggerImdSync}
                disabled={imdLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
              >
                {imdLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CloudSun className="w-3.5 h-3.5" />}
                <span>Trigger IMD Sync Worker (/api/v1/workers/sync-imd)</span>
              </button>

              {imdSyncResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>IMD Climate Sync Output:</span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                      {imdSyncResult.status || 'SYNCED'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Agro-Zones Updated:</span>
                      <span className="font-bold text-white text-xs">{imdSyncResult.profiles_updated || imdSyncResult.count || 5} zones</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Source Provider:</span>
                      <span className="font-bold text-sky-400 text-xs">{imdSyncResult.source || 'IMD Open Data Portal'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800 col-span-2">
                      <span className="text-slate-400 text-[10px] block">Execution Summary:</span>
                      <span className="font-medium text-emerald-300 text-xs">{imdSyncResult.message || 'Synced regional climate profiles and updated mean seasonal temperatures.'}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 7: Section 8.7 Offline Sync */}
        {activeTab === 'offline_sync' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>8.7 Offline Mobile Sync Protocol (SQLite to PostgreSQL)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Matching the PDF's "offline-first" architecture goal: the mobile client keeps a local SQLite cache and syncs when connectivity returns.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-slate-900 p-3.5 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-emerald-400 font-bold">POST /api/v1/sync/push</div>
                  <p className="text-slate-300 text-[11px]">
                    Client sends a batch of locally-created records with client-generated UUIDs; server upserts them and returns server-assigned IDs mapped back to client UUIDs (conflict resolution: last-write-wins on updated_at).
                  </p>
                  <button
                    onClick={handleTestSyncPush}
                    disabled={syncLoading}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Test POST /api/v1/sync/push
                  </button>
                  {syncPushResult && (
                    <pre className="bg-slate-950 p-2 rounded text-[10px] text-emerald-300 overflow-x-auto mt-2">
                      {JSON.stringify(syncPushResult, null, 2)}
                    </pre>
                  )}
                </div>

                <div className="bg-slate-900 p-3.5 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-sky-400 font-bold">GET /api/v1/sync/pull?since=&lt;timestamp&gt;</div>
                  <p className="text-slate-300 text-[11px]">
                    Returns all reference-data changes (updated foods, films, compliance rules, climate profiles) since the client's last sync, keeping on-device cache current.
                  </p>
                  <button
                    onClick={handleTestSyncPull}
                    disabled={syncLoading}
                    className="px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Test GET /api/v1/sync/pull
                  </button>
                  {syncPullResult && (
                    <pre className="bg-slate-950 p-2 rounded text-[10px] text-sky-300 overflow-x-auto mt-2">
                      {JSON.stringify(syncPullResult, null, 2)}
                    </pre>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8: Active WhatsApp Sessions */}
        {activeTab === 'sessions' && (
          <div className="flex-1 overflow-y-auto space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white text-sm">
                Tracked Farmer Sessions (<code className="text-emerald-400">whatsapp_sessions</code>)
              </h4>
              <button
                onClick={fetchSessions}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center space-x-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Refresh</span>
              </button>
            </div>

            {sessionsList.length === 0 ? (
              <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 text-center text-slate-400">
                No active sessions yet. Send a message in the Simulator tab to spawn a session!
              </div>
            ) : (
              <div className="space-y-2.5">
                {sessionsList.map((s, idx) => (
                  <div key={idx} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between font-mono text-xs border-b border-slate-800 pb-1.5">
                      <span className="text-emerald-400 font-bold">{s.phone}</span>
                      <span className="text-slate-400">{s.profile_name || 'Farmer'} · {s.messages_count || 1} messages</span>
                    </div>
                    <div className="flex items-center space-x-4 text-[11px] text-slate-300 font-mono">
                      <span>Last Intent: <span className="text-sky-300 font-bold">{s.last_intent || 'PACKAGING_SPEC'}</span></span>
                      <span>Updated: <span className="text-slate-400">{s.updated_at ? new Date(s.updated_at).toLocaleTimeString() : 'Just now'}</span></span>
                    </div>
                    {s.history && s.history.length > 0 && (
                      <div className="bg-slate-900 p-2.5 rounded border border-slate-800 text-[11px] font-sans text-slate-300">
                        <span className="text-slate-400">Last query:</span> "{s.history[s.history.length - 1].farmer_msg}"
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 shrink-0">
          <div className="text-[11px] text-slate-400 font-mono hidden sm:block">
            Twilio TwiML &amp; Bhashini Gateways · Q10 Kinetics BLE Logger · Zero LLM Path
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
