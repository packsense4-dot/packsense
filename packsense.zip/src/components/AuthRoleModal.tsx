import React, { useState, useEffect } from 'react';
import {
  Shield,
  User,
  Key,
  Phone,
  CheckCircle2,
  AlertCircle,
  X,
  Lock,
  ArrowRight,
  RefreshCw,
  Building,
  Sparkles,
  Clock,
  Check,
  Ban
} from 'lucide-react';
import { fetchWithAuth, setStoredTokens } from '../core/apiClient.ts';

interface AuthRoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRoleChanged?: (newRole: string) => void;
}

export const AuthRoleModal: React.FC<AuthRoleModalProps> = ({ isOpen, onClose, onRoleChanged }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'otp_login' | 'roles_matrix' | 'approvals'>('profile');
  const [currentUser, setCurrentUser] = useState<any>({
    name: 'Ramesh Patil',
    email: 'farmer@packsense.org',
    phone_number: '+919822001122',
    role: 'farmer',
    role_status: 'approved',
    preferred_language: 'marathi',
    organization: 'Devgad Mango Growers Co-op'
  });

  const [phoneNumber, setPhoneNumber] = useState('+919822001122');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // Application for government/admin roles
  const [applyingRole, setApplyingRole] = useState<'government' | 'admin' | null>(null);
  const [applicantAgency, setApplicantAgency] = useState('Ministry of Food Processing Industries (MoFPI) Regional Office');
  const [applicantReason, setApplicantReason] = useState('District post-harvest loss monitoring, cold chain subsidy allocation under PM-FME scheme.');
  
  // Pending approvals list for Admin
  const [pendingRequests, setPendingRequests] = useState<any[]>([]);

  const fetchUserData = () => {
    fetchWithAuth('/api/v1/auth/me')
      .then(r => r.json())
      .then(d => {
        if (d.user || d.current_user) {
          setCurrentUser(d.user || d.current_user);
        }
      })
      .catch(() => {});

    fetchWithAuth('/api/v1/admin/pending-approvals')
      .then(r => r.json())
      .then(d => {
        if (d.requests) {
          setPendingRequests(d.requests);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    if (isOpen) {
      fetchUserData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSendOtp = async () => {
    setLoading(true);
    setStatusMsg('');
    try {
      const res = await fetchWithAuth('/api/v1/auth/otp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone_number: phoneNumber })
      });
      const data = await res.json();
      setOtpSent(true);
      setStatusMsg(`OTP dispatched! Demo Sandbox OTP: ${data.demo_sandbox_otp || '123456'}`);
    } catch (err: any) {
      setStatusMsg(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setLoading(true);
    setStatusMsg('');
    try {
      const res = await fetchWithAuth('/api/v1/auth/otp/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone_number: phoneNumber, otp_code: otpCode })
      });
      const data = await res.json();
      if (res.ok) {
        if (data.access_token && data.refresh_token) {
          setStoredTokens(data.access_token, data.refresh_token, data.user);
        }
        setCurrentUser(data.user);
        setStatusMsg('Successfully authenticated! JWT 24h token generated.');
        if (onRoleChanged) onRoleChanged(data.user.role);
        fetchUserData();
      } else {
        setStatusMsg(data.error || 'Verification failed.');
      }
    } catch (err: any) {
      setStatusMsg(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Self-service roles switch immediately
  const handleSelectSelfServiceRole = async (targetRole: string) => {
    setLoading(true);
    try {
      const res = await fetchWithAuth('/api/v1/auth/switch-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: targetRole })
      });
      const data = await res.json();
      if (res.ok) {
        if (data.access_token && data.refresh_token) {
          setStoredTokens(data.access_token, data.refresh_token, data.user);
        }
        setCurrentUser(data.user);
        setStatusMsg(`Active session switched to '${targetRole}' role.`);
        if (onRoleChanged) onRoleChanged(targetRole);
      }
    } catch (err: any) {
      setStatusMsg(`Failed to switch role: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Submit request for non-self-service roles
  const handleSubmitRoleRequest = async () => {
    if (!applyingRole) return;
    setLoading(true);
    try {
      const res = await fetchWithAuth('/api/v1/auth/request-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target_role: applyingRole,
          organization: applicantAgency,
          reason: applicantReason,
          user_id: currentUser.id,
          user_name: currentUser.name,
          email: currentUser.email,
          phone_number: currentUser.phone_number
        })
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMsg(`Request submitted! Status: PENDING APPROVAL for '${applyingRole.toUpperCase()}'.`);
        setApplyingRole(null);
        fetchUserData();
      } else {
        setStatusMsg(data.error || 'Request submission failed.');
      }
    } catch (err: any) {
      setStatusMsg(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Admin approves role request
  const handleApproveRequest = async (requestId: string) => {
    setLoading(true);
    try {
      const res = await fetchWithAuth('/api/v1/admin/approve-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ request_id: requestId })
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMsg(data.message);
        fetchUserData();
        if (data.request?.requested_role && onRoleChanged) {
          onRoleChanged(data.request.requested_role);
        }
      }
    } catch (err: any) {
      setStatusMsg(`Approval failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Admin rejects role request
  const handleRejectRequest = async (requestId: string) => {
    setLoading(true);
    try {
      const res = await fetchWithAuth('/api/v1/admin/reject-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ request_id: requestId, reason: 'Official agency credentials could not be verified' })
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMsg(data.message);
        fetchUserData();
      }
    } catch (err: any) {
      setStatusMsg(`Rejection failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const selfServiceRoles = [
    {
      role: 'farmer',
      title: 'Farmer / Grower',
      desc: 'Point camera at harvest produce, shelf-life prediction, ZECC passive evaporative cooler guide, Rupee savings.',
      isSelfService: true
    },
    {
      role: 'fpo',
      title: 'FPO (Farmer Producer Org)',
      desc: 'Aggregated mandi cold-chain logs, local film converter sourcing, batch crate QR passports.',
      isSelfService: true
    },
    {
      role: 'msme',
      title: 'MSME Food Processor',
      desc: 'Active packaging sachets, right-sizing, spoilage autopsy matrix, FSSAI IS 9845 compliance.',
      isSelfService: true
    },
    {
      role: 'industry',
      title: 'Packaging Industry / Brand',
      desc: 'Bulk multi-layer barrier optimization, technical PDF spec sheet generation, shipper BCT calculations.',
      isSelfService: true
    }
  ];

  const regulatedRoles = [
    {
      role: 'government',
      title: 'Government Official (MoFPI / APEDA)',
      desc: 'District post-harvest loss telemetry, PM-FME subsidy verification, export packaging standards dashboard. Requires official agency approval.',
      isSelfService: false
    },
    {
      role: 'admin',
      title: 'System Administrator',
      desc: 'Full role approval governance, commodity/material reference editing, system health diagnostics. Requires administrator authorization.',
      isSelfService: false
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <span>User Authentication & Role Access</span>
                <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {currentUser.role}
                </span>
                {currentUser.role_status === 'pending_approval' && (
                  <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold uppercase bg-amber-950 text-amber-300 border border-amber-800 flex items-center space-x-1">
                    <Clock className="w-3 h-3 inline mr-1" />
                    Pending Approval
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                Self-service roles for producers & industry · Non-self-service approval for Government & Admin
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex border-b border-slate-800 px-5 pt-2 text-xs font-semibold space-x-3">
          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'profile'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Active User & Session
          </button>
          <button
            onClick={() => setActiveTab('otp_login')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'otp_login'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Phone OTP Sign-In
          </button>
          <button
            onClick={() => setActiveTab('roles_matrix')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'roles_matrix'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Switch Role & Request Access
          </button>
          <button
            onClick={() => setActiveTab('approvals')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'approvals'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Pending Approvals ({pendingRequests.filter(r => r.status === 'pending').length})
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {activeTab === 'profile' && (
            <div className="space-y-4">
              {currentUser.role_status === 'pending_approval' && (
                <div className="p-3 bg-amber-950/60 border border-amber-700/60 rounded-xl text-amber-200 space-y-2">
                  <div className="font-bold flex items-center space-x-1.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>Access Request Pending: {currentUser.pending_role?.toUpperCase()}</span>
                  </div>
                  <p className="text-[11px] text-amber-300/90 leading-relaxed">
                    Your request for official {currentUser.pending_role?.toUpperCase()} access is in queue for administrative verification. You can continue using full Farmer/Grower features in the meantime.
                  </p>
                  <button
                    onClick={() => {
                      // Demo instant approval
                      const req = pendingRequests.find(r => r.status === 'pending');
                      if (req) handleApproveRequest(req.id);
                      else handleSelectSelfServiceRole(currentUser.pending_role || 'government');
                    }}
                    className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-[10px] transition-colors"
                  >
                    ⚡ Demo Quick-Approve (Reviewer Test Helper)
                  </button>
                </div>
              )}

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">User Full Name</span>
                    <strong className="text-white text-sm">{currentUser.name}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Current Active Role</span>
                    <span className="text-emerald-400 font-mono text-sm font-bold uppercase">{currentUser.role}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Phone (Twilio OTP)</span>
                    <span className="text-slate-300 font-mono">{currentUser.phone_number || 'None'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Email Address</span>
                    <span className="text-slate-300 font-mono">{currentUser.email || 'None'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Organization / Agency</span>
                    <span className="text-slate-300">{currentUser.organization || 'Independent Farm Cluster'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Preferred Language</span>
                    <span className="text-slate-300 uppercase font-mono">{currentUser.preferred_language}</span>
                  </div>
                </div>
              </div>

              {/* Role-Based Permissions Checklist */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <span className="text-[11px] font-semibold text-white block">Active Feature Visibility for {currentUser.role.toUpperCase()}:</span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="flex items-center space-x-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Produce Camera Scanner (All Users)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>ASTM Digital Twin & Kinetics (All Users)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Rupee Impact & ZECC Cooling (All Users)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Dynamic Result QR Passport & PDF (All Users)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    {['government', 'admin'].includes(currentUser.role) ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-slate-500" />
                    )}
                    <span className={['government', 'admin'].includes(currentUser.role) ? 'text-white' : 'text-slate-500'}>
                      MoFPI District Dashboard (/api/v1/gov/*)
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    {currentUser.role === 'admin' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-slate-500" />
                    )}
                    <span className={currentUser.role === 'admin' ? 'text-white' : 'text-slate-500'}>
                      Admin Approvals & Database CRUD (/api/v1/admin/*)
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'otp_login' && (
            <div className="space-y-4">
              <p className="text-slate-300 text-xs">
                Log in via your phone number with verified 6-digit OTP (Twilio Verify).
              </p>

              <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Registered Phone Number</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={phoneNumber}
                      onChange={e => setPhoneNumber(e.target.value)}
                      placeholder="+919822001122"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      disabled={loading}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold transition-colors flex items-center space-x-1"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Send OTP</span>
                    </button>
                  </div>
                </div>

                {otpSent && (
                  <div className="pt-2 border-t border-slate-800">
                    <label className="text-slate-400 block mb-1 font-semibold">Enter 6-Digit Verification Code</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={otpCode}
                        onChange={e => setOtpCode(e.target.value)}
                        placeholder="e.g. 123456"
                        maxLength={6}
                        className="w-40 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono text-center tracking-widest text-sm"
                      />
                      <button
                        type="button"
                        onClick={handleVerifyOtp}
                        disabled={loading || otpCode.length < 6}
                        className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-semibold transition-colors"
                      >
                        Verify & Login
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'roles_matrix' && (
            <div className="space-y-4">
              {/* Applying modal for Government / Admin */}
              {applyingRole && (
                <div className="p-4 bg-slate-950 border border-indigo-500/50 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <strong className="text-white text-xs flex items-center space-x-2">
                      <Building className="w-4 h-4 text-indigo-400" />
                      <span>Apply for {applyingRole.toUpperCase()} Access</span>
                    </strong>
                    <button onClick={() => setApplyingRole(null)} className="text-slate-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Government and Admin roles provide elevated access and require administrative approval per PackSense governance policies.
                  </p>
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase block mb-1 font-bold">Government Department / Organization</label>
                    <input
                      type="text"
                      value={applicantAgency}
                      onChange={e => setApplicantAgency(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase block mb-1 font-bold">Official Justification</label>
                    <input
                      type="text"
                      value={applicantReason}
                      onChange={e => setApplicantReason(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                    />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button
                      type="button"
                      onClick={() => setApplyingRole(null)}
                      className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSubmitRoleRequest}
                      disabled={loading}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
                    >
                      Submit for Approval
                    </button>
                  </div>
                </div>
              )}

              {/* Group 1: Self-Service Roles */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Self-Service Roles (Instant Activation)</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {selfServiceRoles.map(r => {
                    const isCurrent = currentUser.role === r.role;
                    return (
                      <button
                        key={r.role}
                        type="button"
                        onClick={() => handleSelectSelfServiceRole(r.role)}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isCurrent
                            ? 'bg-emerald-950/70 border-emerald-600 ring-1 ring-emerald-500'
                            : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <strong className="text-white font-semibold flex items-center space-x-1.5">
                            <span>{r.title}</span>
                            {isCurrent && <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-800 text-emerald-200">Active</span>}
                          </strong>
                          <span className="text-emerald-400 font-mono text-[9px] uppercase font-bold">Self-Service</span>
                        </div>
                        <p className="text-[11px] text-slate-400">{r.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Group 2: Non-Self-Service Regulated Roles */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 flex items-center space-x-1">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Governance &amp; Admin Roles (1-Tap Switch or Approval Request)</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {regulatedRoles.map(r => {
                    const isCurrent = currentUser.role === r.role;
                    return (
                      <div
                        key={r.role}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isCurrent
                            ? 'bg-indigo-950/70 border-indigo-600 ring-1 ring-indigo-500'
                            : 'bg-slate-950 border-slate-800 hover:border-indigo-800'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <strong className="text-white font-semibold flex items-center space-x-1.5">
                            <span>{r.title}</span>
                            {isCurrent && <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-800 text-indigo-200">Active</span>}
                          </strong>
                          <span className="text-amber-400 font-mono text-[9px] uppercase font-bold">Governance</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mb-2">{r.desc}</p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSelectSelfServiceRole(r.role)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition-colors"
                          >
                            Switch Role Now
                          </button>
                          <button
                            type="button"
                            onClick={() => setApplyingRole(r.role as any)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded-lg text-[10px] font-bold border border-slate-700 transition-colors"
                          >
                            Request Approval
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'approvals' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Pending Government & Admin Access Requests</span>
                <button onClick={fetchUserData} className="text-slate-400 hover:text-white flex items-center space-x-1 text-[11px]">
                  <RefreshCw className="w-3 h-3" />
                  <span>Refresh</span>
                </button>
              </div>

              {pendingRequests.length === 0 ? (
                <div className="p-4 bg-slate-950 rounded-xl text-center text-slate-500">
                  No pending role approval requests.
                </div>
              ) : (
                <div className="space-y-2">
                  {pendingRequests.map(req => (
                    <div key={req.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <strong className="text-white text-xs">{req.user_name}</strong>
                          <span className="text-[10px] text-slate-400 ml-2">({req.email || req.phone_number})</span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono uppercase ${
                          req.status === 'approved' ? 'bg-emerald-950 text-emerald-300' : req.status === 'rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'
                        }`}>
                          {req.status}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-300">
                        Requested Role: <strong className="text-indigo-300 uppercase">{req.requested_role}</strong>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Organization: {req.organization}
                      </div>
                      <div className="text-[10px] text-slate-500 italic">
                        "{req.reason}"
                      </div>

                      {req.status === 'pending' && (
                        <div className="flex gap-2 pt-1 border-t border-slate-900 justify-end">
                          <button
                            onClick={() => handleRejectRequest(req.id)}
                            disabled={loading}
                            className="px-3 py-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded text-xs font-semibold flex items-center space-x-1"
                          >
                            <Ban className="w-3 h-3" />
                            <span>Reject</span>
                          </button>
                          <button
                            onClick={() => handleApproveRequest(req.id)}
                            disabled={loading}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center space-x-1"
                          >
                            <Check className="w-3 h-3" />
                            <span>Approve & Grant Role</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {statusMsg && (
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-emerald-300 font-mono text-[11px]">
              {statusMsg}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs">
          <span className="text-slate-500 font-mono">
            Role Access Governance Active
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
