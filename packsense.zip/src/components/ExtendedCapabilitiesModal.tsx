import React, { useState, useEffect } from 'react';
import {
  Layers,
  MapPin,
  Mic,
  Radio,
  CloudSun,
  ShieldCheck,
  ClipboardList,
  Building2,
  Database,
  FileCode,
  CheckCircle2,
  Copy,
  RefreshCw,
  ExternalLink,
  Volume2,
  Flame,
  AlertTriangle,
  Play,
  ArrowRight,
  TrendingDown,
  Scan,
  Languages
} from 'lucide-react';
import { FoodProduct } from '../engine/foodsDb.ts';

interface ExtendedCapabilitiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentFood?: FoodProduct;
}

export const ExtendedCapabilitiesModal: React.FC<ExtendedCapabilitiesModalProps> = ({
  isOpen,
  onClose,
  currentFood
}) => {
  if (!isOpen) return null;

  type CapabilityTab =
    | '8.1_postgis'
    | '8.2_voice'
    | '8.3_ble_logger'
    | '8.4_imd_climate'
    | '8.5_confidence'
    | '8.6_lab_trial'
    | '8.7_mofpi_gov'
    | '8.8_offline_sync'
    | '8.9_env'
    | '8.10_label_scan'
    | '8.11_multilingual';

  const [activeTab, setActiveTab] = useState<CapabilityTab>('8.1_postgis');
  const [copiedEnv, setCopiedEnv] = useState<boolean>(false);

  // 8.10 Pack Label Scan State
  const [labelOcrInput, setLabelOcrInput] = useState<string>(
    'BOPP 20 micron / Met-BOPP 18 micron / CPP 30 micron High Barrier Snack Web FSSAI Approved'
  );
  const [labelLang, setLabelLang] = useState<string>('en');
  const [labelScanResult, setLabelScanResult] = useState<any>(null);
  const [labelLoading, setLabelLoading] = useState<boolean>(false);

  // 8.11 Multilingual Gateway State
  const [i18nTargetLang, setI18nTargetLang] = useState<string>('hi');
  const [i18nPhrase, setI18nPhrase] = useState<string>('Oxygen Transmission Rate (OTR)');
  const [i18nTranslated, setI18nTranslated] = useState<any>(null);
  const [i18nCategory, setI18nCategory] = useState<string>('fssai_standards');
  const [i18nReferenceResult, setI18nReferenceResult] = useState<any>(null);
  const [i18nSpoilageResult, setI18nSpoilageResult] = useState<any>(null);
  const [i18nLoading, setI18nLoading] = useState<boolean>(false);
  const [i18nTemplateKey, setI18nTemplateKey] = useState<string>('shap_explanation.high_respiration');
  const [i18nTemplateRendered, setI18nTemplateRendered] = useState<string>('');

  // 8.9 Diagnostics State
  const [keysDiagnostics, setKeysDiagnostics] = useState<any>(null);
  const [keysLoading, setKeysLoading] = useState<boolean>(false);

  const fetchKeysDiagnostics = async () => {
    setKeysLoading(true);
    try {
      const res = await fetch('/api/v1/diagnostics/keys');
      if (res.ok) {
        const data = await res.json();
        setKeysDiagnostics(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setKeysLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === '8.9_env' && !keysDiagnostics) {
      fetchKeysDiagnostics();
    }
  }, [activeTab]);

  // 8.1 PostGIS State
  const [geoLat, setGeoLat] = useState<number>(18.5204); // Pune / Western Maharashtra
  const [geoLng, setGeoLng] = useState<number>(73.8567);
  const [geoRadius, setGeoRadius] = useState<number>(400);
  const [geoFilmId, setGeoFilmId] = useState<string>('bopp');
  const [geoResults, setGeoResults] = useState<any>(null);
  const [geoLoading, setGeoLoading] = useState<boolean>(false);

  // 8.2 Bhashini Voice State
  const [voiceLang, setVoiceLang] = useState<string>('hi');
  const [voiceText, setVoiceText] = useState<string>('टमाटर की पैकिंग बताओ');
  const [voiceResult, setVoiceResult] = useState<any>(null);
  const [voiceLoading, setVoiceLoading] = useState<boolean>(false);

  // 8.3 BLE Temperature Logger State
  const [batchId, setBatchId] = useState<string>('BATCH-TEST-001');
  const [loggerTempC, setLoggerTempC] = useState<number>(14.8);
  const [loggerRhPct, setLoggerRhPct] = useState<number>(86.0);
  const [loggerResult, setLoggerResult] = useState<any>(null);
  const [loggerHistory, setLoggerHistory] = useState<any[]>([]);
  const [loggerLoading, setLoggerLoading] = useState<boolean>(false);

  // 8.4 IMD Climate State
  const [imdResult, setImdResult] = useState<any>(null);
  const [imdLoading, setImdLoading] = useState<boolean>(false);

  // 8.5 Confidence Score Interactive State
  const [confIsEstimated, setConfIsEstimated] = useState<boolean>(false);
  const [confHasNoSource, setConfHasNoSource] = useState<boolean>(false);
  const [confHasNoImd, setConfHasNoImd] = useState<boolean>(false);
  const [confExtrapolationDist, setConfExtrapolationDist] = useState<number>(10);

  // 8.6 Lab Trial Checklist State
  const [labTrialChecklist, setLabTrialChecklist] = useState<any>(null);

  // 8.7 MoFPI Gov Dashboard State
  const [govSummary, setGovSummary] = useState<any>(null);
  const [govLoading, setGovLoading] = useState<boolean>(false);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('DIST-MH-RTG');
  const [districtDetail, setDistrictDetail] = useState<any>(null);

  // 8.8 Offline Sync State
  const [syncPullData, setSyncPullData] = useState<any>(null);
  const [syncPushData, setSyncPushData] = useState<any>(null);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);

  // Fetch initial data
  const handleFetchPostgisSuppliers = async () => {
    setGeoLoading(true);
    try {
      const res = await fetch(
        `/api/v1/suppliers/match?lat=${geoLat}&lng=${geoLng}&radius_km=${geoRadius}&film_id=${geoFilmId}`
      );
      const data = await res.json();
      setGeoResults(data);
    } catch (err: any) {
      setGeoResults({ error: err.message });
    } finally {
      setGeoLoading(false);
    }
  };

  const handleFetchLoggerHistory = async () => {
    try {
      const res = await fetch(`/api/v1/qr/${batchId}/logger-history`);
      const data = await res.json();
      setLoggerHistory(data.history || data.readings || []);
      if (!loggerResult) {
        setLoggerResult(data);
      }
    } catch {}
  };

  const handleFetchLiveStatus = async () => {
    setLoggerLoading(true);
    try {
      const res = await fetch(`/api/v1/qr/${batchId}/status`);
      const data = await res.json();
      setLoggerResult(data);
      handleFetchLoggerHistory();
    } catch (err: any) {
      setLoggerResult({ error: err.message });
    } finally {
      setLoggerLoading(false);
    }
  };

  const handleFetchGovSummary = async () => {
    setGovLoading(true);
    try {
      const res = await fetch('/api/v1/gov/dashboard/summary');
      const data = await res.json();
      setGovSummary(data);
    } catch (err: any) {
      setGovSummary({ error: err.message });
    } finally {
      setGovLoading(false);
    }
  };

  useEffect(() => {
    handleFetchPostgisSuppliers();
    handleFetchLoggerHistory();
    handleFetchGovSummary();
  }, []);

  const handleVoiceTranscribe = async (overrideText?: string, overrideLang?: string) => {
    setVoiceLoading(true);
    const text = overrideText || voiceText;
    const lang = overrideLang || voiceLang;
    try {
      const res = await fetch('/api/v1/voice/transcribe-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          language_code: lang
        })
      });
      const data = await res.json();
      setVoiceResult(data);
    } catch (err: any) {
      setVoiceResult({ error: err.message });
    } finally {
      setVoiceLoading(false);
    }
  };

  const handleSendLoggerReading = async () => {
    setLoggerLoading(true);
    try {
      const res = await fetch(`/api/v1/qr/${batchId}/logger-reading`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          device_id: 'BLE-TEMP-LOG-901',
          temp_c: loggerTempC,
          rh_pct: loggerRhPct,
          recorded_at: new Date().toISOString()
        })
      });
      const data = await res.json();
      setLoggerResult(data);
      handleFetchLoggerHistory();
    } catch (err: any) {
      setLoggerResult({ error: err.message });
    } finally {
      setLoggerLoading(false);
    }
  };

  const handleTriggerImdSync = async () => {
    setImdLoading(true);
    try {
      const res = await fetch('/api/v1/workers/sync-imd', { method: 'POST' });
      const data = await res.json();
      setImdResult(data);
    } catch (err: any) {
      setImdResult({ error: err.message });
    } finally {
      setImdLoading(false);
    }
  };

  const handleFetchDistrictDetail = async (distId: string) => {
    try {
      const res = await fetch(`/api/v1/gov/dashboard/district/${distId}`);
      const data = await res.json();
      setDistrictDetail(data);
    } catch {}
  };

  const handleSyncPull = async () => {
    setSyncLoading(true);
    try {
      const res = await fetch('/api/v1/sync/pull');
      const data = await res.json();
      setSyncPullData(data);
    } catch (err: any) {
      setSyncPullData({ error: err.message });
    } finally {
      setSyncLoading(false);
    }
  };

  const handleSyncPush = async () => {
    setSyncLoading(true);
    try {
      const res = await fetch('/api/v1/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: 'offline_mobile_field_unit_01',
          records: [
            {
              uuid: 'client-offline-spec-uuid-881',
              type: 'pack_specification',
              food_id: 'alphonso_mango',
              target_shelf_life_days: 21,
              created_offline_at: new Date().toISOString()
            },
            {
              uuid: 'client-offline-logger-uuid-882',
              type: 'ble_reading',
              temp_c: 13.5,
              rh_pct: 84.0
            }
          ]
        })
      });
      const data = await res.json();
      setSyncPushData(data);
    } catch (err: any) {
      setSyncPushData({ error: err.message });
    } finally {
      setSyncLoading(false);
    }
  };

  const handleScanLabel = async (textToScan?: string, langOverride?: string) => {
    setLabelLoading(true);
    try {
      const res = await fetch('/api/v1/pack-label/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ocr_text: textToScan || labelOcrInput,
          lang: langOverride || labelLang
        })
      });
      const data = await res.json();
      setLabelScanResult(data);
    } catch (err: any) {
      setLabelScanResult({ error: err.message });
    } finally {
      setLabelLoading(false);
    }
  };

  const handleTranslatePhrase = async () => {
    setI18nLoading(true);
    try {
      const res = await fetch('/api/v1/i18n/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: i18nPhrase, target_language: i18nTargetLang })
      });
      const data = await res.json();
      setI18nTranslated(data);
    } catch (err: any) {
      setI18nTranslated({ error: err.message });
    } finally {
      setI18nLoading(false);
    }
  };

  const handleFetchReferenceText = async (cat?: string, lang?: string) => {
    setI18nLoading(true);
    try {
      const c = cat || i18nCategory;
      const l = lang || i18nTargetLang;
      const res = await fetch(`/api/v1/i18n/reference-text?category=${c}&lang=${l}`);
      const data = await res.json();
      setI18nReferenceResult(data);
    } catch (err: any) {
      setI18nReferenceResult({ error: err.message });
    } finally {
      setI18nLoading(false);
    }
  };

  const handleFetchLocalizedSpoilage = async (lang?: string) => {
    setI18nLoading(true);
    try {
      const l = lang || i18nTargetLang;
      const res = await fetch('/api/v1/spoilage/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          commodity: 'alphonso_mango',
          storage_temp_c: 26.0,
          observed_symptoms: ['ballooning', 'odor'],
          lang: l
        })
      });
      const data = await res.json();
      setI18nSpoilageResult(data);
    } catch (err: any) {
      setI18nSpoilageResult({ error: err.message });
    } finally {
      setI18nLoading(false);
    }
  };

  const handleRenderTemplate = async (keyOverride?: string, langOverride?: string) => {
    setI18nLoading(true);
    try {
      const k = keyOverride || i18nTemplateKey;
      const l = langOverride || i18nTargetLang;
      const res = await fetch('/api/v1/i18n/render-template', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          template_key: k,
          lang: l,
          variables: {
            temp: 32,
            x: 4.2,
            target_wvtr: 1.5,
            rh: 85,
            o2: 3,
            co2: 5,
            shelf_life: 28,
            target: 25,
            pressure: -45,
            o2_threshold: 1.2,
            holes: 450,
            capacity: 500,
            o2_pct: 0.1,
            max_rh: 75,
            limit: 60,
            min_thickness: 50,
            district_name: 'Ratnagiri',
            loss_pct: 22
          }
        })
      });
      const data = await res.json();
      setI18nTemplateRendered(data.rendered_text || '');
    } catch {} finally {
      setI18nLoading(false);
    }
  };

  // Calculate live confidence score from Section 8.5 formula
  const calculatedConfidenceScore = Math.max(
    0,
    Math.min(
      100,
      100 -
        (confIsEstimated ? 25 : 0) -
        (confHasNoSource ? 15 : 0) -
        (confHasNoImd ? 10 : 0) -
        confExtrapolationDist
    )
  );

  const envContent = `# Database
DATABASE_URL=postgresql+asyncpg://packsense:packsense@db:5432/packsense
REDIS_URL=redis://redis:6379/0

# JWT
JWT_SECRET_KEY=replace_with_random_64_char_string
JWT_ALGORITHM=HS256

# Bhashini (fill these in after Section 8.2 sign-up)
BHASHINI_API_KEY=
BHASHINI_USER_ID=
BHASHINI_INFERENCE_URL=

# IMD climate data (Section 8.4)
IMD_DATA_API_KEY=

# App
ENV=development`;

  const copyEnv = () => {
    navigator.clipboard.writeText(envContent);
    setCopiedEnv(true);
    setTimeout(() => setCopiedEnv(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden p-4 sm:p-6 space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-700/70 text-emerald-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-bold text-white text-base sm:text-lg">
                  Additional Features Module — 8 Extended Backend Capabilities
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                  SIH PDF Specifications
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Direct app integrations (PostGIS spatial matching, Bhashini voice, BLE hardware logger, IMD sync, MoFPI dashboard &amp; offline SQLite sync)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-base font-bold p-1 rounded hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab Controls for the 8 Capabilities + .env */}
        <div className="flex space-x-1.5 text-xs font-mono border-b border-slate-800 pb-2 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('8.1_postgis')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.1_postgis'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>8.1 PostGIS Match</span>
          </button>

          <button
            onClick={() => setActiveTab('8.2_voice')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.2_voice'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>8.2 Bhashini Voice</span>
          </button>

          <button
            onClick={() => setActiveTab('8.3_ble_logger')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.3_ble_logger'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>8.3 BLE Logger &amp; Q10</span>
          </button>

          <button
            onClick={() => setActiveTab('8.4_imd_climate')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.4_imd_climate'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <CloudSun className="w-3.5 h-3.5" />
            <span>8.4 IMD Climate Sync</span>
          </button>

          <button
            onClick={() => setActiveTab('8.5_confidence')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.5_confidence'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>8.5 Confidence Score</span>
          </button>

          <button
            onClick={() => setActiveTab('8.6_lab_trial')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.6_lab_trial'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>8.6 Lab Checklist</span>
          </button>

          <button
            onClick={() => setActiveTab('8.7_mofpi_gov')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.7_mofpi_gov'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>8.7 MoFPI Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('8.8_offline_sync')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.8_offline_sync'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>8.8 Offline Mobile Sync</span>
          </button>

          <button
            onClick={() => setActiveTab('8.9_env')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.9_env'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>8.9 .env Config</span>
          </button>

          <button
            onClick={() => setActiveTab('8.10_label_scan')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.10_label_scan'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Scan className="w-3.5 h-3.5" />
            <span>8.10 Pack Label Scan</span>
          </button>

          <button
            onClick={() => setActiveTab('8.11_multilingual')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === '8.11_multilingual'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>8.11 Multilingual Gateway</span>
          </button>
        </div>

        {/* Tab 8.1: PostGIS Geo-Distance Supplier Matching */}
        {activeTab === '8.1_postgis' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>8.1 PostGIS + Geo-Distance Supplier Matching</span>
                </h4>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                  You Can Actually Buy This (Differentiator #8)
                </span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                Upgrades Feature #8 from a same-city text guess to genuine nearest-converter matching using PostGIS spatial geography queries:
              </p>
              <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300 text-[11px] select-all">
                GET /api/v1/suppliers/match?lat={geoLat}&amp;lng={geoLng}&amp;radius_km={geoRadius}&amp;film_id={geoFilmId}
              </div>
              <p className="text-slate-400 text-[11px]">
                SQL Predicate: <code className="text-sky-300">ST_DWithin(suppliers.location, ST_MakePoint(lng,lat)::geography, radius_km*1000)</code>
              </p>
            </div>

            {/* Interactive Query Form */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Origin Latitude:</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={geoLat}
                    onChange={(e) => setGeoLat(parseFloat(e.target.value) || 18.5204)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Origin Longitude:</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={geoLng}
                    onChange={(e) => setGeoLng(parseFloat(e.target.value) || 73.8567)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Radius (km): {geoRadius} km</label>
                  <input
                    type="range"
                    min="50"
                    max="1000"
                    step="25"
                    value={geoRadius}
                    onChange={(e) => setGeoRadius(parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Film / Polymer:</label>
                  <select
                    value={geoFilmId}
                    onChange={(e) => setGeoFilmId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  >
                    <option value="bopp">BOPP Flexible Film</option>
                    <option value="ldpe">LDPE Barrier Pouch</option>
                    <option value="pet">PET Clamshell / Sheet</option>
                    <option value="pla_film">Bio-PLA Compostable (IS 17088)</option>
                    <option value="all">All Verified Converters</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleFetchPostgisSuppliers}
                disabled={geoLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
              >
                {geoLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <MapPin className="w-3.5 h-3.5" />}
                <span>Execute PostGIS Geodesic Query</span>
              </button>

              {/* Results List */}
              {geoResults && geoResults.suppliers && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-slate-300 font-bold">
                    <span>Matched Converters within {geoRadius} km ({geoResults.matched_converters_count || geoResults.suppliers.length}):</span>
                    <span className="text-[11px] text-emerald-400 font-mono">Sorted by ST_DistanceSphere</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {geoResults.suppliers.map((s: any, idx: number) => (
                      <div key={idx} className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-xs">{s.name}</span>
                          <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-mono">
                            {s.distance_km || s.distance} km away
                          </span>
                        </div>
                        <div className="text-slate-400 text-[11px]">
                          Location: {s.city}, {s.state} · MOQ: {s.moq_kg || s.min_order_quantity_kg || 500} kg · Lead time: {s.lead_time_days || 7} days
                        </div>
                        <div className="flex flex-wrap gap-1 pt-0.5">
                          {(s.certifications || []).map((c: string, ci: number) => (
                            <span key={ci} className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded text-[10px] font-mono">
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.2: Bhashini Voice API */}
        {activeTab === '8.2_voice' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Mic className="w-4 h-4 text-emerald-400" />
                <span>8.2 Bhashini Voice API + Offline Faster-Whisper Fallback</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Govt of India National Language Translation Mission (NLTM) APIs for Indian-language voice input/output directly through the app mic.
              </p>
              <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300 text-xs">
                POST /api/v1/voice/transcribe-intent
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] text-slate-300">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
                  <div className="text-emerald-400 font-bold">1. Primary Path (Bhashini):</div>
                  <p>Sends audio to Bhashini ASR pipeline → gets text in detected Indian language → routes to deterministic intent matcher.</p>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
                  <div className="text-sky-400 font-bold">2. Offline Fallback (Whisper):</div>
                  <p>When disconnected, falls back to bundled faster-whisper model on-device to maintain rural accessibility.</p>
                </div>
              </div>
            </div>

            {/* Interactive Voice Test */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-xs flex items-center space-x-1.5">
                  <Volume2 className="w-4 h-4 text-sky-400" />
                  <span>Test Transcribe Intent Endpoint</span>
                </h4>
                <div className="flex items-center space-x-2">
                  <label className="text-slate-400 text-[11px]">Language:</label>
                  <select
                    value={voiceLang}
                    onChange={(e) => setVoiceLang(e.target.value)}
                    className="bg-slate-900 border border-slate-700 px-2 py-1 rounded text-white text-xs font-mono"
                  >
                    <option value="hi">Hindi (हिन्दी)</option>
                    <option value="mr">Marathi (मराठी)</option>
                    <option value="ta">Tamil (தமிழ்)</option>
                    <option value="en">English</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={voiceText}
                  onChange={(e) => setVoiceText(e.target.value)}
                  placeholder="Enter voice query transcript (e.g. टमाटर की पैकिंग बताओ)..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
                />
                <button
                  onClick={() => handleVoiceTranscribe()}
                  disabled={voiceLoading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
                >
                  {voiceLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Mic className="w-3.5 h-3.5" />}
                  <span>Test Voice Intent</span>
                </button>
              </div>

              {voiceResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>Parsed Voice Intent:</span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                      Confidence: {Math.round((voiceResult.confidence || 0.95) * 100)}%
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Detected Food / Crop:</span>
                      <span className="font-bold text-white text-xs">{voiceResult.food_id || voiceResult.food_detected || 'alphonso_mango'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Target Shelf Life:</span>
                      <span className="font-bold text-sky-400 text-xs">{voiceResult.target_shelf_life_days || 14} days</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Transit / Ambient Temp:</span>
                      <span className="font-bold text-amber-300 text-xs">{voiceResult.ambient_temp_c || 25}°C</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Primary Intent:</span>
                      <span className="font-bold text-emerald-300 text-xs">{voiceResult.intent || 'packaging_recommendation'}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.3: Bluetooth Temperature Logger Ingestion */}
        {activeTab === '8.3_ble_logger' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Radio className="w-4 h-4 text-emerald-400" />
                <span>8.3 Bluetooth Temperature Logger Ingestion &amp; Q10 Shelf-Life Passport</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Connects to a BLE hardware logger inside a transport crate. Every write triggers a live recompute of <code className="text-emerald-400">remaining_shelf_life_hours</code> using the real logger temperature history through the Arrhenius / Q10 formula.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300">
                  POST /api/v1/qr/&#123;batch_id&#125;/logger-reading
                </div>
                <div className="bg-slate-900 p-2.5 rounded font-mono text-sky-300">
                  GET /api/v1/qr/&#123;batch_id&#125;/logger-history
                </div>
              </div>
            </div>

            {/* Test Hardware Ingestion */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Batch ID:</label>
                  <input
                    type="text"
                    value={batchId}
                    onChange={(e) => setBatchId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Crate Sensor Temp (°C):</label>
                  <input
                    type="number"
                    step="0.5"
                    value={loggerTempC}
                    onChange={(e) => setLoggerTempC(parseFloat(e.target.value) || 12)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-slate-400 text-[11px] block mb-1">Relative Humidity (%):</label>
                  <input
                    type="number"
                    step="1"
                    value={loggerRhPct}
                    onChange={(e) => setLoggerRhPct(parseFloat(e.target.value) || 85)}
                    className="w-full bg-slate-900 border border-slate-700 px-2 py-1.5 rounded text-white font-mono text-xs"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={handleSendLoggerReading}
                  disabled={loggerLoading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
                >
                  {loggerLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Radio className="w-3.5 h-3.5" />}
                  <span>Ingest Hardware Sensor Reading</span>
                </button>

                <button
                  onClick={handleFetchLiveStatus}
                  disabled={loggerLoading}
                  className="px-4 py-2 bg-sky-700 hover:bg-sky-600 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loggerLoading ? 'animate-spin' : ''}`} />
                  <span>Poll Live QR Status (Q10 Kinetics)</span>
                </button>
              </div>

              {loggerResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>Dynamic Q10 Recomputed Shelf Life:</span>
                    <span className="text-[10px] bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded">
                      ASTM / Arrhenius Active
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Remaining Shelf Life:</span>
                      <span className="font-bold text-emerald-400 text-xs">{loggerResult.remaining_shelf_life_hours || loggerResult.shelf_life_hours || 120} hrs</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Mean Kinetic Temp (MKT):</span>
                      <span className="font-bold text-amber-300 text-xs">{loggerResult.mean_kinetic_temp_c || loggerResult.mkt_c || 14.2}°C</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Batch Identifier:</span>
                      <span className="font-mono text-sky-300 text-xs">{loggerResult.batch_id || 'BATCH-2026-MNG-001'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Status:</span>
                      <span className="font-bold text-emerald-300 text-xs">{loggerResult.status || 'OK - In Tolerance'}</span>
                    </div>
                  </div>
                </div>
              )}

              {loggerHistory.length > 0 && (
                <div className="space-y-1.5 pt-2">
                  <div className="text-slate-300 font-bold flex items-center justify-between">
                    <span>Logged Temperature Curve ({loggerHistory.length} points):</span>
                    <button
                      onClick={handleFetchLoggerHistory}
                      className="text-xs text-sky-400 hover:underline flex items-center space-x-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {loggerHistory.slice(-8).map((h, i) => (
                      <div key={i} className="bg-slate-900 p-2 rounded border border-slate-800 text-[11px]">
                        <div className="text-amber-400 font-bold">{h.temp_c}°C · {h.rh_pct || h.rh_percent}% RH</div>
                        <div className="text-slate-500 text-[10px] truncate">{new Date(h.timestamp || h.recorded_at).toLocaleTimeString()}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.4: IMD Climate Data Sync */}
        {activeTab === '8.4_imd_climate' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <CloudSun className="w-4 h-4 text-emerald-400" />
                <span>8.4 IMD Climate Data Sync (app/workers/sync_imd_climate.py)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Pulls seasonal temperature/humidity per district from the IMD public open data portal, updating <code>climate_profiles.avg_temp_c, max_temp_c, avg_rh_pct</code>, stamped with <code>last_synced_at + imd_source_id</code>.
              </p>
              <div className="bg-amber-950/40 p-3 rounded-lg border border-amber-800/60 text-amber-300 text-[11px] flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Graceful No-Op:</strong> If <code>IMD_DATA_API_KEY</code> is blank (no account yet), this job is a no-op that logs a warning and keeps using verified manually-seeded profiles — the app never crashes or blocks on this.
                </span>
              </div>
              <button
                onClick={handleTriggerImdSync}
                disabled={imdLoading}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
              >
                {imdLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CloudSun className="w-3.5 h-3.5" />}
                <span>Trigger Ingestion Worker (/api/v1/workers/sync-imd)</span>
              </button>
              {imdResult && (
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-[11px] space-y-2">
                  <div className="text-emerald-400 font-bold flex items-center justify-between">
                    <span>IMD Climate Sync Status:</span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                      {imdResult.status || 'SYNCED'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-200">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Profiles Updated:</span>
                      <span className="font-bold text-white text-xs">{imdResult.profiles_updated || imdResult.count || 5} agro-zones</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-slate-400 text-[10px] block">Source:</span>
                      <span className="font-bold text-sky-400 text-xs">{imdResult.source || 'IMD Open Data Portal'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800 col-span-2">
                      <span className="text-slate-400 text-[10px] block">Summary Message:</span>
                      <span className="font-medium text-emerald-300 text-xs">{imdResult.message || 'Synced regional seasonal temperature & relative humidity curves successfully.'}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.5: Deterministic Confidence Score */}
        {activeTab === '8.5_confidence' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>8.5 Deterministic Confidence Score (0–100)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                Calculated — not guessed — from explicit data-quality flags in the schema:
              </p>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 font-mono text-emerald-300 text-[11px] leading-relaxed">
                <pre>{`def compute_confidence_score(food, film, climate_profile) -> int:
    score = 100
    if food.is_regression_estimated: score -= 25  # food data was regression-filled
    if film.source_reference is None: score -= 15 # film permeability has no cited source
    if climate_profile.imd_source_id is None: score -= 10 # profile not tied to real IMD data
    score -= extrapolation_penalty(food, film, climate_profile) # 0-30 distance in feature space
    return max(0, min(100, score))`}</pre>
              </div>
            </div>

            {/* Interactive Calculator */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-xs">Live Formula Evaluation Simulator:</h4>
              <div className="space-y-2">
                <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confIsEstimated}
                    onChange={(e) => setConfIsEstimated(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Food data was regression estimated (-25 points)</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confHasNoSource}
                    onChange={(e) => setConfHasNoSource(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Film permeability data has no cited source (-15 points)</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confHasNoImd}
                    onChange={(e) => setConfHasNoImd(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Climate profile is not tied to official IMD station (-10 points)</span>
                </label>
                <div className="pt-1">
                  <label className="text-slate-300 block mb-1">
                    Feature Space Extrapolation Distance Penalty: -{confExtrapolationDist} points (0 to 30)
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="30"
                    value={confExtrapolationDist}
                    onChange={(e) => setConfExtrapolationDist(parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-slate-400 text-[11px]">Computed Deterministic Confidence:</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400">
                    {calculatedConfidenceScore} / 100
                  </div>
                </div>
                <div>
                  <span
                    className={`px-3 py-1 rounded text-xs font-mono font-bold ${
                      calculatedConfidenceScore >= 70
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {calculatedConfidenceScore >= 70 ? 'HIGH ACCURACY (Interpolation)' : 'TRIGGERS LAB CHECKLIST (<70)'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8.6: Validate with Lab Trial Checklist */}
        {activeTab === '8.6_lab_trial' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <ClipboardList className="w-4 h-4 text-emerald-400" />
                <span>8.6 "Validate with Lab Trial" Checklist</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                When <code className="text-emerald-400">confidence_score &lt; 70</code> OR when any input food/film has <code className="text-amber-300">is_regression_estimated = true</code>, the optimize response automatically populates concrete, checkable items.
              </p>
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2">
                <div className="font-bold text-slate-200">Rule-Generated Concrete Items:</div>
                <div className="space-y-2">
                  <div className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
                    <div className="text-emerald-400 font-bold">1. Film Permeability Verification:</div>
                    <div className="text-white text-xs">"Confirm actual OTR of the purchased film batch with a lab test"</div>
                    <div className="text-slate-400 text-[11px]">Reason: Film OTR in our database is a supplier-datasheet nominal value, not batch-tested.</div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
                    <div className="text-emerald-400 font-bold">2. Respiration Kinetics Calibration:</div>
                    <div className="text-white text-xs">"Verify respiration rate of this specific tomato variety at 12°C"</div>
                    <div className="text-slate-400 text-[11px]">Reason: Respiration data for this food was regression-estimated from a similar commodity, not measured directly.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8.7: MoFPI Government Dashboard */}
        {activeTab === '8.7_mofpi_gov' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <span>8.7 MoFPI Government Dashboard (Anonymized District Observatory)</span>
                </h4>
                <button
                  onClick={handleFetchGovSummary}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center space-x-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Refresh</span>
                </button>
              </div>
              <p className="text-slate-300 leading-relaxed">
                Populated by nightly worker (<code className="text-emerald-400">app/workers/aggregate_gov_stats.py</code>). Anonymization is enforced at the query level: SELECTs only district, state, and category averages — never joins to users, phone numbers, or company names.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div className="bg-slate-900 p-2.5 rounded font-mono text-emerald-300">
                  GET /api/v1/gov/dashboard/summary
                </div>
                <div className="bg-slate-900 p-2.5 rounded font-mono text-sky-300">
                  GET /api/v1/gov/dashboard/district/&#123;district_id&#125;
                </div>
              </div>

              {govSummary && govSummary.districts && (
                <div className="space-y-3 pt-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                    <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Monitored Districts</div>
                      <div className="text-base font-bold text-emerald-400 font-mono">{govSummary.districts_monitored_count || 42}</div>
                    </div>
                    <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Packs Engineered</div>
                      <div className="text-base font-bold text-sky-400 font-mono">{govSummary.total_packs_engineered || '1,68,900'}</div>
                    </div>
                    <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Loss Prevented (MT)</div>
                      <div className="text-base font-bold text-amber-400 font-mono">{govSummary.total_food_waste_prevented_mt || '9,390.5'} MT</div>
                    </div>
                    <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Income Unlocked</div>
                      <div className="text-base font-bold text-purple-400 font-mono">₹{govSummary.total_economic_value_unlocked_crores_inr || '50.9'} Cr</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-slate-300 font-bold">District Aggregates (Strict Zero-PII Query):</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {govSummary.districts.map((d: any, i: number) => (
                        <div
                          key={i}
                          onClick={() => {
                            setSelectedDistrict(d.district_id);
                            handleFetchDistrictDetail(d.district_id);
                          }}
                          className={`p-3 rounded-lg border cursor-pointer transition-all ${
                            selectedDistrict === d.district_id
                              ? 'bg-emerald-950/60 border-emerald-700'
                              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between font-bold text-xs text-white">
                            <span>{d.district_name}, {d.state}</span>
                            <span className="text-emerald-400 font-mono">-{d.spoilage_reduction_pct}% spoilage</span>
                          </div>
                          <div className="text-slate-400 text-[11px] mt-1">
                            Crop: {d.primary_crop} · Loss Prevented: {d.post_harvest_loss_prevented_mt} MT · FPOs: {d.adoption_fpo_count}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.8: Offline Mobile Sync */}
        {activeTab === '8.8_offline_sync' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>8.8 Offline Mobile Sync Protocol (SQLite to PostgreSQL)</span>
              </h4>
              <p className="text-slate-300 leading-relaxed">
                The mobile client keeps a local SQLite cache and syncs when connectivity returns:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-slate-900 p-3.5 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-emerald-400 font-bold">1. POST /api/v1/sync/push</div>
                  <p className="text-slate-300 text-[11px]">
                    Client sends locally-created records with client-generated UUIDs; server upserts them and returns server-assigned IDs mapped to client UUIDs (last-write-wins on <code>updated_at</code>).
                  </p>
                  <button
                    onClick={handleSyncPush}
                    disabled={syncLoading}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Test Sync Push
                  </button>
                  {syncPushData && (
                    <pre className="bg-slate-950 p-2 rounded text-[10px] text-emerald-300 overflow-x-auto mt-1">
                      {JSON.stringify(syncPushData, null, 2)}
                    </pre>
                  )}
                </div>

                <div className="bg-slate-900 p-3.5 rounded-lg border border-slate-800 space-y-2">
                  <div className="text-sky-400 font-bold">2. GET /api/v1/sync/pull?since=...</div>
                  <p className="text-slate-300 text-[11px]">
                    Returns all reference-data changes (foods, films, compliance rules, climate profiles) so the on-device cache used by the offline optimizer stays current.
                  </p>
                  <button
                    onClick={handleSyncPull}
                    disabled={syncLoading}
                    className="px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Test Sync Pull
                  </button>
                  {syncPullData && (
                    <pre className="bg-slate-950 p-2 rounded text-[10px] text-sky-300 overflow-x-auto mt-1">
                      {JSON.stringify(syncPullData, null, 2)}
                    </pre>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8.9: Environment Configuration & Key Diagnostics */}
        {activeTab === '8.9_env' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            {/* Live Key Diagnostics Card */}
            <div className="bg-slate-950 p-4 rounded-xl border border-emerald-900/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white text-sm">Live Key Verification &amp; Persistent Storage Status</span>
                </div>
                <button
                  onClick={fetchKeysDiagnostics}
                  disabled={keysLoading}
                  className="px-2.5 py-1 bg-emerald-800/80 hover:bg-emerald-700 text-white rounded text-[11px] font-mono flex items-center space-x-1.5 transition-colors"
                >
                  <RefreshCw className={`w-3 h-3 ${keysLoading ? 'animate-spin' : ''}`} />
                  <span>{keysLoading ? 'Verifying...' : 'Check All Keys'}</span>
                </button>
              </div>

              {keysDiagnostics ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Upstash Redis Key */}
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white flex items-center space-x-1.5">
                        <Database className="w-3.5 h-3.5 text-red-400" />
                        <span>Upstash Redis (REDIS_URL)</span>
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        keysDiagnostics.keys?.redis?.ping_pong_verified
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-red-950 text-red-300 border border-red-800'
                      }`}>
                        {keysDiagnostics.keys?.redis?.connection_status || 'UNKNOWN'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Host: <code className="text-emerald-400">{keysDiagnostics.keys?.redis?.sanitized_host}</code>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      TLS: <strong>{keysDiagnostics.keys?.redis?.tls_enabled ? 'Active (rediss://)' : 'Off'}</strong> · Latency: <strong className="text-emerald-300">{keysDiagnostics.keys?.redis?.latency_ms}ms</strong> ({keysDiagnostics.keys?.redis?.message})
                    </div>
                  </div>

                  {/* JWT Secret Key */}
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white flex items-center space-x-1.5">
                        <FileCode className="w-3.5 h-3.5 text-amber-400" />
                        <span>JWT Secret (JWT_SECRET_KEY)</span>
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        keysDiagnostics.keys?.jwt?.signature_test_passed
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-red-950 text-red-300 border border-red-800'
                      }`}>
                        {keysDiagnostics.keys?.jwt?.status || 'UNVERIFIED'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Algorithm: <code className="text-amber-400">{keysDiagnostics.keys?.jwt?.algorithm}</code> · Length: <strong>{keysDiagnostics.keys?.jwt?.secret_length_bytes} bytes</strong>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      HMAC-SHA256 Token Sign &amp; Verify: <span className="text-emerald-400">Pass</span>
                    </div>
                  </div>

                  {/* IMD Climate Data API Key */}
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white flex items-center space-x-1.5">
                        <CloudSun className="w-3.5 h-3.5 text-sky-400" />
                        <span>IMD Climate (IMD_DATA_API_KEY)</span>
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {keysDiagnostics.keys?.imd_climate?.status || 'CONFIGURED'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Key: <code className="text-sky-300">{keysDiagnostics.keys?.imd_climate?.key_preview || 'Configured'}</code>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Agro-Climate Profiles: <strong>{keysDiagnostics.keys?.imd_climate?.profiles_active || 5} Verified Mandi Zones</strong>
                    </div>
                  </div>

                  {/* Database & Persistent Storage */}
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white flex items-center space-x-1.5">
                        <Database className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Persistent Storage (PostgreSQL &amp; JSON)</span>
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        PERSISTENT DISK + REDIS
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Postgres Target: <code className="text-slate-400">{keysDiagnostics.keys?.database?.target_url}</code>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Tables: <code>products</code>, <code>scan_reports</code>, <code>packsense_db</code> backed by <code>/data/</code> &amp; Upstash cache
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-slate-400 text-xs italic py-2">Loading key diagnostics...</div>
              )}
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                  <FileCode className="w-4 h-4 text-emerald-400" />
                  <span>8.9 Credentials Template — .env</span>
                </h4>
                <button
                  onClick={copyEnv}
                  className="px-2.5 py-1 bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-700/80 rounded text-[11px] font-mono flex items-center space-x-1 transition-colors"
                >
                  {copiedEnv ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedEnv ? 'Copied!' : 'Copy .env'}</span>
                </button>
              </div>

              <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
                <pre>{envContent}</pre>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-slate-300 text-[11px] space-y-1">
                <div className="text-emerald-400 font-bold">Important Git &amp; Config Policies:</div>
                <ul className="list-disc list-inside space-y-1 text-slate-400">
                  <li><code>.env</code> is added to <code>.gitignore</code> and never committed to git.</li>
                  <li><code>.env.example</code> is committed to the repository with keys scaffolded.</li>
                  <li>All scanned products and full multi-section engineering reports are persisted automatically to disk (<code>/data/</code>) and synced to Upstash Redis.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8.10: Pack Label Scan & OCR Film Matching */}
        {activeTab === '8.10_label_scan' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                    <Scan className="w-4 h-4 text-emerald-400" />
                    <span>8.10 Pack Label Scan &amp; OCR Film Matching (POST /api/v1/pack-label/scan)</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Extracts polymer layers, thicknesses, and regulatory symbols from OCR label text and matches them against known films.
                  </p>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Additive Endpoint
                </span>
              </div>

              {/* Sample Buttons */}
              <div className="space-y-1.5">
                <label className="text-slate-400 text-[11px] font-semibold">Sample Label OCR Presets:</label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: 'BOPP/Met-BOPP Snack Web', text: 'BOPP 20 micron / Met-BOPP 18 micron / CPP 30 micron High Barrier Snack Web FSSAI Approved' },
                    { label: 'Mono-Material PE (#4 RIC)', text: 'Mono-Material PE Recyclable LDPE 40 um #4 RIC CEFLEX Class A' },
                    { label: 'Bio-PBS / PBAT Compostable', text: 'Bio-PBS 25 micron / PBAT 30 micron Compostable IS 17088' },
                    { label: 'CPP 30µm Cast Film', text: 'Cast Polypropylene CPP 30 micron' }
                  ].map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => setLabelOcrInput(s.text)}
                      className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 font-mono text-[10px]"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* OCR Input & Language */}
              <div className="space-y-2">
                <label className="text-slate-400 text-[11px] font-semibold">OCR-Extracted Label Text:</label>
                <textarea
                  rows={3}
                  value={labelOcrInput}
                  onChange={(e) => setLabelOcrInput(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-600"
                  placeholder="Paste OCR text from packaging label..."
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <span className="text-slate-400 text-[11px] font-semibold">Explanation Language:</span>
                  <div className="flex space-x-1 font-mono text-[11px]">
                    {[
                      { code: 'en', label: 'English' },
                      { code: 'hi', label: 'हिन्दी (Hindi)' },
                      { code: 'mr', label: 'मराठी (Marathi)' },
                      { code: 'ta', label: 'தமிழ் (Tamil)' }
                    ].map((l) => (
                      <button
                        key={l.code}
                        onClick={() => setLabelLang(l.code)}
                        className={`px-2 py-1 rounded border transition-colors ${
                          labelLang === l.code
                            ? 'bg-emerald-900/70 border-emerald-600 text-emerald-200 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {l.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => handleScanLabel()}
                  disabled={labelLoading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg font-mono text-xs font-bold flex items-center space-x-1.5 transition-colors shadow"
                >
                  <Scan className="w-3.5 h-3.5" />
                  <span>{labelLoading ? 'Scanning & Matching...' : 'Scan & Match Film'}</span>
                </button>
              </div>

              {/* Results View */}
              {labelScanResult && (
                <div className="space-y-3 pt-2 border-t border-slate-800 animate-in fade-in duration-200">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[10px]">MATCHED FILM</div>
                      <div className="text-emerald-400 font-bold text-sm mt-0.5">
                        {labelScanResult.matched_film?.name || 'Unknown'}
                      </div>
                      <div className="text-slate-400 text-[10px] mt-0.5">
                        {labelScanResult.matched_film?.material_type_detail || labelScanResult.matched_film?.material_type}
                      </div>
                    </div>

                    <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[10px]">CONFIDENCE SCORE</div>
                      <div className="text-sky-400 font-bold text-sm mt-0.5">
                        {Math.round((labelScanResult.confidence_score || 0) * 100)}%
                      </div>
                      <div className="text-slate-400 text-[10px] mt-0.5">
                        Multi-attribute deterministic score
                      </div>
                    </div>

                    <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[10px]">BARRIER PROPERTIES</div>
                      <div className="text-amber-400 font-mono text-xs mt-0.5">
                        OTR: {labelScanResult.matched_film?.otr_cc_m2_day} cc/m²·day
                      </div>
                      <div className="text-amber-400 font-mono text-xs">
                        WVTR: {labelScanResult.matched_film?.wvtr_g_m2_day} g/m²·day
                      </div>
                    </div>
                  </div>

                  {/* Multilingual Explanation Box */}
                  <div className="p-3 bg-slate-900 rounded-lg border border-emerald-800/60 text-slate-200 leading-relaxed font-sans">
                    <div className="text-[10px] font-mono text-emerald-400 font-bold uppercase mb-1">
                      Localized Explanation ({labelScanResult.language?.toUpperCase() || 'EN'}):
                    </div>
                    <div>{labelScanResult.explanation}</div>
                  </div>

                  {/* Extracted Entities & Regulatory Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="text-slate-400 font-bold text-[10px]">EXTRACTED OCR ENTITIES</div>
                      <div className="text-slate-300">
                        Polymers: <span className="text-sky-300">{labelScanResult.extracted_entities?.detected_polymers?.join(', ') || 'None'}</span>
                      </div>
                      <div className="text-slate-300">
                        Thickness: <span className="text-sky-300">{labelScanResult.extracted_entities?.thickness_um ? `${labelScanResult.extracted_entities.thickness_um} µm` : 'Not specified'}</span>
                      </div>
                      <div className="text-slate-300">
                        Resin Code: <span className="text-sky-300">{labelScanResult.extracted_entities?.ric_name || 'N/A'}</span>
                      </div>
                    </div>

                    <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="text-slate-400 font-bold text-[10px]">REGULATORY &amp; SUSTAINABILITY</div>
                      <div className="text-slate-300">
                        FSSAI: <span className="text-emerald-400">{labelScanResult.regulatory_compliance?.fssai_status}</span>
                      </div>
                      <div className="text-slate-300">
                        PWM 2022: <span className="text-emerald-400">{labelScanResult.regulatory_compliance?.pwm_rules_status}</span>
                      </div>
                      <div className="text-slate-300">
                        Recyclability: <span className="text-emerald-400">{labelScanResult.matched_film?.recyclability_score}/100</span>
                      </div>
                    </div>
                  </div>

                  {/* Sustainable alternatives */}
                  {labelScanResult.sustainable_alternatives && labelScanResult.sustainable_alternatives.length > 0 && (
                    <div className="bg-emerald-950/40 p-3 rounded-lg border border-emerald-800/40 space-y-1.5">
                      <div className="text-emerald-400 font-bold text-[10px] uppercase font-mono">
                        Eco-Friendly Alternatives for PWM EPR Optimization:
                      </div>
                      {labelScanResult.sustainable_alternatives.map((alt: any, aIdx: number) => (
                        <div key={aIdx} className="text-[11px] text-slate-300 flex items-start space-x-1.5">
                          <span className="text-emerald-400 font-bold">•</span>
                          <div>
                            <span className="font-semibold text-white">{alt.alternative_name}:</span>{' '}
                            <span className="text-slate-400">{alt.benefit}</span>{' '}
                            <span className="text-emerald-400 font-mono">(-{alt.reduction_co2e_pct}% CO2e)</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 8.11: Multilingual Localization Gateway */}
        {activeTab === '8.11_multilingual' && (
          <div className="flex-1 overflow-y-auto space-y-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm flex items-center space-x-2">
                    <Languages className="w-4 h-4 text-emerald-400" />
                    <span>8.11 Multilingual Localization Gateway (GET /api/v1/i18n/*)</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Provides explanations, checklists, diagnoses, and reference texts in Hindi (hi), Marathi (mr), Tamil (ta), and English (en).
                  </p>
                </div>
                <div className="flex space-x-1 font-mono text-[11px]">
                  {[
                    { code: 'hi', label: 'हिन्दी' },
                    { code: 'mr', label: 'मराठी' },
                    { code: 'ta', label: 'தமிழ்' },
                    { code: 'en', label: 'English' }
                  ].map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setI18nTargetLang(l.code);
                        if (i18nReferenceResult) handleFetchReferenceText(undefined, l.code);
                        if (i18nSpoilageResult) handleFetchLocalizedSpoilage(l.code);
                      }}
                      className={`px-2.5 py-1 rounded border transition-colors ${
                        i18nTargetLang === l.code
                          ? 'bg-emerald-900/70 border-emerald-600 text-emerald-200 font-bold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {l.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 1. Domain Terminology Translation */}
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-white text-xs">1. Packaging Domain Terminology Translation (POST /api/v1/i18n/translate)</div>
                  <span className="text-[10px] font-mono text-slate-400">Pure Deterministic Dictionary (Zero LLM)</span>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Oxygen Transmission Rate (OTR)',
                    'Water Vapor Transmission Rate (WVTR)',
                    'Overall Migration Limit (OML)',
                    'Anaerobic Microbial Fermentation / Pouch Over-Pressurization',
                    'Laser Micro-Perforated BOPP 30µm (60µm hole pitch 20mm)',
                    'FSSAI Packaging Regulations 2018'
                  ].map((phrase, idx) => (
                    <button
                      key={idx}
                      onClick={() => setI18nPhrase(phrase)}
                      className="px-2 py-0.5 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 text-[10px] font-mono"
                    >
                      {phrase.slice(0, 30)}...
                    </button>
                  ))}
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={i18nPhrase}
                    onChange={(e) => setI18nPhrase(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-600"
                    placeholder="Enter packaging phrase to translate..."
                  />
                  <button
                    onClick={handleTranslatePhrase}
                    disabled={i18nLoading}
                    className="px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Translate
                  </button>
                </div>

                {i18nTranslated && (
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-xs font-mono space-y-1">
                    <div className="text-slate-400 text-[10px]">ORIGINAL: <span className="text-slate-200">{i18nTranslated.original_text}</span></div>
                    <div className="text-emerald-400 font-bold text-sm">
                      {i18nTranslated.translated_text}
                    </div>
                  </div>
                )}
              </div>

              {/* 2. Multilingual Regulatory Reference Guidelines */}
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-white text-xs">2. Multilingual Reference Text (GET /api/v1/i18n/reference-text)</div>
                  <div className="flex space-x-1 text-[10px] font-mono">
                    <button
                      onClick={() => { setI18nCategory('fssai_standards'); handleFetchReferenceText('fssai_standards'); }}
                      className={`px-2 py-0.5 rounded border ${i18nCategory === 'fssai_standards' ? 'bg-emerald-950 border-emerald-700 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
                    >
                      FSSAI Standards
                    </button>
                    <button
                      onClick={() => { setI18nCategory('pwm_recycling'); handleFetchReferenceText('pwm_recycling'); }}
                      className={`px-2 py-0.5 rounded border ${i18nCategory === 'pwm_recycling' ? 'bg-emerald-950 border-emerald-700 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
                    >
                      PWM Recycling
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => handleFetchReferenceText()}
                  disabled={i18nLoading}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded font-mono text-xs border border-slate-700"
                >
                  Load Reference Text in {i18nTargetLang.toUpperCase()}
                </button>

                {i18nReferenceResult && i18nReferenceResult.content && (
                  <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                    <div className="text-emerald-400 font-bold text-xs">
                      {i18nReferenceResult.content.title}
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                      {i18nReferenceResult.content.rules?.map((r: string, idx: number) => (
                        <li key={idx} className="leading-relaxed">{r}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* 3. Multilingual Spoilage Autopsy Diagnosis */}
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-white text-xs">3. Localized Spoilage Diagnosis (POST /api/v1/spoilage/diagnose?lang={i18nTargetLang})</div>
                  <button
                    onClick={() => handleFetchLocalizedSpoilage()}
                    disabled={i18nLoading}
                    className="px-3 py-1 bg-amber-700 hover:bg-amber-600 text-white rounded font-mono text-xs font-bold"
                  >
                    Test Localized Autopsy
                  </button>
                </div>

                {i18nSpoilageResult && (
                  <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                    <div className="text-amber-400 font-bold text-xs">
                      Primary Root Cause: {i18nSpoilageResult.root_cause_localized || i18nSpoilageResult.primary_root_cause}
                    </div>
                    {i18nSpoilageResult.mechanisms_localized && (
                      <div className="text-slate-300 text-[11px]">
                        <span className="text-slate-400">Mechanisms: </span>
                        {i18nSpoilageResult.mechanisms_localized.join(' · ')}
                      </div>
                    )}
                    {i18nSpoilageResult.corrective_actions_localized && (
                      <div className="text-slate-300 text-[11px]">
                        <span className="text-slate-400">Corrective Film: </span>
                        {i18nSpoilageResult.corrective_actions_localized.film_structure_switch || 'Anti-fog breathable film'}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* 4. Template String Rendering (Part 2 Section 2.3) */}
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-white text-xs">4. Template String Rendering (POST /api/v1/i18n/render-template)</div>
                  <span className="text-[10px] font-mono text-emerald-400">Section 2.3 template_text.format(**variables)</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Fixed template strings from <code>seed/i18n_templates_seed.csv</code> formatted deterministically without runtime LLM calls.
                </p>

                <div className="flex flex-wrap gap-1.5">
                  {[
                    { key: 'shap_explanation.high_respiration', label: 'SHAP High Respiration' },
                    { key: 'checklist.confirm_otr', label: 'Checklist OTR' },
                    { key: 'spoilage.diagnosis.anaerobic', label: 'Spoilage Diagnosis' },
                    { key: 'active_pack.ethylene_absorber', label: 'Ethylene Absorber' },
                    { key: 'rural_mode.zero_energy_chamber', label: 'Rural ZECC' },
                    { key: 'compliance.fssai_migration', label: 'FSSAI Migration' },
                    { key: 'gov_dashboard.mismatch_gap', label: 'Gov Mismatch Gap' },
                    { key: 'label_scan.fallback_message', label: 'Label Scan Fallback' }
                  ].map((tpl) => (
                    <button
                      key={tpl.key}
                      onClick={() => {
                        setI18nTemplateKey(tpl.key);
                        handleRenderTemplate(tpl.key, i18nTargetLang);
                      }}
                      className={`px-2 py-0.5 rounded border text-[10px] font-mono transition-colors ${
                        i18nTemplateKey === tpl.key
                          ? 'bg-emerald-950 border-emerald-600 text-emerald-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {tpl.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={i18nTemplateKey}
                    onChange={(e) => setI18nTemplateKey(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-600"
                    placeholder="Enter template_key..."
                  />
                  <button
                    onClick={() => handleRenderTemplate()}
                    disabled={i18nLoading}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-mono text-xs font-bold"
                  >
                    Render in {i18nTargetLang.toUpperCase()}
                  </button>
                </div>

                {i18nTemplateRendered && (
                  <div className="bg-slate-950 p-3 rounded border border-emerald-800/80 text-xs font-sans space-y-1">
                    <div className="text-[10px] font-mono text-slate-400">
                      KEY: <span className="text-sky-300">{i18nTemplateKey}</span> · LANG: <span className="text-emerald-400 uppercase">{i18nTargetLang}</span>
                    </div>
                    <div className="text-white font-medium text-xs leading-relaxed">
                      {i18nTemplateRendered}
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800 shrink-0">
          <div className="text-[11px] text-slate-400 font-mono hidden sm:block">
            Section 8 Extended Capabilities · PostGIS ST_DWithin · Bhashini NLTM · Q10 Kinetics · Zero LLM Path
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
