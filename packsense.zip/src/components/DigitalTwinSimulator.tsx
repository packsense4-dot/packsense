import React, { useState, useMemo } from 'react';
import {
  Layers,
  Thermometer,
  Droplets,
  Wind,
  Box,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Leaf,
  Recycle,
  Sparkles,
  Info,
  Database
} from 'lucide-react';
import { PackagingMaterial, MATERIALS_DATABASE } from '../engine/materialsDb.ts';
import { FoodProduct, FOODS_DATABASE } from '../engine/foodsDb.ts';
import {
  LaminateLayerInput,
  LaminateBarrierResult,
  PackageGeometry,
  SimulationConditions,
  MapGasConfig,
  ShelfLifeSimulationResult,
  calculateLaminateBarrier,
  simulateShelfLife,
  calculatePackageGeometry
} from '../engine/physics.ts';

interface DigitalTwinSimulatorProps {
  currentFoodId: string;
  setCurrentFoodId: (id: string) => void;
  layers: LaminateLayerInput[];
  setLayers: React.Dispatch<React.SetStateAction<LaminateLayerInput[]>>;
  geometry: PackageGeometry;
  setGeometry: React.Dispatch<React.SetStateAction<PackageGeometry>>;
  conditions: SimulationConditions;
  setConditions: React.Dispatch<React.SetStateAction<SimulationConditions>>;
  mapGas: MapGasConfig;
  setMapGas: React.Dispatch<React.SetStateAction<MapGasConfig>>;
  onOpenSpecSheet: () => void;
  onSaveSimulation?: () => void;
}

export const DigitalTwinSimulator: React.FC<DigitalTwinSimulatorProps> = ({
  currentFoodId,
  setCurrentFoodId,
  layers,
  setLayers,
  geometry,
  setGeometry,
  conditions,
  setConditions,
  mapGas,
  setMapGas,
  onOpenSpecSheet,
  onSaveSimulation
}) => {
  const currentFood = useMemo(() => {
    return FOODS_DATABASE.find(f => f.id === currentFoodId) || FOODS_DATABASE[0];
  }, [currentFoodId]);

  // Active chart display channels
  const [showO2, setShowO2] = useState(true);
  const [showCO2, setShowCO2] = useState(true);
  const [showMoisture, setShowMoisture] = useState(true);
  const [showMicrobial, setShowMicrobial] = useState(true);
  const [showQuality, setShowQuality] = useState(true);
  const [hoveredDayIdx, setHoveredDayIdx] = useState<number | null>(null);

  // Real-time barrier calculation
  const barrierResult: LaminateBarrierResult = useMemo(() => {
    try {
      return calculateLaminateBarrier(layers, conditions.storage_temp_c, conditions.ambient_rh_percent);
    } catch {
      return calculateLaminateBarrier([{ material_id: 'lldpe', thickness_um: 50 }], conditions.storage_temp_c, conditions.ambient_rh_percent);
    }
  }, [layers, conditions.storage_temp_c, conditions.ambient_rh_percent]);

  // Real-time package geometry calculation
  const geomCalc = useMemo(() => {
    return calculatePackageGeometry(geometry, currentFood.density_kg_m3);
  }, [geometry, currentFood.density_kg_m3]);

  // Real-time shelf-life simulation
  const simulationResult: ShelfLifeSimulationResult = useMemo(() => {
    return simulateShelfLife(
      currentFood,
      barrierResult,
      geometry,
      conditions,
      mapGas,
      Math.max(180, Math.round(currentFood.target_shelf_life_days * 1.5))
    );
  }, [currentFood, barrierResult, geometry, conditions, mapGas]);

  // Layer manipulation handlers
  const handleAddLayer = (materialId: string) => {
    const mat = MATERIALS_DATABASE.find(m => m.id === materialId) || MATERIALS_DATABASE[0];
    const defaultThickness = Math.round((mat.standard_thickness_range[0] + mat.standard_thickness_range[1]) / 2);
    setLayers(prev => [...prev, { material_id: mat.id, thickness_um: defaultThickness }]);
  };

  const handleUpdateThickness = (index: number, thickness: number) => {
    setLayers(prev => {
      const next = [...prev];
      next[index] = { ...next[index], thickness_um: Math.max(1, thickness) };
      return next;
    });
  };

  const handleRemoveLayer = (index: number) => {
    if (layers.length <= 1) return;
    setLayers(prev => prev.filter((_, i) => i !== index));
  };

  const handleMoveLayer = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= layers.length) return;
    setLayers(prev => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[targetIdx];
      next[targetIdx] = temp;
      return next;
    });
  };

  const handleApplyPreset = (presetType: 'mono_pe' | 'mono_pp' | 'high_barrier_foil' | 'compostable') => {
    if (presetType === 'mono_pe') {
      setLayers([
        { material_id: 'lldpe', thickness_um: 25 },
        { material_id: 'evoh_32', thickness_um: 3 },
        { material_id: 'lldpe', thickness_um: 40 }
      ]);
    } else if (presetType === 'mono_pp') {
      setLayers([
        { material_id: 'bopp', thickness_um: 20 },
        { material_id: 'met_bopp', thickness_um: 20 },
        { material_id: 'cpp', thickness_um: 30 }
      ]);
    } else if (presetType === 'high_barrier_foil') {
      setLayers([
        { material_id: 'bopet', thickness_um: 12 },
        { material_id: 'alu_foil', thickness_um: 7 },
        { material_id: 'lldpe', thickness_um: 50 }
      ]);
    } else if (presetType === 'compostable') {
      setLayers([
        { material_id: 'pla', thickness_um: 25 },
        { material_id: 'bio_pbs', thickness_um: 35 }
      ]);
    }
  };

  const handleApplyFoodMap = () => {
    setMapGas({
      initial_o2_percent: currentFood.recommended_map.o2_percent,
      initial_co2_percent: currentFood.recommended_map.co2_percent,
      initial_n2_percent: currentFood.recommended_map.n2_percent,
      gas_to_product_volume_ratio: currentFood.recommended_map.gas_to_product_ratio
    });
  };

  const handleApplyAirMap = () => {
    setMapGas({
      initial_o2_percent: 20.9,
      initial_co2_percent: 0.04,
      initial_n2_percent: 79.06,
      gas_to_product_volume_ratio: 1.5
    });
  };

  // Trajectory Chart Dimensions & Scale
  const trajectory = simulationResult.daily_trajectory;
  const maxDay = trajectory.length > 0 ? trajectory[trajectory.length - 1].day : 100;
  const chartWidth = 600;
  const chartHeight = 220;
  const padding = { top: 20, right: 30, bottom: 30, left: 45 };
  const plotWidth = chartWidth - padding.left - padding.right;
  const plotHeight = chartHeight - padding.top - padding.bottom;

  const scaleX = (day: number) => padding.left + (day / Math.max(1, maxDay)) * plotWidth;
  // Normalized 0-100% scale for Y axis
  const scaleY = (pct: number) => padding.top + plotHeight - (Math.max(0, Math.min(100, pct)) / 100) * plotHeight;

  // Path generator for trajectory data
  const generatePath = (getValue: (d: typeof trajectory[0]) => number, yMax: number = 100) => {
    if (!trajectory.length) return '';
    return trajectory.map((d, i) => {
      const x = scaleX(d.day);
      const normalizedY = (getValue(d) / yMax) * 100;
      const y = scaleY(normalizedY);
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  };

  const pathO2 = generatePath(d => d.headspace_o2_percent, 100);
  const pathCO2 = generatePath(d => d.headspace_co2_percent, 100);
  const pathQuality = generatePath(d => d.quality_retention_percent, 100);
  // Moisture normalized to 0-100% scale relative to max or baseline
  const maxMoistureRef = Math.max(10, (currentFood.crit_moisture_max_g100g || 5) * 1.3);
  const pathMoisture = generatePath(d => (d.product_moisture_g100g / maxMoistureRef) * 100, 100);
  // Microbial normalized 0-10 log CFU
  const pathMicrobial = generatePath(d => (d.microbial_log_cfu_g / 10) * 100, 100);

  const failureX = scaleX(simulationResult.predicted_shelf_life_days);
  const meetsShelfLife = simulationResult.predicted_shelf_life_days >= currentFood.target_shelf_life_days;

  const currentHoverPoint = hoveredDayIdx !== null && trajectory[hoveredDayIdx]
    ? trajectory[hoveredDayIdx]
    : trajectory[Math.min(trajectory.length - 1, simulationResult.predicted_shelf_life_days)];

  return (
    <div className="space-y-6">
      {/* Top Banner: Food Selection & Critical Specs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Select Food Product Matrix
            </label>
            <div className="flex flex-wrap items-center gap-3">
              <select
                value={currentFoodId}
                onChange={(e) => setCurrentFoodId(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-white font-medium text-sm rounded-lg px-3.5 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {FOODS_DATABASE.map(f => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.category.replace('_', ' ').toUpperCase()})
                  </option>
                ))}
              </select>

              <div className="flex flex-wrap gap-2 text-xs">
                <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  Target: <strong className="text-emerald-400">{currentFood.target_shelf_life_days} Days</strong>
                </span>
                <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  Initial aw: <strong>{currentFood.initial_aw.toFixed(2)}</strong>
                </span>
                <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  Std Temp: <strong>{currentFood.storage_temp_c}°C</strong>
                </span>
                <span className="px-2.5 py-1 rounded bg-amber-950/70 border border-amber-800/60 text-amber-300">
                  Primary Failure: <strong>{currentFood.primary_degradation_mechanism.replace('_', ' ')}</strong>
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 mt-2 max-w-3xl">
              {currentFood.description}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {onSaveSimulation && (
              <button
                onClick={onSaveSimulation}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 hover:border-emerald-500/50 text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
                title="Persist this digital twin simulation run and predicted shelf life into the backend database"
              >
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                <span>Save to Database</span>
              </button>
            )}
            <button
              onClick={onOpenSpecSheet}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
            >
              <span>Export Technical Spec Sheet</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Parameters on Left, Simulation on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Physical Configuration (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Multilayer Film Structure Builder */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-slate-100 font-semibold text-sm">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>Multilayer Barrier Film Architecture</span>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {barrierResult.total_thickness_um} µm ({barrierResult.total_mass_gsm} gsm)
              </span>
            </div>

            {/* Quick Laminate Preset Buttons */}
            <div className="flex flex-wrap gap-1.5 text-xs">
              <span className="text-slate-400 py-0.5 text-[11px]">Presets:</span>
              <button
                onClick={() => handleApplyPreset('mono_pe')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-900/60 transition-colors"
                title="Mono-PE High Barrier Coex (CEFLEX Class A Recyclable)"
              >
                Mono-PE Barrier
              </button>
              <button
                onClick={() => handleApplyPreset('mono_pp')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 border border-sky-900/60 transition-colors"
                title="Mono-PP Metallized Snack Web"
              >
                Mono-PP Snack
              </button>
              <button
                onClick={() => handleApplyPreset('high_barrier_foil')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-900/60 transition-colors"
                title="PET / Alu-Foil / PE Retort Vacuum Web"
              >
                Foil Triplex
              </button>
              <button
                onClick={() => handleApplyPreset('compostable')}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-900/60 transition-colors"
                title="PLA / Bio-PBS Compostable Film"
              >
                Bio Compostable
              </button>
            </div>

            {/* Visual Film Cross-Section Bar */}
            <div className="w-full h-4 rounded-md overflow-hidden flex border border-slate-700/60 shadow-inner">
              {barrierResult.layers.map((l, i) => {
                const colorMap: Record<string, string> = {
                  ldpe: 'bg-emerald-600',
                  lldpe: 'bg-emerald-500',
                  hdpe: 'bg-emerald-700',
                  bopp: 'bg-sky-600',
                  cpp: 'bg-sky-500',
                  bopet: 'bg-indigo-600',
                  evoh_32: 'bg-rose-500',
                  bopa: 'bg-violet-600',
                  met_pet: 'bg-slate-400',
                  met_bopp: 'bg-slate-400',
                  alu_foil: 'bg-slate-200',
                  pla: 'bg-lime-600',
                  bio_pbs: 'bg-lime-500',
                  pvdc_coating: 'bg-orange-500',
                  barrier_paper: 'bg-amber-700'
                };
                const bg = colorMap[l.material.id] || 'bg-slate-500';
                return (
                  <div
                    key={i}
                    style={{ width: `${Math.max(4, l.mass_fraction_percent)}%` }}
                    className={`${bg} h-full transition-all relative group cursor-pointer`}
                    title={`${l.material.code} (${l.thickness_um} µm, ${l.mass_fraction_percent}%)`}
                  />
                );
              })}
            </div>

            {/* Layer List with Controls */}
            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {layers.map((layer, idx) => {
                const mat = MATERIALS_DATABASE.find(m => m.id === layer.material_id) || MATERIALS_DATABASE[0];
                return (
                  <div
                    key={idx}
                    className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs gap-2"
                  >
                    <div className="flex items-center space-x-2 flex-1 min-w-0">
                      <div className="flex flex-col space-y-0.5">
                        <button
                          onClick={() => handleMoveLayer(idx, 'up')}
                          disabled={idx === 0}
                          className="text-slate-500 hover:text-slate-300 disabled:opacity-20 p-0.5"
                        >
                          <ArrowUp className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleMoveLayer(idx, 'down')}
                          disabled={idx === layers.length - 1}
                          className="text-slate-500 hover:text-slate-300 disabled:opacity-20 p-0.5"
                        >
                          <ArrowDown className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center space-x-1.5">
                          <span className="font-semibold text-white truncate">{mat.code}</span>
                          <span className="text-[11px] text-slate-400 truncate">({mat.name})</span>
                        </div>
                        <div className="text-[10px] text-slate-500 truncate font-mono">
                          {idx === 0 ? 'Outer Web' : idx === layers.length - 1 ? 'Food Contact Sealant' : 'Barrier Core'}
                        </div>
                      </div>
                    </div>

                    {/* Thickness Slider & Input */}
                    <div className="flex items-center space-x-2">
                      <input
                        type="range"
                        min="2"
                        max="120"
                        value={layer.thickness_um}
                        onChange={(e) => handleUpdateThickness(idx, Number(e.target.value))}
                        className="w-20 accent-emerald-500"
                      />
                      <div className="flex items-center">
                        <input
                          type="number"
                          min="1"
                          max="250"
                          value={layer.thickness_um}
                          onChange={(e) => handleUpdateThickness(idx, Number(e.target.value))}
                          className="w-12 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right font-mono text-white text-xs"
                        />
                        <span className="ml-1 text-slate-400 text-[10px]">µm</span>
                      </div>

                      <button
                        onClick={() => handleRemoveLayer(idx)}
                        disabled={layers.length <= 1}
                        className="text-slate-500 hover:text-rose-400 disabled:opacity-20 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Add Layer Selector */}
            <div className="flex items-center space-x-2 pt-1 border-t border-slate-800">
              <select
                id="add-material-select"
                className="flex-1 bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
                defaultValue=""
                onChange={(e) => {
                  if (e.target.value) {
                    handleAddLayer(e.target.value);
                    e.target.value = '';
                  }
                }}
              >
                <option value="" disabled>+ Add Material Layer to Laminate...</option>
                {MATERIALS_DATABASE.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.code} - {m.name} ({m.category})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Storage Conditions & Ambient Physics */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center space-x-2 text-slate-100 font-semibold text-sm">
              <Thermometer className="w-4 h-4 text-rose-400" />
              <span>Storage Environment & Driving Gradients</span>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Storage Temperature:</span>
                  <span className="font-mono font-semibold text-white">{conditions.storage_temp_c} °C</span>
                </div>
                <input
                  type="range"
                  min="-18"
                  max="45"
                  step="1"
                  value={conditions.storage_temp_c}
                  onChange={(e) => setConditions(prev => ({ ...prev, storage_temp_c: Number(e.target.value) }))}
                  className="w-full accent-rose-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                  <span>-18°C (Frozen)</span>
                  <span>2°C (Chilled)</span>
                  <span>21°C (Ambient)</span>
                  <span>38°C (Tropical)</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Ambient Relative Humidity (RH):</span>
                  <span className="font-mono font-semibold text-white">{conditions.ambient_rh_percent} %</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="95"
                  step="5"
                  value={conditions.ambient_rh_percent}
                  onChange={(e) => setConditions(prev => ({ ...prev, ambient_rh_percent: Number(e.target.value) }))}
                  className="w-full accent-blue-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                  <span>20% (Dry Arid)</span>
                  <span>50% (Standard ASTM)</span>
                  <span>85% (Chilled Display)</span>
                  <span>95% (Tropical)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Package Geometry & Net Weight */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center space-x-2 text-slate-100 font-semibold text-sm">
              <Box className="w-4 h-4 text-amber-400" />
              <span>Package Geometry & Net Weight</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Package Format</label>
                <select
                  value={geometry.package_type}
                  onChange={(e) => setGeometry(prev => ({ ...prev, package_type: e.target.value as any }))}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded px-2 py-1.5 focus:outline-none"
                >
                  <option value="pillow_pouch">Pillow Pouch</option>
                  <option value="stand_up_pouch">Stand-Up Pouch (Doypack)</option>
                  <option value="thermoformed_tray">Thermoformed MAP Tray</option>
                  <option value="flow_wrap">Horizontal Flow Wrap</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Food Net Weight</label>
                <div className="flex items-center">
                  <input
                    type="number"
                    min="10"
                    max="5000"
                    value={geometry.net_weight_g}
                    onChange={(e) => setGeometry(prev => ({ ...prev, net_weight_g: Number(e.target.value) }))}
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded px-2 py-1.5 font-mono text-right"
                  />
                  <span className="ml-1 text-slate-400">g</span>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Length (mm)</label>
                <input
                  type="number"
                  min="50"
                  max="600"
                  value={geometry.length_mm}
                  onChange={(e) => setGeometry(prev => ({ ...prev, length_mm: Number(e.target.value) }))}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded px-2 py-1.5 font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Width (mm)</label>
                <input
                  type="number"
                  min="40"
                  max="400"
                  value={geometry.width_mm}
                  onChange={(e) => setGeometry(prev => ({ ...prev, width_mm: Number(e.target.value) }))}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded px-2 py-1.5 font-mono"
                />
              </div>
            </div>

            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[11px]">Surface Area:</span>
                <span className="text-slate-200 font-semibold">{geomCalc.surface_area_m2} m²</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Headspace Volume:</span>
                <span className="text-slate-200 font-semibold">{geomCalc.headspace_volume_cm3} cm³</span>
              </div>
            </div>
          </div>

          {/* MAP Gas Mix Studio */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-slate-100 font-semibold text-sm">
                <Wind className="w-4 h-4 text-sky-400" />
                <span>Modified Atmosphere Packaging (MAP) Gas Mix</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="bg-slate-950 border border-slate-800 rounded p-2 text-center">
                <span className="text-blue-400 font-semibold block text-[11px]">O₂ (Oxygen)</span>
                <div className="font-mono text-base font-bold text-white mt-1">
                  {mapGas.initial_o2_percent.toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-950 border border-slate-800 rounded p-2 text-center">
                <span className="text-purple-400 font-semibold block text-[11px]">CO₂ (Inhibitor)</span>
                <div className="font-mono text-base font-bold text-white mt-1">
                  {mapGas.initial_co2_percent.toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-950 border border-slate-800 rounded p-2 text-center">
                <span className="text-slate-400 font-semibold block text-[11px]">N₂ (Inert Filler)</span>
                <div className="font-mono text-base font-bold text-white mt-1">
                  {Math.max(0, 100 - mapGas.initial_o2_percent - mapGas.initial_co2_percent).toFixed(1)}%
                </div>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400">O₂ Concentration:</span>
                  <span className="font-mono text-white">{mapGas.initial_o2_percent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="90"
                  step="0.5"
                  value={mapGas.initial_o2_percent}
                  onChange={(e) => {
                    const newO2 = Number(e.target.value);
                    const rem = Math.max(0, 100 - newO2);
                    const newCO2 = Math.min(mapGas.initial_co2_percent, rem);
                    setMapGas(prev => ({
                      ...prev,
                      initial_o2_percent: newO2,
                      initial_co2_percent: newCO2,
                      initial_n2_percent: rem - newCO2
                    }));
                  }}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400">CO₂ Concentration:</span>
                  <span className="font-mono text-white">{mapGas.initial_co2_percent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="80"
                  step="1"
                  value={mapGas.initial_co2_percent}
                  onChange={(e) => {
                    const newCO2 = Number(e.target.value);
                    const rem = Math.max(0, 100 - newCO2);
                    const newO2 = Math.min(mapGas.initial_o2_percent, rem);
                    setMapGas(prev => ({
                      ...prev,
                      initial_co2_percent: newCO2,
                      initial_o2_percent: newO2,
                      initial_n2_percent: rem - newO2
                    }));
                  }}
                  className="w-full accent-purple-500"
                />
              </div>
            </div>

            <div className="flex space-x-2 pt-1 border-t border-slate-800 text-xs">
              <button
                onClick={handleApplyFoodMap}
                className="flex-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded font-medium border border-slate-700 transition-colors"
              >
                Apply Food Recommended MAP
              </button>
              <button
                onClick={handleApplyAirMap}
                className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-medium border border-slate-700 transition-colors"
              >
                Standard Air
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Real-Time Deterministic Simulation Outputs (7 cols) */}
        <div className="lg:col-span-7 space-y-6">

          {/* Top Outcome Callout: Shelf Life & Limiting Factor */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Predicted Food Shelf Life
                </span>
                <div className="flex items-baseline space-x-3 mt-1">
                  <span className="text-4xl sm:text-5xl font-extrabold font-mono text-white tracking-tight">
                    {simulationResult.predicted_shelf_life_days}
                  </span>
                  <span className="text-lg font-medium text-slate-400">Days</span>
                  
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                    meetsShelfLife
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                      : 'bg-rose-950 text-rose-300 border border-rose-800/80'
                  }`}>
                    {meetsShelfLife ? 'Meets Engineering Target' : 'Below Target Shelf Life'}
                  </span>
                </div>
              </div>

              {/* Economic & Environmental Quick Metrics */}
              <div className="flex items-center space-x-4 text-xs font-mono">
                <div className="text-right">
                  <span className="text-slate-500 block text-[11px]">Cost / Pack:</span>
                  <span className="text-slate-100 font-bold text-sm">
                    ${simulationResult.cost_per_pack_usd.toFixed(3)}
                  </span>
                </div>
                <div className="text-right border-l border-slate-800 pl-4">
                  <span className="text-slate-500 block text-[11px]">CO₂e / Pack:</span>
                  <span className="text-slate-100 font-bold text-sm">
                    {simulationResult.carbon_per_pack_g_co2e.toFixed(1)} g
                  </span>
                </div>
                <div className="text-right border-l border-slate-800 pl-4">
                  <span className="text-slate-500 block text-[11px]">Film Mass:</span>
                  <span className="text-slate-100 font-bold text-sm">
                    {simulationResult.packaging_weight_per_pack_g.toFixed(1)} g
                  </span>
                </div>
              </div>
            </div>

            {/* Limiting Degradation Factor Banner */}
            <div className={`p-3 rounded-lg border flex items-start space-x-3 text-xs ${
              simulationResult.limiting_factor === 'none'
                ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
                : 'bg-amber-950/40 border-amber-800/60 text-amber-200'
            }`}>
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-semibold">
                  Primary Failure Mode: {simulationResult.limiting_factor.replace('_', ' ').toUpperCase()}
                </strong>
                <p className="text-slate-300 mt-0.5">
                  {simulationResult.limiting_description}
                </p>
              </div>
            </div>
          </div>

          {/* Barrier Transmission Rates Card (ASTM Calibrated) */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-100 flex items-center space-x-1.5">
                <span>Laminate Barrier Transmission Metrics</span>
              </span>
              <span className="text-slate-400 font-mono">
                Arrhenius Scaled to {conditions.storage_temp_c}°C / {conditions.ambient_rh_percent}% RH
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {/* OTR Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3">
                <span className="text-slate-400 block text-[11px] font-mono">OTR (O₂ Rate)</span>
                <span className="text-lg font-bold font-mono text-emerald-400 block my-0.5">
                  {barrierResult.otr_cc_m2_day_atm}
                </span>
                <span className="text-[10px] text-slate-500 block">
                  cm³/(m²·day·atm)
                </span>
                <div className="mt-1 pt-1 border-t border-slate-800 text-[10px] text-slate-400">
                  ASTM D3985: {barrierResult.ref_otr_23c}
                </div>
              </div>

              {/* WVTR Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3">
                <span className="text-slate-400 block text-[11px] font-mono">WVTR (Moisture)</span>
                <span className="text-lg font-bold font-mono text-sky-400 block my-0.5">
                  {barrierResult.wvtr_g_m2_day}
                </span>
                <span className="text-[10px] text-slate-500 block">
                  g/(m²·day)
                </span>
                <div className="mt-1 pt-1 border-t border-slate-800 text-[10px] text-slate-400">
                  ASTM F1249: {barrierResult.ref_wvtr_38c}
                </div>
              </div>

              {/* CTR Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3">
                <span className="text-slate-400 block text-[11px] font-mono">CTR (CO₂ Rate)</span>
                <span className="text-lg font-bold font-mono text-purple-400 block my-0.5">
                  {barrierResult.ctr_cc_m2_day_atm}
                </span>
                <span className="text-[10px] text-slate-500 block">
                  cm³/(m²·day·atm)
                </span>
                <div className="mt-1 pt-1 border-t border-slate-800 text-[10px] text-slate-400">
                  Selectivity: {(barrierResult.ctr_cc_m2_day_atm / Math.max(0.01, barrierResult.otr_cc_m2_day_atm)).toFixed(1)}x OTR
                </div>
              </div>

              {/* Recyclability Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3">
                <span className="text-slate-400 block text-[11px] font-mono">Recyclability</span>
                <span className="text-sm font-bold text-white block my-1 truncate">
                  {barrierResult.recyclability_class.split(' ')[0]}
                </span>
                <div className="flex items-center space-x-1">
                  <Recycle className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-mono font-bold text-xs">
                    {barrierResult.recyclability_score} / 100
                  </span>
                </div>
                <div className="mt-1 pt-1 border-t border-slate-800 text-[10px] text-slate-400 truncate">
                  {barrierResult.dominant_polymer}
                </div>
              </div>
            </div>
          </div>

          {/* Degradation Kinetics Trajectory Simulation Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-slate-100">
                Transient Physics Kinetics Trajectory (t = 0 to {maxDay} Days)
              </span>

              {/* Toggleable Channel Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setShowO2(!showO2)}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border transition-colors ${
                    showO2
                      ? 'bg-blue-950 border-blue-700 text-blue-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  ● O₂ %
                </button>
                <button
                  onClick={() => setShowCO2(!showCO2)}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border transition-colors ${
                    showCO2
                      ? 'bg-purple-950 border-purple-700 text-purple-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  ● CO₂ %
                </button>
                <button
                  onClick={() => setShowMoisture(!showMoisture)}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border transition-colors ${
                    showMoisture
                      ? 'bg-sky-950 border-sky-700 text-sky-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  ● Moisture
                </button>
                <button
                  onClick={() => setShowMicrobial(!showMicrobial)}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border transition-colors ${
                    showMicrobial
                      ? 'bg-rose-950 border-rose-700 text-rose-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  ● Microbial CFU
                </button>
                <button
                  onClick={() => setShowQuality(!showQuality)}
                  className={`px-2 py-0.5 rounded font-mono text-[11px] border transition-colors ${
                    showQuality
                      ? 'bg-emerald-950 border-emerald-700 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  ● Quality Index
                </button>
              </div>
            </div>

            {/* Interactive SVG Chart Container */}
            <div className="relative bg-slate-950 border border-slate-800 rounded-lg p-2 overflow-hidden">
              <svg
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                className="w-full h-auto cursor-crosshair"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const mouseX = e.clientX - rect.left;
                  const ratio = (mouseX / rect.width) * chartWidth;
                  const dayRatio = (ratio - padding.left) / plotWidth;
                  const day = Math.round(dayRatio * maxDay);
                  const clamped = Math.max(0, Math.min(trajectory.length - 1, day));
                  setHoveredDayIdx(clamped);
                }}
                onMouseLeave={() => setHoveredDayIdx(null)}
              >
                {/* Horizontal Grid lines */}
                {[0, 25, 50, 75, 100].map(val => (
                  <g key={val}>
                    <line
                      x1={padding.left}
                      y1={scaleY(val)}
                      x2={chartWidth - padding.right}
                      y2={scaleY(val)}
                      stroke="#334155"
                      strokeWidth="0.8"
                      strokeDasharray="3 3"
                    />
                    <text
                      x={padding.left - 6}
                      y={scaleY(val) + 3}
                      fill="#64748b"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="end"
                    >
                      {val}%
                    </text>
                  </g>
                ))}

                {/* Vertical Failure Cutoff Line */}
                <line
                  x1={failureX}
                  y1={padding.top}
                  x2={failureX}
                  y2={chartHeight - padding.bottom}
                  stroke="#ef4444"
                  strokeWidth="1.5"
                  strokeDasharray="4 2"
                />
                <text
                  x={failureX}
                  y={padding.top - 6}
                  fill="#ef4444"
                  fontSize="9"
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  Day {simulationResult.predicted_shelf_life_days} (Cutoff)
                </text>

                {/* Plot Paths */}
                {showO2 && (
                  <path
                    d={pathO2}
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="2"
                  />
                )}

                {showCO2 && (
                  <path
                    d={pathCO2}
                    fill="none"
                    stroke="#a855f7"
                    strokeWidth="2"
                  />
                )}

                {showMoisture && (
                  <path
                    d={pathMoisture}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="1.8"
                    strokeDasharray="5 2"
                  />
                )}

                {showMicrobial && (
                  <path
                    d={pathMicrobial}
                    fill="none"
                    stroke="#f43f5e"
                    strokeWidth="2"
                  />
                )}

                {showQuality && (
                  <path
                    d={pathQuality}
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                  />
                )}

                {/* Scrubber vertical line when hovering */}
                {hoveredDayIdx !== null && (
                  <line
                    x1={scaleX(currentHoverPoint.day)}
                    y1={padding.top}
                    x2={scaleX(currentHoverPoint.day)}
                    y2={chartHeight - padding.bottom}
                    stroke="#ffffff"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}
              </svg>

              {/* Scrubber Tooltip / Inspector Box */}
              <div className="mt-3 p-3 bg-slate-900 border border-slate-800 rounded-lg grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 block text-[10px]">Simulation Time:</span>
                  <span className="text-white font-bold">Day {currentHoverPoint.day}</span>
                </div>
                <div>
                  <span className="text-blue-400 block text-[10px]">Headspace O₂:</span>
                  <span className="text-white font-semibold">{currentHoverPoint.headspace_o2_percent}%</span>
                </div>
                <div>
                  <span className="text-purple-400 block text-[10px]">Headspace CO₂:</span>
                  <span className="text-white font-semibold">{currentHoverPoint.headspace_co2_percent}%</span>
                </div>
                <div>
                  <span className="text-sky-400 block text-[10px]">Product Moisture:</span>
                  <span className="text-white font-semibold">{currentHoverPoint.product_moisture_g100g} g%</span>
                </div>
                <div>
                  <span className="text-rose-400 block text-[10px]">Microbial Load:</span>
                  <span className="text-white font-semibold">{currentHoverPoint.microbial_log_cfu_g} log</span>
                </div>
                <div>
                  <span className="text-emerald-400 block text-[10px]">Quality Score:</span>
                  <span className="text-white font-bold">{currentHoverPoint.quality_retention_percent}%</span>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
