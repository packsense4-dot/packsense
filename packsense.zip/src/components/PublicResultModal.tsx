import React, { useEffect, useState } from 'react';
import {
  QrCode,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  ShieldCheck,
  Radio,
  ExternalLink,
  LogIn,
  X,
  Share2,
  Copy,
  Layers,
  Leaf
} from 'lucide-react';

export interface PublicResultData {
  status: string;
  batch_code: string;
  commodity: {
    name: string;
    category: string;
    ripeness_stage: string;
  };
  chosen_option: {
    film_name: string;
    thickness_micron: number;
    otr: number;
    wvtr: number;
    recyclability_score: number;
    explanation: string;
  };
  shelf_life: {
    low_days: number;
    expected_days: number;
    high_days: number;
    remaining_hours?: number;
    logger_paired?: boolean;
    last_temp_c?: number;
  };
  compliance: {
    is_compliant: boolean;
  };
  confidence_score: number;
}

interface PublicResultModalProps {
  batchCode: string;
  isOpen: boolean;
  onClose: () => void;
  onLoginPrompt?: () => void;
}

export const PublicResultModal: React.FC<PublicResultModalProps> = ({
  batchCode,
  isOpen,
  onClose,
  onLoginPrompt
}) => {
  const [data, setData] = useState<PublicResultData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (!isOpen || !batchCode) return;
    const cleanCode = batchCode.replace(/^packsense:\/\/result\//, '').trim();
    setIsLoading(true);
    setErrorMessage(null);

    fetch(`/api/v1/scan/reports/public/${encodeURIComponent(cleanCode)}`)
      .then(async (res) => {
        if (!res.ok) {
          const errJson = await res.json().catch(() => ({}));
          throw new Error(errJson.detail || `Public result for '${cleanCode}' not found`);
        }
        return res.json();
      })
      .then((json: PublicResultData) => {
        setData(json);
      })
      .catch((err) => {
        setErrorMessage(err.message || 'Unable to load public result summary');
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [isOpen, batchCode]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    const shareableUrl = `${window.location.origin}/#result=${batchCode}`;
    navigator.clipboard?.writeText(shareableUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#F4F8FC] w-full max-w-lg rounded-3xl shadow-2xl border border-[#E3E9F2] overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-white px-5 py-4 border-b border-[#E3E9F2] flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#E8F1FD] flex items-center justify-center text-[#1565C0]">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-extrabold text-[#0F1C2E]">PackSense Public Verification</h3>
                <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  Read-Only
                </span>
              </div>
              <div className="text-[11px] text-[#6B7A90] font-mono">
                Code: {batchCode.replace(/^packsense:\/\/result\//, '')}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-3 overflow-y-auto flex-1">
          {isLoading ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-8 h-8 border-3 border-[#1E88E5] border-t-transparent rounded-full animate-spin mx-auto" />
              <div className="text-xs font-bold text-[#6B7A90]">Fetching verified packaging recommendation...</div>
            </div>
          ) : errorMessage ? (
            <div className="p-5 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-2">
              <AlertTriangle className="w-6 h-6 text-rose-600 mx-auto" />
              <div className="text-xs font-bold text-rose-800">Result Not Found</div>
              <div className="text-[11px] text-rose-600 font-mono">{errorMessage}</div>
            </div>
          ) : data ? (
            <>
              {/* Privacy Notice Banner */}
              <div className="bg-[#E8F1FD] border border-[#1E88E5]/20 rounded-2xl p-3 flex items-start space-x-2.5 text-xs">
                <ShieldCheck className="w-4 h-4 text-[#1565C0] shrink-0 mt-0.5" />
                <div className="text-[#1565C0]">
                  <span className="font-bold">Shareable Mandi / Inspector Summary:</span> This is a privacy-trimmed preview of the physical chemistry recommendation. Cost details, raw calculations, and user profile are withheld.
                </div>
              </div>

              {/* Commodity Identity Card */}
              <div className="bg-gradient-to-br from-[#1565C0] to-[#42A5F5] rounded-2xl p-4 text-white shadow-md space-y-1">
                <div className="flex items-center justify-between text-[10px] font-bold">
                  <span className="bg-white/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {data.commodity.category.replace('_', ' ')}
                  </span>
                  <span className="bg-emerald-500/30 text-emerald-100 px-2 py-0.5 rounded-full border border-emerald-300/30">
                    {data.confidence_score}% Confidence
                  </span>
                </div>
                <div className="text-lg font-black tracking-tight">{data.commodity.name}</div>
                <div className="text-xs text-sky-100 font-medium">
                  Ripeness Stage: <strong>{data.commodity.ripeness_stage}</strong>
                </div>
              </div>

              {/* Shelf Life Digital Twin Card */}
              <div className="bg-white rounded-2xl p-4 border border-[#E3E9F2] shadow-sm space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[#6B7A90] uppercase tracking-wider">
                    Expected Shelf Life Window
                  </span>
                  <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    data.compliance.is_compliant ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{data.compliance.is_compliant ? 'FSSAI Compliant' : 'Review Needed'}</span>
                  </span>
                </div>

                <div className="flex items-baseline space-x-2">
                  <span className="text-3xl font-black text-[#0F1C2E]">
                    {data.shelf_life.expected_days}
                  </span>
                  <span className="text-xs font-bold text-[#6B7A90]">Days Recommended</span>
                  <span className="text-xs font-bold text-[#1E88E5] bg-[#E8F1FD] px-2.5 py-1 rounded-full ml-auto">
                    Safe Range: {data.shelf_life.low_days} – {data.shelf_life.high_days} Days
                  </span>
                </div>

                {data.shelf_life.logger_paired && (
                  <div className="p-2.5 bg-sky-50 border border-sky-200 rounded-xl flex items-center space-x-2 text-xs">
                    <Radio className="w-4 h-4 text-sky-600 animate-pulse shrink-0" />
                    <div className="text-sky-900 text-[11px]">
                      <strong>Bluetooth Logger Live Sync:</strong> Real-time temperature kinetics adjusting shelf life ({data.shelf_life.last_temp_c}°C recorded).
                    </div>
                  </div>
                )}
              </div>

              {/* Recommended Packaging Film */}
              <div className="bg-white rounded-2xl p-4 border border-[#E3E9F2] shadow-sm space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-[#0F1C2E]">
                  <span className="flex items-center space-x-1.5">
                    <Layers className="w-4 h-4 text-[#1E88E5]" />
                    <span>Recommended MAP Film Specification</span>
                  </span>
                  <span className="text-[10px] font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                    Score: {data.chosen_option.recyclability_score}/100
                  </span>
                </div>

                <div className="p-3 bg-[#F4F8FC] rounded-xl border border-[#E3E9F2] space-y-1">
                  <div className="text-xs font-bold text-[#0F1C2E]">{data.chosen_option.film_name}</div>
                  <div className="text-[11px] text-[#6B7A90]">{data.chosen_option.explanation}</div>
                </div>

                <div className="grid grid-cols-3 gap-2 font-mono text-center text-xs">
                  <div className="bg-[#F4F8FC] p-2 rounded-xl border border-[#E3E9F2]">
                    <span className="text-[8px] text-[#6B7A90] block uppercase">Thickness</span>
                    <span className="font-bold text-[#0F1C2E]">{data.chosen_option.thickness_micron} µm</span>
                  </div>
                  <div className="bg-[#F4F8FC] p-2 rounded-xl border border-[#E3E9F2]">
                    <span className="text-[8px] text-[#6B7A90] block uppercase">Target OTR</span>
                    <span className="font-bold text-[#0F1C2E]">{data.chosen_option.otr}</span>
                    <span className="text-[8px] text-slate-400 block">cc/m²·d</span>
                  </div>
                  <div className="bg-[#F4F8FC] p-2 rounded-xl border border-[#E3E9F2]">
                    <span className="text-[8px] text-[#6B7A90] block uppercase">Target WVTR</span>
                    <span className="font-bold text-[#0F1C2E]">{data.chosen_option.wvtr}</span>
                    <span className="text-[8px] text-slate-400 block">g/m²·d</span>
                  </div>
                </div>
              </div>

              {/* Login CTA Card */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-lg space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-sky-300">
                  <LogIn className="w-4 h-4" />
                  <span>Want Full Access to Suppliers & Cost Breakdowns?</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Log in or register to inspect regional film suppliers, Rupee ROI savings, printable PDF spec sheets, and full multi-objective film options.
                </p>
                <div className="flex gap-2 pt-1">
                  {onLoginPrompt && (
                    <button
                      onClick={onLoginPrompt}
                      className="flex-1 py-2 bg-[#1E88E5] hover:bg-[#1565C0] text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>Log In to View Full Details</span>
                    </button>
                  )}
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedLink ? 'Copied' : 'Share'}</span>
                  </button>
                </div>
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
};
