import React, { useState, useEffect } from 'react';
import {
  Wrench,
  Maximize2,
  Box,
  TrendingDown,
  DollarSign,
  Truck,
  AlertTriangle,
  FileCheck2,
  Building2,
  MessageSquare,
  Users,
  Search,
  CheckCircle2,
  Info,
  Layers,
  Thermometer,
  Droplets,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Scan
} from 'lucide-react';
import { FOODS_DATABASE, FoodProduct } from '../engine/foodsDb.ts';
import {
  calculateRightSizing,
  RightSizingResult,
  calculateSecondaryPackaging,
  SecondaryPackagingResult,
  evaluateCondensationRisk,
  CondensationRiskResult,
  diagnoseSpoilageAutopsy,
  SpoilageAutopsyResult,
  calculateRupeeImpact,
  RupeeImpactResult,
  recommendRuralMode,
  RuralModeRecommendation,
  checkMixedLoadCompatibility,
  MixedLoadCheckResult,
  performReversePackAudit,
  ReverseAuditResult,
  getMoFpiDashboardSummary,
  GovDashboardSummary,
  getCommunityAccuracyStats
} from '../engine/featuresSuite.ts';

interface IndustrialSuiteProps {
  currentFoodId: string;
}

export const IndustrialEngineeringSuite: React.FC<IndustrialSuiteProps> = ({ currentFoodId }) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'right_sizing' | 'autopsy_condensation' | 'rupee_rural' | 'mixed_load' | 'reverse_audit' | 'gov_community' | 'whatsapp_bot'
  >('right_sizing');

  const selectedFood = FOODS_DATABASE.find(f => f.id === currentFoodId) || FOODS_DATABASE[0];

  // 1. Right Sizing & Secondary State
  const [packType, setPackType] = useState<'pillow_pouch' | 'stand_up_pouch' | 'rigid_tray' | 'gusseted_bag'>('pillow_pouch');
  const [netWeightG, setNetWeightG] = useState<number>(250);
  const [baselineWidthMm, setBaselineWidthMm] = useState<number>(160);
  const [baselineLengthMm, setBaselineLengthMm] = useState<number>(220);
  const [unitsPerShipper, setUnitsPerShipper] = useState<number>(24);
  const [palletLayers, setPalletLayers] = useState<number>(5);
  const [transitHumidity, setTransitHumidity] = useState<number>(85);

  const rightSizingResult: RightSizingResult = calculateRightSizing({
    food_id: selectedFood.id,
    net_weight_g: netWeightG,
    pack_type: packType,
    current_pouch_dimensions_mm: { length: baselineLengthMm, width: baselineWidthMm }
  });

  const secondaryResult: SecondaryPackagingResult = calculateSecondaryPackaging({
    primary_pack_weight_g: netWeightG,
    primary_pack_dimensions_mm: {
      length: rightSizingResult.optimal_dimensions_mm.length,
      width: rightSizingResult.optimal_dimensions_mm.width,
      height: rightSizingResult.optimal_dimensions_mm.depth || 35
    },
    units_per_shipper_carton: unitsPerShipper,
    pallet_stacking_layers: palletLayers,
    transit_humidity_rh_percent: transitHumidity,
    transit_days: 7
  });

  // 2. Spoilage Autopsy & Condensation State
  const [selectedSymptoms, setSelectedSymptoms] = useState<Array<'ballooning_puffing' | 'mold_growth' | 'browning_oxidation' | 'moisture_desiccation' | 'fogging_sweating'>>([
    'fogging_sweating',
    'mold_growth'
  ]);
  const [storageTempC, setStorageTempC] = useState<number>(14);
  const [hasAntiFog, setHasAntiFog] = useState<boolean>(false);

  const autopsyResult: SpoilageAutopsyResult = diagnoseSpoilageAutopsy({
    food_id: selectedFood.id,
    observed_symptoms: selectedSymptoms,
    days_to_failure: 12,
    storage_temp_c: storageTempC
  });

  const condensationResult: CondensationRiskResult = evaluateCondensationRisk({
    food_id: selectedFood.id,
    internal_temp_c: storageTempC,
    internal_rh_percent: 92,
    external_temp_cycle: [
      { temp_c: 4, rh_percent: 85, hours: 12 },
      { temp_c: 28, rh_percent: 75, hours: 6 },
      { temp_c: 34, rh_percent: 65, hours: 6 }
    ],
    has_anti_fog_coating: hasAntiFog
  });

  // 3. Rupee Impact & Rural Mode State
  const [annualPacks, setAnnualPacks] = useState<number>(250000);
  const [basePackCostRs, setBasePackCostRs] = useState<number>(2.4);
  const [baseSpoilagePct, setBaseSpoilagePct] = useState<number>(18);
  const [propPackCostRs, setPropPackCostRs] = useState<number>(3.1);
  const [propSpoilagePct, setPropSpoilagePct] = useState<number>(4);
  const [productUnitValueRs, setProductUnitValueRs] = useState<number>(65);

  const rupeeResult: RupeeImpactResult = calculateRupeeImpact({
    annual_production_packs: annualPacks,
    baseline_cost_per_pack_inr: basePackCostRs,
    baseline_spoilage_rate_pct: baseSpoilagePct,
    proposed_cost_per_pack_inr: propPackCostRs,
    proposed_spoilage_rate_pct: propSpoilagePct,
    product_retail_value_inr: productUnitValueRs
  });

  const ruralRec: RuralModeRecommendation = recommendRuralMode({
    food_id: selectedFood.id,
    ambient_temp_c: 32,
    available_budget_per_kg_inr: 0.8,
    fpo_village_context: 'Rural FPO Village Aggregation'
  });

  // 4. Mixed Load State
  const [mixedFoodIds, setMixedFoodIds] = useState<string[]>([
    'alphonso_mango',
    'table_grapes',
    'fresh_onion'
  ]);
  const mixedLoadResult: MixedLoadCheckResult = checkMixedLoadCompatibility({
    food_ids: mixedFoodIds
  });

  // 5. Reverse Audit & OCR Pack Label Auto-Fill State (Part 1 Section 1.1)
  const [auditOcrText, setAuditOcrText] = useState<string>('LDPE 40 MICRON FOOD GRADE');
  const [auditScanResult, setAuditScanResult] = useState<any>(null);
  const [auditScanLoading, setAuditScanLoading] = useState<boolean>(false);
  const [auditAccepted, setAuditAccepted] = useState<boolean | null>(null);
  const [auditMaterialType, setAuditMaterialType] = useState<string>('LDPE');
  const [auditThickness, setAuditThickness] = useState<number>(40);

  const reverseAuditResult: ReverseAuditResult = performReversePackAudit({
    food_id: selectedFood.id,
    film_material_type: auditMaterialType,
    film_thickness_micron: auditThickness,
    current_layers: [
      { material_id: auditMaterialType.toLowerCase().includes('ldpe') ? 'ldpe' : 'pp', thickness_um: auditThickness }
    ],
    current_observed_shelf_life_days: 18
  });

  const handleAuditScan = async () => {
    setAuditScanLoading(true);
    try {
      const res = await fetch('/api/v1/pack-label/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw_text: auditOcrText })
      });
      const data = await res.json();
      setAuditScanResult(data);
      if (data.matched) {
        if (data.extracted_material) setAuditMaterialType(data.extracted_material);
        if (data.extracted_thickness) setAuditThickness(Number(data.extracted_thickness));
        setAuditAccepted(null);
      }
    } catch {} finally {
      setAuditScanLoading(false);
    }
  };

  const handleFeedback = async (accepted: boolean) => {
    setAuditAccepted(accepted);
    if (auditScanResult?.scan_record_id) {
      try {
        await fetch('/api/v1/pack-label/feedback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            scan_id: auditScanResult.scan_record_id,
            was_accepted_by_user: accepted
          })
        });
      } catch {}
    }
  };

  // 6. Gov & Community State
  const govSummary: GovDashboardSummary = getMoFpiDashboardSummary();
  const communityStats = getCommunityAccuracyStats();

  // 7. WhatsApp Inbound Simulator
  const [waInputText, setWaInputText] = useState<string>('Mango Devgad 21 days 12C');
  const [waResponse, setWaResponse] = useState<string>('');
  const [waLoading, setWaLoading] = useState<boolean>(false);

  const handleTestWhatsApp = async () => {
    setWaLoading(true);
    try {
      const res = await fetch('/api/v1/whatsapp/webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Body: waInputText })
      });
      const text = await res.text();
      setWaResponse(text);
    } catch (err: any) {
      setWaResponse(`Error: ${err.message}`);
    } finally {
      setWaLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <Wrench className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Industrial Packaging Engineering Suite</h2>
                <p className="text-xs text-slate-400">
                  Features 9–22: Right-sizing, condensation Magnus-Tetens, spoilage autopsy, rupee ROI, mixed-load transshipment, MoFPI dashboard & WhatsApp bot.
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
              Active Commodity: <strong className="text-emerald-400">{selectedFood.name}</strong>
            </span>
            <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/60">
              Deterministic Math Engine
            </span>
          </div>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex flex-wrap gap-1.5 mt-5 pt-4 border-t border-slate-800 text-xs font-medium">
          {[
            { id: 'right_sizing', label: 'Right-Sizing & Shipper BCT', icon: Maximize2 },
            { id: 'autopsy_condensation', label: 'Dew-Point & Spoilage Autopsy', icon: Droplets },
            { id: 'rupee_rural', label: 'Rupee Impact & Rural Mode', icon: DollarSign },
            { id: 'mixed_load', label: 'Mixed-Load Transshipment', icon: Truck },
            { id: 'reverse_audit', label: 'Pack Auditor (Reverse Mode)', icon: RotateCcw },
            { id: 'gov_community', label: 'MoFPI Gov & Community Accuracy', icon: Building2 },
            { id: 'whatsapp_bot', label: 'WhatsApp / SMS Gateway', icon: MessageSquare }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. RIGHT SIZING & SECONDARY PACKAGING */}
      {activeSubTab === 'right_sizing' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Maximize2 className="w-4 h-4 text-emerald-400" />
                <span>Feature 14: Pouch Right-Sizing Engine</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">ASTM Pouch Vol Equation</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Package Architecture</label>
                <select
                  value={packType}
                  onChange={e => setPackType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                >
                  <option value="pillow_pouch">Pillow Pouch (Standard Form-Fill-Seal)</option>
                  <option value="stand_up_pouch">Stand-Up Doypack (Bottom Gusset)</option>
                  <option value="rigid_tray">Rigid MAP Tray + Top Lid</option>
                  <option value="gusseted_bag">Side Gusseted Block-Bottom Bag</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Target Net Weight (g)</label>
                <input
                  type="number"
                  value={netWeightG}
                  onChange={e => setNetWeightG(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Current Baseline Width (mm)</label>
                <input
                  type="number"
                  value={baselineWidthMm}
                  onChange={e => setBaselineWidthMm(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Current Baseline Length (mm)</label>
                <input
                  type="number"
                  value={baselineLengthMm}
                  onChange={e => setBaselineLengthMm(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>

            {/* Right sizing calculation cards */}
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Optimal Width</span>
                  <span className="text-base font-bold text-emerald-400 font-mono">
                    {rightSizingResult.optimal_dimensions_mm.width} mm
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Optimal Length</span>
                  <span className="text-base font-bold text-emerald-400 font-mono">
                    {rightSizingResult.optimal_dimensions_mm.length} mm
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Headspace Vg:Vp</span>
                  <span className="text-base font-bold text-sky-400 font-mono">
                    {(rightSizingResult.required_headspace_volume_cm3 / rightSizingResult.required_product_volume_cm3).toFixed(1)}:1
                  </span>
                </div>
              </div>

              {rightSizingResult.material_savings && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between text-emerald-300 font-semibold">
                    <span>Polymer Surface Area Reduction:</span>
                    <span>{rightSizingResult.material_savings.surface_area_reduction_pct}%</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span>Annual Savings per 1 Lakh Packs:</span>
                    <strong className="text-white font-mono">
                      ₹{rightSizingResult.material_savings.annual_rupee_savings_per_lakh_packs.toLocaleString('en-IN')}
                    </strong>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>CO2e Polymer Footprint Avoided:</span>
                    <span className="font-mono">{rightSizingResult.material_savings.annual_co2e_kg_saved_per_lakh_packs} kg CO2e</span>
                  </div>
                </div>
              )}

              <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                {rightSizingResult.engineering_notes.map((note, i) => (
                  <p key={i} className="flex items-start space-x-1.5">
                    <span className="text-emerald-400">•</span>
                    <span>{note}</span>
                  </p>
                ))}
              </div>
            </div>
          </div>

          {/* Secondary packaging */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Box className="w-4 h-4 text-sky-400" />
                <span>Feature 15: Secondary Packaging & Corrugated BCT</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">McKee BCT Formula</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Units / Shipper</label>
                <input
                  type="number"
                  value={unitsPerShipper}
                  onChange={e => setUnitsPerShipper(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Stacking Layers</label>
                <input
                  type="number"
                  value={palletLayers}
                  onChange={e => setPalletLayers(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Monsoon RH (%)</label>
                <input
                  type="number"
                  value={transitHumidity}
                  onChange={e => setTransitHumidity(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Shipper Outer Dimensions</span>
                  <span className="text-sm font-bold text-white font-mono">
                    {secondaryResult.shipper_box_dimensions_mm.length} × {secondaryResult.shipper_box_dimensions_mm.width} × {secondaryResult.shipper_box_dimensions_mm.height} mm
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-1">Gross: {secondaryResult.gross_box_weight_kg} kg</span>
                </div>

                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Required BCT Compression</span>
                  <span className="text-sm font-bold text-sky-400 font-mono">
                    {secondaryResult.box_compression_test_bct_kn} kN
                  </span>
                  <span className="text-[10px] text-amber-400 block mt-1">
                    Safety Factor: {secondaryResult.required_safety_factor}x (derated for {transitHumidity}% RH)
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-900/60 rounded border border-slate-800 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Recommended Board Flute:</span>
                  <strong className="text-white font-mono">{secondaryResult.corrugated_board_specification.flute_type}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Bursting Strength:</span>
                  <span className="text-slate-200 font-mono">{secondaryResult.corrugated_board_specification.bursting_strength_kpa} kPa</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Paper GSM Combination:</span>
                  <span className="text-slate-300 font-mono">{secondaryResult.corrugated_board_specification.recommended_paper_gsm}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">ISO Pallet Layout:</span>
                  <span className="text-emerald-400 font-mono">{secondaryResult.pallet_pattern.total_boxes_per_pallet} cartons / pallet ({secondaryResult.pallet_pattern.iso_pallet_coverage_pct}% coverage)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. DEW-POINT & SPOILAGE AUTOPSY */}
      {activeSubTab === 'autopsy_condensation' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Condensation Map */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Droplets className="w-4 h-4 text-cyan-400" />
                <span>Feature 12: Dew-Point & Condensation Risk Engine</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">Magnus-Tetens Formula</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Cold-Room Internal Temp (°C)</label>
                <input
                  type="number"
                  value={storageTempC}
                  onChange={e => setStorageTempC(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Anti-Fog Inner Additive</label>
                <button
                  type="button"
                  onClick={() => setHasAntiFog(!hasAntiFog)}
                  className={`w-full p-2 rounded border text-left font-medium transition-colors ${
                    hasAntiFog
                      ? 'bg-cyan-950 text-cyan-300 border-cyan-800'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {hasAntiFog ? '✓ Anti-Fog Masterbatch Enabled' : '✗ Untreated Film (No Anti-Fog)'}
                </button>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Magnus Dew Point</span>
                  <span className="text-base font-bold text-cyan-400 font-mono">
                    {condensationResult.dew_point_c}°C
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Safe Thermal Margin</span>
                  <span className="text-base font-bold text-slate-200 font-mono">
                    {condensationResult.critical_temperature_drop_threshold_c}°C
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Condensation Hazard</span>
                  <span className={`text-base font-bold font-mono ${
                    condensationResult.condensation_risk_level === 'CRITICAL' ? 'text-rose-400' : 'text-amber-400'
                  }`}>
                    {condensationResult.condensation_risk_level}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-900/60 rounded border border-slate-800 text-xs space-y-2">
                <p className="text-slate-300">{condensationResult.microbial_germination_hazard}</p>
                <div className="border-t border-slate-800/80 pt-2 space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Engineering Mitigations:</span>
                  {condensationResult.mitigation_recommendations.map((m, idx) => (
                    <p key={idx} className="text-slate-400 flex items-start space-x-1.5">
                      <span className="text-cyan-400">•</span>
                      <span>{m}</span>
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Spoilage Autopsy */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Feature 10: Spoilage Autopsy Diagnosis</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">Failure Tree Root Cause</span>
            </div>

            <div className="space-y-2 text-xs">
              <label className="text-slate-400 block">Observed Failure Symptoms (Multi-Select):</label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'ballooning_puffing', label: 'Pouch Ballooning / Distension' },
                  { id: 'fogging_sweating', label: 'Internal Droplets / Sweating' },
                  { id: 'mold_growth', label: 'Fungal Mold / Mycelium' },
                  { id: 'browning_oxidation', label: 'Enzymatic Darkening / Browning' },
                  { id: 'moisture_desiccation', label: 'Surface Desiccation / Shrivel' }
                ].map(sym => {
                  const isChecked = selectedSymptoms.includes(sym.id as any);
                  return (
                    <button
                      key={sym.id}
                      type="button"
                      onClick={() => {
                        if (isChecked) {
                          setSelectedSymptoms(selectedSymptoms.filter(s => s !== sym.id));
                        } else {
                          setSelectedSymptoms([...selectedSymptoms, sym.id as any]);
                        }
                      }}
                      className={`p-2 rounded text-left border transition-colors ${
                        isChecked
                          ? 'bg-amber-950/70 border-amber-700 text-amber-200'
                          : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '} {sym.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">Diagnosed Primary Root Cause</span>
                <span className="text-sm font-bold text-amber-300 font-mono">
                  {autopsyResult.primary_root_cause} ({autopsyResult.confidence_score_pct}% confidence)
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Physical Mechanisms:</span>
                {autopsyResult.failure_mechanisms.map((mech, i) => (
                  <p key={i} className="text-slate-300 flex items-start space-x-1.5">
                    <span className="text-amber-400">•</span>
                    <span>{mech}</span>
                  </p>
                ))}
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Corrective Packaging Actions:</span>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-300 pt-1">
                  <span>Target OTR: <strong className="text-white">{autopsyResult.corrective_engineering_actions.target_otr_cc}</strong></span>
                  <span>Target WVTR: <strong className="text-white">{autopsyResult.corrective_engineering_actions.target_wvtr_g}</strong></span>
                  <span className="col-span-2">Target MAP: <strong className="text-emerald-400">{autopsyResult.corrective_engineering_actions.recommended_map_gas}</strong></span>
                  <span className="col-span-2 text-slate-400">Film Spec: {autopsyResult.corrective_engineering_actions.recommended_film_structure}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. RUPEE IMPACT & RURAL MODE */}
      {activeSubTab === 'rupee_rural' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Rupee Impact */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Feature 16: Rupee Impact & ROI Calculator</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">FPO Unit Economics</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Annual Packs Produced</label>
                <input
                  type="number"
                  value={annualPacks}
                  onChange={e => setAnnualPacks(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Product Market Value (₹/unit)</label>
                <input
                  type="number"
                  value={productUnitValueRs}
                  onChange={e => setProductUnitValueRs(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Baseline Spoilage (%)</label>
                <input
                  type="number"
                  value={baseSpoilagePct}
                  onChange={e => setBaseSpoilagePct(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">PackSense Spoilage (%)</label>
                <input
                  type="number"
                  value={propSpoilagePct}
                  onChange={e => setPropSpoilagePct(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Net Annual Profit Gain</span>
                  <span className="text-base font-bold text-emerald-400 font-mono">
                    ₹{rupeeResult.net_annual_financial_gain_inr.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Investment ROI</span>
                  <span className="text-base font-bold text-sky-400 font-mono">
                    {rupeeResult.roi_percent}%
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Payback Period</span>
                  <span className="text-base font-bold text-amber-300 font-mono">
                    {rupeeResult.payback_period_months} mo
                  </span>
                </div>
              </div>

              <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded text-xs space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Food Waste Losses Prevented:</span>
                  <strong className="text-white font-mono">₹{rupeeResult.food_waste_savings_inr.toLocaleString('en-IN')} / yr</strong>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Methane / Food Loss Carbon Avoided:</span>
                  <span className="font-mono text-emerald-300">{rupeeResult.co2e_food_waste_prevented_tons} Metric Tons CO2e</span>
                </div>
              </div>
            </div>
          </div>

          {/* Rural Mode */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>Feature 17: Low-Cost Rural Farmer Mode</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">Zero-CAPEX Protocols</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">Recommended Rural Intervention</span>
                <span className="text-sm font-bold text-white font-mono">{ruralRec.intervention_name}</span>
                <div className="flex items-center space-x-3 mt-1 text-[11px] text-slate-400">
                  <span>Cost: <strong className="text-emerald-400 font-mono">₹{ruralRec.packaging_cost_per_kg_inr}/kg</strong></span>
                  <span>Expected Life: <strong className="text-sky-300 font-mono">{ruralRec.expected_shelf_life_days} days</strong></span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Locally Sourced Materials:</span>
                {ruralRec.materials_needed.map((mat, i) => (
                  <p key={i} className="text-slate-300 flex items-start space-x-1.5">
                    <span className="text-emerald-400">•</span>
                    <span>{mat}</span>
                  </p>
                ))}
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Standard Operating Protocol (SOP):</span>
                {ruralRec.operational_protocol.map((step, i) => (
                  <p key={i} className="text-slate-400 flex items-start space-x-1.5">
                    <span className="text-slate-500">{i + 1}.</span>
                    <span>{step}</span>
                  </p>
                ))}
              </div>

              <p className="p-2.5 bg-slate-900 rounded text-slate-400 text-[11px] italic">
                "{ruralRec.science_rationale}"
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 4. MIXED LOAD COMPATIBILITY */}
      {activeSubTab === 'mixed_load' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-semibold text-white flex items-center space-x-2">
              <Truck className="w-4 h-4 text-emerald-400" />
              <span>Feature 13: Mixed-Load Transshipment Compatibility</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">Ethylene & Odor Cross-Taint Checker</span>
          </div>

          <div className="text-xs space-y-2">
            <label className="text-slate-400 block">Select Commodities Co-Loaded in Transit Reefer:</label>
            <div className="flex flex-wrap gap-2">
              {FOODS_DATABASE.slice(0, 8).map(food => {
                const isSelected = mixedFoodIds.includes(food.id);
                return (
                  <button
                    key={food.id}
                    onClick={() => {
                      if (isSelected) {
                        if (mixedFoodIds.length > 1) {
                          setMixedFoodIds(mixedFoodIds.filter(id => id !== food.id));
                        }
                      } else {
                        setMixedFoodIds([...mixedFoodIds, food.id]);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-lg border text-xs transition-colors ${
                      isSelected
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700 font-semibold'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '} {food.name} ({food.storage_temp_c}°C)
                  </button>
                );
              })}
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">Reefer Compatibility Status</span>
                <span className={`text-base font-bold font-mono ${
                  mixedLoadResult.overall_compatibility === 'INCOMPATIBLE'
                    ? 'text-rose-400'
                    : mixedLoadResult.overall_compatibility === 'REQUIRES_SEGREGATION'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}>
                  {mixedLoadResult.overall_compatibility} (Hazard Score: {mixedLoadResult.hazard_score_100}/100)
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 uppercase block">Reefer Temp Range</span>
                <span className="text-sm font-bold text-white font-mono">
                  {mixedLoadResult.suggested_transit_temp_c.min}°C – {mixedLoadResult.suggested_transit_temp_c.max}°C
                </span>
              </div>
            </div>

            {mixedLoadResult.incompatibilities.length > 0 ? (
              <div className="space-y-2">
                <span className="text-[10px] text-slate-500 uppercase font-semibold">Cross-Commodity Incompatibilities Detected:</span>
                {mixedLoadResult.incompatibilities.map((inc, i) => (
                  <div key={i} className="p-3 bg-rose-950/30 border border-rose-900/60 rounded text-rose-200 space-y-1">
                    <div className="flex items-center justify-between font-mono text-[11px]">
                      <strong>{inc.commodity_a} ↔ {inc.commodity_b}</strong>
                      <span className="px-1.5 py-0.5 rounded bg-rose-900 text-white text-[9px] uppercase font-bold">{inc.issue_type}</span>
                    </div>
                    <p className="text-[11px] text-slate-300">{inc.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-emerald-400">All chosen commodities share compatible cold-chain and respiratory requirements.</p>
            )}

            <div className="border-t border-slate-800 pt-2 space-y-1 text-slate-400">
              {mixedLoadResult.recommendations.map((r, i) => (
                <p key={i} className="flex items-start space-x-1.5">
                  <span className="text-emerald-400">•</span>
                  <span>{r}</span>
                </p>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. REVERSE AUDIT */}
      {activeSubTab === 'reverse_audit' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-semibold text-white flex items-center space-x-2">
              <RotateCcw className="w-4 h-4 text-emerald-400" />
              <span>Feature 9: Pack Auditor (Reverse Mode)</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">Audit Existing Market Packs</span>
          </div>

          {/* Part 1: Pack Label Scan OCR Auto-Fill */}
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2.5 text-xs">
            <div className="flex items-center justify-between">
              <div className="font-semibold text-emerald-400 flex items-center space-x-1.5 font-mono">
                <Scan className="w-3.5 h-3.5" />
                <span>Pack Label Scan (OCR Auto-Fill)</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">POST /api/v1/pack-label/scan</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Instead of manual entry, paste client-side OCR text from an existing label to auto-fill the current film material and thickness.
            </p>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={auditOcrText}
                onChange={(e) => setAuditOcrText(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-600"
                placeholder="e.g. LDPE 40 MICRON FOOD GRADE"
              />
              <button
                onClick={handleAuditScan}
                disabled={auditScanLoading}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded font-mono text-xs font-bold transition-colors whitespace-nowrap"
              >
                {auditScanLoading ? 'Matching...' : 'Scan & Auto-Fill'}
              </button>
            </div>

            {auditScanResult && (
              <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-2 mt-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="text-slate-400 text-[10px] font-mono">MATCHED FILM:</div>
                    <div className="text-emerald-400 font-bold text-xs">
                      {auditScanResult.film_name || auditScanResult.matched_film?.name || 'No close match'}
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 text-[11px] font-mono">
                    <span className="text-slate-300">
                      Material: <strong className="text-sky-300">{auditMaterialType}</strong>
                    </span>
                    <span className="text-slate-300">
                      Thickness: <strong className="text-sky-300">{auditThickness} µm</strong>
                    </span>
                    <span className="text-amber-300">
                      Confidence: <strong>{auditScanResult.match_confidence || Math.round((auditScanResult.confidence_score || 0)*100)}%</strong>
                    </span>
                  </div>
                </div>

                {auditScanResult.fallback_message && (
                  <p className="text-amber-400 text-[11px]">{auditScanResult.fallback_message}</p>
                )}

                {/* Section 1.5 Continuous Feedback */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px] font-mono">
                  <span className="text-slate-400">Did this match your packaging label?</span>
                  <div className="flex items-center space-x-1.5">
                    <button
                      onClick={() => handleFeedback(true)}
                      className={`px-2 py-0.5 rounded border ${
                        auditAccepted === true ? 'bg-emerald-900 border-emerald-600 text-emerald-200 font-bold' : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      ✓ Keep Match
                    </button>
                    <button
                      onClick={() => handleFeedback(false)}
                      className={`px-2 py-0.5 rounded border ${
                        auditAccepted === false ? 'bg-rose-950 border-rose-600 text-rose-200 font-bold' : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      ✕ Override
                    </button>
                    {auditAccepted !== null && (
                      <span className="text-emerald-400 ml-1">Feedback recorded!</span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Barrier Efficiency Score</span>
                <span className="text-lg font-bold text-emerald-400 font-mono">{reverseAuditResult.barrier_efficiency_score_100}/100</span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Diagnosis</span>
                <span className="text-lg font-bold text-amber-300 font-mono">{reverseAuditResult.engineering_diagnosis}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Potential Material Savings</span>
                <span className="text-lg font-bold text-sky-400 font-mono">{reverseAuditResult.potential_savings_pct}%</span>
              </div>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Audit Observations & Over-Engineering Flags:</span>
              {reverseAuditResult.audit_observations.map((obs, i) => (
                <p key={i} className="text-slate-300 flex items-start space-x-1.5">
                  <span className="text-emerald-400">•</span>
                  <span>{obs}</span>
                </p>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 6. GOV DASHBOARD & COMMUNITY ACCURACY */}
      {activeSubTab === 'gov_community' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>Feature 22: MoFPI Government Dashboard (District-Level Postharvest Metrics)</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">PMFME Anonymized Aggregation</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center text-xs">
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Food Loss Prevented</span>
                <span className="text-base font-bold text-emerald-400 font-mono">
                  {govSummary.total_post_harvest_loss_prevented_metric_tons.toLocaleString()} MT
                </span>
              </div>
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Economic Value Unlocked</span>
                <span className="text-base font-bold text-sky-400 font-mono">
                  ₹{govSummary.total_economic_value_unlocked_crores_inr} Crores
                </span>
              </div>
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Avg Shelf Life Extension</span>
                <span className="text-base font-bold text-white font-mono">
                  +{govSummary.average_shelf_life_extension_days} Days
                </span>
              </div>
              <div className="p-3 bg-slate-950 rounded border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Bio-Polymer Adoption</span>
                <span className="text-base font-bold text-amber-300 font-mono">
                  {govSummary.bio_polymer_adoption_index_pct}%
                </span>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-500 uppercase block mb-2 font-semibold">Active District Performance:</span>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-[11px]">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-500">
                      <th className="py-2">District</th>
                      <th>State</th>
                      <th>Key Crop</th>
                      <th>Loss Reduction</th>
                      <th>Active FPOs</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {govSummary.top_active_districts.map(d => (
                      <tr key={d.district_id} className="text-slate-300 hover:bg-slate-900/50">
                        <td className="py-2 font-semibold text-white">{d.district_name}</td>
                        <td>{d.state}</td>
                        <td className="text-emerald-400">{d.key_crop}</td>
                        <td className="text-sky-300 font-bold">-{d.loss_reduction_pct}%</td>
                        <td>{d.fpos_active_count} FPOs</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Community accuracy */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-semibold text-white flex items-center space-x-2">
                <Users className="w-4 h-4 text-sky-400" />
                <span>Feature 18: Community Learning Loop & Field Accuracy</span>
              </h3>
              <span className="text-xs font-mono text-emerald-400">
                Field Correlation: {communityStats.regional_prediction_accuracy_pct}%
              </span>
            </div>
            <p className="text-slate-400">
              Aggregated across {communityStats.total_logs} verified farm-gate trials. Mean absolute prediction error is only{' '}
              <strong className="text-white font-mono">{communityStats.mean_absolute_error_days} days</strong>.
            </p>
          </div>
        </div>
      )}

      {/* 7. WHATSAPP & SMS BOT */}
      {activeSubTab === 'whatsapp_bot' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-semibold text-white flex items-center space-x-2">
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Feature 6: Inbound WhatsApp & SMS Bot Webhook Simulator</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">Deterministic NLP-Free Gateway</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-4 text-xs">
            <div>
              <label className="text-slate-400 block mb-1 font-semibold">Test Inbound Farmer Message</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={waInputText}
                  onChange={e => setWaInputText(e.target.value)}
                  placeholder="e.g. Mango Devgad 21 days 12C"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white font-mono"
                />
                <button
                  type="button"
                  onClick={handleTestWhatsApp}
                  disabled={waLoading}
                  className="px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center space-x-1.5 transition-colors"
                >
                  {waLoading ? <span>Processing...</span> : <span>Send Webhook</span>}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 text-[11px]">
              <span className="text-slate-500">Quick Prompts:</span>
              {['Mango Ratnagiri 21 days 12C', 'Tomato Kolar 15 days 10C', 'Table Grapes Nashik 45 days 2C', 'Fresh Paneer Pune 14 days 4C'].map(p => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setWaInputText(p)}
                  className="px-2 py-1 rounded bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700"
                >
                  {p}
                </button>
              ))}
            </div>

            {waResponse && (
              <div className="mt-4 p-4 bg-slate-900 rounded-lg border border-emerald-800/60 font-mono text-[11px] text-emerald-300 whitespace-pre-wrap">
                <span className="text-[10px] text-slate-500 uppercase block mb-1 font-sans">Twilio Gateway Response:</span>
                {waResponse}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
