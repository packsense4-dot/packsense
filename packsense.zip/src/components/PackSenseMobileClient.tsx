/**
 * PackSense AI Mobile App Client
 * Conforms strictly to reference design specifications:
 * - App Name: PackSense AI
 * - Tagline: "Smarter Packaging. Fresher Food. A Greener Future."
 * - Footer Tag on Splash: "Powered by AI + Physics + Sustainability"
 * - Zero chat bubbles, zero streaming text, zero "AI assistant" persona
 * - Palette:
 *     gradientStart: #1565C0, gradientEnd: #42A5F5
 *     primary: #1E88E5, primaryDark: #1565C0, primaryTint: #E8F1FD
 *     background: #F4F8FC, surface: #FFFFFF
 *     textPrimary: #0F1C2E, textSecondary: #6B7A90
 *     success: #2E9E5B, successTint: #E3F5EA
 *     warning: #F59E0B, warningTint: #FCF1DD
 *     danger: #DC2626, border: #E3E9F2
 * - Core Reusable Components:
 *     GradientHeroCard, SettingsGridTile, StatusBadge, SegmentedTabBar,
 *     StatRow, RadioSelectCard, LineChartCard, GasStatCircle, InfoBar,
 *     ProfileMenuRow, PrimaryButton, BottomNavShell
 */

import React, { useState } from 'react';
import {
  Smartphone,
  Scan,
  QrCode,
  Camera,
  Mic,
  History as HistoryIcon,
  BookOpen,
  User,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Download,
  ExternalLink,
  Layers,
  Thermometer,
  Wind,
  Droplets,
  DollarSign,
  Building,
  Settings,
  Flame,
  FileText,
  Boxes,
  Maximize2,
  Wifi,
  WifiOff,
  Sun,
  Activity,
  Award,
  ChevronRight,
  TrendingUp,
  Check
} from 'lucide-react';

interface PackSenseMobileClientProps {
  currentUserRole: string;
  onRoleChange: (role: string) => void;
}

export const PackSenseMobileClient: React.FC<PackSenseMobileClientProps> = ({
  currentUserRole,
  onRoleChange
}) => {
  // Navigation & View States
  const [activeBottomTab, setActiveBottomTab] = useState<'home' | 'history' | 'learn' | 'profile'>('home');
  const [showSplashOnboarding, setShowSplashOnboarding] = useState<boolean>(false);
  const [onboardingStep, setOnboardingStep] = useState<number>(0);
  const [currentLang, setCurrentLang] = useState<'en' | 'hi' | 'mr' | 'ta'>('en');

  // Recommendation SegmentedTabBar State
  // 0: Shelf Life, 1: Gas Dynamics, 2: Temperature & Climate
  const [recommendationTab, setRecommendationTab] = useState<number>(0);

  // Scanner States
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [selectedCrop, setSelectedCrop] = useState<string>('potato_chips');
  const [detectedMaterial, setDetectedMaterial] = useState<string>('BOPP 20µm / Met-PET 12µm / LDPE 40µm');
  const [shelfLifeDays, setShelfLifeDays] = useState<number>(78);
  const [detectedOtr, setDetectedOtr] = useState<number>(1.2);
  const [detectedWvtr, setDetectedWvtr] = useState<number>(0.8);
  const [pouchCost, setPouchCost] = useState<number>(3.85);
  const [isCompliant, setIsCompliant] = useState<boolean>(true);

  // Secondary Options State
  const [isVoiceListening, setIsVoiceListening] = useState<boolean>(false);
  const [voiceTranscript, setVoiceTranscript] = useState<string>('');

  // 23 Backend Features Switcher
  const [activeFeatureView, setActiveFeatureView] = useState<string | null>(null);
  const [featurePillTab, setFeaturePillTab] = useState<number>(0);

  // Device framing toggle
  const [isExpandedView, setIsExpandedView] = useState<boolean>(false);

  // Multilingual Strings
  const strings: Record<string, Record<string, string>> = {
    en: {
      appName: 'PackSense AI',
      tagline: 'Smarter Packaging. Fresher Food. A Greener Future.',
      footerTag: 'Powered by AI + Physics + Sustainability',
      homeTab: 'Home',
      historyTab: 'History',
      learnTab: 'Learn',
      profileTab: 'Profile',
      heroScanTitle: 'Scan Barcode / Label',
      heroScanSubtitle: 'Point camera at any pouch or label to analyze film barrier specs instantly.',
      heroScanBtn: 'Scan Now',
      heroScanningBtn: 'Analyzing...',
      infoBarTip: 'Simulation based on Indian climate & FSSAI IS 9845 migration standards.',
      recTitle: 'AI Recommendation',
      verifiedBadge: 'Verified',
      balancedBadge: 'Balanced',
      tabShelfLife: 'Shelf Life',
      tabGasDynamics: 'Gas Dynamics',
      tabTemperature: 'Temperature',
      otrLabel: 'Oxygen Transmission Rate (OTR)',
      wvtrLabel: 'Water Vapor Transmission Rate (WVTR)',
      shelfLifeLabel: 'Predicted Shelf Life',
      costLabel: 'Estimated Unit Packaging Cost',
      getStarted: 'Get Started',
      enterConsole: 'Enter Scanner Console'
    },
    hi: {
      appName: 'पैकसेंस AI',
      tagline: 'स्मार्ट पैकेजिंग। ताज़ा भोजन। हरित भविष्य।',
      footerTag: 'AI + भौतिकी + पर्यावरण स्थिरता द्वारा संचालित',
      homeTab: 'होम',
      historyTab: 'इतिहास',
      learnTab: 'सीखें',
      profileTab: 'प्रोफाइल',
      heroScanTitle: 'बारकोड / लेबल स्कैन करें',
      heroScanSubtitle: 'फिल्म बैरियर विनिर्देशों का तुरंत विश्लेषण करने के लिए कैमरा रखें।',
      heroScanBtn: 'अभी स्कैन करें',
      heroScanningBtn: 'विश्लेषण जारी है...',
      infoBarTip: 'भारतीय जलवायु और FSSAI IS 9845 मानकों पर आधारित सिमुलेशन।',
      recTitle: 'AI सिफ़ारिश (Recommendation)',
      verifiedBadge: 'सत्यापित (Verified)',
      balancedBadge: 'संतुलित (Balanced)',
      tabShelfLife: 'शेल्फ लाइफ',
      tabGasDynamics: 'गैस गतिशीलता',
      tabTemperature: 'तापमान',
      otrLabel: 'ऑक्सीजन ट्रांसमिशन दर (OTR)',
      wvtrLabel: 'जल वाष्प दर (WVTR)',
      shelfLifeLabel: 'अनुमानित शेल्फ लाइफ',
      costLabel: 'अनुमानित पैकेजिंग लागत',
      getStarted: 'शुरू करें',
      enterConsole: 'स्कैनर में प्रवेश करें'
    },
    mr: {
      appName: 'पॅकसेंस AI',
      tagline: 'स्मार्ट पॅकेजिंग. ताजे अन्न. हरित भविष्य.',
      footerTag: 'AI + भौतिकशास्त्र + पर्यावरण पूरकतेवर आधारित',
      homeTab: 'होम',
      historyTab: 'इतिहास',
      learnTab: 'मार्गदर्शक',
      profileTab: 'प्रोफाईल',
      heroScanTitle: 'बारकोड / लेबल स्कॅन करा',
      heroScanSubtitle: 'फिल्म बॅरियर गुणधर्म तात्काळ तपासण्यासाठी कॅमेरा रोखा.',
      heroScanBtn: 'आता स्कॅन करा',
      heroScanningBtn: 'विश्लेषण सुरू आहे...',
      infoBarTip: 'भारतीय हवामान आणि FSSAI IS 9845 निकषांवर आधारित सिम्युलेशन.',
      recTitle: 'AI शिफारस (Recommendation)',
      verifiedBadge: 'प्रमाणित (Verified)',
      balancedBadge: 'संतुलित (Balanced)',
      tabShelfLife: 'शेल्फ लाईफ',
      tabGasDynamics: 'वायू संतुलन',
      tabTemperature: 'तापमान',
      otrLabel: 'ऑक्सिजन दर (OTR)',
      wvtrLabel: 'ओलावा दर (WVTR)',
      shelfLifeLabel: 'अपेक्षित टिकवण क्षमता',
      costLabel: 'अंदाजे पॅकेजिंग खर्च',
      getStarted: 'सुरू करा',
      enterConsole: 'कन्सोल सुरू करा'
    },
    ta: {
      appName: 'பேக்சென்ஸ் AI',
      tagline: 'சிறந்த பேக்கேஜிங். புதிய உணவு. பசுமையான எதிர்காலம்.',
      footerTag: 'AI + இயற்பியல் + நிலைத்தன்மை மூலம் இயக்கப்படுகிறது',
      homeTab: 'முகப்பு',
      historyTab: 'வரலாறு',
      learnTab: 'கற்க',
      profileTab: 'சுயவிவரம்',
      heroScanTitle: 'பார்கோடு / லேபிளை ஸ்கேன் செய்க',
      heroScanSubtitle: 'பிலிம் பண்புகளை உடனடியாக பகுப்பாய்வு செய்ய கேமராவை வைக்கவும்.',
      heroScanBtn: 'இப்போது ஸ்கேன் செய்க',
      heroScanningBtn: 'ஆய்வு நடக்கிறது...',
      infoBarTip: 'இந்திய காலநிலை மற்றும் FSSAI IS 9845 தரநிலைகளின் அடிப்படையிலானது.',
      recTitle: 'AI பரிந்துரை',
      verifiedBadge: 'சரிபார்க்கப்பட்டது',
      balancedBadge: 'சமநிலையானது',
      tabShelfLife: 'அடுக்கு ஆயுள்',
      tabGasDynamics: 'வாயு சமநிலை',
      tabTemperature: 'வெப்பநிலை',
      otrLabel: 'ஆக்சிஜன் வீதம் (OTR)',
      wvtrLabel: 'ஈரப்பதம் வீதம் (WVTR)',
      shelfLifeLabel: 'கணிக்கப்பட்ட ஆயுள்',
      costLabel: 'மதிப்பிடப்பட்ட விலை',
      getStarted: 'தொடங்குங்கள்',
      enterConsole: 'ஸ்கேனரைத் திறக்கவும்'
    }
  };

  const t = strings[currentLang] || strings['en'];

  // Scan Action Simulator
  const handleTriggerScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setDetectedMaterial('BOPP 20µm / Met-PET 12µm / LDPE 40µm (ASTM D3985)');
      setShelfLifeDays(78);
      setDetectedOtr(1.2);
      setDetectedWvtr(0.8);
      setPouchCost(3.85);
      setIsCompliant(true);
    }, 650);
  };

  // Voice Action Simulator
  const handleVoiceToggle = () => {
    setIsVoiceListening(!isVoiceListening);
    if (!isVoiceListening) {
      setVoiceTranscript('Listening via Bhashini Indic Speech Recognition...');
      setTimeout(() => {
        setIsVoiceListening(false);
        setVoiceTranscript('Recognized: "Check shelf life for Alphonso Mango in ZECC chamber"');
        setSelectedCrop('alphonso_mango');
        setShelfLifeDays(21);
      }, 1400);
    }
  };

  // History sample records
  const historyItems = [
    {
      date: 'Today, 11:42 AM',
      produce: 'Potato Chips (150g Pouch)',
      material: 'BOPP 20µm / Met-PET 12µm / LDPE 40µm',
      shelfLife: '78 Days',
      status: 'Verified',
      pass: true
    },
    {
      date: 'Yesterday, 04:15 PM',
      produce: 'Alphonso Mango (4-pack Tray)',
      material: 'Micro-perforated LDPE 30µm',
      shelfLife: '18 Days',
      status: 'Optimal MAP',
      pass: true
    },
    {
      date: '26 Sep 2026',
      produce: 'Tomato Puree Pouch (200g)',
      material: 'PET 12µm / Al-Foil 7µm / CPP 40µm',
      shelfLife: '180 Days',
      status: 'Compliant',
      pass: true
    },
    {
      date: '24 Sep 2026',
      produce: 'Basmati Rice (1kg)',
      material: 'Monolayer LDPE 40µm Non-barrier',
      shelfLife: '35 Days',
      status: 'Moisture Risk',
      pass: false
    }
  ];

  return (
    <div className="py-6 px-3 flex flex-col items-center justify-center min-h-[calc(100vh-80px)] bg-slate-100">
      {/* Top Banner / Device Bar */}
      <div className="w-full max-w-4xl flex flex-wrap items-center justify-between gap-3 mb-4 bg-white border border-[#E3E9F2] rounded-xl px-4 py-3 shadow-sm text-xs">
        <div className="flex items-center space-x-3">
          <div className="p-1.5 bg-[#E8F1FD] text-[#1E88E5] rounded-lg border border-[#B3D4FC] flex items-center space-x-1.5 font-bold font-mono">
            <Smartphone className="w-4 h-4 text-[#1E88E5]" />
            <span>PACKSENSE AI FLUTTER CLIENT</span>
          </div>
          <span className="text-[#6B7A90] hidden md:inline">
            Industrial engineering cards, forms, charts · Soft blue-grey (#F4F8FC) · Persistent 4-tab bar
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Splash / Onboarding Toggle */}
          <button
            onClick={() => setShowSplashOnboarding(!showSplashOnboarding)}
            className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center space-x-1 transition-colors ${
              showSplashOnboarding
                ? 'bg-[#1E88E5] text-white border-[#1E88E5] shadow-sm'
                : 'bg-slate-50 text-[#0F1C2E] border-[#E3E9F2] hover:bg-slate-100'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{showSplashOnboarding ? 'Exit Splash View' : 'View Splash Screen'}</span>
          </button>

          {/* Viewport Width Toggle */}
          <button
            onClick={() => setIsExpandedView(!isExpandedView)}
            className="p-1.5 bg-slate-50 hover:bg-slate-100 border border-[#E3E9F2] rounded-lg text-[#6B7A90]"
            title="Toggle Expanded View"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile Device Mockup / Surface Container */}
      <div
        className={`w-full transition-all duration-300 ${
          isExpandedView ? 'max-w-2xl' : 'max-w-[420px]'
        } bg-[#F4F8FC] rounded-[36px] border-[8px] border-[#0F1C2E] shadow-2xl overflow-hidden flex flex-col min-h-[780px] relative`}
      >
        {/* Phone Notch & Status Bar */}
        <div className="bg-[#0F1C2E] pt-2 pb-1 px-6 flex items-center justify-between text-slate-300 text-[10px] select-none">
          <div className="flex items-center space-x-1">
            <span className="font-semibold">09:41</span>
            <span className="text-slate-400">· 5G</span>
          </div>
          <div className="w-16 h-1.5 bg-slate-700 rounded-full" />
          <div className="flex items-center space-x-1.5">
            <Wifi className="w-3 h-3 text-[#2E9E5B]" />
            <span>100%</span>
          </div>
        </div>

        {/* SCREEN CONTENT AREA */}
        {showSplashOnboarding ? (
          /* ==================================================================== */
          /* 1. BLUE-GRADIENT SPLASH / ONBOARDING SCREEN                          */
          /* ==================================================================== */
          <div className="flex-1 flex flex-col bg-[#F4F8FC]">
            {onboardingStep === 0 ? (
              <div className="flex-1 flex flex-col">
                {/* Blue Gradient Header Hero: #1565C0 to #42A5F5 */}
                <div className="bg-gradient-to-br from-[#1565C0] to-[#42A5F5] p-6 pb-8 rounded-b-[28px] text-white shadow-md">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg text-[#1E88E5]">
                      <Scan className="w-6 h-6 text-[#1E88E5]" />
                    </div>
                    <div className="flex items-center space-x-1 bg-white/20 backdrop-blur-sm px-2.5 py-1 rounded-full text-[10px] font-bold border border-white/30">
                      <ShieldCheck className="w-3.5 h-3.5 text-white" />
                      <span>ISO 15105 / ASTM D3985</span>
                    </div>
                  </div>
                  <h1 className="text-2xl font-black tracking-tight">{t.appName}</h1>
                  <p className="text-sky-100 text-xs font-semibold mt-1">{t.tagline}</p>
                  <p className="text-white/90 text-xs mt-2 leading-relaxed">
                    Deterministic food packaging simulation, barrier optimization, and scan-first diagnostics.
                  </p>
                </div>

                {/* Body: White Rounded Cards on Soft Blue-Grey Background */}
                <div className="p-4 space-y-3 flex-1 overflow-y-auto">
                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-full bg-[#E8F1FD] flex items-center justify-center text-[#1E88E5] shrink-0">
                      <Scan className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#0F1C2E]">Scan-First Film & Barrier Detection</h4>
                      <p className="text-[11px] text-[#6B7A90] mt-0.5 leading-snug">
                        Point camera at any pouch or packaging label for instant OTR/WVTR & FSSAI check.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-full bg-[#E8F1FD] flex items-center justify-center text-[#1E88E5] shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#0F1C2E]">Multi-Objective Physics Optimizer</h4>
                      <p className="text-[11px] text-[#6B7A90] mt-0.5 leading-snug">
                        Balance shelf life, material cost (₹/m²), and sustainability on the Pareto frontier.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-full bg-[#E3F5EA] flex items-center justify-center text-[#2E9E5B] shrink-0">
                      <WifiOff className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#0F1C2E]">Offline-Ready for Farm & Factory</h4>
                      <p className="text-[11px] text-[#6B7A90] mt-0.5 leading-snug">
                        Full deterministic physics calculations run locally without internet connectivity.
                      </p>
                    </div>
                  </div>

                  {/* Language Pills */}
                  <div className="pt-2">
                    <div className="text-[10px] font-mono font-bold text-[#6B7A90] mb-1.5 uppercase">Language</div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { code: 'en', label: 'English' },
                        { code: 'hi', label: 'हिंदी' },
                        { code: 'mr', label: 'मराठी' },
                        { code: 'ta', label: 'தமிழ்' }
                      ].map((item) => (
                        <button
                          key={item.code}
                          onClick={() => setCurrentLang(item.code as any)}
                          className={`py-1.5 text-xs font-bold rounded-full border transition-colors ${
                            currentLang === item.code
                              ? 'bg-[#1E88E5] text-white border-[#1E88E5] shadow-sm'
                              : 'bg-white text-[#6B7A90] border-[#E3E9F2] hover:border-[#1E88E5]'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Action Button & Tag */}
                <div className="p-4 bg-white/80 border-t border-[#E3E9F2]">
                  {/* PrimaryButton style: full-width, #1E88E5, 24px radius, bold white text */}
                  <button
                    onClick={() => setOnboardingStep(1)}
                    className="w-full py-3 bg-[#1E88E5] hover:bg-[#1565C0] text-white font-bold text-sm rounded-[24px] shadow-md transition-all flex items-center justify-center space-x-2"
                  >
                    <span>{t.getStarted}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  {/* Footer Tag on Splash */}
                  <div className="text-center text-[10px] text-[#6B7A90] font-semibold mt-3">
                    {t.footerTag}
                  </div>
                </div>
              </div>
            ) : (
              /* Step 1: Role Configuration with RadioSelectCards */
              <div className="flex-1 flex flex-col p-4 overflow-y-auto">
                <div className="flex items-center space-x-2 mb-3">
                  <button
                    onClick={() => setOnboardingStep(0)}
                    className="p-1.5 rounded-lg bg-white border border-[#E3E9F2] text-[#6B7A90]"
                  >
                    <ChevronDown className="w-4 h-4 rotate-90" />
                  </button>
                  <h3 className="text-sm font-bold text-[#0F1C2E]">Select Operating Role</h3>
                </div>

                {/* RadioSelectCards */}
                <div className="space-y-2 flex-1">
                  {[
                    { id: 'farmer', title: 'Farmer / Grower', desc: 'Scan-first mode, voice queries, shelf-life, ZECC advice', icon: Sun },
                    { id: 'fpo', title: 'FPO Manager', desc: 'Aggregated crop batching, group film procurement, cold chain audit', icon: Boxes },
                    { id: 'msme', title: 'MSME Food Processor', desc: 'Pouch barrier selection, seal integrity testing, FSSAI IS 9845', icon: Building },
                    { id: 'industry', title: 'Packaging Engineer', desc: 'Full Arrhenius kinetics, gas diffusion curves, Pareto optimization', icon: Activity },
                    { id: 'government', title: 'MoFPI / Ag Officer', desc: 'District-level post-harvest food loss heatmaps, schemes', icon: Award },
                    { id: 'admin', title: 'System Administrator', desc: 'Master materials database CRUD, lab calibration constants', icon: Settings }
                  ].map((role) => {
                    const isSelected = currentUserRole.toLowerCase() === role.id;
                    return (
                      <div
                        key={role.id}
                        onClick={() => onRoleChange(role.id)}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center space-x-3 ${
                          isSelected
                            ? 'bg-[#E8F1FD]/60 border-[#1E88E5] shadow-sm'
                            : 'bg-white border-[#E3E9F2] hover:border-sky-300'
                        }`}
                      >
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-[#1E88E5] text-white' : 'bg-[#E8F1FD] text-[#1E88E5]'
                          }`}
                        >
                          <role.icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <div className="text-xs font-bold text-[#0F1C2E]">{role.title}</div>
                          <p className="text-[10px] text-[#6B7A90] mt-0.5 leading-snug">{role.desc}</p>
                        </div>
                        {/* Trailing Radio Circle */}
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            isSelected ? 'border-[#1E88E5]' : 'border-[#CBD5E1]'
                          }`}
                        >
                          {isSelected && <div className="w-2.5 h-2.5 bg-[#1E88E5] rounded-full" />}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-3">
                  <button
                    onClick={() => setShowSplashOnboarding(false)}
                    className="w-full py-3 bg-[#1E88E5] hover:bg-[#1565C0] text-white font-bold text-sm rounded-[24px] shadow-md transition-all"
                  >
                    {t.enterConsole}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* ==================================================================== */
          /* 2. MAIN APP: SCAN-FIRST HOME + 4 TABS                                */
          /* ==================================================================== */
          <div className="flex-1 flex flex-col justify-between overflow-hidden bg-[#F4F8FC]">
            {/* Top Bar Header */}
            <div className="bg-white border-b border-[#E3E9F2] px-4 py-2.5 flex items-center justify-between shadow-sm select-none">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                  <Scan className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-extrabold text-sm text-[#0F1C2E] tracking-tight leading-none">{t.appName}</div>
                  <div className="flex items-center space-x-1.5 mt-0.5">
                    <span className="text-[9px] font-mono font-bold text-[#1E88E5] uppercase">
                      {currentUserRole}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-[9px] font-mono font-semibold text-[#2E9E5B] flex items-center">
                      <span className="w-1.5 h-1.5 bg-[#2E9E5B] rounded-full inline-block mr-1" />
                      OFFLINE KERNEL
                    </span>
                  </div>
                </div>
              </div>

              {/* Language Selector */}
              <div className="flex items-center space-x-1">
                <select
                  value={currentLang}
                  onChange={(e) => setCurrentLang(e.target.value as any)}
                  className="bg-slate-50 border border-[#E3E9F2] rounded-lg px-2 py-1 text-[11px] font-bold text-[#0F1C2E] focus:outline-none focus:border-[#1E88E5]"
                >
                  <option value="en">EN</option>
                  <option value="hi">हिंदी</option>
                  <option value="mr">मराठी</option>
                  <option value="ta">தமிழ்</option>
                </select>
              </div>
            </div>

            {/* TAB CONTENTS CONTAINER */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {activeBottomTab === 'home' && (
                /* TAB 0: HOME SCREEN */
                <>
                  {/* 1. InfoBar */}
                  <div className="w-full bg-[#E8F1FD] border border-[#1E88E5]/20 rounded-xl px-3.5 py-2.5 flex items-center space-x-2.5">
                    <ShieldCheck className="w-4 h-4 text-[#1E88E5] shrink-0" />
                    <span className="text-[11px] text-[#0F1C2E] font-medium leading-snug">
                      {t.infoBarTip}
                    </span>
                  </div>

                  {/* 2. GradientHeroCard: The Big Rounded Blue-Gradient CTA Card */}
                  <div
                    onClick={handleTriggerScan}
                    className="cursor-pointer bg-gradient-to-br from-[#1565C0] to-[#42A5F5] rounded-[20px] p-5 text-white shadow-[0_6px_16px_rgba(21,101,192,0.3)] transition-transform active:scale-[0.99] flex items-center justify-between"
                  >
                    <div className="space-y-1 max-w-[70%]">
                      <h2 className="text-xl font-bold tracking-tight">{t.heroScanTitle}</h2>
                      <p className="text-xs text-white/90 leading-snug">{t.heroScanSubtitle}</p>
                      <div className="pt-2">
                        <span className="inline-flex items-center space-x-1.5 bg-white text-[#1565C0] text-[11px] font-bold px-3 py-1 rounded-full shadow-sm">
                          <Scan className="w-3.5 h-3.5" />
                          <span>{isScanning ? t.heroScanningBtn : t.heroScanBtn}</span>
                        </span>
                      </div>
                    </div>
                    {/* Floating Right Circle Icon */}
                    <div className="w-16 h-16 rounded-full bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
                      <Scan className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  {/* 3. SettingsGridTile (2x2 Grid) */}
                  <div>
                    <div className="text-[10px] font-mono font-bold text-[#6B7A90] uppercase mb-1.5 tracking-wider">
                      Quick Shortcuts
                    </div>
                    <div className="grid grid-cols-2 gap-2.5">
                      {/* Tile 1: History */}
                      <div
                        onClick={() => setActiveBottomTab('history')}
                        className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] cursor-pointer hover:border-[#1E88E5] transition-all flex flex-col justify-between"
                      >
                        <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center mb-3">
                          <HistoryIcon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">My History</div>
                          <div className="text-[10px] text-[#6B7A90]">Past audits & scans</div>
                        </div>
                      </div>

                      {/* Tile 2: Learn */}
                      <div
                        onClick={() => setActiveBottomTab('learn')}
                        className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] cursor-pointer hover:border-[#1E88E5] transition-all flex flex-col justify-between"
                      >
                        <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center mb-3">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Learn</div>
                          <div className="text-[10px] text-[#6B7A90]">OTR / WVTR guide</div>
                        </div>
                      </div>

                      {/* Tile 3: Rupee Impact */}
                      <div
                        onClick={() => {
                          setActiveFeatureView('rupee');
                          setFeaturePillTab(0);
                        }}
                        className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] cursor-pointer hover:border-[#1E88E5] transition-all flex flex-col justify-between"
                      >
                        <div className="w-9 h-9 rounded-full bg-[#E3F5EA] text-[#2E9E5B] flex items-center justify-center mb-3">
                          <DollarSign className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Rupee Impact</div>
                          <div className="text-[10px] text-[#6B7A90]">Food waste ROI (₹)</div>
                        </div>
                      </div>

                      {/* Tile 4: Rural ZECC */}
                      <div
                        onClick={() => {
                          setActiveFeatureView('rural');
                          setFeaturePillTab(0);
                        }}
                        className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] cursor-pointer hover:border-[#1E88E5] transition-all flex flex-col justify-between"
                      >
                        <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center mb-3">
                          <Droplets className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Rural ZECC</div>
                          <div className="text-[10px] text-[#6B7A90]">Evaporative chamber</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 4. AI Recommendation Card */}
                  <div className="bg-white rounded-2xl p-4 border border-[#E3E9F2] shadow-[0_2px_10px_rgba(15,28,46,0.04)]">
                    <div className="flex items-center justify-between mb-1.5">
                      <h3 className="text-sm font-bold text-[#0F1C2E]">{t.recTitle}</h3>
                      {/* StatusBadge: Green (successTint bg, success text) */}
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#E3F5EA] text-[#2E9E5B]">
                        <CheckCircle2 className="w-3 h-3 text-[#2E9E5B]" />
                        <span>{t.verifiedBadge}</span>
                      </span>
                    </div>

                    <div className="text-xs font-semibold text-[#1565C0] mb-3">
                      {detectedMaterial}
                    </div>

                    {/* SegmentedTabBar: Pill-style tab row */}
                    <div className="flex space-x-1.5 overflow-x-auto pb-1 mb-3">
                      {[
                        { id: 0, label: t.tabShelfLife },
                        { id: 1, label: t.tabGasDynamics },
                        { id: 2, label: t.tabTemperature }
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setRecommendationTab(tab.id)}
                          className={`px-3.5 py-1.5 text-xs rounded-full font-semibold transition-all whitespace-nowrap ${
                            recommendationTab === tab.id
                              ? 'bg-[#1E88E5] text-white shadow-sm'
                              : 'bg-transparent text-[#6B7A90] border border-[#E3E9F2] hover:border-[#1E88E5]'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* Tab 0: Shelf Life StatRows */}
                    {recommendationTab === 0 && (
                      <div className="space-y-2">
                        {/* StatRow: Shelf Life */}
                        <div className="flex items-center justify-between py-1.5 border-b border-[#E3E9F2]/60">
                          <div className="flex items-center space-x-3">
                            <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                              <Activity className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-[10px] text-[#6B7A90] font-medium">{t.shelfLifeLabel}</div>
                              <div className="text-sm font-bold text-[#0F1C2E]">
                                {shelfLifeDays} <span className="text-[11px] font-normal text-[#6B7A90]">Days at 25°C 70% RH</span>
                              </div>
                            </div>
                          </div>
                          {/* StatusBadge: Balanced */}
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E3F5EA] text-[#2E9E5B]">
                            {t.balancedBadge}
                          </span>
                        </div>

                        {/* StatRow: OTR */}
                        <div className="flex items-center space-x-3 py-1.5 border-b border-[#E3E9F2]/60">
                          <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                            <Wind className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-[10px] text-[#6B7A90] font-medium">{t.otrLabel}</div>
                            <div className="text-sm font-bold text-[#0F1C2E]">
                              {detectedOtr} <span className="text-[11px] font-normal text-[#6B7A90]">cc/m²·day</span>
                            </div>
                          </div>
                        </div>

                        {/* StatRow: WVTR */}
                        <div className="flex items-center space-x-3 py-1.5 border-b border-[#E3E9F2]/60">
                          <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                            <Droplets className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-[10px] text-[#6B7A90] font-medium">{t.wvtrLabel}</div>
                            <div className="text-sm font-bold text-[#0F1C2E]">
                              {detectedWvtr} <span className="text-[11px] font-normal text-[#6B7A90]">g/m²·day</span>
                            </div>
                          </div>
                        </div>

                        {/* StatRow: Cost */}
                        <div className="flex items-center space-x-3 py-1.5">
                          <div className="w-9 h-9 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                            <DollarSign className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-[10px] text-[#6B7A90] font-medium">{t.costLabel}</div>
                            <div className="text-sm font-bold text-[#0F1C2E]">
                              ₹{pouchCost} <span className="text-[11px] font-normal text-[#6B7A90]">per pouch</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Tab 1: GasStatCircle (3-up row: O2 / CO2 / N2 %) */}
                    {recommendationTab === 1 && (
                      <div className="py-2">
                        <div className="text-[10px] font-mono font-bold text-[#6B7A90] uppercase mb-3 text-center">
                          Headspace Gas Composition (MAP Equilibrium)
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 rounded-full border-2 border-[#1E88E5]/40 bg-[#1E88E5]/10 flex items-center justify-center text-sm font-bold text-[#1E88E5]">
                              1.2%
                            </div>
                            <span className="text-[10px] font-semibold text-[#6B7A90] mt-1.5">Oxygen (O₂)</span>
                          </div>
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 rounded-full border-2 border-[#1565C0]/40 bg-[#1565C0]/10 flex items-center justify-center text-sm font-bold text-[#1565C0]">
                              18.5%
                            </div>
                            <span className="text-[10px] font-semibold text-[#6B7A90] mt-1.5">CO₂</span>
                          </div>
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 rounded-full border-2 border-[#2E9E5B]/40 bg-[#2E9E5B]/10 flex items-center justify-center text-sm font-bold text-[#2E9E5B]">
                              80.3%
                            </div>
                            <span className="text-[10px] font-semibold text-[#6B7A90] mt-1.5">Nitrogen (N₂)</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Tab 2: LineChartCard */}
                    {recommendationTab === 2 && (
                      <div className="py-2">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-bold text-[#0F1C2E]">Storage Temp vs Decay</span>
                          <span className="text-sm font-bold text-[#1E88E5]">78 Days</span>
                        </div>
                        {/* Simulated Clean Chart SVG */}
                        <div className="w-full h-32 bg-slate-50 border border-[#E3E9F2] rounded-xl p-2 flex flex-col justify-end">
                          <svg className="w-full h-24 overflow-visible" viewBox="0 0 300 80">
                            {/* Grid horizontal lines */}
                            <line x1="0" y1="20" x2="300" y2="20" stroke="#E3E9F2" strokeWidth="1" />
                            <line x1="0" y1="50" x2="300" y2="50" stroke="#E3E9F2" strokeWidth="1" />
                            {/* Standard curve (dashed) */}
                            <path
                              d="M 10 30 Q 80 50 150 65 T 290 75"
                              fill="none"
                              stroke="#6B7A90"
                              strokeWidth="2"
                              strokeDasharray="4,4"
                            />
                            {/* Recommended curve (solid primary) */}
                            <path
                              d="M 10 15 Q 80 20 150 35 T 290 55"
                              fill="none"
                              stroke="#1E88E5"
                              strokeWidth="2.5"
                            />
                          </svg>
                          <div className="flex justify-between text-[9px] text-[#6B7A90] pt-1 border-t border-[#E3E9F2]">
                            <span>10°C</span>
                            <span>25°C</span>
                            <span>35°C</span>
                            <span>45°C</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-center space-x-4 mt-2 text-[10px]">
                          <span className="flex items-center space-x-1 text-[#0F1C2E] font-semibold">
                            <span className="w-3 h-0.5 bg-[#1E88E5] inline-block" />
                            <span>Recommended Tri-Laminate</span>
                          </span>
                          <span className="flex items-center space-x-1 text-[#6B7A90]">
                            <span className="w-3 h-0.5 bg-[#6B7A90] border-t border-dashed inline-block" />
                            <span>Monolayer Baseline</span>
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Primary Button */}
                    <div className="pt-3">
                      <button
                        onClick={handleTriggerScan}
                        className="w-full py-2.5 bg-[#1E88E5] hover:bg-[#1565C0] text-white font-bold text-xs rounded-[24px] shadow-sm flex items-center justify-center space-x-2 transition-all"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Optimize Barrier Formulation</span>
                      </button>
                    </div>
                  </div>

                  {/* 5. Secondary Options (Voice & Produce Profile) */}
                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)]">
                    <div className="text-[10px] font-mono font-bold text-[#6B7A90] uppercase mb-2">
                      Secondary Inputs & Produce Profile
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={handleVoiceToggle}
                        className={`p-2.5 rounded-xl border font-bold text-xs flex items-center justify-center space-x-1.5 transition-colors ${
                          isVoiceListening
                            ? 'bg-rose-50 text-rose-600 border-rose-300 animate-pulse'
                            : 'bg-white text-[#1E88E5] border-[#B3D4FC] hover:bg-[#E8F1FD]'
                        }`}
                      >
                        <Mic className="w-3.5 h-3.5" />
                        <span className="truncate">{isVoiceListening ? 'Listening...' : 'Voice Query'}</span>
                      </button>

                      <select
                        value={selectedCrop}
                        onChange={(e) => {
                          setSelectedCrop(e.target.value);
                          if (e.target.value === 'alphonso_mango') {
                            setShelfLifeDays(21);
                            setDetectedMaterial('Micro-perforated LDPE 30µm');
                          } else {
                            setShelfLifeDays(78);
                            setDetectedMaterial('BOPP 20µm / Met-PET 12µm / LDPE 40µm');
                          }
                        }}
                        className="bg-slate-50 border border-[#E3E9F2] rounded-xl px-2.5 py-2 text-xs font-bold text-[#0F1C2E] focus:outline-none focus:border-[#1E88E5]"
                      >
                        <option value="potato_chips">Potato Chips (150g)</option>
                        <option value="alphonso_mango">Alphonso Mango</option>
                        <option value="tomato_puree">Tomato Puree Pouch</option>
                        <option value="basmati_rice">Basmati Rice (1kg)</option>
                      </select>
                    </div>

                    {voiceTranscript && (
                      <div className="mt-2 text-[10px] font-mono text-[#1565C0] bg-[#E8F1FD] p-2 rounded-lg border border-[#B3D4FC]">
                        {voiceTranscript}
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* MODAL / EMBEDDED VIEW FOR FEATURES */}
              {activeFeatureView && (
                <div className="bg-white rounded-2xl p-4 border border-[#E3E9F2] shadow-lg">
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#E3E9F2]">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <h4 className="text-xs font-bold text-[#0F1C2E] uppercase">
                        Feature: {activeFeatureView.toUpperCase()}
                      </h4>
                    </div>
                    <button
                      onClick={() => setActiveFeatureView(null)}
                      className="text-[#6B7A90] hover:text-[#0F1C2E] font-bold text-sm px-2"
                    >
                      ✕
                    </button>
                  </div>

                  {activeFeatureView === 'rupee' && (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-slate-50 p-2.5 rounded-xl border border-[#E3E9F2]">
                          <div className="text-[9px] font-mono text-[#6B7A90]">SAVINGS / SHIPMENT</div>
                          <div className="text-base font-black font-mono text-[#2E9E5B]">₹1,42,800</div>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded-xl border border-[#E3E9F2]">
                          <div className="text-[9px] font-mono text-[#6B7A90]">NET FINANCIAL ROI</div>
                          <div className="text-base font-black font-mono text-[#1E88E5]">9.05x</div>
                        </div>
                      </div>
                      <p className="text-[11px] text-[#6B7A90] leading-relaxed">
                        Transitioning to 3-ply high-barrier laminate prevents produce spoilage loss, paying back the film cost within 12 days.
                      </p>
                    </div>
                  )}

                  {activeFeatureView === 'rural' && (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-slate-50 p-2.5 rounded-xl border border-[#E3E9F2]">
                          <div className="text-[9px] font-mono text-[#6B7A90]">TEMP REDUCTION</div>
                          <div className="text-base font-black font-mono text-[#1E88E5]">10-15°C</div>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded-xl border border-[#E3E9F2]">
                          <div className="text-[9px] font-mono text-[#6B7A90]">GRID ELECTRICITY</div>
                          <div className="text-base font-black font-mono text-[#2E9E5B]">0 kWh</div>
                        </div>
                      </div>
                      <p className="text-[11px] text-[#6B7A90] leading-relaxed">
                        Double-brick ZECC chamber with saturated sand walls uses natural evaporative cooling for off-grid farm storage.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeBottomTab === 'history' && (
                /* TAB 1: HISTORY TAB */
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="text-sm font-bold text-[#0F1C2E]">{t.historyTab}</h3>
                    <span className="text-[10px] font-mono bg-[#E8F1FD] text-[#1E88E5] px-2 py-0.5 rounded-full border border-[#B3D4FC]">
                      {historyItems.length} Audits
                    </span>
                  </div>

                  {historyItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)]"
                    >
                      <div className="flex items-center justify-between text-[10px] text-[#6B7A90] mb-1">
                        <span>{item.date}</span>
                        <span
                          className={`font-mono font-bold px-2 py-0.5 rounded-full text-[10px] ${
                            item.pass ? 'bg-[#E3F5EA] text-[#2E9E5B]' : 'bg-red-50 text-red-600'
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-[#0F1C2E]">{item.produce}</div>
                      <div className="text-[11px] text-[#6B7A90] mt-0.5 truncate">{item.material}</div>
                      <div className="mt-2 flex items-center justify-between pt-2 border-t border-[#E3E9F2] text-[11px]">
                        <span className="text-[#6B7A90]">Predicted Life:</span>
                        <span className="font-mono font-bold text-[#1E88E5]">{item.shelfLife}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeBottomTab === 'learn' && (
                /* TAB 2: LEARN TAB */
                <div className="space-y-2.5">
                  <h3 className="text-sm font-bold text-[#0F1C2E] mb-1">{t.learnTab}</h3>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)]">
                    <div className="flex items-center space-x-2 text-[#1E88E5] font-bold text-xs mb-1">
                      <div className="w-7 h-7 rounded-full bg-[#E8F1FD] flex items-center justify-center">
                        <Wind className="w-3.5 h-3.5" />
                      </div>
                      <span>OTR (Oxygen Transmission Rate)</span>
                    </div>
                    <p className="text-[11px] text-[#6B7A90] leading-relaxed">
                      Measured in cc/m²·day. High OTR accelerates oil oxidation, rancidity, and enzymatic browning. Keep &lt; 2.0 for roasted snacks.
                    </p>
                  </div>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)]">
                    <div className="flex items-center space-x-2 text-[#1E88E5] font-bold text-xs mb-1">
                      <div className="w-7 h-7 rounded-full bg-[#E8F1FD] flex items-center justify-center">
                        <Droplets className="w-3.5 h-3.5" />
                      </div>
                      <span>WVTR (Water Vapor Transmission Rate)</span>
                    </div>
                    <p className="text-[11px] text-[#6B7A90] leading-relaxed">
                      Measured in g/m²·day. Prevents moisture ingress from humidity. Moisture gain &gt; 4.5% causes sogginess and loss of crunch.
                    </p>
                  </div>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)]">
                    <div className="flex items-center space-x-2 text-[#1E88E5] font-bold text-xs mb-1">
                      <div className="w-7 h-7 rounded-full bg-[#E8F1FD] flex items-center justify-center">
                        <Award className="w-3.5 h-3.5" />
                      </div>
                      <span>FSSAI IS 9845 Regulatory Standard</span>
                    </div>
                    <p className="text-[11px] text-[#6B7A90] leading-relaxed">
                      Mandates overall migration &lt; 10 mg/dm² into food simulants. All food contact films must adhere to BIS Indian safety standards.
                    </p>
                  </div>
                </div>
              )}

              {activeBottomTab === 'profile' && (
                /* TAB 3: PROFILE TAB (ProfileMenuRows) */
                <div className="space-y-3">
                  <h3 className="text-sm font-bold text-[#0F1C2E] mb-1">{t.profileTab}</h3>

                  <div className="bg-white rounded-2xl p-3.5 border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] flex items-center space-x-3">
                    <div className="w-11 h-11 bg-[#E8F1FD] text-[#1E88E5] rounded-full flex items-center justify-center font-bold">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[#0F1C2E]">Ramesh Patil</div>
                      <div className="text-[10px] font-mono font-bold text-[#1E88E5] uppercase">{currentUserRole}</div>
                      <div className="text-[10px] text-[#6B7A90]">Maharashtra Agro Cluster · Pune</div>
                    </div>
                  </div>

                  {/* ProfileMenuRows */}
                  <div className="bg-white rounded-2xl border border-[#E3E9F2] shadow-[0_2px_8px_rgba(15,28,46,0.04)] overflow-hidden">
                    {/* Menu Row 1: Role */}
                    <div className="p-3 border-b border-[#E3E9F2] flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                          <Settings className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Operational Role</div>
                          <div className="text-[10px] text-[#6B7A90] uppercase">{currentUserRole}</div>
                        </div>
                      </div>
                      <select
                        value={currentUserRole.toLowerCase()}
                        onChange={(e) => onRoleChange(e.target.value)}
                        className="bg-slate-50 border border-[#E3E9F2] rounded-lg px-2 py-1 text-xs font-bold text-[#1E88E5]"
                      >
                        {['farmer', 'fpo', 'msme', 'industry', 'government', 'admin'].map((r) => (
                          <option key={r} value={r}>
                            {r.toUpperCase()}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Menu Row 2: Offline Database */}
                    <div className="p-3 border-b border-[#E3E9F2] flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-[#E3F5EA] text-[#2E9E5B] flex items-center justify-center">
                          <WifiOff className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Offline Database Cache</div>
                          <div className="text-[10px] text-[#6B7A90]">30 Substrates Indexed</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#6B7A90]" />
                    </div>

                    {/* Menu Row 3: Standards */}
                    <div className="p-3 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-[#E8F1FD] text-[#1E88E5] flex items-center justify-center">
                          <Award className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-[#0F1C2E]">Standards & Compliance</div>
                          <div className="text-[10px] text-[#6B7A90]">ASTM D3985 / IS 9845</div>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#6B7A90]" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 4-TAB BOTTOM NAVIGATION BAR (Home / History / Learn / Profile) */}
            <div className="bg-white border-t border-[#E3E9F2] px-2 py-2 flex items-center justify-around shadow-[0_-3px_10px_rgba(15,28,46,0.03)] select-none">
              <button
                onClick={() => setActiveBottomTab('home')}
                className={`flex flex-col items-center py-1 px-3 rounded-xl transition-all ${
                  activeBottomTab === 'home' ? 'text-[#1E88E5]' : 'text-[#6B7A90] hover:text-[#0F1C2E]'
                }`}
              >
                <div
                  className={`p-1 rounded-full ${
                    activeBottomTab === 'home' ? 'bg-[#E8F1FD] text-[#1E88E5]' : ''
                  }`}
                >
                  <Scan className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold mt-0.5">{t.homeTab}</span>
              </button>

              <button
                onClick={() => setActiveBottomTab('history')}
                className={`flex flex-col items-center py-1 px-3 rounded-xl transition-all ${
                  activeBottomTab === 'history' ? 'text-[#1E88E5]' : 'text-[#6B7A90] hover:text-[#0F1C2E]'
                }`}
              >
                <div
                  className={`p-1 rounded-full ${
                    activeBottomTab === 'history' ? 'bg-[#E8F1FD] text-[#1E88E5]' : ''
                  }`}
                >
                  <HistoryIcon className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold mt-0.5">{t.historyTab}</span>
              </button>

              <button
                onClick={() => setActiveBottomTab('learn')}
                className={`flex flex-col items-center py-1 px-3 rounded-xl transition-all ${
                  activeBottomTab === 'learn' ? 'text-[#1E88E5]' : 'text-[#6B7A90] hover:text-[#0F1C2E]'
                }`}
              >
                <div
                  className={`p-1 rounded-full ${
                    activeBottomTab === 'learn' ? 'bg-[#E8F1FD] text-[#1E88E5]' : ''
                  }`}
                >
                  <BookOpen className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold mt-0.5">{t.learnTab}</span>
              </button>

              <button
                onClick={() => setActiveBottomTab('profile')}
                className={`flex flex-col items-center py-1 px-3 rounded-xl transition-all ${
                  activeBottomTab === 'profile' ? 'text-[#1E88E5]' : 'text-[#6B7A90] hover:text-[#0F1C2E]'
                }`}
              >
                <div
                  className={`p-1 rounded-full ${
                    activeBottomTab === 'profile' ? 'bg-[#E8F1FD] text-[#1E88E5]' : ''
                  }`}
                >
                  <User className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold mt-0.5">{t.profileTab}</span>
              </button>
            </div>
          </div>
        )}

        {/* Bottom Home Indicator */}
        <div className="bg-white pb-2 pt-1 flex justify-center">
          <div className="w-28 h-1 bg-slate-300 rounded-full" />
        </div>
      </div>
    </div>
  );
};
