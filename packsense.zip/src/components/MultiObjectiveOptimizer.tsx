import React, { useState, useMemo } from 'react';
import {
  Cpu,
  Target,
  Sliders,
  DollarSign,
  Leaf,
  Recycle,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  Sparkles,
  Info
} from 'lucide-react';
import { FoodProduct, FOODS_DATABASE } from '../engine/foodsDb.ts';
import {
  PackageGeometry,
  SimulationConditions,
  LaminateLayerInput,
  MapGasConfig
} from '../engine/physics.ts';
import {
  OptimizationPreferences,
  OptimizationResult,
  EvaluatedPackagingCandidate,
  runPackagingOptimization
} from '../engine/optimizer.ts';

interface MultiObjectiveOptimizerProps {
  currentFoodId: string;
  setCurrentFoodId: (id: string) => void;
  geometry: PackageGeometry;
  conditions: SimulationConditions;
  onApplyCandidate: (candidate: EvaluatedPackagingCandidate) => void;
}

export const MultiObjectiveOptimizer: React.FC<MultiObjectiveOptimizerProps> = ({
  currentFoodId,
  setCurrentFoodId,
  geometry,
  conditions,
  onApplyCandidate
}) => {
  const currentFood = useMemo(() => {
    return FOODS_DATABASE.find(f => f.id === currentFoodId) || FOODS_DATABASE[0];
  }, [currentFoodId]);

  const [targetShelfLife, setTargetShelfLife] = useState<number>(currentFood.target_shelf_life_days);
  const [priority, setPriority] = useState<OptimizationPreferences['prioritize']>('balanced');
  const [minRecyclability, setMinRecyclability] = useState<number>(0);
  const [hoveredCandidate, setHoveredCandidate] = useState<EvaluatedPackagingCandidate | null>(null);
  const [selectedCandidate, setSelectedCandidate] = useState<EvaluatedPackagingCandidate | null>(null);

  // Run deterministic optimizer
  const optResult: OptimizationResult = useMemo(() => {
    const prefs: OptimizationPreferences = {
      target_shelf_life_days: targetShelfLife,
      min_recyclability_score: minRecyclability,
      prioritize: priority
    };
    return runPackagingOptimization(currentFood, geometry, conditions, prefs);
  }, [currentFood, geometry, conditions, targetShelfLife, minRecyclability, priority]);

  const recommendations = optResult.recommendations;
  const activeCandidate = selectedCandidate || recommendations.balanced;

  // Scatter plot geometry
  // X axis: Cost per pack ($0.01 to max)
  // Y axis: Carbon footprint per pack (g CO2e)
  const allCandidates = optResult.all_candidates;
  const maxCost = Math.max(0.1, ...allCandidates.map(c => c.cost_per_pack_usd));
  const maxCarbon = Math.max(5, ...allCandidates.map(c => c.carbon_per_pack_g_co2e));

  const svgWidth = 620;
  const svgHeight = 280;
  const pad = { top: 25, right: 35, bottom: 40, left: 55 };
  const plotW = svgWidth - pad.left - pad.right;
  const plotH = svgHeight - pad.top - pad.bottom;

  const getX = (cost: number) => pad.left + (cost / maxCost) * plotW;
  const getY = (carbon: number) => pad.top + plotH - (carbon / maxCarbon) * plotH;

  return (
    <div className="space-y-6">
      {/* Control Panel: Engineering Goal & Optimizer Settings */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Multi-Objective Packaging Optimizer (Pareto Frontier)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Evaluates non-dominated trade-offs across shelf life, unit cost, carbon footprint, and circularity.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
              Permutations: <strong className="text-emerald-400">{optResult.all_candidates_count}</strong>
            </span>
            <span className="px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-850/80 text-emerald-300">
              Pareto Optimal: <strong>{optResult.pareto_frontier_count} Solutions</strong>
            </span>
          </div>
        </div>

        {/* Inputs & Priority Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-slate-800 text-xs">
          <div>
            <label className="text-slate-400 block mb-1 font-medium">Target Shelf Life Goal</label>
            <div className="flex items-center space-x-2">
              <input
                type="number"
                min="1"
                max="730"
                value={targetShelfLife}
                onChange={(e) => setTargetShelfLife(Math.max(1, Number(e.target.value)))}
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono rounded px-3 py-2 text-sm focus:outline-none"
              />
              <span className="text-slate-400 font-medium">Days</span>
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1 font-medium">Optimization Priority</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700 text-white rounded px-3 py-2 text-sm focus:outline-none"
            >
              <option value="balanced">Balanced Engineering Compromise</option>
              <option value="shelf_life">Maximize Product Freshness / Shelf Life</option>
              <option value="cost">Minimize Unit Packaging Cost ($/pack)</option>
              <option value="carbon">Minimize Carbon Footprint (Eco-Design)</option>
              <option value="circularity">Maximize Circularity / Mono-Material</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1 font-medium">Circularity Filter (Min Recyclability)</label>
            <select
              value={minRecyclability}
              onChange={(e) => setMinRecyclability(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 text-white rounded px-3 py-2 text-sm focus:outline-none"
            >
              <option value="0">All Packaging Structures (including multilayers)</option>
              <option value="75">Recyclable Compatible (Score ≥ 75)</option>
              <option value="90">Strict Mono-Material Only (CEFLEX Class A)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Exact Numeric Packaging Specification Callout */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-800/40 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              Optimal Packaging Specification (Recommended Output)
            </span>
          </div>
          <button
            onClick={() => onApplyCandidate(activeCandidate)}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
          >
            <span>Apply This Spec to Simulator</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <p className="text-sm font-semibold text-white">
          {activeCandidate.archetype_name} ({activeCandidate.gauge_level.toUpperCase()} Gauge · {activeCandidate.barrier.total_thickness_um} µm)
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs font-mono pt-1">
          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Target OTR:</span>
            <span className="text-emerald-400 font-bold text-sm">
              {activeCandidate.barrier.otr_cc_m2_day_atm}
            </span>
            <span className="text-[10px] text-slate-500 block">cm³/(m²·day)</span>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Target WVTR:</span>
            <span className="text-sky-400 font-bold text-sm">
              {activeCandidate.barrier.wvtr_g_m2_day}
            </span>
            <span className="text-[10px] text-slate-500 block">g/(m²·day)</span>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Film Thickness:</span>
            <span className="text-white font-bold text-sm">
              {activeCandidate.barrier.total_thickness_um} µm
            </span>
            <span className="text-[10px] text-slate-500 block">{activeCandidate.barrier.total_mass_gsm} gsm</span>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">MAP Gas Mix:</span>
            <span className="text-purple-300 font-bold text-sm">
              {optResult.exact_packaging_spec.recommended_map.o2_percent} / {optResult.exact_packaging_spec.recommended_map.co2_percent}
            </span>
            <span className="text-[10px] text-slate-500 block">% O₂ / % CO₂</span>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Cost / Pack:</span>
            <span className="text-white font-bold text-sm">
              ${activeCandidate.cost_per_pack_usd.toFixed(3)}
            </span>
            <span className="text-[10px] text-slate-500 block">USD</span>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">CO₂e / Pack:</span>
            <span className="text-white font-bold text-sm">
              {activeCandidate.carbon_per_pack_g_co2e.toFixed(1)} g
            </span>
            <span className="text-[10px] text-slate-500 block">Embodied</span>
          </div>
        </div>
      </div>

      {/* Pareto Frontier Scatter Plot */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div>
            <span className="font-semibold text-slate-100">
              Pareto Frontier: Cost vs. Embodied Carbon vs. Shelf Life
            </span>
            <p className="text-slate-400 text-[11px] mt-0.5">
              Glowing diamonds represent non-dominated Pareto-optimal solutions. Circle radius corresponds to shelf-life days.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-[11px] font-mono">
            <span className="flex items-center space-x-1 text-emerald-400">
              <span className="w-2.5 h-2.5 rotate-45 bg-emerald-400 inline-block"></span>
              <span>Pareto Optimal</span>
            </span>
            <span className="flex items-center space-x-1 text-slate-500">
              <span className="w-2 h-2 rounded-full bg-slate-600 inline-block"></span>
              <span>Dominated</span>
            </span>
          </div>
        </div>

        {/* SVG Scatter Plot */}
        <div className="relative bg-slate-950 border border-slate-800 rounded-lg p-2 overflow-hidden">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-auto cursor-pointer"
          >
            {/* Grid & Axis Lines */}
            {[0, 0.25, 0.5, 0.75, 1.0].map((frac) => {
              const yVal = frac * maxCarbon;
              const yPos = getY(yVal);
              return (
                <g key={`y-${frac}`}>
                  <line
                    x1={pad.left}
                    y1={yPos}
                    x2={svgWidth - pad.right}
                    y2={yPos}
                    stroke="#334155"
                    strokeWidth="0.8"
                    strokeDasharray="2 2"
                  />
                  <text
                    x={pad.left - 6}
                    y={yPos + 3}
                    fill="#64748b"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    {yVal.toFixed(1)}g
                  </text>
                </g>
              );
            })}

            {[0, 0.25, 0.5, 0.75, 1.0].map((frac) => {
              const xVal = frac * maxCost;
              const xPos = getX(xVal);
              return (
                <g key={`x-${frac}`}>
                  <line
                    x1={xPos}
                    y1={pad.top}
                    x2={xPos}
                    y2={svgHeight - pad.bottom}
                    stroke="#334155"
                    strokeWidth="0.8"
                    strokeDasharray="2 2"
                  />
                  <text
                    x={xPos}
                    y={svgHeight - pad.bottom + 14}
                    fill="#64748b"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    ${xVal.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {/* Axis Titles */}
            <text
              x={svgWidth / 2}
              y={svgHeight - 6}
              fill="#94a3b8"
              fontSize="10"
              fontFamily="sans-serif"
              textAnchor="middle"
              fontWeight="600"
            >
              Unit Packaging Cost ($ / pack) →
            </text>

            <text
              x={14}
              y={svgHeight / 2}
              fill="#94a3b8"
              fontSize="10"
              fontFamily="sans-serif"
              textAnchor="middle"
              fontWeight="600"
              transform={`rotate(-90 14 ${svgHeight / 2})`}
            >
              Embodied Carbon (g CO₂e / pack) →
            </text>

            {/* Render Dominated Points First */}
            {allCandidates.filter(c => !c.is_pareto_optimal).map((c) => {
              const cx = getX(c.cost_per_pack_usd);
              const cy = getY(c.carbon_per_pack_g_co2e);
              const isSelected = activeCandidate.id === c.id;
              return (
                <circle
                  key={c.id}
                  cx={cx}
                  cy={cy}
                  r={isSelected ? 6 : 4}
                  fill={isSelected ? '#38bdf8' : '#475569'}
                  opacity={isSelected ? 0.9 : 0.4}
                  onClick={() => setSelectedCandidate(c)}
                  onMouseEnter={() => setHoveredCandidate(c)}
                  onMouseLeave={() => setHoveredCandidate(null)}
                />
              );
            })}

            {/* Render Pareto Optimal Points (Diamonds with Glow) */}
            {allCandidates.filter(c => c.is_pareto_optimal).map((c) => {
              const cx = getX(c.cost_per_pack_usd);
              const cy = getY(c.carbon_per_pack_g_co2e);
              const isSelected = activeCandidate.id === c.id;
              const size = isSelected ? 8 : 6;
              return (
                <g
                  key={c.id}
                  onClick={() => setSelectedCandidate(c)}
                  onMouseEnter={() => setHoveredCandidate(c)}
                  onMouseLeave={() => setHoveredCandidate(null)}
                  className="cursor-pointer"
                >
                  <polygon
                    points={`${cx},${cy - size} ${cx + size},${cy} ${cx},${cy + size} ${cx - size},${cy}`}
                    fill={isSelected ? '#10b981' : '#34d399'}
                    stroke="#ffffff"
                    strokeWidth={isSelected ? 2 : 1}
                  />
                  {isSelected && (
                    <circle
                      cx={cx}
                      cy={cy}
                      r={size + 5}
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="1.5"
                      strokeDasharray="2 2"
                      opacity="0.8"
                    />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Interactive Scatter Hover Tooltip */}
          {hoveredCandidate && (
            <div className="mt-2 p-2.5 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-xs font-mono">
              <div className="flex items-center space-x-2">
                <span className={`w-2 h-2 ${hoveredCandidate.is_pareto_optimal ? 'rotate-45 bg-emerald-400' : 'rounded-full bg-slate-500'}`} />
                <span className="text-white font-semibold">{hoveredCandidate.archetype_name}</span>
                <span className="text-slate-400">({hoveredCandidate.gauge_level})</span>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-slate-300">Shelf Life: <strong className="text-emerald-400">{hoveredCandidate.predicted_shelf_life_days}d</strong></span>
                <span className="text-slate-300">Cost: <strong className="text-white">${hoveredCandidate.cost_per_pack_usd.toFixed(3)}</strong></span>
                <span className="text-slate-300">Carbon: <strong className="text-white">{hoveredCandidate.carbon_per_pack_g_co2e.toFixed(1)}g</strong></span>
                <span className="text-slate-300">Recycle: <strong className="text-sky-400">{hoveredCandidate.recyclability_score}</strong></span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 5 Specialized Category Recommendations */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
          Specialized Engineering Recommendations on Pareto Frontier
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          {/* Card 1: Balanced */}
          <div
            onClick={() => setSelectedCandidate(recommendations.balanced)}
            className={`cursor-pointer rounded-xl p-3.5 border transition-all ${
              activeCandidate.id === recommendations.balanced.id
                ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                ★ Best Balanced
              </span>
              <span className="text-slate-400 font-mono text-[10px]">
                {recommendations.balanced.utility_score.toFixed(0)} pts
              </span>
            </div>
            <h4 className="font-semibold text-white truncate text-xs">
              {recommendations.balanced.archetype_name.split('(')[0]}
            </h4>
            <div className="space-y-1 font-mono text-[11px] text-slate-300 mt-2">
              <div>Shelf Life: <strong className="text-emerald-400">{recommendations.balanced.predicted_shelf_life_days}d</strong></div>
              <div>Cost: <strong className="text-white">${recommendations.balanced.cost_per_pack_usd.toFixed(3)}</strong></div>
              <div>Carbon: <strong className="text-white">{recommendations.balanced.carbon_per_pack_g_co2e.toFixed(1)}g</strong></div>
            </div>
          </div>

          {/* Card 2: Max Shelf Life */}
          <div
            onClick={() => setSelectedCandidate(recommendations.max_shelf_life)}
            className={`cursor-pointer rounded-xl p-3.5 border transition-all ${
              activeCandidate.id === recommendations.max_shelf_life.id
                ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800/80">
                Max Shelf Life
              </span>
              <span className="text-slate-400 font-mono text-[10px]">Long-Life</span>
            </div>
            <h4 className="font-semibold text-white truncate text-xs">
              {recommendations.max_shelf_life.archetype_name.split('(')[0]}
            </h4>
            <div className="space-y-1 font-mono text-[11px] text-slate-300 mt-2">
              <div>Shelf Life: <strong className="text-blue-400">{recommendations.max_shelf_life.predicted_shelf_life_days}d</strong></div>
              <div>Cost: <strong className="text-white">${recommendations.max_shelf_life.cost_per_pack_usd.toFixed(3)}</strong></div>
              <div>Carbon: <strong className="text-white">{recommendations.max_shelf_life.carbon_per_pack_g_co2e.toFixed(1)}g</strong></div>
            </div>
          </div>

          {/* Card 3: Lowest Cost */}
          <div
            onClick={() => setSelectedCandidate(recommendations.lowest_cost)}
            className={`cursor-pointer rounded-xl p-3.5 border transition-all ${
              activeCandidate.id === recommendations.lowest_cost.id
                ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800/80">
                Lowest Cost
              </span>
              <span className="text-slate-400 font-mono text-[10px]">Economy</span>
            </div>
            <h4 className="font-semibold text-white truncate text-xs">
              {recommendations.lowest_cost.archetype_name.split('(')[0]}
            </h4>
            <div className="space-y-1 font-mono text-[11px] text-slate-300 mt-2">
              <div>Shelf Life: <strong className="text-white">{recommendations.lowest_cost.predicted_shelf_life_days}d</strong></div>
              <div>Cost: <strong className="text-amber-400">${recommendations.lowest_cost.cost_per_pack_usd.toFixed(3)}</strong></div>
              <div>Carbon: <strong className="text-white">{recommendations.lowest_cost.carbon_per_pack_g_co2e.toFixed(1)}g</strong></div>
            </div>
          </div>

          {/* Card 4: Lowest Carbon */}
          <div
            onClick={() => setSelectedCandidate(recommendations.lowest_carbon)}
            className={`cursor-pointer rounded-xl p-3.5 border transition-all ${
              activeCandidate.id === recommendations.lowest_carbon.id
                ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-lime-950 text-lime-400 border border-lime-800/80">
                Eco-Champion
              </span>
              <span className="text-slate-400 font-mono text-[10px]">Low CO₂e</span>
            </div>
            <h4 className="font-semibold text-white truncate text-xs">
              {recommendations.lowest_carbon.archetype_name.split('(')[0]}
            </h4>
            <div className="space-y-1 font-mono text-[11px] text-slate-300 mt-2">
              <div>Shelf Life: <strong className="text-white">{recommendations.lowest_carbon.predicted_shelf_life_days}d</strong></div>
              <div>Cost: <strong className="text-white">${recommendations.lowest_carbon.cost_per_pack_usd.toFixed(3)}</strong></div>
              <div>Carbon: <strong className="text-lime-400">{recommendations.lowest_carbon.carbon_per_pack_g_co2e.toFixed(1)}g</strong></div>
            </div>
          </div>

          {/* Card 5: Mono-Material / Circular */}
          <div
            onClick={() => setSelectedCandidate(recommendations.best_circular_recyclable)}
            className={`cursor-pointer rounded-xl p-3.5 border transition-all ${
              activeCandidate.id === recommendations.best_circular_recyclable.id
                ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800/80">
                Circular PE/PP
              </span>
              <span className="text-slate-400 font-mono text-[10px]">CEFLEX A</span>
            </div>
            <h4 className="font-semibold text-white truncate text-xs">
              {recommendations.best_circular_recyclable.archetype_name.split('(')[0]}
            </h4>
            <div className="space-y-1 font-mono text-[11px] text-slate-300 mt-2">
              <div>Shelf Life: <strong className="text-white">{recommendations.best_circular_recyclable.predicted_shelf_life_days}d</strong></div>
              <div>Cost: <strong className="text-white">${recommendations.best_circular_recyclable.cost_per_pack_usd.toFixed(3)}</strong></div>
              <div>Recycle: <strong className="text-sky-400">{recommendations.best_circular_recyclable.recyclability_score} / 100</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
