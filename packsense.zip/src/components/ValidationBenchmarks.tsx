import React from 'react';
import { Award, CheckCircle2, BookOpen, ExternalLink, ShieldCheck, ArrowRight } from 'lucide-react';
import { VALIDATION_BENCHMARKS, ValidationBenchmark } from '../engine/benchmarks.ts';
import { TEST_STANDARDS } from '../engine/standards.ts';

interface ValidationBenchmarksProps {
  onLoadBenchmarkCase: (benchmarkId: string) => void;
}

export const ValidationBenchmarks: React.FC<ValidationBenchmarksProps> = ({
  onLoadBenchmarkCase
}) => {
  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
        <div className="flex items-center space-x-2">
          <Award className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white tracking-tight">
            Scientific Literature Grounding & Experimental Validation
          </h2>
        </div>
        <p className="text-xs text-slate-400 max-w-4xl leading-relaxed">
          PackSense executes deterministic physics simulations (Fickian series-resistance diffusion, Arrhenius temperature dependence, GAB moisture sorption isotherms, and microbial kinetics). The table below benchmarks PackSense predictions against empirical trials published in peer-reviewed food science and packaging literature.
        </p>
      </div>

      {/* Benchmark Verification Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {VALIDATION_BENCHMARKS.map((bench) => {
          return (
            <div
              key={bench.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 shadow-sm hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {bench.status}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5">
                    {bench.name}
                  </h3>
                </div>

                <button
                  onClick={() => onLoadBenchmarkCase(bench.id)}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-medium rounded border border-slate-700 flex items-center space-x-1 shrink-0 transition-colors"
                  title="Load this packaging test setup into Simulator"
                >
                  <span>Load Setup</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <p className="text-xs text-slate-400 italic">
                Citation: {bench.reference_paper}
              </p>

              <div className="space-y-1.5 text-xs font-mono bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-slate-300">
                  <span className="text-slate-500">Structure:</span> {bench.packaging_structure}
                </div>
                <div className="text-slate-300">
                  <span className="text-slate-500">Conditions:</span> {bench.test_conditions}
                </div>
              </div>

              {/* Empirical vs Predicted Days Comparison */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono pt-1">
                <div className="bg-slate-950 p-2 rounded text-center border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Literature Observed</span>
                  <span className="text-base font-bold text-slate-200 mt-0.5 block">
                    {bench.measured_experimental_days} Days
                  </span>
                </div>

                <div className="bg-slate-950 p-2 rounded text-center border border-slate-800">
                  <span className="text-emerald-400 block text-[10px]">PackSense Predicted</span>
                  <span className="text-base font-bold text-emerald-400 mt-0.5 block">
                    {bench.packsense_predicted_days} Days
                  </span>
                </div>

                <div className="bg-slate-950 p-2 rounded text-center border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Relative Variance</span>
                  <span className="text-base font-bold text-white mt-0.5 block">
                    {bench.deviation_percent > 0 ? `+${bench.deviation_percent}%` : `${bench.deviation_percent}%`}
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-400 border-t border-slate-800/80 pt-2">
                <strong className="text-slate-300">Mechanism:</strong> {bench.measured_limiting_factor}. {bench.notes}
              </p>
            </div>
          );
        })}
      </div>

      {/* Test Standards Reference Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5 text-sky-400" />
          <h3 className="text-base font-bold text-white tracking-tight">
            Governing Industry & Regulatory Test Standards
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {TEST_STANDARDS.map((std) => (
            <div key={std.code} className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-emerald-400 text-sm">{std.code}</span>
                <span className="font-mono text-[10px] text-slate-400">{std.reference_units}</span>
              </div>
              <h4 className="font-semibold text-white text-xs">{std.title}</h4>
              <p className="text-slate-400 text-[11px] leading-relaxed">{std.scope}</p>
              <div className="text-[10px] font-mono text-slate-500 pt-1 border-t border-slate-900">
                Conditions: <span className="text-slate-300">{std.standard_test_conditions}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
