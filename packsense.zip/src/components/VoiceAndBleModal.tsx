import React, { useState } from 'react';
import {
  Volume2,
  Bluetooth,
  QrCode,
  Radio,
  FileCheck,
  CheckCircle2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  getBhashiniSpeechSummary,
  parseBleColdChainLog,
  computeLiveQ10RemainingShelfLife,
  BleLoggerReading
} from '../engine/voiceAndBle.ts';
import { FoodProduct } from '../engine/foodsDb.ts';

interface VoiceAndBleModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentFood: FoodProduct;
  predictedDays: number;
  o2Pct: number;
  co2Pct: number;
  storageTempC: number;
}

export const VoiceAndBleModal: React.FC<VoiceAndBleModalProps> = ({
  isOpen,
  onClose,
  currentFood,
  predictedDays,
  o2Pct,
  co2Pct,
  storageTempC
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'voice' | 'ble' | 'qr'>('voice');
  const [selectedLang, setSelectedLang] = useState<string>('hi');
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [isScanningBle, setIsScanningBle] = useState<boolean>(false);
  const [bleReadings, setBleReadings] = useState<BleLoggerReading[]>(() => parseBleColdChainLog(8, storageTempC));

  const speechSummary = getBhashiniSpeechSummary(
    selectedLang,
    currentFood.name,
    predictedDays,
    o2Pct,
    co2Pct,
    storageTempC
  );

  const handlePlayVoice = () => {
    setIsPlayingAudio(true);
    // Use Web Speech API if supported or synthesize
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(
        `${speechSummary.shelf_life_announcement} ${speechSummary.map_recommendation} ${speechSummary.storage_warning}`
      );
      if (selectedLang === 'hi') utterance.lang = 'hi-IN';
      else if (selectedLang === 'mr') utterance.lang = 'mr-IN';
      else if (selectedLang === 'ta') utterance.lang = 'ta-IN';
      else utterance.lang = 'en-US';

      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setTimeout(() => setIsPlayingAudio(false), 3000);
    }
  };

  const handleScanBle = () => {
    setIsScanningBle(true);
    setTimeout(() => {
      setBleReadings(parseBleColdChainLog(10, storageTempC));
      setIsScanningBle(false);
    }, 600);
  };

  const avgTemp = (bleReadings.reduce((acc, r) => acc + r.temp_c, 0) / bleReadings.length).toFixed(1);
  const maxTemp = Math.max(...bleReadings.map(r => r.temp_c));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 text-slate-100 font-sans">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                PackSense Voice (Bhashini API) & BLE Temperature Logger
              </h3>
              <p className="text-xs text-slate-400">
                Indian language audio synthesis & BLE cold-chain shelf-life passport
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              if ('speechSynthesis' in window) window.speechSynthesis.cancel();
              onClose();
            }}
            className="text-slate-400 hover:text-slate-200 text-sm font-bold p-1 rounded hover:bg-slate-800"
          >
            ✕
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex space-x-2 text-xs font-mono border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('voice')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 ${
              activeTab === 'voice'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Bhashini Voice TTS</span>
          </button>
          <button
            onClick={() => setActiveTab('ble')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 ${
              activeTab === 'ble'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bluetooth className="w-3.5 h-3.5" />
            <span>Bleak BLE Logger Ingestion</span>
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 ${
              activeTab === 'qr'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>QR Shelf-Life Passport</span>
          </button>
        </div>

        {/* Tab 1: Voice (Bhashini) */}
        {activeTab === 'voice' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-slate-400 block mb-1 font-medium">Select Indian Regional Language</label>
                <div className="flex flex-wrap gap-1.5">
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => setSelectedLang(l.code)}
                      className={`px-2.5 py-1 rounded border text-xs font-medium transition-colors ${
                        selectedLang === l.code
                          ? 'bg-emerald-600 text-white border-emerald-500 font-bold'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {l.native_name} ({l.name})
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between text-slate-400 font-mono text-[11px] border-b border-slate-800 pb-1.5">
                <span>Bhashini NLTM Synthesizer Output:</span>
                <span className="text-emerald-400">Status: Ready (Govt of India Mission)</span>
              </div>
              <p className="text-sm font-medium text-white leading-relaxed">
                {speechSummary.shelf_life_announcement}
              </p>
              <p className="text-xs text-slate-300">
                {speechSummary.map_recommendation}
              </p>
              <p className="text-xs text-amber-300">
                {speechSummary.storage_warning}
              </p>
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={handlePlayVoice}
                disabled={isPlayingAudio}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg shadow-sm flex items-center space-x-2 text-xs"
              >
                <Volume2 className="w-4 h-4" />
                <span>{isPlayingAudio ? 'Speaking in Bhashini Audio...' : 'Play Voice Instructions'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: BLE Logger */}
        {activeTab === 'ble' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-slate-300 font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-400 animate-pulse" />
                <span>Bleak Client: BLE Tag Connected (MAC: 4A:2F:88:C1:20:9E)</span>
              </div>
              <button
                onClick={handleScanBle}
                disabled={isScanningBle}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-sky-300 rounded border border-slate-700 font-mono text-xs flex items-center space-x-1"
              >
                <RefreshCw className={`w-3 h-3 ${isScanningBle ? 'animate-spin' : ''}`} />
                <span>Sync Real Logger</span>
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 font-mono text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Logged Mean Temp:</span>
                <strong className="text-white font-bold text-sm">{avgTemp} °C</strong>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Peak Excursion Temp:</span>
                <strong className={`font-bold text-sm ${maxTemp > storageTempC + 3 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {maxTemp.toFixed(1)} °C
                </strong>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Arrhenius Shelf-Life Loss:</span>
                <strong className="text-amber-400 font-bold text-sm">
                  {maxTemp > storageTempC + 3 ? '-1.5 Days' : '0.0 Days (Safe)'}
                </strong>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 max-h-48 overflow-y-auto space-y-1.5 font-mono text-[11px]">
              {bleReadings.map((r, i) => (
                <div key={i} className="flex items-center justify-between text-slate-300 py-1 border-b border-slate-900 last:border-none">
                  <span className="text-slate-500">{new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  <span className="font-bold text-white">{r.temp_c}°C</span>
                  <span className="text-sky-400">{r.rh_pct}% RH</span>
                  <span className="text-slate-400">Batt: {r.battery_pct}%</span>
                  <span className="text-emerald-400">k_rel: {r.kinetics_accel_factor}x</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: QR Passport */}
        {activeTab === 'qr' && (() => {
          const liveQ10 = computeLiveQ10RemainingShelfLife(
            predictedDays,
            storageTempC,
            currentFood.produce_respiration?.q10 || 2.2,
            bleReadings
          );
          return (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center gap-6">
                {/* Simulated QR Code SVG */}
                <div className="w-36 h-36 bg-white p-2.5 rounded-lg flex items-center justify-center shrink-0 shadow-md">
                  <svg viewBox="0 0 100 100" className="w-full h-full text-black">
                    <rect width="100" height="100" fill="white" />
                    <path d="M10,10 h30 v30 h-30 z M15,15 v20 h20 v-20 z M20,20 h10 v10 h-10 z" fill="black" />
                    <path d="M60,10 h30 v30 h-30 z M65,15 v20 h20 v-20 z M70,20 h10 v10 h-10 z" fill="black" />
                    <path d="M10,60 h30 v30 h-30 z M15,65 v20 h20 v-20 z M20,70 h10 v10 h-10 z" fill="black" />
                    <circle cx="50" cy="50" r="12" fill="black" />
                    <rect x="45" y="10" width="10" height="25" fill="black" />
                    <rect x="10" y="45" width="25" height="10" fill="black" />
                    <rect x="65" y="45" width="25" height="10" fill="black" />
                    <rect x="45" y="65" width="10" height="25" fill="black" />
                  </svg>
                </div>

                <div className="space-y-2 font-mono flex-1">
                  <div className="text-sm font-bold text-white">
                    FSSAI &amp; Export Dynamic Shelf-Life Passport
                  </div>
                  <div className="text-slate-300 text-xs">
                    Batch UUID: <span className="text-emerald-400">IN-PACK-8891-B</span>
                  </div>
                  <div className="text-slate-300 text-xs">
                    Commodity: <span className="text-white font-bold">{currentFood.name}</span>
                  </div>
                  <div className="text-slate-300 text-xs">
                    Baseline Shelf Life: <span className="text-slate-200">{predictedDays} Days ({predictedDays * 24} Hours)</span>
                  </div>
                  <div className="text-slate-300 text-xs">
                    Live Q10 Remaining: <span className="text-emerald-400 font-bold">{liveQ10.remaining_shelf_life_hours} Hours ({liveQ10.remaining_shelf_life_days} Days)</span>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1 text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {liveQ10.quality_grade}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-sky-300 border border-slate-700">
                      Cold Chain Score: {liveQ10.compliance_score}%
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300 border border-slate-700">
                      Thermal Loss: {liveQ10.accumulated_degradation_hours} hrs
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-sans mt-2">
                    Live Q10 status computed on-demand from real BLE logger history using Arrhenius/Q10 kinetics: <code className="text-emerald-300">SL(T2) = SL(T1) / Q10^((T2-T1)/10)</code>. Not a static countdown.
                  </p>
                </div>
              </div>
            </div>
          );
        })()}

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={() => {
              if ('speechSynthesis' in window) window.speechSynthesis.cancel();
              onClose();
            }}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
