import React, { useState } from 'react';
import {
  MapPin,
  Truck,
  Phone,
  MessageSquare,
  Thermometer,
  ShieldCheck,
  Building,
  Navigation
} from 'lucide-react';
import {
  CLIMATE_PROFILES,
  PACKAGING_SUPPLIERS,
  calculateGeoDistanceKm,
  ClimateProfile,
  PackagingSupplier
} from '../engine/climateAndSuppliers.ts';

interface RegionalSupplyProps {
  onSelectSupplierWhatsapp: (supplier: PackagingSupplier) => void;
  onApplyClimateConditions: (climate: ClimateProfile) => void;
}

export const RegionalSupply: React.FC<RegionalSupplyProps> = ({
  onSelectSupplierWhatsapp,
  onApplyClimateConditions
}) => {
  const [selectedZoneId, setSelectedZoneId] = useState<string>('konkan_maharashtra');
  const [userLat, setUserLat] = useState<number>(18.5204); // Default near Pune / Western India
  const [userLon, setUserLon] = useState<number>(73.8567);

  const selectedZone = CLIMATE_PROFILES.find(z => z.id === selectedZoneId) || CLIMATE_PROFILES[0];

  // Sort suppliers by distance from selected zone's coordinates
  const sortedSuppliers = [...PACKAGING_SUPPLIERS].map(s => {
    const dist = calculateGeoDistanceKm(selectedZone.latitude, selectedZone.longitude, s.latitude, s.longitude);
    return { ...s, distance_km: dist };
  }).sort((a, b) => a.distance_km - b.distance_km);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
        <div className="flex items-center space-x-2">
          <MapPin className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white tracking-tight">
            IMD Climate Profiles & PostGIS Regional Supplier Directory
          </h2>
        </div>
        <p className="text-xs text-slate-400 max-w-4xl leading-relaxed">
          Geo-distance spatial matching for FPOs, farmers, and MSMEs. Couples India Meteorological Department (IMD) ambient temperature/humidity seasonal transit data with certified flexible barrier film converters and reel suppliers.
        </p>
      </div>

      {/* Agro-Climatic Zone Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
              Select Indian Agro-Climatic Region
            </label>
            <select
              value={selectedZoneId}
              onChange={(e) => setSelectedZoneId(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-white font-medium text-sm rounded-lg px-3.5 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {CLIMATE_PROFILES.map(z => (
                <option key={z.id} value={z.id}>
                  {z.zone_name} ({z.state}) · {z.major_mandi}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => onApplyClimateConditions(selectedZone)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center space-x-1.5 self-start sm:self-center"
          >
            <Thermometer className="w-4 h-4" />
            <span>Apply IMD Climate to Simulator</span>
          </button>
        </div>

        {/* Climate Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono pt-1">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Summer (May-Jun):</span>
            <strong className="text-rose-400 text-base font-bold">{selectedZone.summer_temp_c}°C</strong>
            <span className="text-slate-400 block text-[11px] mt-0.5">{selectedZone.summer_rh_pct}% RH</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Monsoon (Jul-Sep):</span>
            <strong className="text-sky-400 text-base font-bold">{selectedZone.monsoon_temp_c}°C</strong>
            <span className="text-slate-400 block text-[11px] mt-0.5">{selectedZone.monsoon_rh_pct}% RH (Critical)</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Winter (Dec-Jan):</span>
            <strong className="text-blue-400 text-base font-bold">{selectedZone.winter_temp_c}°C</strong>
            <span className="text-slate-400 block text-[11px] mt-0.5">{selectedZone.winter_rh_pct}% RH</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-500 block text-[10px]">Transit Hazard Level:</span>
            <span className={`inline-block font-bold text-xs px-2 py-0.5 rounded mt-1 ${
              selectedZone.transit_hazard_rating === 'Extreme'
                ? 'bg-rose-950 text-rose-300 border border-rose-800'
                : 'bg-amber-950 text-amber-300 border border-amber-800'
            }`}>
              {selectedZone.transit_hazard_rating} Risk
            </span>
            <span className="text-[10px] text-slate-500 block mt-1">GAB Isotherm Strain</span>
          </div>
        </div>
      </div>

      {/* PostGIS Nearby Suppliers List */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          PostGIS Distance-Sorted Barrier Film Converters & Suppliers
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sortedSuppliers.map((sup) => (
            <div
              key={sup.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 shadow-sm hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{sup.name}</h4>
                  <div className="flex items-center space-x-1.5 text-xs text-slate-400 mt-0.5">
                    <Building className="w-3.5 h-3.5 text-slate-500" />
                    <span>{sup.city}, {sup.state}</span>
                  </div>
                </div>

                <div className="text-right font-mono text-xs">
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    {sup.distance_km} km
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">from Mandi</span>
                </div>
              </div>

              {/* Certifications & Products */}
              <div className="space-y-1.5 text-xs">
                <div className="flex flex-wrap gap-1">
                  {sup.certifications.map(c => (
                    <span key={c} className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-slate-300 border border-slate-800">
                      ✓ {c}
                    </span>
                  ))}
                </div>

                <div className="text-slate-300 text-xs">
                  <span className="text-slate-500">Materials:</span> {sup.products.join(' · ')}
                </div>
              </div>

              {/* Order Info & WhatsApp Action */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                <div className="text-slate-400 text-[11px]">
                  MOQ: <strong className="text-white">{sup.min_order_quantity_kg} kg</strong> · Lead: <strong className="text-white">{sup.lead_time_days} days</strong>
                </div>

                <button
                  onClick={() => onSelectSupplierWhatsapp(sup)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center space-x-1.5 shadow-sm transition-colors text-xs"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Send Spec on WhatsApp</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
