import React from 'react';
import {
  ShieldCheck,
  Cpu,
  Database,
  Activity,
  RefreshCw,
  MapPin,
  Camera,
  Radio,
  FileCheck,
  CheckCircle2,
  FileText,
  Wrench,
  User,
  MessageSquare,
  Layers,
  Smartphone
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'simulator' | 'optimizer' | 'materials' | 'spec_sheet' | 'benchmarks' | 'regional_supply' | 'compliance_shap' | 'industrial_suite' | 'mobile_app';
  setActiveTab: (tab: 'simulator' | 'optimizer' | 'materials' | 'spec_sheet' | 'benchmarks' | 'regional_supply' | 'compliance_shap' | 'industrial_suite' | 'mobile_app') => void;
  serverStatus: {
    healthy: boolean;
    engineName?: string;
    runtime?: string;
    llmCalls?: number;
  };
  onOpenRipenessModal: () => void;
  onOpenVoiceBleModal: () => void;
  onOpenWhatsAppModal: () => void;
  onOpenExtendedModal?: () => void;
  onOpenAuthModal?: () => void;
  currentUserRole?: string;
  onResetToDefaults?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  serverStatus,
  onOpenRipenessModal,
  onOpenVoiceBleModal,
  onOpenWhatsAppModal,
  onOpenExtendedModal,
  onOpenAuthModal,
  currentUserRole = 'farmer',
  onResetToDefaults
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Core Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold shadow-inner">
              <Cpu className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-bold tracking-tight text-white">PackSense</span>
                <span className="text-xs px-2 py-0.5 rounded font-mono font-medium bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                  Engineering Suite
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Deterministic Physics · NSGA-II · FSSAI Compliance · PostGIS Climate
              </p>
            </div>
          </div>

          {/* Verification & Mobile Tool Actions */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenRipenessModal}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-mono text-xs flex items-center space-x-1.5 transition-colors"
              title="Open MobileNetV3 .ONNX Harvest Ripeness Classifier"
            >
              <Camera className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Ripeness Scanner</span>
            </button>

            <button
              onClick={onOpenVoiceBleModal}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 font-mono text-xs flex items-center space-x-1.5 transition-colors"
              title="Bhashini Voice (Hindi/Marathi/Tamil) & BLE Logger Passport"
            >
              <Radio className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden md:inline">Voice & BLE Logger</span>
            </button>

            <button
              onClick={onOpenExtendedModal || onOpenWhatsAppModal}
              className="px-2.5 py-1.5 rounded-lg bg-emerald-950/90 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/80 font-mono text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
              title="Additional Features Module — 8 Extended Backend Capabilities (Section 8)"
            >
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Extended Module 8</span>
            </button>

            {onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="px-2.5 py-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-800/80 font-mono text-xs flex items-center space-x-1.5 transition-colors"
                title="Account, Twilio Phone OTP Login & Role Permissions"
              >
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span className="uppercase font-bold tracking-wider">{currentUserRole}</span>
              </button>
            )}

            {onResetToDefaults && (
              <button
                onClick={onResetToDefaults}
                className="text-xs flex items-center space-x-1 text-slate-400 hover:text-slate-200 transition-colors px-2 py-1.5 rounded hover:bg-slate-800"
                title="Reset simulation parameters to default baseline"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 -mb-px border-t border-slate-800/80 pt-1 overflow-x-auto text-sm font-medium">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'simulator'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Digital Twin Simulator</span>
          </button>

          <button
            onClick={() => setActiveTab('optimizer')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'optimizer'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>NSGA-II Optimizer</span>
          </button>

          <button
            onClick={() => setActiveTab('compliance_shap')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'compliance_shap'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>SHAP & FSSAI Compliance</span>
          </button>

          <button
            onClick={() => setActiveTab('regional_supply')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'regional_supply'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>IMD Climate & Suppliers</span>
          </button>

          <button
            onClick={() => setActiveTab('materials')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'materials'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Materials Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab('spec_sheet')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'spec_sheet'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Engineering TDS</span>
          </button>

          <button
            onClick={() => setActiveTab('industrial_suite')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'industrial_suite'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Wrench className="w-4 h-4 text-emerald-400" />
            <span>Industrial Engineering Suite</span>
          </button>

          <button
            onClick={() => setActiveTab('mobile_app')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'mobile_app'
                ? 'border-emerald-500 text-emerald-400 font-semibold bg-emerald-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">Flutter Mobile App</span>
          </button>

          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`px-3 py-2 border-b-2 whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'benchmarks'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-blue-400"></span>
            <span>Literature Benchmarks</span>
          </button>
        </div>
      </div>
    </header>
  );
};
