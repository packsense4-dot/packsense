/**
 * PackSense Application Entry Point
 * 
 * Displays the Official PackSense AI Mobile Application exclusively.
 * Fully wired to all deterministic backend endpoints and calculation engines.
 */

import React from 'react';
import { PackSenseOfficialApp } from './components/PackSenseOfficialApp.tsx';

export default function App() {
  return <PackSenseOfficialApp />;
}
