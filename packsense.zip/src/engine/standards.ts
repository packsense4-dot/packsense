/**
 * PackSense ASTM / ISO Test Standards and Regulatory Specifications
 */

export interface TestStandard {
  code: string;
  title: string;
  scope: string;
  measurement_principle: string;
  reference_units: string;
  standard_test_conditions: string;
}

export const TEST_STANDARDS: TestStandard[] = [
  {
    code: 'ASTM D3985',
    title: 'Standard Test Method for Oxygen Gas Transmission Rate Through Plastic Film and Sheeting Using a Coulometric Sensor',
    scope: 'Measures steady-state transmission rate of oxygen gas through barrier plastics.',
    measurement_principle: 'Coulometric P2O5 / galvanic sensor detects electrochemical reduction of permeating O2 molecules.',
    reference_units: 'cm³ / (m² · day · atm) or cc / (100 in² · day · atm)',
    standard_test_conditions: '23.0°C ± 0.5°C, 0% RH carrier gas, 100% dry oxygen driving concentration'
  },
  {
    code: 'ASTM F1249',
    title: 'Standard Test Method for Water Vapor Transmission Rate Through Plastic Film and Sheeting Using a Modulated Infrared Sensor',
    scope: 'Measures steady-state water vapor transmission rate across polymer barriers.',
    measurement_principle: 'Modulated infrared absorption spectrophotometry of water vapor permeating into dry nitrogen sweep gas.',
    reference_units: 'g / (m² · day) or g / (100 in² · day)',
    standard_test_conditions: '37.8°C (100°F) ± 0.5°C, 90% RH driving gradient'
  },
  {
    code: 'ASTM F1927',
    title: 'Standard Test Method for Determination of Oxygen Gas Transmission Rate, Permeance and Permeability at Controlled Relative Humidity',
    scope: 'Crucial for EVOH, Polyamide, and cellulose films where moisture plasticization alters oxygen permeability.',
    measurement_principle: 'Dual-chamber coulometric cell with precision relative humidity vapor conditioning on carrier and test sides.',
    reference_units: 'cm³ / (m² · day · atm)',
    standard_test_conditions: '23.0°C, 50% RH and 90% RH'
  },
  {
    code: 'ASTM F1307',
    title: 'Standard Test Method for Oxygen Transmission Rate Through Dry Packages Using a Coulometric Sensor',
    scope: 'Evaluates whole finished packages (pouches, thermoformed trays, bottles) including seam and seal micro-channel integrity.',
    measurement_principle: 'Nitrogen gas sweeps interior of sealed package while ambient air surrounds package in test chamber.',
    reference_units: 'cm³ / (package · day · atm)',
    standard_test_conditions: '23.0°C, 50% ambient RH'
  },
  {
    code: 'EN 13432',
    title: 'Packaging - Requirements for packaging recoverable through composting and biodegradation',
    scope: 'European industrial composting standard: >90% disintegration within 12 weeks, ecotoxicity and heavy metals testing.',
    measurement_principle: 'Aerobic composting in controlled thermophilic composting vessels.',
    reference_units: '% Mass loss / conversion to CO2',
    standard_test_conditions: '58°C ± 2°C, 50-55% moisture content'
  },
  {
    code: 'CEFLEX D4ACE',
    title: 'Designing for a Circular Economy: Guidelines for Flexible Packaging Recyclability',
    scope: 'Monopolymer design guidelines for mechanical recycling: >90% polyolefin content (PE or PP stream), EVOH < 5%.',
    measurement_principle: 'Sortability, extrusion stability, NIR identification, and blown film tensile retention of recycled resin.',
    reference_units: 'Polymer mass fraction (%)',
    standard_test_conditions: 'Class A Sortability and Recyclate Yield Threshold'
  }
];
