/**
 * scanReportsDb.ts
 * 
 * In-memory / persistent database storage for Part A.2: Scan Reports.
 * Implements:
 * CREATE TABLE scan_reports (
 *     id SERIAL PRIMARY KEY,
 *     user_id INTEGER REFERENCES users(id),
 *     product_id INTEGER REFERENCES products(id),
 *     food_id INTEGER REFERENCES foods(id),
 *     input_payload JSONB,     -- the exact request
 *     report JSONB,            -- the exact response (all sections)
 *     status VARCHAR(20),      -- complete | partial | needs_input
 *     compute_ms INTEGER,
 *     created_at TIMESTAMP DEFAULT now()
 * );
 */

import fs from 'fs';
import path from 'path';
import { cacheSet } from './redisClient.ts';

export interface ScanReportRecord {
  id: number;
  user_id: number;
  product_id: number | null;
  food_id: string | null;
  input_payload: any;
  report: any;
  status: 'complete' | 'partial' | 'needs_input';
  compute_ms: number;
  created_at: string;
}

const SCAN_REPORTS_FILE = path.resolve(process.cwd(), 'data', 'scan_reports_db.json');

// In-memory table initialized with seed history
export const SCAN_REPORTS_TABLE: ScanReportRecord[] = [
  {
    id: 480,
    user_id: 1,
    product_id: 1, // Lay's
    food_id: 'potato_crisps',
    input_payload: {
      source: 'barcode',
      barcode: '8901491101851',
      climate_profile_id: 2,
      target_shelf_life_days: 180,
      weight_kg: 500,
      price_per_kg: 120
    },
    report: null, // hydrated on demand or populated from orchestrator
    status: 'complete',
    compute_ms: 540,
    created_at: new Date(Date.now() - 3600000 * 24).toISOString()
  }
];

let nextReportId = 481;

export function persistScanReportsToDisk(): void {
  try {
    const dir = path.dirname(SCAN_REPORTS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SCAN_REPORTS_FILE, JSON.stringify(SCAN_REPORTS_TABLE, null, 2), 'utf-8');
  } catch (err: any) {
    console.warn('[ScanReportsDb] Failed to write scan_reports_db.json:', err.message);
  }
}

export function loadScanReportsFromDisk(): void {
  try {
    if (fs.existsSync(SCAN_REPORTS_FILE)) {
      const raw = fs.readFileSync(SCAN_REPORTS_FILE, 'utf-8');
      const loaded: ScanReportRecord[] = JSON.parse(raw);
      if (Array.isArray(loaded) && loaded.length > 0) {
        SCAN_REPORTS_TABLE.length = 0;
        SCAN_REPORTS_TABLE.push(...loaded);
        const maxId = Math.max(...loaded.map(r => r.id || 0), 480);
        nextReportId = maxId + 1;
      }
    } else {
      persistScanReportsToDisk();
    }
  } catch (err: any) {
    console.warn('[ScanReportsDb] Failed to load scan_reports_db.json:', err.message);
  }
}

// Hydrate on module load
loadScanReportsFromDisk();

export function createScanReport(record: {
  user_id?: number;
  product_id?: number | null;
  food_id?: string | null;
  input_payload: any;
  report: any;
  status: 'complete' | 'partial' | 'needs_input';
  compute_ms: number;
}): ScanReportRecord {
  const newRecord: ScanReportRecord = {
    id: nextReportId++,
    user_id: record.user_id ?? 1,
    product_id: record.product_id ?? null,
    food_id: record.food_id ?? null,
    input_payload: record.input_payload,
    report: record.report,
    status: record.status,
    compute_ms: record.compute_ms,
    created_at: new Date().toISOString()
  };

  // Prepend so latest reports appear first
  SCAN_REPORTS_TABLE.unshift(newRecord);
  persistScanReportsToDisk();
  cacheSet(`scan_report:${newRecord.id}`, newRecord);
  cacheSet('scan_reports:latest_ids', SCAN_REPORTS_TABLE.slice(0, 20).map(r => r.id));

  return newRecord;
}

export function getScanReportById(id: number): ScanReportRecord | null {
  return SCAN_REPORTS_TABLE.find(r => r.id === id) || null;
}

export function listScanReports(options?: {
  user_id?: number;
  limit?: number;
  offset?: number;
}): { total: number; reports: Array<{
  id: number;
  product_name: string;
  thumbnail: string | null;
  expected_shelf_life_days: number;
  confidence_score: number;
  status: string;
  created_at: string;
}> } {
  const limit = options?.limit ?? 20;
  const offset = options?.offset ?? 0;

  const filtered = options?.user_id 
    ? SCAN_REPORTS_TABLE.filter(r => r.user_id === options.user_id)
    : SCAN_REPORTS_TABLE;

  const paginated = filtered.slice(offset, offset + limit);

  const mapped = paginated.map(r => {
    const reportData = r.report;
    const productName = reportData?.input?.data?.product?.name 
      || reportData?.food_profile?.data?.name 
      || r.input_payload?.barcode 
      || `Report #${r.id}`;
    
    const thumbnail = reportData?.input?.data?.product?.image_url || null;
    const expectedShelfLife = reportData?.twin?.data?.shelf_life?.expected_days 
      || Math.round((reportData?.twin?.data?.shelf_life?.expected_h || 2400) / 24);
    
    const confidenceScore = reportData?.confidence?.data?.score || 88;

    return {
      id: r.id,
      product_name: productName,
      thumbnail,
      expected_shelf_life_days: expectedShelfLife,
      confidence_score: confidenceScore,
      status: r.status,
      created_at: r.created_at
    };
  });

  return {
    total: filtered.length,
    reports: mapped
  };
}
