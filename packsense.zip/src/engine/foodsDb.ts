/**
 * PackSense Food Science & Preservation Database
 * 
 * Food products, primary degradation pathways, critical moisture limits,
 * GAB sorption isotherm parameters, Michaelis-Menten produce respiration constants,
 * microbial spoilage parameters, and recommended Modified Atmosphere Packaging (MAP) gas mixes.
 */

export interface FoodProduct {
  id: string;
  name: string;
  category: 'fresh_meat' | 'poultry' | 'seafood' | 'fresh_produce' | 'dairy_cheese' | 'bakery' | 'dry_snacks' | 'coffee_tea' | 'ready_to_eat';
  storage_temp_c: number; // Standard storage temp (°C)
  density_kg_m3: number; // Density for volume displacement
  initial_aw: number; // Water activity aw (0.0 to 1.0)
  initial_moisture_g100g: number; // g H2O / 100g dry solid or wet basis
  
  // Critical failure limits
  primary_degradation_mechanism: 'microbial' | 'oxidation' | 'moisture_gain' | 'moisture_loss' | 'respiration_fermentation' | 'enzymatic';
  crit_moisture_max_g100g?: number; // Critical soggy/caking moisture limit
  crit_moisture_min_g100g?: number; // Critical staling/drying limit
  crit_o2_ppm?: number; // Critical O2 limit in headspace (%)
  max_o2_uptake_mg_kg?: number; // Maximum allowable O2 absorbed (mg O2 / kg product) before rancidity
  crit_microbial_cfu_g: number; // CFU/g log10 threshold (e.g. 7.0 for meat/produce spoilage)
  initial_cfu_g: number; // Initial log10 CFU/g (e.g. 3.0)
  
  // GAB (Guggenheim-Anderson-de Boer) Sorption Isotherm constants
  // X = (Xm * C * K * aw) / ((1 - K * aw) * (1 - K * aw + C * K * aw))
  gab_xm: number; // Monolayer moisture content (g H2O / 100g dry solids)
  gab_c: number; // Energy constant related to monolayer sorption
  gab_k: number; // Multilayer factor

  // Microbial kinetics (Gompertz / Baranyi model)
  max_growth_rate_mu_max: number; // 1/day at reference temp
  lag_phase_lambda_days: number; // Days of lag phase at reference temp
  co2_inhibition_factor: number; // Efficacy of dissolved CO2 inhibiting growth (0.0 to 1.0)

  // Lipid Oxidation kinetics
  oxidation_rate_k: number; // mg O2 / (kg · day · %O2^0.5)

  // Fresh produce respiration (Michaelis-Menten kinetics)
  is_respiring_produce: boolean;
  produce_respiration?: {
    vm_o2_ref: number; // mL O2 / (kg · hr) at reference temp
    km_o2: number; // % O2 at half-max respiration
    ki_co2: number; // % CO2 inhibition constant
    rq: number; // Respiratory quotient (R_CO2 / R_O2)
    t_ref_c: number; // Reference temp (°C)
    q10: number; // Temperature coefficient Q10
    extinction_o2_percent: number; // Critical low O2 % below which anaerobic fermentation starts
  };

  // Recommended MAP gas baseline
  recommended_map: {
    o2_percent: number;
    co2_percent: number;
    n2_percent: number;
    gas_to_product_ratio: number; // Vg / Vp (e.g. 2.0 = 2x volume of gas to food)
    reasoning: string;
  };

  target_shelf_life_days: number; // Baseline target shelf life
  description: string;
}

export const FOODS_DATABASE: FoodProduct[] = [
  {
    id: 'potato_crisps',
    name: 'Potato Crisps (Kettle Fried)',
    category: 'dry_snacks',
    storage_temp_c: 21,
    density_kg_m3: 320,
    initial_aw: 0.15,
    initial_moisture_g100g: 2.0,
    primary_degradation_mechanism: 'moisture_gain',
    crit_moisture_max_g100g: 3.8, // Crispness loss occurs at aw > 0.38 (~3.8% moisture)
    max_o2_uptake_mg_kg: 35.0, // Rancidity threshold
    crit_microbial_cfu_g: 5.0,
    initial_cfu_g: 1.5,
    gab_xm: 3.2,
    gab_c: 18.5,
    gab_k: 0.76,
    max_growth_rate_mu_max: 0.01,
    lag_phase_lambda_days: 180,
    co2_inhibition_factor: 0.1,
    oxidation_rate_k: 0.18,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.2,
      co2_percent: 0.0,
      n2_percent: 99.8,
      gas_to_product_ratio: 2.5,
      reasoning: 'High nitrogen flush eliminates oxidation and provides cushion against mechanical breakage; ultra-low WVTR required.'
    },
    target_shelf_life_days: 180,
    description: 'Crispy fried snack susceptible to moisture absorption causing soggy texture, and oxidation of unsaturated cooking oils.'
  },
  {
    id: 'fresh_beef_steak',
    name: 'Fresh Beef Ribeye Steak',
    category: 'fresh_meat',
    storage_temp_c: 2.0,
    density_kg_m3: 1050,
    initial_aw: 0.99,
    initial_moisture_g100g: 74.0,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 7.0, // Pseudomonas / Brochothrix spoilage odor threshold
    initial_cfu_g: 3.2,
    gab_xm: 22.0,
    gab_c: 8.0,
    gab_k: 0.88,
    max_growth_rate_mu_max: 0.65, // Fast bacterial growth at chill temps
    lag_phase_lambda_days: 2.5,
    co2_inhibition_factor: 0.75, // CO2 dissolves in aqueous phase, lowering pH and inhibiting gram-negative bacteria
    oxidation_rate_k: 0.95, // Metmyoglobin browning
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 75.0,
      co2_percent: 25.0,
      n2_percent: 0.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'High oxygen (70-80%) preserves bright red oxymyoglobin cherry color; 20-30% CO2 inhibits aerobic psychrotrophic bacteria.'
    },
    target_shelf_life_days: 14,
    description: 'High-moisture protein requiring bright oxymyoglobin color preservation and inhibition of psychrotrophic bacterial slime.'
  },
  {
    id: 'poultry_breast',
    name: 'Fresh Chicken Breast Fillet',
    category: 'poultry',
    storage_temp_c: 2.0,
    density_kg_m3: 1040,
    initial_aw: 0.99,
    initial_moisture_g100g: 75.5,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 7.0,
    initial_cfu_g: 3.5,
    gab_xm: 21.5,
    gab_c: 7.5,
    gab_k: 0.87,
    max_growth_rate_mu_max: 0.72,
    lag_phase_lambda_days: 1.8,
    co2_inhibition_factor: 0.82,
    oxidation_rate_k: 0.40,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.0,
      co2_percent: 35.0,
      n2_percent: 65.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'Poultry does not require high O2 for color; 30-40% CO2 provides potent antimicrobial suppression with N2 inert filler.'
    },
    target_shelf_life_days: 12,
    description: 'Poultry meat susceptible to Pseudomonas and lactic acid bacteria; high CO2 concentration retards growth effectively.'
  },
  {
    id: 'salmon_fillet',
    name: 'Atlantic Salmon Fillet (Fatty Fish)',
    category: 'seafood',
    storage_temp_c: 1.0,
    density_kg_m3: 1020,
    initial_aw: 0.985,
    initial_moisture_g100g: 68.0,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 6.8, // Photobacterium phosphoreum / Shewanella
    initial_cfu_g: 3.0,
    max_o2_uptake_mg_kg: 25.0, // High polyunsaturated omega-3 fatty acids oxidize quickly
    gab_xm: 18.0,
    gab_c: 9.0,
    gab_k: 0.85,
    max_growth_rate_mu_max: 0.58,
    lag_phase_lambda_days: 2.0,
    co2_inhibition_factor: 0.78,
    oxidation_rate_k: 1.20,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.0,
      co2_percent: 50.0,
      n2_percent: 50.0,
      gas_to_product_ratio: 2.5,
      reasoning: 'High CO2 (50-60%) retards gram-negative fish flora; zero O2 prevents rapid lipid oxidation of omega-3 fats.'
    },
    target_shelf_life_days: 10,
    description: 'Perishable seafood with high omega-3 lipid content prone to oxidation and psychrophilic bacterial degradation.'
  },
  {
    id: 'strawberries',
    name: 'Fresh Whole Strawberries',
    category: 'fresh_produce',
    storage_temp_c: 4.0,
    density_kg_m3: 750,
    initial_aw: 0.99,
    initial_moisture_g100g: 91.0,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 6.5, // Botrytis cinerea gray mold
    initial_cfu_g: 2.8,
    gab_xm: 25.0,
    gab_c: 5.0,
    gab_k: 0.90,
    max_growth_rate_mu_max: 0.35,
    lag_phase_lambda_days: 3.0,
    co2_inhibition_factor: 0.60,
    oxidation_rate_k: 0.10,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 18.5, // mL O2 / (kg·h) at 4°C
      km_o2: 1.8, // %
      ki_co2: 12.0, // %
      rq: 1.25,
      t_ref_c: 4.0,
      q10: 2.4,
      extinction_o2_percent: 1.5 // Fermentation onset if O2 < 1.5%
    },
    recommended_map: {
      o2_percent: 3.0,
      co2_percent: 12.0,
      n2_percent: 85.0,
      gas_to_product_ratio: 1.5,
      reasoning: 'Equilibrium modified atmosphere (EMA) with 10-15% CO2 suppresses Botrytis cinerea mold without causing carbon dioxide injury.'
    },
    target_shelf_life_days: 14,
    description: 'Living tissue with high metabolic rate; requires controlled permeability film to balance respiration with gas exchange.'
  },
  {
    id: 'cut_salad_greens',
    name: 'Pre-Cut Mixed Salad Leaves (Romaine & Baby Spinach)',
    category: 'fresh_produce',
    storage_temp_c: 4.0,
    density_kg_m3: 350,
    initial_aw: 0.995,
    initial_moisture_g100g: 94.5,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 7.0,
    initial_cfu_g: 4.0,
    gab_xm: 28.0,
    gab_c: 4.5,
    gab_k: 0.92,
    max_growth_rate_mu_max: 0.42,
    lag_phase_lambda_days: 2.2,
    co2_inhibition_factor: 0.55,
    oxidation_rate_k: 0.25, // Enzymatic browning of cut edges
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 28.0, // High respiration rate
      km_o2: 2.2,
      ki_co2: 9.5,
      rq: 1.15,
      t_ref_c: 4.0,
      q10: 2.5,
      extinction_o2_percent: 1.2
    },
    recommended_map: {
      o2_percent: 2.5,
      co2_percent: 6.0,
      n2_percent: 91.5,
      gas_to_product_ratio: 2.0,
      reasoning: 'Low O2 (2-3%) delays browning of cut margins; 5-8% CO2 retards microbial growth while avoiding tissue breakdown.'
    },
    target_shelf_life_days: 10,
    description: 'Wounded produce with elevated respiration rate and polyphenol oxidase enzyme activity causing edge browning.'
  },
  {
    id: 'cheddar_cheese_blocks',
    name: 'Mature Cheddar Cheese (Block / Slices)',
    category: 'dairy_cheese',
    storage_temp_c: 4.0,
    density_kg_m3: 1100,
    initial_aw: 0.93,
    initial_moisture_g100g: 37.0,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 6.0, // Surface mold (Penicillium)
    initial_cfu_g: 2.0,
    gab_xm: 12.0,
    gab_c: 12.0,
    gab_k: 0.82,
    max_growth_rate_mu_max: 0.22,
    lag_phase_lambda_days: 14.0,
    co2_inhibition_factor: 0.88, // Mold is strictly aerobic and strongly inhibited by CO2
    oxidation_rate_k: 0.35,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.1,
      co2_percent: 30.0,
      n2_percent: 69.9,
      gas_to_product_ratio: 1.2,
      reasoning: 'Residual O2 < 0.2% arrests mold germination; 30% CO2 maintains antimicrobial barrier without causing package collapse.'
    },
    target_shelf_life_days: 90,
    description: 'Hard fermented dairy requiring absolute exclusion of oxygen to prevent superficial fungal colony development.'
  },
  {
    id: 'sliced_bread',
    name: 'Artisan Sliced Sandwich Bread',
    category: 'bakery',
    storage_temp_c: 21.0,
    density_kg_m3: 280,
    initial_aw: 0.94,
    initial_moisture_g100g: 38.0,
    primary_degradation_mechanism: 'microbial',
    crit_moisture_min_g100g: 31.0, // Staling limit
    crit_microbial_cfu_g: 5.5, // Rhizopus / Aspergillus bread molds
    initial_cfu_g: 1.8,
    gab_xm: 11.5,
    gab_c: 14.0,
    gab_k: 0.84,
    max_growth_rate_mu_max: 0.45,
    lag_phase_lambda_days: 3.5,
    co2_inhibition_factor: 0.90, // High CO2 completely stops bread mold
    oxidation_rate_k: 0.05,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.1,
      co2_percent: 60.0,
      n2_percent: 39.9,
      gas_to_product_ratio: 1.5,
      reasoning: 'High CO2 (60-70%) extends mold-free shelf life from 5 days to 28+ days at ambient temperatures.'
    },
    target_shelf_life_days: 28,
    description: 'High moisture bakery product prone to mold development and amylopectin retrogradation (staling).'
  },
  {
    id: 'roasted_coffee_beans',
    name: 'Dark Roast Whole Coffee Beans',
    category: 'coffee_tea',
    storage_temp_c: 21.0,
    density_kg_m3: 420,
    initial_aw: 0.20,
    initial_moisture_g100g: 2.5,
    primary_degradation_mechanism: 'oxidation',
    crit_moisture_max_g100g: 5.0,
    max_o2_uptake_mg_kg: 18.0, // Volatile aroma loss and lipid rancidity
    crit_microbial_cfu_g: 4.0,
    initial_cfu_g: 1.0,
    gab_xm: 3.5,
    gab_c: 16.0,
    gab_k: 0.72,
    max_growth_rate_mu_max: 0.005,
    lag_phase_lambda_days: 200,
    co2_inhibition_factor: 0.1,
    oxidation_rate_k: 0.65,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.2,
      co2_percent: 0.0,
      n2_percent: 99.8,
      gas_to_product_ratio: 1.8,
      reasoning: 'Coffee releases internal CO2 post-roasting (degassing); requires one-way degassing valve and ultra-high O2 barrier.'
    },
    target_shelf_life_days: 365,
    description: 'Roasted beans containing delicate volatile aromatics and oils prone to oxidation, staling, and degassing pressure.'
  },
  {
    id: 'ready_pasta_meal',
    name: 'Fresh Cooked Pasta with Marinara Sauce',
    category: 'ready_to_eat',
    storage_temp_c: 3.0,
    density_kg_m3: 1080,
    initial_aw: 0.985,
    initial_moisture_g100g: 72.0,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 6.5,
    initial_cfu_g: 2.5,
    gab_xm: 19.0,
    gab_c: 8.5,
    gab_k: 0.86,
    max_growth_rate_mu_max: 0.50,
    lag_phase_lambda_days: 3.0,
    co2_inhibition_factor: 0.80,
    oxidation_rate_k: 0.30,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.2,
      co2_percent: 40.0,
      n2_percent: 59.8,
      gas_to_product_ratio: 1.8,
      reasoning: '40% CO2 inhibits Bacillus and psychrotrophs while preserving sauce texture and preventing lipid oxidation.'
    },
    target_shelf_life_days: 21,
    description: 'Multi-component cooked meal requiring high antimicrobial headspace protection and thermal sealing barrier integrity.'
  },
  {
    id: 'alphonso_mango',
    name: 'Alphonso Mango (Ratnagiri / Konkan GI)',
    category: 'fresh_produce',
    storage_temp_c: 12.0,
    density_kg_m3: 980,
    initial_aw: 0.985,
    initial_moisture_g100g: 83.5,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 6.0,
    initial_cfu_g: 2.2,
    gab_xm: 22.0,
    gab_c: 6.5,
    gab_k: 0.88,
    max_growth_rate_mu_max: 0.28,
    lag_phase_lambda_days: 4.0,
    co2_inhibition_factor: 0.65,
    oxidation_rate_k: 0.15,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 22.0,
      km_o2: 1.9,
      ki_co2: 8.5,
      rq: 1.18,
      t_ref_c: 12.0,
      q10: 2.3,
      extinction_o2_percent: 2.0
    },
    recommended_map: {
      o2_percent: 4.0,
      co2_percent: 5.0,
      n2_percent: 91.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'Equilibrium MAP (4% O2, 5% CO2) retards ethylene synthesis and anthracnose fungal rot while maintaining aroma.'
    },
    target_shelf_life_days: 28,
    description: 'High-value GI export fruit susceptible to rapid climacteric softening, chilling injury below 10°C, and anthracnose.'
  },
  {
    id: 'cavendish_banana',
    name: 'Cavendish Banana Cluster',
    category: 'fresh_produce',
    storage_temp_c: 13.5,
    density_kg_m3: 950,
    initial_aw: 0.98,
    initial_moisture_g100g: 75.0,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 6.0,
    initial_cfu_g: 2.0,
    gab_xm: 20.0,
    gab_c: 7.0,
    gab_k: 0.86,
    max_growth_rate_mu_max: 0.32,
    lag_phase_lambda_days: 3.5,
    co2_inhibition_factor: 0.60,
    oxidation_rate_k: 0.20,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 26.5,
      km_o2: 2.1,
      ki_co2: 9.0,
      rq: 1.20,
      t_ref_c: 13.5,
      q10: 2.4,
      extinction_o2_percent: 1.8
    },
    recommended_map: {
      o2_percent: 3.0,
      co2_percent: 5.0,
      n2_percent: 92.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'Low O2 suppresses climacteric ethylene surge; 5% CO2 inhibits peel spot senescence.'
    },
    target_shelf_life_days: 25,
    description: 'Highly climacteric fruit prone to rapid peel browning and sugar conversion under ambient conditions.'
  },
  {
    id: 'roma_tomato',
    name: 'Roma Field Tomatoes (Nashik / Kolar)',
    category: 'fresh_produce',
    storage_temp_c: 12.0,
    density_kg_m3: 920,
    initial_aw: 0.99,
    initial_moisture_g100g: 93.5,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 6.5,
    initial_cfu_g: 3.0,
    gab_xm: 24.0,
    gab_c: 5.5,
    gab_k: 0.90,
    max_growth_rate_mu_max: 0.38,
    lag_phase_lambda_days: 2.8,
    co2_inhibition_factor: 0.58,
    oxidation_rate_k: 0.12,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 16.0,
      km_o2: 1.6,
      ki_co2: 10.0,
      rq: 1.10,
      t_ref_c: 12.0,
      q10: 2.2,
      extinction_o2_percent: 1.5
    },
    recommended_map: {
      o2_percent: 3.5,
      co2_percent: 4.5,
      n2_percent: 92.0,
      gas_to_product_ratio: 1.8,
      reasoning: 'Maintains lycopene color while preventing Botrytis and Alternaria mold decay during long-haul interstate trucking.'
    },
    target_shelf_life_days: 21,
    description: 'High-volume perishable Indian crop subject to post-harvest transit losses and mechanical pressure bruising.'
  },
  {
    id: 'fresh_paneer_block',
    name: 'Fresh Dairy Paneer (Vacuum / MAP)',
    category: 'dairy_cheese',
    storage_temp_c: 4.0,
    density_kg_m3: 1060,
    initial_aw: 0.992,
    initial_moisture_g100g: 54.0,
    primary_degradation_mechanism: 'microbial',
    crit_microbial_cfu_g: 6.0,
    initial_cfu_g: 2.5,
    gab_xm: 16.0,
    gab_c: 10.0,
    gab_k: 0.85,
    max_growth_rate_mu_max: 0.48,
    lag_phase_lambda_days: 3.0,
    co2_inhibition_factor: 0.84,
    oxidation_rate_k: 0.22,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.1,
      co2_percent: 40.0,
      n2_percent: 59.9,
      gas_to_product_ratio: 1.5,
      reasoning: 'High CO2 (40%) suppresses Coliforms and Pseudomonas slime, extending shelf life from 3 to 21 days.'
    },
    target_shelf_life_days: 21,
    description: 'High moisture traditional unaged dairy cheese susceptible to rapid microbial souring and yeast/mold proliferation.'
  },
  {
    id: 'nashik_red_onion',
    name: 'Nashik Red Onions (Rabi / Kharif)',
    category: 'fresh_produce',
    storage_temp_c: 24.0,
    density_kg_m3: 650,
    initial_aw: 0.97,
    initial_moisture_g100g: 86.0,
    primary_degradation_mechanism: 'moisture_loss',
    crit_microbial_cfu_g: 6.0,
    initial_cfu_g: 2.0,
    gab_xm: 18.0,
    gab_c: 6.0,
    gab_k: 0.85,
    max_growth_rate_mu_max: 0.15,
    lag_phase_lambda_days: 10.0,
    co2_inhibition_factor: 0.50,
    oxidation_rate_k: 0.10,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 8.0,
      km_o2: 1.5,
      ki_co2: 12.0,
      rq: 1.05,
      t_ref_c: 20.0,
      q10: 2.0,
      extinction_o2_percent: 1.0
    },
    recommended_map: {
      o2_percent: 5.0,
      co2_percent: 3.0,
      n2_percent: 92.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'Ventilated mesh or breathable micro-perforated film prevents neck rot mold and sprouting.'
    },
    target_shelf_life_days: 90,
    description: 'High-volume Indian staple vegetable vulnerable to sprouting, rotting, and post-harvest moisture shrinkage in transit.'
  },
  {
    id: 'table_grapes_nashik',
    name: 'Thompson Seedless Grapes (Nashik GI)',
    category: 'fresh_produce',
    storage_temp_c: 1.0,
    density_kg_m3: 980,
    initial_aw: 0.98,
    initial_moisture_g100g: 82.0,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 5.5,
    initial_cfu_g: 2.0,
    gab_xm: 20.0,
    gab_c: 7.0,
    gab_k: 0.87,
    max_growth_rate_mu_max: 0.22,
    lag_phase_lambda_days: 6.0,
    co2_inhibition_factor: 0.70,
    oxidation_rate_k: 0.12,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 12.0,
      km_o2: 1.8,
      ki_co2: 10.0,
      rq: 1.12,
      t_ref_c: 2.0,
      q10: 2.3,
      extinction_o2_percent: 1.5
    },
    recommended_map: {
      o2_percent: 5.0,
      co2_percent: 10.0,
      n2_percent: 85.0,
      gas_to_product_ratio: 2.0,
      reasoning: 'SO2 dual-release generator pad + micro-perforated punnet suppresses Botrytis cinerea grey mold during export.'
    },
    target_shelf_life_days: 45,
    description: 'Prime export table grape susceptible to grey mold rot, berry shatter, and stem rachis browning.'
  },
  {
    id: 'shimla_apple',
    name: 'Royal Delicious Apple (Himachal / Kashmir)',
    category: 'fresh_produce',
    storage_temp_c: 2.0,
    density_kg_m3: 840,
    initial_aw: 0.985,
    initial_moisture_g100g: 85.0,
    primary_degradation_mechanism: 'respiration_fermentation',
    crit_microbial_cfu_g: 5.0,
    initial_cfu_g: 1.8,
    gab_xm: 21.0,
    gab_c: 7.5,
    gab_k: 0.88,
    max_growth_rate_mu_max: 0.18,
    lag_phase_lambda_days: 14.0,
    co2_inhibition_factor: 0.65,
    oxidation_rate_k: 0.14,
    is_respiring_produce: true,
    produce_respiration: {
      vm_o2_ref: 10.0,
      km_o2: 1.5,
      ki_co2: 9.0,
      rq: 1.10,
      t_ref_c: 2.0,
      q10: 2.2,
      extinction_o2_percent: 1.2
    },
    recommended_map: {
      o2_percent: 2.0,
      co2_percent: 1.5,
      n2_percent: 96.5,
      gas_to_product_ratio: 2.0,
      reasoning: 'Ultra-low O2 (1-2%) retards ethylene-induced starch degradation and flesh mealy softening.'
    },
    target_shelf_life_days: 120,
    description: 'Temperate climate fruit stored in controlled atmosphere chambers, vulnerable to superficial scald and bitter pit.'
  },
  {
    id: 'turmeric_curcumin',
    name: 'Salem / Erode Pure Turmeric Powder',
    category: 'dry_snacks',
    storage_temp_c: 22.0,
    density_kg_m3: 650,
    initial_aw: 0.35,
    initial_moisture_g100g: 7.5,
    primary_degradation_mechanism: 'oxidation',
    crit_moisture_max_g100g: 10.0,
    crit_microbial_cfu_g: 4.5,
    initial_cfu_g: 1.5,
    gab_xm: 5.0,
    gab_c: 15.0,
    gab_k: 0.75,
    max_growth_rate_mu_max: 0.01,
    lag_phase_lambda_days: 150,
    co2_inhibition_factor: 0.2,
    oxidation_rate_k: 0.25,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.5,
      co2_percent: 0.0,
      n2_percent: 99.5,
      gas_to_product_ratio: 1.5,
      reasoning: 'High nitrogen flush in metallized foil prevents UV photo-oxidation and curcumin pigment bleaching.'
    },
    target_shelf_life_days: 365,
    description: 'High-value aromatic spice rich in bioactive curcuminoids, vulnerable to photodegradation, moisture caking, and aroma loss.'
  },
  {
    id: 'basmati_rice',
    name: 'Pusa 1121 Aged Basmati Rice',
    category: 'dry_snacks',
    storage_temp_c: 22.0,
    density_kg_m3: 820,
    initial_aw: 0.45,
    initial_moisture_g100g: 11.5,
    primary_degradation_mechanism: 'moisture_gain',
    crit_moisture_max_g100g: 14.0,
    crit_microbial_cfu_g: 4.0,
    initial_cfu_g: 1.0,
    gab_xm: 6.5,
    gab_c: 14.0,
    gab_k: 0.74,
    max_growth_rate_mu_max: 0.005,
    lag_phase_lambda_days: 200,
    co2_inhibition_factor: 0.3,
    oxidation_rate_k: 0.08,
    is_respiring_produce: false,
    recommended_map: {
      o2_percent: 0.2,
      co2_percent: 20.0,
      n2_percent: 79.8,
      gas_to_product_ratio: 1.2,
      reasoning: 'Vacuum or nitrogen barrier prevents weevil (Sitophilus oryzae) infestation and yellowing rancidity.'
    },
    target_shelf_life_days: 540,
    description: 'Premium aromatic long-grain cereal grain requiring moisture exclusion to prevent mold growth, mycotoxins, and infestation.'
  }
];

const FOOD_ALIASES: Record<string, string> = {
  tomato: 'roma_tomato',
  tomato_hybrid: 'roma_tomato',
  tamatar: 'roma_tomato',
  mango: 'alphonso_mango',
  aam: 'alphonso_mango',
  banana: 'cavendish_banana',
  kela: 'cavendish_banana',
  paneer: 'fresh_paneer_block',
  fresh_paneer: 'fresh_paneer_block',
  cheese: 'cheddar_cheese_blocks',
  chips: 'potato_crisps',
  crisps: 'potato_crisps',
  bread: 'sliced_bread',
  coffee: 'roasted_coffee_beans',
  salad: 'cut_salad_greens',
  lettuce: 'cut_salad_greens',
  strawberry: 'strawberries',
  onion: 'nashik_red_onion',
  pyaz: 'nashik_red_onion',
  grapes: 'table_grapes_nashik',
  angoor: 'table_grapes_nashik',
  table_grapes: 'table_grapes_nashik',
  apple: 'shimla_apple',
  seb: 'shimla_apple',
  turmeric: 'turmeric_curcumin',
  haldi: 'turmeric_curcumin',
  rice: 'basmati_rice',
  chawal: 'basmati_rice'
};

export function getFoodById(id: string): FoodProduct | undefined {
  if (!id) return undefined;
  const direct = FOODS_DATABASE.find(f => f.id === id);
  if (direct) return direct;
  const canonicalId = FOOD_ALIASES[id.toLowerCase()];
  if (canonicalId) {
    return FOODS_DATABASE.find(f => f.id === canonicalId);
  }
  // Substring match
  const lower = id.toLowerCase();
  return FOODS_DATABASE.find(f => f.id.toLowerCase().includes(lower) || f.name.toLowerCase().includes(lower));
}
