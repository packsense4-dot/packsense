/**
 * redisClient.ts
 * 
 * Production-ready Upstash / Redis Client for PackSense Engineering Suite.
 * Handles TLS, connection string sanitization (stripping CLI flags), caching,
 * and live health checks.
 */

import Redis from 'ioredis';

let redisInstance: Redis | null = null;
let isConnected = false;
let lastPingLatencyMs = 0;
let lastCheckedAt = '';

/**
 * Sanitizes connection string:
 * - strips "redis-cli --tls -u " CLI prefixes if pasted directly from Upstash console
 * - ensures Upstash domains use rediss:// (TLS)
 */
export function sanitizeRedisUrl(rawUrl?: string): string {
  if (!rawUrl) {
    return 'redis://localhost:6379/0';
  }

  let cleaned = rawUrl.trim();

  // Strip CLI prefix like "redis-cli --tls -u "
  if (cleaned.startsWith('redis-cli')) {
    cleaned = cleaned.replace(/^redis-cli\s+(--tls\s+)?-u\s+/, '').trim();
  }

  // If pointing to upstash.io and starts with redis://, upgrade to rediss:// for TLS
  if (cleaned.includes('upstash.io') && cleaned.startsWith('redis://')) {
    cleaned = cleaned.replace(/^redis:\/\//, 'rediss://');
  }

  return cleaned;
}

export function getRedisClient(): Redis | null {
  if (redisInstance) {
    return redisInstance;
  }

  const rawEnvUrl = process.env.REDIS_URL || process.env.REDIS_SYNC_URL;
  if (!rawEnvUrl) {
    return null;
  }

  try {
    const sanitizedUrl = sanitizeRedisUrl(rawEnvUrl);
    const isTls = sanitizedUrl.startsWith('rediss://') || sanitizedUrl.includes('upstash.io');

    redisInstance = new Redis(sanitizedUrl, {
      maxRetriesPerRequest: 2,
      enableReadyCheck: true,
      lazyConnect: false,
      connectTimeout: 5000,
      tls: isTls ? { rejectUnauthorized: false } : undefined,
      retryStrategy(times) {
        if (times > 3) {
          return null; // Stop retrying after 3 attempts
        }
        return Math.min(times * 200, 1000);
      }
    });

    redisInstance.on('connect', () => {
      isConnected = true;
      console.log('[Redis] Connected successfully to Upstash / Redis instance.');
    });

    redisInstance.on('ready', () => {
      isConnected = true;
    });

    redisInstance.on('error', (err) => {
      isConnected = false;
      console.warn('[Redis] Connection warning (running in graceful cache mode):', err.message);
    });

    redisInstance.on('close', () => {
      isConnected = false;
    });

    return redisInstance;
  } catch (err: any) {
    console.error('[Redis Init Failed]', err.message);
    return null;
  }
}

/**
 * Checks Redis health, performs live PING, and returns latency
 */
export async function checkRedisHealth(): Promise<{
  ok: boolean;
  status: string;
  latency_ms: number;
  host: string;
  tls_enabled: boolean;
  checked_at: string;
  message?: string;
}> {
  const rawEnvUrl = process.env.REDIS_URL;
  const sanitized = sanitizeRedisUrl(rawEnvUrl);
  let host = 'localhost';
  try {
    const parsed = new URL(sanitized);
    host = parsed.hostname;
  } catch {
    // fallback
  }

  const client = getRedisClient();
  if (!client) {
    return {
      ok: false,
      status: 'NOT_CONFIGURED',
      latency_ms: 0,
      host,
      tls_enabled: false,
      checked_at: new Date().toISOString(),
      message: 'REDIS_URL is not configured.'
    };
  }

  const t0 = Date.now();
  try {
    const res = await client.ping();
    const latency = Date.now() - t0;
    lastPingLatencyMs = latency;
    lastCheckedAt = new Date().toISOString();
    isConnected = res === 'PONG';

    return {
      ok: isConnected,
      status: isConnected ? 'CONNECTED' : 'UNEXPECTED_PING_REPLY',
      latency_ms: latency,
      host,
      tls_enabled: sanitized.startsWith('rediss://') || host.includes('upstash.io'),
      checked_at: lastCheckedAt,
      message: isConnected ? `PING-PONG verified in ${latency}ms` : `Replied: ${res}`
    };
  } catch (err: any) {
    return {
      ok: false,
      status: 'CONNECTION_ERROR',
      latency_ms: Date.now() - t0,
      host,
      tls_enabled: sanitized.startsWith('rediss://') || host.includes('upstash.io'),
      checked_at: new Date().toISOString(),
      message: err.message || 'Failed to ping Redis server'
    };
  }
}

/**
 * Cache Set with optional TTL
 */
export async function cacheSet(key: string, value: any, ttlSeconds?: number): Promise<boolean> {
  const client = getRedisClient();
  if (!client) return false;

  try {
    const strVal = typeof value === 'string' ? value : JSON.stringify(value);
    if (ttlSeconds && ttlSeconds > 0) {
      await client.set(key, strVal, 'EX', ttlSeconds);
    } else {
      await client.set(key, strVal);
    }
    return true;
  } catch (err: any) {
    console.warn(`[Redis Cache Set Error for ${key}]:`, err.message);
    return false;
  }
}

/**
 * Cache Get
 */
export async function cacheGet<T = any>(key: string): Promise<T | null> {
  const client = getRedisClient();
  if (!client) return null;

  try {
    const val = await client.get(key);
    if (!val) return null;
    try {
      return JSON.parse(val) as T;
    } catch {
      return val as unknown as T;
    }
  } catch (err: any) {
    console.warn(`[Redis Cache Get Error for ${key}]:`, err.message);
    return null;
  }
}

/**
 * Cache Delete
 */
export async function cacheDel(key: string): Promise<boolean> {
  const client = getRedisClient();
  if (!client) return false;

  try {
    await client.del(key);
    return true;
  } catch {
    return false;
  }
}
