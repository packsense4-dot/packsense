/**
 * PackSense Multi-Objective Packaging Optimizer
 * 
 * Explores combinatorial film structures, layer gauges, and MAP formulations
 * against deterministic physics simulations to compute Pareto frontiers:
 * - Maximize Shelf Life (days)
 * - Minimize Cost per Pack ($)
 * - Minimize Carbon Footprint (g CO2e / pack)
 * - Maximize Circularity / Recyclability Score
 * 
 * Returns non-dominated Pareto front and engineered recommendations.
 */

import { FoodProduct } from './foodsDb.ts';
import {
  LaminateLayerInput,
  LaminateBarrierResult,
  PackageGeometry,
  SimulationConditions,
  MapGasConfig,
  calculateLaminateBarrier,
  simulateShelfLife,
  ShelfLifeSimulationResult
} from './physics.ts';

export interface CandidateStructureArchetype {
  id: string;
  name: string;
  category: 'mono_pe' | 'mono_pp' | 'multimaterial_barrier' | 'paper_barrier' | 'compostable';
  description: string;
  generateLayers: (gauge_level: 'thin' | 'medium' | 'heavy' | 'ultra') => LaminateLayerInput[];
}

export const ARCHETYPES: CandidateStructureArchetype[] = [
  {
    id: 'mono_pe_standard',
    name: 'Mono-PE Standard Sealing Film (HDPE / LLDPE)',
    category: 'mono_pe',
    description: '100% Polyethylene laminate recyclable in PE stream (CEFLEX Class A). High moisture barrier, moderate gas barrier.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [20, 30],
        medium: [30, 45],
        heavy: [40, 60],
        ultra: [50, 75]
      }[gauge];
      return [
        { material_id: 'hdpe', thickness_um: thicknesses[0] },
        { material_id: 'lldpe', thickness_um: thicknesses[1] }
      ];
    }
  },
  {
    id: 'mono_pe_high_barrier',
    name: 'Mono-PE High-Barrier Coex (PE / EVOH / PE)',
    category: 'mono_pe',
    description: 'Recyclable Mono-PE structure with encapsulated EVOH core (<5% total mass) for extreme O2 barrier without compromising PE recycling.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [25, 2.5, 30],
        medium: [35, 3.5, 45],
        heavy: [45, 4.5, 55],
        ultra: [60, 5.0, 70]
      }[gauge];
      return [
        { material_id: 'lldpe', thickness_um: thicknesses[0] },
        { material_id: 'evoh_32', thickness_um: thicknesses[1] },
        { material_id: 'lldpe', thickness_um: thicknesses[2] }
      ];
    }
  },
  {
    id: 'mono_pp_barrier',
    name: 'Mono-PP Metallized Snack Web (BOPP / Met-BOPP / CPP)',
    category: 'mono_pp',
    description: 'Fully circular Polypropylene laminate with vacuum-metallized barrier. Exceptional moisture and light shield.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [15, 18, 25],
        medium: [20, 20, 30],
        heavy: [25, 25, 40],
        ultra: [30, 28, 50]
      }[gauge];
      return [
        { material_id: 'bopp', thickness_um: thicknesses[0] },
        { material_id: 'met_bopp', thickness_um: thicknesses[1] },
        { material_id: 'cpp', thickness_um: thicknesses[2] }
      ];
    }
  },
  {
    id: 'pet_alu_pe_foil',
    name: 'Ultra-High Barrier Foil Laminate (BOPET / Alu-Foil / LLDPE)',
    category: 'multimaterial_barrier',
    description: 'Classic 3-ply retort/vacuum foil structure. Near-zero OTR and WVTR for multi-year ambient stability.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [12, 7, 35],
        medium: [12, 7, 50],
        heavy: [12, 9, 70],
        ultra: [15, 12, 90]
      }[gauge];
      return [
        { material_id: 'bopet', thickness_um: thicknesses[0] },
        { material_id: 'alu_foil', thickness_um: thicknesses[1] },
        { material_id: 'lldpe', thickness_um: thicknesses[2] }
      ];
    }
  },
  {
    id: 'pet_met_pe',
    name: 'High Barrier Metallized Laminate (BOPET / Met-PET / LLDPE)',
    category: 'multimaterial_barrier',
    description: 'High tensile strength metallized PET barrier with PE seal layer. Excellent puncture resistance.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [12, 12, 35],
        medium: [12, 15, 45],
        heavy: [15, 18, 60],
        ultra: [18, 23, 75]
      }[gauge];
      return [
        { material_id: 'bopet', thickness_um: thicknesses[0] },
        { material_id: 'met_pet', thickness_um: thicknesses[1] },
        { material_id: 'lldpe', thickness_um: thicknesses[2] }
      ];
    }
  },
  {
    id: 'bopa_pe_meat',
    name: 'Puncture Resistant Vacuum Film (BOPA / LLDPE)',
    category: 'multimaterial_barrier',
    description: 'Biaxially oriented nylon laminated to PE. High puncture resistance for bone-in fresh meat and vacuum packs.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [15, 40],
        medium: [18, 55],
        heavy: [20, 70],
        ultra: [25, 90]
      }[gauge];
      return [
        { material_id: 'bopa', thickness_um: thicknesses[0] },
        { material_id: 'lldpe', thickness_um: thicknesses[1] }
      ];
    }
  },
  {
    id: 'kraft_bio_paper',
    name: 'Renewable FSC Kraft Paper + Bio-Barrier (Paper / Bio-PBS)',
    category: 'paper_barrier',
    description: 'Curbside recyclable paper laminate with aqueous bio-barrier for dry goods and ambient snacks.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [45, 20],
        medium: [60, 25],
        heavy: [75, 30],
        ultra: [90, 40]
      }[gauge];
      return [
        { material_id: 'barrier_paper', thickness_um: thicknesses[0] },
        { material_id: 'bio_pbs', thickness_um: thicknesses[1] }
      ];
    }
  },
  {
    id: 'compostable_bio',
    name: 'Industrial Compostable Duplex (PLA / Bio-PBS)',
    category: 'compostable',
    description: '100% bio-based compostable film certified under EN 13432. Breathable barrier suitable for produce and organic foods.',
    generateLayers: (gauge) => {
      const thicknesses = {
        thin: [20, 25],
        medium: [25, 35],
        heavy: [35, 45],
        ultra: [45, 60]
      }[gauge];
      return [
        { material_id: 'pla', thickness_um: thicknesses[0] },
        { material_id: 'bio_pbs', thickness_um: thicknesses[1] }
      ];
    }
  }
];

export interface EvaluatedPackagingCandidate {
  id: string;
  archetype_id: string;
  archetype_name: string;
  gauge_level: 'thin' | 'medium' | 'heavy' | 'ultra';
  map_strategy: string;
  layers: LaminateLayerInput[];
  barrier: LaminateBarrierResult;
  predicted_shelf_life_days: number;
  cost_per_pack_usd: number;
  carbon_per_pack_g_co2e: number;
  recyclability_score: number;
  recyclability_class: string;
  is_pareto_optimal: boolean;
  limiting_factor: string;
  utility_score: number;
  meets_target_shelf_life: boolean;
}

export interface OptimizationPreferences {
  target_shelf_life_days?: number;
  max_cost_per_pack_usd?: number;
  max_carbon_per_pack_g_co2e?: number;
  min_recyclability_score?: number;
  prioritize: 'balanced' | 'shelf_life' | 'cost' | 'carbon' | 'circularity';
}

export interface OptimizationResult {
  all_candidates_count: number;
  pareto_frontier_count: number;
  pareto_candidates: EvaluatedPackagingCandidate[];
  all_candidates: EvaluatedPackagingCandidate[];
  recommendations: {
    balanced: EvaluatedPackagingCandidate;
    max_shelf_life: EvaluatedPackagingCandidate;
    lowest_cost: EvaluatedPackagingCandidate;
    lowest_carbon: EvaluatedPackagingCandidate;
    best_circular_recyclable: EvaluatedPackagingCandidate;
  };
  exact_packaging_spec: {
    target_otr_cc_m2_day: number;
    target_wvtr_g_m2_day: number;
    film_thickness_um: number;
    recommended_map: {
      o2_percent: number;
      co2_percent: number;
      n2_percent: number;
    };
    predicted_shelf_life_days: number;
    cost_per_pack_usd: number;
    co2_footprint_per_pack_g: number;
    structure_summary: string;
  };
}

/**
 * Executes deterministic multi-objective optimization across archetypes, gauges, and MAP configs
 */
export function runPackagingOptimization(
  food: FoodProduct,
  geometry: PackageGeometry,
  conditions: SimulationConditions,
  preferences: OptimizationPreferences
): OptimizationResult {
  const targetShelfLife = preferences.target_shelf_life_days || food.target_shelf_life_days;
  const gauges: Array<'thin' | 'medium' | 'heavy' | 'ultra'> = ['thin', 'medium', 'heavy', 'ultra'];

  // Test MAP variants:
  // 1. Recommended Food MAP
  // 2. Air Pack (20.9% O2, 0.04% CO2)
  // 3. High CO2 Flush (if applicable) or Pure N2
  const mapConfigs: Array<{ name: string; cfg: MapGasConfig }> = [
    {
      name: 'Optimized MAP',
      cfg: {
        initial_o2_percent: food.recommended_map.o2_percent,
        initial_co2_percent: food.recommended_map.co2_percent,
        initial_n2_percent: food.recommended_map.n2_percent,
        gas_to_product_volume_ratio: food.recommended_map.gas_to_product_ratio
      }
    },
    {
      name: 'Ambient Air',
      cfg: {
        initial_o2_percent: 20.9,
        initial_co2_percent: 0.04,
        initial_n2_percent: 79.06,
        gas_to_product_volume_ratio: 1.5
      }
    }
  ];

  if (food.recommended_map.co2_percent > 0 && food.recommended_map.co2_percent < 50) {
    mapConfigs.push({
      name: 'High-CO2 Antimicrobial Boost',
      cfg: {
        initial_o2_percent: Math.max(0, food.recommended_map.o2_percent - 5),
        initial_co2_percent: Math.min(60, food.recommended_map.co2_percent + 20),
        initial_n2_percent: Math.max(0, 100 - (food.recommended_map.o2_percent - 5) - (food.recommended_map.co2_percent + 20)),
        gas_to_product_volume_ratio: 2.0
      }
    });
  }

  const evaluated: EvaluatedPackagingCandidate[] = [];

  // Generate and simulate all candidate permutations
  for (const arch of ARCHETYPES) {
    for (const gauge of gauges) {
      for (const mapEntry of mapConfigs) {
        const layers = arch.generateLayers(gauge);
        const barrier = calculateLaminateBarrier(layers, conditions.storage_temp_c, conditions.ambient_rh_percent);
        
        const sim = simulateShelfLife(
          food,
          barrier,
          geometry,
          conditions,
          mapEntry.cfg,
          Math.max(180, targetShelfLife * 1.5)
        );

        const meetsShelf = sim.predicted_shelf_life_days >= targetShelfLife;

        // Base weights for utility calculation
        const shelfScore = Math.min(1.5, sim.predicted_shelf_life_days / targetShelfLife);
        const costScore = 1 / (1 + sim.cost_per_pack_usd * 20);
        const carbonScore = 1 / (1 + sim.carbon_per_pack_g_co2e * 0.1);
        const recyclabilityScore = barrier.recyclability_score / 100;

        let w_shelf = 0.35;
        let w_cost = 0.25;
        let w_carbon = 0.20;
        let w_rec = 0.20;

        if (preferences.prioritize === 'shelf_life') {
          w_shelf = 0.60; w_cost = 0.15; w_carbon = 0.15; w_rec = 0.10;
        } else if (preferences.prioritize === 'cost') {
          w_shelf = 0.20; w_cost = 0.60; w_carbon = 0.10; w_rec = 0.10;
        } else if (preferences.prioritize === 'carbon') {
          w_shelf = 0.20; w_cost = 0.15; w_carbon = 0.50; w_rec = 0.15;
        } else if (preferences.prioritize === 'circularity') {
          w_shelf = 0.20; w_cost = 0.15; w_carbon = 0.15; w_rec = 0.50;
        }

        const utility = (
          shelfScore * w_shelf +
          costScore * w_cost +
          carbonScore * w_carbon +
          recyclabilityScore * w_rec
        ) * 100;

        evaluated.push({
          id: `${arch.id}_${gauge}_${mapEntry.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
          archetype_id: arch.id,
          archetype_name: arch.name,
          gauge_level: gauge,
          map_strategy: mapEntry.name,
          layers,
          barrier,
          predicted_shelf_life_days: sim.predicted_shelf_life_days,
          cost_per_pack_usd: sim.cost_per_pack_usd,
          carbon_per_pack_g_co2e: sim.carbon_per_pack_g_co2e,
          recyclability_score: barrier.recyclability_score,
          recyclability_class: barrier.recyclability_class,
          is_pareto_optimal: false,
          limiting_factor: sim.limiting_description,
          utility_score: Number(utility.toFixed(2)),
          meets_target_shelf_life: meetsShelf
        });
      }
    }
  }

  // Non-dominated Pareto Filtering:
  // Objective 1: Maximize Shelf Life
  // Objective 2: Minimize Cost
  // Objective 3: Minimize Carbon
  // Objective 4: Maximize Recyclability
  for (let i = 0; i < evaluated.length; i++) {
    const p = evaluated[i];
    let isDominated = false;

    for (let j = 0; j < evaluated.length; j++) {
      if (i === j) continue;
      const q = evaluated[j];

      const q_better_or_equal =
        q.predicted_shelf_life_days >= p.predicted_shelf_life_days &&
        q.cost_per_pack_usd <= p.cost_per_pack_usd &&
        q.carbon_per_pack_g_co2e <= p.carbon_per_pack_g_co2e &&
        q.recyclability_score >= p.recyclability_score;

      const q_strictly_better =
        q.predicted_shelf_life_days > p.predicted_shelf_life_days ||
        q.cost_per_pack_usd < p.cost_per_pack_usd ||
        q.carbon_per_pack_g_co2e < p.carbon_per_pack_g_co2e ||
        q.recyclability_score > p.recyclability_score;

      if (q_better_or_equal && q_strictly_better) {
        isDominated = true;
        break;
      }
    }

    p.is_pareto_optimal = !isDominated;
  }

  const pareto_candidates = evaluated.filter(c => c.is_pareto_optimal);

  // Recommendations:
  // 1. Balanced: highest utility among candidates meeting target shelf life (or highest utility overall)
  const meetingCandidates = evaluated.filter(c => c.meets_target_shelf_life);
  const pool = meetingCandidates.length > 0 ? meetingCandidates : evaluated;

  const balanced = [...pool].sort((a, b) => b.utility_score - a.utility_score)[0] || evaluated[0];
  const max_shelf_life = [...evaluated].sort((a, b) => b.predicted_shelf_life_days - a.predicted_shelf_life_days)[0];
  const lowest_cost = [...pool].sort((a, b) => a.cost_per_pack_usd - b.cost_per_pack_usd)[0] || evaluated[0];
  const lowest_carbon = [...pool].sort((a, b) => a.carbon_per_pack_g_co2e - b.carbon_per_pack_g_co2e)[0] || evaluated[0];
  const best_circular = [...pool].sort((a, b) => b.recyclability_score - a.recyclability_score || b.predicted_shelf_life_days - a.predicted_shelf_life_days)[0] || evaluated[0];

  const primaryChoice = balanced;

  return {
    all_candidates_count: evaluated.length,
    pareto_frontier_count: pareto_candidates.length,
    pareto_candidates,
    all_candidates: evaluated,
    recommendations: {
      balanced,
      max_shelf_life,
      lowest_cost,
      lowest_carbon,
      best_circular_recyclable: best_circular
    },
    exact_packaging_spec: {
      target_otr_cc_m2_day: primaryChoice.barrier.otr_cc_m2_day_atm,
      target_wvtr_g_m2_day: primaryChoice.barrier.wvtr_g_m2_day,
      film_thickness_um: primaryChoice.barrier.total_thickness_um,
      recommended_map: {
        o2_percent: food.recommended_map.o2_percent,
        co2_percent: food.recommended_map.co2_percent,
        n2_percent: food.recommended_map.n2_percent
      },
      predicted_shelf_life_days: primaryChoice.predicted_shelf_life_days,
      cost_per_pack_usd: primaryChoice.cost_per_pack_usd,
      co2_footprint_per_pack_g: primaryChoice.carbon_per_pack_g_co2e,
      structure_summary: `${primaryChoice.archetype_name} (${primaryChoice.gauge_level.toUpperCase()} gauge - ${primaryChoice.barrier.total_thickness_um} µm)`
    }
  };
}
