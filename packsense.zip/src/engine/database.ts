import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

export interface UserRecord {
  id: number;
  phone_number?: string;
  email: string;
  password_hash: string;
  name: string;
  preferred_language: string;
  role: 'farmer' | 'fpo' | 'msme' | 'industry' | 'admin' | 'government';
  role_status?: 'pending' | 'approved' | 'rejected';
  organization: string;
  is_active: boolean;
  last_login_at?: string | null;
  created_at: string;
  last_active_at?: string;
  pending_role?: string;
  must_change_password?: boolean;
  is_bootstrap_admin?: boolean;
  email_verified?: boolean;
  verification_token?: string;
}

export interface RefreshTokenRecord {
  id: number;
  user_id: number;
  token_hash: string; // sha256 hash of refresh token
  expires_at: string;
  revoked: boolean;
  created_at: string;
}

export interface SimulationRecord {
  id: string;
  user_id?: number;
  user_name?: string;
  food_id: string;
  food_name: string;
  predicted_shelf_life_days: number;
  layers_summary: string;
  thickness_um: number;
  otr: number;
  wvtr: number;
  storage_temp_c: number;
  ambient_rh_pct: number;
  created_at: string;
  notes?: string;
}

export interface BatchLoggerRecord {
  batch_id: string;
  food_name: string;
  registered_at: string;
  device_mac?: string;
  current_status: 'ACTIVE_TRANSIT' | 'DELIVERED_SAFE' | 'COLD_CHAIN_ALERT';
  readings: Array<{
    timestamp: string;
    temperature_c: number;
    rh_percent: number;
    sensor_id: string;
    battery_mv?: number;
  }>;
}

export interface CommunityFeedbackRecord {
  id: number;
  commodity: string;
  user_stage: number;
  predicted_stage: number;
  comment?: string;
  created_at: string;
}

export interface CommunityOutcomeRecord {
  id: string;
  commodity: string;
  pack_type: string;
  days_achieved: number;
  farmer_location: string;
  rating: number;
  created_at: string;
}

export interface WhatsAppSessionRecord {
  phone: string;
  profile_name: string;
  created_at: string;
  updated_at: string;
  messages_count: number;
  last_intent: string;
  history: Array<{
    timestamp: string;
    farmer_msg: string;
    bot_reply: string;
    intent: string;
  }>;
}

export interface SyncTransactionRecord {
  id: string;
  client_id: string;
  received_at: string;
  records_count: number;
  status: 'COMMITTED' | 'CONFLICT_RESOLVED';
  records: any[];
}

export interface PackLabelScanRecord {
  id: number;
  user_id?: number;
  raw_text: string;
  extracted_material?: string | null;
  extracted_thickness?: number | null;
  matched_film_id?: number | null;
  match_confidence: number;
  was_accepted_by_user?: boolean | null;
  created_at: string;
}

export interface DatabaseSchema {
  version: string;
  last_updated: string;
  active_user_role: string;
  users: Record<string, UserRecord>;
  simulations: SimulationRecord[];
  batch_loggers: Record<string, BatchLoggerRecord>;
  whatsapp_sessions: Record<string, WhatsAppSessionRecord>;
  community_feedback: CommunityFeedbackRecord[];
  community_outcomes: CommunityOutcomeRecord[];
  sync_transactions: SyncTransactionRecord[];
  pack_label_scans: PackLabelScanRecord[];
  refresh_tokens: RefreshTokenRecord[];
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'packsense_db.json');

// Standard bcrypt hash for seed accounts (password: PackSense2026!)
const SEED_BCRYPT_HASH = bcrypt.hashSync('PackSense2026!', 10);
const ADMIN_BCRYPT_HASH = bcrypt.hashSync('AdminPass123!', 10);

// Initial baseline seed data
const INITIAL_DATABASE: DatabaseSchema = {
  version: '2.6.0',
  last_updated: new Date().toISOString(),
  active_user_role: 'farmer',
  users: {
    'farmer@packsense.org': {
      id: 1,
      phone_number: '+919822001122',
      email: 'farmer@packsense.org',
      password_hash: SEED_BCRYPT_HASH,
      name: 'Ramesh Patil',
      preferred_language: 'marathi',
      role: 'farmer',
      role_status: 'approved',
      organization: 'Devgad Mango Growers Co-op',
      is_active: true,
      last_login_at: null,
      created_at: '2026-01-15T08:00:00Z',
      last_active_at: new Date().toISOString()
    },
    'fpo@packsense.org': {
      id: 2,
      phone_number: '+919822003344',
      email: 'fpo@packsense.org',
      password_hash: SEED_BCRYPT_HASH,
      name: 'Sahyadri Farmers Producer Co.',
      preferred_language: 'marathi',
      role: 'fpo',
      role_status: 'approved',
      organization: 'Sahyadri Farmers Producer Co.',
      is_active: true,
      last_login_at: null,
      created_at: '2026-02-01T09:30:00Z',
      last_active_at: new Date().toISOString()
    },
    'msme@packsense.org': {
      id: 3,
      phone_number: '+919822005566',
      email: 'msme@packsense.org',
      password_hash: SEED_BCRYPT_HASH,
      name: 'Konkan Agro Food Processors',
      preferred_language: 'hindi',
      role: 'msme',
      role_status: 'approved',
      organization: 'Konkan Agro MSME Unit',
      is_active: true,
      last_login_at: null,
      created_at: '2026-02-15T11:00:00Z',
      last_active_at: new Date().toISOString()
    },
    'industry@packsense.org': {
      id: 4,
      phone_number: '+919822007788',
      email: 'industry@packsense.org',
      password_hash: SEED_BCRYPT_HASH,
      name: 'ITC Agro-Tech Operations',
      preferred_language: 'english',
      role: 'industry',
      role_status: 'approved',
      organization: 'ITC Packaging Division',
      is_active: true,
      last_login_at: null,
      created_at: '2026-01-10T14:20:00Z',
      last_active_at: new Date().toISOString()
    },
    'admin@packsense.org': {
      id: 5,
      phone_number: '+919822009900',
      email: 'admin@packsense.org',
      password_hash: ADMIN_BCRYPT_HASH,
      name: 'Dr. S. K. Sharma (Director)',
      preferred_language: 'english',
      role: 'admin',
      role_status: 'approved',
      organization: 'MoFPI Packaging Standards Directorate',
      is_active: true,
      last_login_at: null,
      created_at: '2026-01-01T00:00:00Z',
      last_active_at: new Date().toISOString()
    },
    'gov@packsense.org': {
      id: 6,
      phone_number: '+919811002233',
      email: 'gov@packsense.org',
      password_hash: SEED_BCRYPT_HASH,
      name: 'MoFPI District Data Officer',
      preferred_language: 'english',
      role: 'government',
      role_status: 'approved',
      organization: 'Ministry of Food Processing Industries',
      is_active: true,
      last_login_at: null,
      created_at: '2026-01-05T10:00:00Z',
      last_active_at: new Date().toISOString()
    }
  },
  simulations: [
    {
      id: 'SIM-INIT-001',
      user_id: 1,
      user_name: 'Ramesh Patil',
      food_id: 'potato_crisps',
      food_name: 'Potato Crisps (Kettle Fried)',
      predicted_shelf_life_days: 122.5,
      layers_summary: 'BOPP (20μm) / Met-BOPP (20μm) / CPP (30μm)',
      thickness_um: 70,
      otr: 45.2,
      wvtr: 0.85,
      storage_temp_c: 21,
      ambient_rh_pct: 50,
      created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
      notes: 'Standard 3-ply moisture/oxygen high barrier baseline.'
    },
    {
      id: 'SIM-INIT-002',
      user_id: 1,
      user_name: 'Ramesh Patil',
      food_id: 'alphonso_mango',
      food_name: 'Alphonso Mango (GI Ratnagiri)',
      predicted_shelf_life_days: 22.8,
      layers_summary: 'PLA (20μm) / Bio-PBS (25μm)',
      thickness_um: 45,
      otr: 480.0,
      wvtr: 28.5,
      storage_temp_c: 12.0,
      ambient_rh_pct: 85,
      created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
      notes: 'Equilibrium MAP bio-compostable film for Ratnagiri export.'
    }
  ],
  batch_loggers: {
    'BATCH-TEST-001': {
      batch_id: 'BATCH-TEST-001',
      food_name: 'Alphonso Mango Export Grade A',
      registered_at: '2026-09-20T04:30:00Z',
      device_mac: 'AA:BB:CC:DD:EE:01',
      current_status: 'ACTIVE_TRANSIT',
      readings: [
        { timestamp: '2026-09-20T05:00:00Z', temperature_c: 12.1, rh_percent: 85.0, sensor_id: 'BLE-TEMP-01' },
        { timestamp: '2026-09-20T11:00:00Z', temperature_c: 12.4, rh_percent: 84.5, sensor_id: 'BLE-TEMP-01' },
        { timestamp: '2026-09-21T05:00:00Z', temperature_c: 12.0, rh_percent: 86.0, sensor_id: 'BLE-TEMP-01' },
        { timestamp: '2026-09-21T18:00:00Z', temperature_c: 14.8, rh_percent: 82.0, sensor_id: 'BLE-TEMP-01' },
        { timestamp: '2026-09-22T08:00:00Z', temperature_c: 12.2, rh_percent: 85.2, sensor_id: 'BLE-TEMP-01' }
      ]
    }
  },
  whatsapp_sessions: {
    'whatsapp:+919822001122': {
      phone: 'whatsapp:+919822001122',
      profile_name: 'Ramesh Patil (Devgad Farmer)',
      created_at: new Date(Date.now() - 3600000 * 48).toISOString(),
      updated_at: new Date().toISOString(),
      messages_count: 2,
      last_intent: 'PACKAGING_SPEC',
      history: [
        {
          timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
          farmer_msg: 'Mango Ratnagiri 21 days 12C',
          bot_reply: 'PackSense Engineering Spec: 45um PLA/Bio-PBS pouch, 3% O2 / 5% CO2. Expected shelf life: 22.8 days at 12°C.',
          intent: 'PACKAGING_SPEC'
        }
      ]
    }
  },
  community_feedback: [
    {
      id: 1,
      commodity: 'alphonso_mango',
      user_stage: 3,
      predicted_stage: 3,
      comment: 'Accurate yellow blush breaker stage match in Devgad mandi.',
      created_at: '2026-09-18T10:00:00Z'
    },
    {
      id: 2,
      commodity: 'roma_tomato',
      user_stage: 4,
      predicted_stage: 4,
      comment: 'Firm ripe stage matched Nashik APMC delivery.',
      created_at: '2026-09-22T14:15:00Z'
    }
  ],
  community_outcomes: [
    {
      id: 'OUTCOME-01',
      commodity: 'Alphonso Mango',
      pack_type: 'Micro-perforated Bio-PBS 30um',
      days_achieved: 23,
      farmer_location: 'Ratnagiri, MH',
      rating: 5,
      created_at: '2026-09-10T12:00:00Z'
    },
    {
      id: 'OUTCOME-02',
      commodity: 'Capsicum (Green)',
      pack_type: 'Anti-fog LDPE 40um',
      days_achieved: 18,
      farmer_location: 'Nashik, MH',
      rating: 4.8,
      created_at: '2026-09-15T09:00:00Z'
    }
  ],
  sync_transactions: [],
  pack_label_scans: [],
  refresh_tokens: []
};

let cachedDb: DatabaseSchema | null = null;

export function hashPassword(plain: string): string {
  return bcrypt.hashSync(plain, 10);
}

export function verifyPassword(plain: string, hash: string): boolean {
  try {
    return bcrypt.compareSync(plain, hash);
  } catch {
    return false;
  }
}

export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token.trim()).digest('hex');
}

export function sanitizeUser(user: UserRecord): Omit<UserRecord, 'password_hash'> {
  const { password_hash, ...sanitized } = user;
  return sanitized;
}

export function initDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      cachedDb = JSON.parse(content);
      if (!cachedDb!.pack_label_scans) cachedDb!.pack_label_scans = [];
      if (!cachedDb!.refresh_tokens) cachedDb!.refresh_tokens = [];

      // Ensure all users have lowercase email, valid bcrypt password_hash, and is_active flag
      let needsSave = false;
      for (const [key, user] of Object.entries(cachedDb!.users)) {
        if (!user.email) {
          user.email = key.includes('@') ? key.toLowerCase() : `user_${user.id}@packsense.org`;
          needsSave = true;
        } else if (user.email !== user.email.toLowerCase()) {
          user.email = user.email.toLowerCase();
          needsSave = true;
        }
        if (user.is_active === undefined) {
          user.is_active = true;
          needsSave = true;
        }
        if (user.last_login_at === undefined) {
          user.last_login_at = null;
          needsSave = true;
        }
        if (!user.password_hash || !user.password_hash.startsWith('$2')) {
          user.password_hash = user.role === 'admin' ? ADMIN_BCRYPT_HASH : SEED_BCRYPT_HASH;
          needsSave = true;
        }
      }

      if (needsSave) {
        fs.writeFileSync(DB_FILE, JSON.stringify(cachedDb, null, 2), 'utf-8');
      }

      return cachedDb!;
    } else {
      // First boot: write initial seed database
      cachedDb = JSON.parse(JSON.stringify(INITIAL_DATABASE));
      fs.writeFileSync(DB_FILE, JSON.stringify(cachedDb, null, 2), 'utf-8');
      return cachedDb!;
    }
  } catch (err) {
    console.error('[PackSense Database] Error initializing file database:', err);
    cachedDb = JSON.parse(JSON.stringify(INITIAL_DATABASE));
    if (!cachedDb!.pack_label_scans) cachedDb!.pack_label_scans = [];
    if (!cachedDb!.refresh_tokens) cachedDb!.refresh_tokens = [];
    return cachedDb!;
  }
}

export function getDatabase(): DatabaseSchema {
  if (!cachedDb) {
    return initDatabase();
  }
  return cachedDb;
}

export function persistDatabase(): boolean {
  if (!cachedDb) return false;
  try {
    cachedDb.last_updated = new Date().toISOString();
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(cachedDb, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
    return true;
  } catch (err) {
    console.error('[PackSense Database] Error persisting database to disk:', err);
    return false;
  }
}

export function findUserByEmail(email: string): UserRecord | undefined {
  const db = getDatabase();
  const lower = email.trim().toLowerCase();
  for (const user of Object.values(db.users)) {
    if (user.email && user.email.toLowerCase() === lower) {
      return user;
    }
  }
  return undefined;
}

export function findUserById(id: number): UserRecord | undefined {
  const db = getDatabase();
  for (const user of Object.values(db.users)) {
    if (user.id === id) {
      return user;
    }
  }
  return undefined;
}

export function insertUser(userPayload: {
  email: string;
  password: string;
  name: string;
  role: 'farmer' | 'fpo' | 'msme' | 'industry';
  organization?: string;
  phone_number?: string;
  preferred_language?: string;
}): UserRecord {
  const db = getDatabase();
  const lower = userPayload.email.trim().toLowerCase();
  const existing = findUserByEmail(lower);
  if (existing) {
    const error: any = new Error('An account with this email address already exists.');
    error.code = 'duplicate_email';
    throw error;
  }

  const allUsers = Object.values(db.users);
  const nextId = allUsers.length > 0 ? Math.max(...allUsers.map(u => u.id || 0)) + 1 : 1;
  const password_hash = hashPassword(userPayload.password);

  const newUser: UserRecord = {
    id: nextId,
    email: lower,
    password_hash,
    name: userPayload.name.trim(),
    role: userPayload.role,
    role_status: 'approved',
    organization: userPayload.organization || 'Independent Enterprise',
    phone_number: userPayload.phone_number,
    preferred_language: userPayload.preferred_language || 'english',
    is_active: true,
    last_login_at: new Date().toISOString(),
    created_at: new Date().toISOString()
  };

  db.users[lower] = newUser;
  persistDatabase();
  return newUser;
}

export function updateUserLastLogin(userId: number): void {
  const db = getDatabase();
  const user = findUserById(userId);
  if (user) {
    user.last_login_at = new Date().toISOString();
    persistDatabase();
  }
}

export function storeRefreshToken(userId: number, rawToken: string, expiresInMs = 86400000 * 30): RefreshTokenRecord {
  const db = getDatabase();
  if (!db.refresh_tokens) db.refresh_tokens = [];
  const token_hash = hashToken(rawToken);
  const nextId = db.refresh_tokens.length + 1;
  const expires_at = new Date(Date.now() + expiresInMs).toISOString();

  const rec: RefreshTokenRecord = {
    id: nextId,
    user_id: userId,
    token_hash,
    expires_at,
    revoked: false,
    created_at: new Date().toISOString()
  };

  db.refresh_tokens.push(rec);
  persistDatabase();
  return rec;
}

export function findRefreshTokenRecord(rawToken: string): RefreshTokenRecord | undefined {
  const db = getDatabase();
  if (!db.refresh_tokens) return undefined;
  const token_hash = hashToken(rawToken);
  return db.refresh_tokens.find(r => r.token_hash === token_hash);
}

export function revokeRefreshToken(rawToken: string): boolean {
  const db = getDatabase();
  if (!db.refresh_tokens) return false;
  const token_hash = hashToken(rawToken);
  const rec = db.refresh_tokens.find(r => r.token_hash === token_hash);
  if (rec) {
    rec.revoked = true;
    persistDatabase();
    return true;
  }
  return false;
}

export function revokeAllUserRefreshTokens(userId: number): void {
  const db = getDatabase();
  if (!db.refresh_tokens) return;
  for (const rec of db.refresh_tokens) {
    if (rec.user_id === userId) {
      rec.revoked = true;
    }
  }
  persistDatabase();
}

export function getDatabaseStats() {
  const db = getDatabase();
  let fileSizeBytes = 0;
  try {
    if (fs.existsSync(DB_FILE)) {
      fileSizeBytes = fs.statSync(DB_FILE).size;
    }
  } catch {}

  return {
    engine: 'PackSense Persistent Atomic File Store (SQLite / JSON)',
    status: 'ACTIVE_PERSISTENT',
    db_file_path: DB_FILE,
    file_size_bytes: fileSizeBytes,
    last_updated: db.last_updated,
    records_count: {
      users: Object.keys(db.users).length,
      simulations: db.simulations.length,
      batch_loggers: Object.keys(db.batch_loggers).length,
      total_telemetry_readings: Object.values(db.batch_loggers).reduce((acc, b) => acc + (b.readings?.length || 0), 0),
      whatsapp_sessions: Object.keys(db.whatsapp_sessions).length,
      community_feedback_samples: db.community_feedback.length,
      community_field_outcomes: db.community_outcomes.length,
      sync_transactions: db.sync_transactions.length,
      refresh_tokens: db.refresh_tokens ? db.refresh_tokens.length : 0
    }
  };
}
