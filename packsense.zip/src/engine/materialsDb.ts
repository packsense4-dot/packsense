/**
 * PackSense Polymer & Packaging Substrate Database
 * 
 * Physical properties, permeability coefficients, Arrhenius activation energies,
 * density, resin costs, embodied carbon (cradle-to-gate), and recyclability classifications.
 * 
 * Units:
 * - Density: g/cm³
 * - Permeability (PO2): cm³·µm / (m²·day·atm) at 23°C, 0% RH (ASTM D3985)
 * - Permeability (PWVTR): g·µm / (m²·day) at 38°C, 90% RH (ASTM F1249)
 * - Permeability (PCO2): cm³·µm / (m²·day·atm) at 23°C, 0% RH
 * - Activation Energy (Ep_O2, Ep_H2O): kJ/mol for Arrhenius scaling
 * - Cost: USD/kg resin
 * - Carbon Footprint: kg CO2e / kg resin (IPCC / Ecoinvent LCA)
 */

export interface PackagingMaterial {
  id: string;
  name: string;
  code: string;
  category: 'polyolefin' | 'barrier_polymer' | 'polyester' | 'polyamide' | 'metallized' | 'foil' | 'biopolymer' | 'paper';
  density: number; // g/cm³
  po2_23c: number; // cm³·µm / (m²·day·atm)
  pwvtr_38c: number; // g·µm / (m²·day)
  pco2_23c: number; // cm³·µm / (m²·day·atm)
  ep_o2: number; // kJ/mol (Arrhenius activation energy for O2 permeation)
  ep_h2o: number; // kJ/mol (Arrhenius activation energy for water permeation)
  rh_sensitive: boolean; // True for EVOH, Polyamide, Paper
  cost_per_kg: number; // USD / kg
  carbon_per_kg: number; // kg CO2e / kg
  recyclability_tier: 'Class A (Mono-PE)' | 'Class A (Mono-PP)' | 'Class B (Compatible)' | 'Class C (Compostable)' | 'Class D (Non-recyclable multimaterial)';
  recycled_stream: 'PE' | 'PP' | 'PET' | 'Paper' | 'Organics' | 'None';
  sealable: boolean;
  puncture_resistance: 'Low' | 'Medium' | 'High' | 'Very High';
  transparency: 'Clear' | 'Translucent' | 'Opaque' | 'Silver Metallized';
  standard_thickness_range: [number, number]; // [min µm, max µm]
  description: string;
}

export const MATERIALS_DATABASE: PackagingMaterial[] = [
  {
    id: 'ldpe',
    name: 'Low-Density Polyethylene',
    code: 'LDPE',
    category: 'polyolefin',
    density: 0.92,
    po2_23c: 6500,
    pwvtr_38c: 380,
    pco2_23c: 24000,
    ep_o2: 42.5,
    ep_h2o: 38.0,
    rh_sensitive: false,
    cost_per_kg: 1.45,
    carbon_per_kg: 1.85,
    recyclability_tier: 'Class A (Mono-PE)',
    recycled_stream: 'PE',
    sealable: true,
    puncture_resistance: 'Medium',
    transparency: 'Translucent',
    standard_thickness_range: [20, 100],
    description: 'Universal sealing polymer with excellent moisture barrier, high flex-crack resistance, but high gas permeability.'
  },
  {
    id: 'lldpe',
    name: 'Linear Low-Density Polyethylene',
    code: 'LLDPE',
    category: 'polyolefin',
    density: 0.925,
    po2_23c: 5500,
    pwvtr_38c: 320,
    pco2_23c: 20000,
    ep_o2: 41.0,
    ep_h2o: 37.0,
    rh_sensitive: false,
    cost_per_kg: 1.55,
    carbon_per_kg: 1.90,
    recyclability_tier: 'Class A (Mono-PE)',
    recycled_stream: 'PE',
    sealable: true,
    puncture_resistance: 'High',
    transparency: 'Translucent',
    standard_thickness_range: [15, 80],
    description: 'High tensile strength seal and structural layer with superior hot tack and puncture resistance.'
  },
  {
    id: 'hdpe',
    name: 'High-Density Polyethylene',
    code: 'HDPE',
    category: 'polyolefin',
    density: 0.955,
    po2_23c: 2500,
    pwvtr_38c: 120,
    pco2_23c: 9000,
    ep_o2: 39.0,
    ep_h2o: 35.5,
    rh_sensitive: false,
    cost_per_kg: 1.50,
    carbon_per_kg: 1.78,
    recyclability_tier: 'Class A (Mono-PE)',
    recycled_stream: 'PE',
    sealable: true,
    puncture_resistance: 'Medium',
    transparency: 'Translucent',
    standard_thickness_range: [15, 75],
    description: 'Stiff polyolefin offering enhanced moisture barrier (3x better than LDPE) and moderate gas resistance.'
  },
  {
    id: 'bopp',
    name: 'Biaxially Oriented Polypropylene',
    code: 'BOPP',
    category: 'polyolefin',
    density: 0.905,
    po2_23c: 1800,
    pwvtr_38c: 95,
    pco2_23c: 6500,
    ep_o2: 44.0,
    ep_h2o: 39.0,
    rh_sensitive: false,
    cost_per_kg: 1.65,
    carbon_per_kg: 1.95,
    recyclability_tier: 'Class A (Mono-PP)',
    recycled_stream: 'PP',
    sealable: false,
    puncture_resistance: 'High',
    transparency: 'Clear',
    standard_thickness_range: [12, 40],
    description: 'High-clarity, high-stiffness print web with outstanding moisture barrier and heat stability.'
  },
  {
    id: 'cpp',
    name: 'Cast Polypropylene',
    code: 'CPP',
    category: 'polyolefin',
    density: 0.90,
    po2_23c: 3200,
    pwvtr_38c: 180,
    pco2_23c: 12000,
    ep_o2: 43.0,
    ep_h2o: 38.0,
    rh_sensitive: false,
    cost_per_kg: 1.60,
    carbon_per_kg: 1.88,
    recyclability_tier: 'Class A (Mono-PP)',
    recycled_stream: 'PP',
    sealable: true,
    puncture_resistance: 'High',
    transparency: 'Clear',
    standard_thickness_range: [20, 80],
    description: 'Excellent heat seal layer for retort pouches and PP mono-material laminates.'
  },
  {
    id: 'bopet',
    name: 'Biaxially Oriented Polyethylene Terephthalate',
    code: 'BOPET',
    category: 'polyester',
    density: 1.40,
    po2_23c: 65,
    pwvtr_38c: 350,
    pco2_23c: 240,
    ep_o2: 32.0,
    ep_h2o: 33.0,
    rh_sensitive: false,
    cost_per_kg: 2.20,
    carbon_per_kg: 2.70,
    recyclability_tier: 'Class D (Non-recyclable multimaterial)',
    recycled_stream: 'None',
    sealable: false,
    puncture_resistance: 'Very High',
    transparency: 'Clear',
    standard_thickness_range: [10, 25],
    description: 'Premium print web with high dimensional stability, thermal endurance, and moderate gas barrier.'
  },
  {
    id: 'evoh_32',
    name: 'Ethylene Vinyl Alcohol (32 mol% ethylene)',
    code: 'EVOH-32',
    category: 'barrier_polymer',
    density: 1.19,
    po2_23c: 0.5, // Extremely high O2 barrier at dry conditions
    pwvtr_38c: 2100, // Poor moisture barrier
    pco2_23c: 2.0,
    ep_o2: 52.0,
    ep_h2o: 45.0,
    rh_sensitive: true, // Permeability increases when RH > 65%
    cost_per_kg: 7.80,
    carbon_per_kg: 4.10,
    recyclability_tier: 'Class B (Compatible)', // Compatible if <5% in PE/PP stream (CEFLEX)
    recycled_stream: 'PE',
    sealable: false,
    puncture_resistance: 'Medium',
    transparency: 'Clear',
    standard_thickness_range: [2, 10],
    description: 'Gold standard oxygen barrier coextruded within moisture-protective polyolefin sandwich (e.g. PE/EVOH/PE).'
  },
  {
    id: 'bopa',
    name: 'Biaxially Oriented Polyamide (Nylon 6)',
    code: 'BOPA',
    category: 'polyamide',
    density: 1.15,
    po2_23c: 40,
    pwvtr_38c: 2800,
    pco2_23c: 150,
    ep_o2: 38.0,
    ep_h2o: 41.0,
    rh_sensitive: true,
    cost_per_kg: 3.40,
    carbon_per_kg: 6.80,
    recyclability_tier: 'Class D (Non-recyclable multimaterial)',
    recycled_stream: 'None',
    sealable: false,
    puncture_resistance: 'Very High',
    transparency: 'Clear',
    standard_thickness_range: [12, 25],
    description: 'Extreme puncture and abrasion resistance; widely used in sharp bone-in meat packaging and vacuum bags.'
  },
  {
    id: 'met_pet',
    name: 'Metallized Polyester (Alu-vapor deposited)',
    code: 'Met-PET',
    category: 'metallized',
    density: 1.40,
    po2_23c: 1.2,
    pwvtr_38c: 8.5,
    pco2_23c: 4.5,
    ep_o2: 28.0,
    ep_h2o: 30.0,
    rh_sensitive: false,
    cost_per_kg: 2.90,
    carbon_per_kg: 3.20,
    recyclability_tier: 'Class D (Non-recyclable multimaterial)',
    recycled_stream: 'None',
    sealable: false,
    puncture_resistance: 'High',
    transparency: 'Silver Metallized',
    standard_thickness_range: [12, 23],
    description: 'Vapor-deposited aluminum layer (0.03 µm) on PET film; yields high light, aroma, and moisture barrier.'
  },
  {
    id: 'met_bopp',
    name: 'Metallized BOPP',
    code: 'Met-BOPP',
    category: 'metallized',
    density: 0.91,
    po2_23c: 25.0,
    pwvtr_38c: 4.0,
    pco2_23c: 90.0,
    ep_o2: 36.0,
    ep_h2o: 32.0,
    rh_sensitive: false,
    cost_per_kg: 2.40,
    carbon_per_kg: 2.45,
    recyclability_tier: 'Class A (Mono-PP)', // Thin aluminum deposition is permitted in PP stream if <0.1% metal
    recycled_stream: 'PP',
    sealable: false,
    puncture_resistance: 'High',
    transparency: 'Silver Metallized',
    standard_thickness_range: [15, 30],
    description: 'Standard snack food barrier layer (chips, crisps, pretzels) with superior moisture protection and light shield.'
  },
  {
    id: 'alu_foil',
    name: 'Aluminum Foil (7 µm pinhole model)',
    code: 'Alu-Foil',
    category: 'foil',
    density: 2.70,
    po2_23c: 0.005, // Theoretical zero, small finite value represents micro-pinholes
    pwvtr_38c: 0.005,
    pco2_23c: 0.015,
    ep_o2: 12.0,
    ep_h2o: 12.0,
    rh_sensitive: false,
    cost_per_kg: 4.50,
    carbon_per_kg: 9.80,
    recyclability_tier: 'Class D (Non-recyclable multimaterial)',
    recycled_stream: 'None',
    sealable: false,
    puncture_resistance: 'Low',
    transparency: 'Silver Metallized',
    standard_thickness_range: [6.35, 12],
    description: 'Absolute barrier to gases, water vapor, aroma, and light; prone to flex-crack fatigue.'
  },
  {
    id: 'pla',
    name: 'Polylactic Acid (Bio-based)',
    code: 'PLA',
    category: 'biopolymer',
    density: 1.25,
    po2_23c: 450,
    pwvtr_38c: 2400,
    pco2_23c: 1800,
    ep_o2: 46.0,
    ep_h2o: 42.0,
    rh_sensitive: false,
    cost_per_kg: 3.20,
    carbon_per_kg: 1.20,
    recyclability_tier: 'Class C (Compostable)',
    recycled_stream: 'Organics',
    sealable: true,
    puncture_resistance: 'Low',
    transparency: 'Clear',
    standard_thickness_range: [20, 60],
    description: '100% bio-based corn-derived polyester; industrial compostable under EN 13432. Moderate breathability for produce.'
  },
  {
    id: 'bio_pbs',
    name: 'Polybutylene Succinate (Bio-PBS)',
    code: 'Bio-PBS',
    category: 'biopolymer',
    density: 1.26,
    po2_23c: 820,
    pwvtr_38c: 1650,
    pco2_23c: 3200,
    ep_o2: 44.0,
    ep_h2o: 40.0,
    rh_sensitive: false,
    cost_per_kg: 3.80,
    carbon_per_kg: 1.45,
    recyclability_tier: 'Class C (Compostable)',
    recycled_stream: 'Organics',
    sealable: true,
    puncture_resistance: 'Medium',
    transparency: 'Translucent',
    standard_thickness_range: [25, 75],
    description: 'Home-compostable aliphatic polyester offering good sealability and thermal resistance up to 95°C.'
  },
  {
    id: 'pvdc_coating',
    name: 'PVDC Barrier Lacquer',
    code: 'PVDC',
    category: 'barrier_polymer',
    density: 1.65,
    po2_23c: 6.0,
    pwvtr_38c: 18.0,
    pco2_23c: 24.0,
    ep_o2: 48.0,
    ep_h2o: 43.0,
    rh_sensitive: false,
    cost_per_kg: 6.20,
    carbon_per_kg: 4.80,
    recyclability_tier: 'Class D (Non-recyclable multimaterial)',
    recycled_stream: 'None',
    sealable: false,
    puncture_resistance: 'Medium',
    transparency: 'Clear',
    standard_thickness_range: [2, 5],
    description: 'Chlorine-containing dual gas and moisture barrier coating; effective regardless of high relative humidity.'
  },
  {
    id: 'barrier_paper',
    name: 'FSC Kraft Paper + Bio-dispersion Coating',
    code: 'Kraft-Bio',
    category: 'paper',
    density: 0.85,
    po2_23c: 250,
    pwvtr_38c: 450,
    pco2_23c: 980,
    ep_o2: 35.0,
    ep_h2o: 38.0,
    rh_sensitive: true,
    cost_per_kg: 2.10,
    carbon_per_kg: 0.95,
    recyclability_tier: 'Class B (Compatible)',
    recycled_stream: 'Paper',
    sealable: true,
    puncture_resistance: 'Medium',
    transparency: 'Opaque',
    standard_thickness_range: [40, 90],
    description: 'Renewable wood-pulp substrate with waterborne aqueous barrier coating; curbside paper recyclable (>85% fiber).'
  }
];

export function getMaterialById(id?: string): PackagingMaterial | undefined {
  if (!id) return MATERIALS_DATABASE[0];
  const search = String(id).toLowerCase();
  return MATERIALS_DATABASE.find(m => m.id.toLowerCase() === search || m.code.toLowerCase() === search || search.includes(m.id.toLowerCase())) || MATERIALS_DATABASE[0];
}
