/**
 * PackSense Indian Agro-Climatic Zones & Supplier Directory
 * 
 * Geographic regions with IMD (India Meteorological Department) climate profiles,
 * transit humidity, ambient ambient temperatures, PostGIS distance calculations,
 * and regional flexible film suppliers for MSMEs, FPOs, and farmers.
 */

export interface ClimateProfile {
  id: string;
  zone_name: string;
  state: string;
  major_mandi: string;
  latitude: number;
  longitude: number;
  summer_temp_c: number;
  summer_rh_pct: number;
  monsoon_temp_c: number;
  monsoon_rh_pct: number;
  winter_temp_c: number;
  winter_rh_pct: number;
  transit_hazard_rating: 'Moderate' | 'High' | 'Extreme';
  primary_crops: string[];
}

export interface PackagingSupplier {
  id: string;
  name: string;
  city: string;
  state: string;
  latitude: number;
  longitude: number;
  certifications: string[]; // BRCGS, ISO 22000, FSSAI, CEFLEX
  products: string[];
  min_order_quantity_kg: number;
  contact_person: string;
  whatsapp_phone: string;
  lead_time_days: number;
}

export const CLIMATE_PROFILES: ClimateProfile[] = [
  {
    id: 'konkan_maharashtra',
    zone_name: 'Konkan Coastal Agro-Zone',
    state: 'Maharashtra',
    major_mandi: 'Vashi APMC (Navi Mumbai) / Ratnagiri Mandi',
    latitude: 16.9902,
    longitude: 73.3120,
    summer_temp_c: 34.5,
    summer_rh_pct: 78,
    monsoon_temp_c: 28.5,
    monsoon_rh_pct: 92,
    winter_temp_c: 24.0,
    winter_rh_pct: 68,
    transit_hazard_rating: 'Extreme', // Extreme humidity degrades EVOH if not sealed with thick polyolefins
    primary_crops: ['Alphonso Mango', 'Cashew Apple', 'Fish / Coastal Seafood', 'Rice Flakes']
  },
  {
    id: 'nashik_valley',
    zone_name: 'Western Ghats / Nashik Horticulture Corridor',
    state: 'Maharashtra',
    major_mandi: 'Pimpalgaon Baswant (Onion/Tomato Mandi) / Nashik APMC',
    latitude: 19.9975,
    longitude: 73.7898,
    summer_temp_c: 38.0,
    summer_rh_pct: 42,
    monsoon_temp_c: 26.0,
    monsoon_rh_pct: 85,
    winter_temp_c: 12.0,
    winter_rh_pct: 55,
    transit_hazard_rating: 'High',
    primary_crops: ['Table Grapes', 'Onions', 'Roma Tomatoes', 'Pomegranates']
  },
  {
    id: 'punjab_doaba',
    zone_name: 'Trans-Gangetic Plains',
    state: 'Punjab',
    major_mandi: 'Khanna Grain Mandi / Jalandhar Potato Belt',
    latitude: 31.3260,
    longitude: 75.5762,
    summer_temp_c: 42.5,
    summer_rh_pct: 35,
    monsoon_temp_c: 33.0,
    monsoon_rh_pct: 82,
    winter_temp_c: 6.5,
    winter_rh_pct: 88,
    transit_hazard_rating: 'Extreme', // Frost to scorching 44°C
    primary_crops: ['Seed Potatoes', 'Kinnow Mandarin', 'Basmati Rice', 'Wheat Flour']
  },
  {
    id: 'karnataka_deccan',
    zone_name: 'Southern Semi-Arid Plateau',
    state: 'Karnataka',
    major_mandi: 'Kolar Tomato Mandi / Yeshwanthpur APMC Bangalore',
    latitude: 13.1367,
    longitude: 78.1292,
    summer_temp_c: 35.0,
    summer_rh_pct: 48,
    monsoon_temp_c: 27.5,
    monsoon_rh_pct: 78,
    winter_temp_c: 18.0,
    winter_rh_pct: 62,
    transit_hazard_rating: 'Moderate',
    primary_crops: ['Roma Tomatoes', 'Capsicum', 'Robusta Coffee', 'Gherkins']
  },
  {
    id: 'himachal_temperate',
    zone_name: 'Western Himalayan Temperate Zone',
    state: 'Himachal Pradesh',
    major_mandi: 'Parwanoo Apple Mandi / Shimla APMC',
    latitude: 31.1048,
    longitude: 77.1734,
    summer_temp_c: 24.0,
    summer_rh_pct: 58,
    monsoon_temp_c: 20.0,
    monsoon_rh_pct: 90,
    winter_temp_c: 2.0,
    winter_rh_pct: 70,
    transit_hazard_rating: 'High',
    primary_crops: ['Royal Delicious Apple', 'Stone Fruits (Peach/Plum)', 'Mushrooms']
  }
];

export const PACKAGING_SUPPLIERS: PackagingSupplier[] = [
  {
    id: 'uflex_noida',
    name: 'UFlex Packaging Ltd (Flexible Division)',
    city: 'Noida / Sanand',
    state: 'Uttar Pradesh / Gujarat',
    latitude: 28.5355,
    longitude: 77.3910,
    certifications: ['BRCGS Packaging', 'ISO 22000', 'FSSAI Approved', 'CEFLEX'],
    products: ['Mono-PE Barrier Coex', 'BOPP/Met-BOPP Snack Film', 'High Barrier EVOH Pouch Web'],
    min_order_quantity_kg: 250,
    contact_person: 'Ramesh Sharma (Regional FPO Key Accounts)',
    whatsapp_phone: '+919811002233',
    lead_time_days: 7
  },
  {
    id: 'polyplex_dehradun',
    name: 'Polyplex Corporation Ltd',
    city: 'Bajpur / Kashipur',
    state: 'Uttarakhand',
    latitude: 29.2104,
    longitude: 78.9619,
    certifications: ['ISO 9001', 'FSSAI Food Contact Safe', 'FDA 21 CFR Compliant'],
    products: ['BOPET Ultra-Clear', 'Vapor-Deposited Met-PET', 'Thermal Lamination Film'],
    min_order_quantity_kg: 100,
    contact_person: 'Vikram Negi (Packaging Sales)',
    whatsapp_phone: '+919412003344',
    lead_time_days: 5
  },
  {
    id: 'epl_maharashtra',
    name: 'EPL Limited (formerly Essel Propack)',
    city: 'Vasai / Wada',
    state: 'Maharashtra',
    latitude: 19.3919,
    longitude: 72.8397,
    certifications: ['ISO 14001', 'BRCGS Packaging', 'Recyclable Platinum'],
    products: ['Platina Mono-Material Tubes & Barrier Laminates', 'Pouch Sealing PE Webs'],
    min_order_quantity_kg: 200,
    contact_person: 'Amit Patil (Western India Agro Sales)',
    whatsapp_phone: '+919820005566',
    lead_time_days: 6
  },
  {
    id: 'shrinath_rotopack',
    name: 'Shrinath Flexipack Pvt Ltd',
    city: 'Hyderabad',
    state: 'Telangana',
    latitude: 17.3850,
    longitude: 78.4867,
    certifications: ['ISO 22000', 'FSSAI Registered', 'HACCP'],
    products: ['Vacuum Pouches for Meat/Seafood', 'High-CO2 MAP Barrier Trays & Lidding'],
    min_order_quantity_kg: 150,
    contact_person: 'K. Venkatesh (Cold Chain Specialist)',
    whatsapp_phone: '+919989006677',
    lead_time_days: 4
  }
];

// Haversine formula for geo-distance in km (mirrors PostGIS ST_DistanceSphere)
export function calculateGeoDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(1));
}

export function findSuppliersNearLocation(
  lat: number,
  lon: number,
  maxDistanceKm: number = 500,
  filmType?: string
): Array<PackagingSupplier & { distance_km: number }> {
  const normalizedFilm = filmType && filmType.toUpperCase() !== 'ALL' ? filmType.toLowerCase() : null;
  return PACKAGING_SUPPLIERS
    .map(s => ({
      ...s,
      distance_km: calculateGeoDistanceKm(lat, lon, s.latitude, s.longitude)
    }))
    .filter(s => {
      const withinDistance = s.distance_km <= maxDistanceKm;
      if (!withinDistance) return false;
      if (normalizedFilm) {
        return s.products.some(p => p.toLowerCase().includes(normalizedFilm));
      }
      return true;
    })
    .sort((a, b) => a.distance_km - b.distance_km);
}

export function getAgroClimateProfile(id: string): ClimateProfile | undefined {
  return CLIMATE_PROFILES.find(p => p.id === id);
}

