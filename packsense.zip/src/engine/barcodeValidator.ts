/**
 * Barcode Check Digit & Format Validator
 * 
 * Implements authoritative GS1 specification algorithms for:
 * - EAN-13 (13 digits, mod 10 check digit with 1/3 weighting)
 * - EAN-8 (8 digits, mod 10 check digit with 3/1 weighting)
 * - UPC-A (12 digits, mod 10 check digit with 3/1 weighting)
 * - UPC-E (8 digits, zero-suppression expanded to UPC-A check digit)
 * 
 * Rejects malformed or corrupted scans with clear invalid_barcode errors.
 */

export interface BarcodeValidationResult {
  isValid: boolean;
  format?: 'EAN-13' | 'EAN-8' | 'UPC-A' | 'UPC-E';
  cleanedCode: string;
  error?: string;
}

/**
 * Computes check digit for 12 digits of an EAN-13 code
 */
export function computeEan13CheckDigit(code12: string): number {
  const digits = code12.slice(0, 12).split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    sum += digits[i] * (i % 2 === 0 ? 1 : 3);
  }
  return (10 - (sum % 10)) % 10;
}

/**
 * Validates check digit of an EAN-13 code (13 digits)
 */
export function validateEan13CheckDigit(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  const digits = code.split('').map(Number);
  const checkDigit = computeEan13CheckDigit(code.slice(0, 12));
  return checkDigit === digits[12];
}

/**
 * Validates check digit of an EAN-8 code (8 digits)
 */
export function validateEan8CheckDigit(code: string): boolean {
  if (!/^\d{8}$/.test(code)) return false;
  const digits = code.split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 7; i++) {
    sum += digits[i] * (i % 2 === 0 ? 3 : 1);
  }
  const checkDigit = (10 - (sum % 10)) % 10;
  return checkDigit === digits[7];
}

/**
 * Validates check digit of a UPC-A code (12 digits)
 */
export function validateUpcACheckDigit(code: string): boolean {
  if (!/^\d{12}$/.test(code)) return false;
  const digits = code.split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    sum += digits[i] * (i % 2 === 0 ? 3 : 1);
  }
  const checkDigit = (10 - (sum % 10)) % 10;
  return checkDigit === digits[11];
}

/**
 * Expands a UPC-E code to a 12-digit UPC-A code
 */
export function expandUpcEToUpcA(upce: string): string | null {
  if (!/^[01]\d{7}$/.test(upce)) return null;
  const numSystem = upce[0];
  const d1 = upce[1];
  const d2 = upce[2];
  const d3 = upce[3];
  const d4 = upce[4];
  const d5 = upce[5];
  const d6 = upce[6];
  const check = upce[7];

  let mfr = '';
  let item = '';

  switch (d6) {
    case '0':
    case '1':
    case '2':
      mfr = `${d1}${d2}${d6}00`;
      item = `00${d3}${d4}${d5}`;
      break;
    case '3':
      mfr = `${d1}${d2}${d3}00`;
      item = `000${d4}${d5}`;
      break;
    case '4':
      mfr = `${d1}${d2}${d3}${d4}0`;
      item = `0000${d5}`;
      break;
    default:
      mfr = `${d1}${d2}${d3}${d4}${d5}`;
      item = `0000${d6}`;
      break;
  }

  const candidate = `${numSystem}${mfr}${item}${check}`;
  return candidate;
}

/**
 * Validates check digit of a UPC-E code
 */
export function validateUpcECheckDigit(code: string): boolean {
  const upca = expandUpcEToUpcA(code);
  if (!upca) return false;
  return validateUpcACheckDigit(upca);
}

/**
 * General barcode validation entry point.
 * Checks format, removes whitespace/dashes, and computes check digits.
 */
export function validateBarcode(rawBarcode: string): BarcodeValidationResult {
  if (!rawBarcode || typeof rawBarcode !== 'string') {
    return {
      isValid: false,
      cleanedCode: '',
      error: 'Empty or invalid barcode string'
    };
  }

  const cleaned = rawBarcode.trim().replace(/[\s-]/g, '');

  if (!/^\d+$/.test(cleaned)) {
    return {
      isValid: false,
      cleanedCode: cleaned,
      error: 'Barcode must contain only numeric digits'
    };
  }

  // 1. EAN-13 (13 digits)
  if (cleaned.length === 13) {
    const valid = validateEan13CheckDigit(cleaned);
    if (!valid) {
      return {
        isValid: false,
        cleanedCode: cleaned,
        format: 'EAN-13',
        error: 'Invalid EAN-13 check digit'
      };
    }
    return {
      isValid: true,
      cleanedCode: cleaned,
      format: 'EAN-13'
    };
  }

  // 2. UPC-A (12 digits)
  if (cleaned.length === 12) {
    const valid = validateUpcACheckDigit(cleaned);
    if (!valid) {
      return {
        isValid: false,
        cleanedCode: cleaned,
        format: 'UPC-A',
        error: 'Invalid UPC-A check digit'
      };
    }
    return {
      isValid: true,
      cleanedCode: cleaned,
      format: 'UPC-A'
    };
  }

  // 3. EAN-8 or UPC-E (8 digits)
  if (cleaned.length === 8) {
    if (validateEan8CheckDigit(cleaned)) {
      return {
        isValid: true,
        cleanedCode: cleaned,
        format: 'EAN-8'
      };
    }
    if (validateUpcECheckDigit(cleaned)) {
      return {
        isValid: true,
        cleanedCode: cleaned,
        format: 'UPC-E'
      };
    }
    return {
      isValid: false,
      cleanedCode: cleaned,
      error: 'Invalid EAN-8 or UPC-E check digit'
    };
  }

  return {
    isValid: false,
    cleanedCode: cleaned,
    error: `Unsupported barcode length: ${cleaned.length} digits (expected 8, 12, or 13 digits)`
  };
}
