/**
 * PackSense Multilingual Localization Engine
 * Supports domain-specific terminology, explanations, checklists, diagnoses,
 * and reference text in English (en), Hindi (hi), Marathi (mr), and Tamil (ta).
 * Zero external translation API in the runtime path (Pure Deterministic Dictionaries).
 */

export const SUPPORTED_LANGUAGES: Record<string, { name: string; native: string }> = {
  en: { name: 'English', native: 'English' },
  hi: { name: 'Hindi', native: 'हिन्दी' },
  mr: { name: 'Marathi', native: 'मराठी' },
  ta: { name: 'Tamil', native: 'தமிழ்' }
};

export const TRANSLATIONS: Record<string, Record<string, string>> = {
  // Spoilage Autopsy Root Causes
  'Anaerobic Microbial Fermentation / Pouch Over-Pressurization': {
    hi: 'अवायवीय सूक्ष्मजीव किण्वन / पाउच में अत्यधिक दबाव',
    mr: 'विनॉक्सी सूक्ष्मजीव किण्वन / पाऊचमधील अतिदाब फुगवटा',
    ta: 'காற்றில்லா நுண்ணுயிர் நொதித்தல் / பாக்கெட் அதிக அழுத்தம்'
  },
  'Moisture Condensation & Fungal Germination': {
    hi: 'नमी संक्षेपण (कंडेनसेशन) एवं फफूंद का अंकुरण',
    mr: 'आर्द्रता साठवण (कंडेन्सेशन) आणि बुरशीची वाढ',
    ta: 'ஈரப்பதம் ஒடுக்கம் மற்றும் பூஞ்சை முளைத்தல்'
  },
  'Polyphenol Oxidase Enzymatic Browning / Oxidation': {
    hi: 'पॉलीफेनोल ऑक्सीडेज एंजाइम द्वारा भूरापन / ऑक्सीकरण',
    mr: 'पॉलिफेनॉल ऑक्सिडेस एन्झाईममुळे काळे/तपकिरी पडणे',
    ta: 'பாலிபினால் ஆக்சிடேஸ் நொதி பழுப்பு நிறமாதல் / ஆக்ஸிஜனேற்றம்'
  },
  'Desiccation / Transpirational Weight Loss Failure': {
    hi: 'अत्यधिक शुष्कता / वाष्पोत्सर्जन से वजन में भारी गिरावट',
    mr: 'अति कोरडेपणा / बाष्पोत्सर्जनामुळे वजनात लक्षणीय घट',
    ta: 'நீர் வறட்சி / ஆவியாதல் மூலம் எடை இழப்பு தோல்வி'
  },
  'Lipid Peroxidation & Oxidative Rancidity': {
    hi: 'वसा का ऑक्सीकरण एवं दुर्गंधयुक्त खट्टापन (रैंसिडिटी)',
    mr: 'स्निग्ध पदार्थांचे ऑक्सिडीकरण आणि खवट वास',
    ta: 'கொழுப்பு பெராக்ஸைடேஷன் மற்றும் காரத்தன்மை சிதைவு'
  },

  // Corrective Film / Action Keywords
  'Micro-perforated breathable film': {
    hi: 'सूक्ष्म-छिद्रित सांस लेने योग्य फिल्म',
    mr: 'सूक्ष्म-छिद्रयुक्त हवा खेळती ठेवणारी फिल्म',
    ta: 'நுண் துளையிடப்பட்ட சுவாசிக்கக்கூடிய பிலிம்'
  },
  'Laser Micro-Perforated BOPP 30µm (60µm hole pitch 20mm)': {
    hi: 'लेजर सूक्ष्म-छिद्रित बीओपीपी 30 माइक्रोन (60µm छिद्र, 20mm दूरी)',
    mr: 'लेसर सूक्ष्म-छिद्रित बीओपीपी ३० मायक्रॉन (६० मायक्रॉन छिद्र, २० मिमी अंतर)',
    ta: 'லேசர் நுண் துளையிடப்பட்ட BOPP 30µm (60µm துளை 20mm இடைவெளி)'
  },
  'Anti-Fog Coated OPP 25µm // CPP 30µm with inner sealant masterbatch': {
    hi: 'एंटी-फॉग कोटेड ओप्प 25µm // सीप्प 30µm सीलेंट परत के साथ',
    mr: 'धुकं-रोधक (अँटी-फॉग) लेपित ओप्प २५ मायक्रॉन // सीप्प ३० मायक्रॉन',
    ta: 'பனி எதிர்ப்பு பூசப்பட்ட OPP 25µm // CPP 30µm சீலண்ட் அடுக்கு'
  },

  // Lab Trial Checklist Standards & Tests
  'Oxygen Transmission Rate (OTR)': {
    hi: 'ऑक्सीजन संचरण दर (OTR)',
    mr: 'ऑक्सिजन वहन दर (OTR)',
    ta: 'ஆக்சிஜன் பரிமாற்ற விகிதம் (OTR)'
  },
  'Water Vapor Transmission Rate (WVTR)': {
    hi: 'जलवाष्प संचरण दर (WVTR)',
    mr: 'पाण्याची वाफ वहन दर (WVTR)',
    ta: 'நீராவி பரிமாற்ற விகிதம் (WVTR)'
  },
  'Overall Migration Limit (OML)': {
    hi: 'समग्र प्रवासन सीमा (OML - रासायनिक सुरक्षा)',
    mr: 'एकूण स्थलांतर मर्यादा (OML - अन्न सुरक्षितता)',
    ta: 'ஒட்டுமொத்த இடம்பெயர்வு வரம்பு (OML)'
  },
  'Bubble Emission Seal Integrity': {
    hi: 'बबल उत्सर्जन सील अखंडता परीक्षण (लीकेज टेस्ट)',
    mr: 'बबल उत्सर्जन सील अखंडता चाचणी (गळती चाचणी)',
    ta: 'குமிழி உமிழ்வு சீல் ஒருமைப்பாடு சோதனை'
  },
  'Coulometric Detector at 23°C, 0% RH': {
    hi: 'कौलोमेट्रिक संसूचक 23°C, 0% सापेक्ष आर्द्रता पर',
    mr: 'कौलोमेट्रिक डिटेक्टर २३° से. आणि ०% आर्द्रतेवर',
    ta: 'கூலோமெட்ரிக் டிடெக்டர் 23°C, 0% RH இல்'
  },
  'Infrared Sensor at 37.8°C, 90% RH': {
    hi: 'अवरक्त (IR) सेंसर 37.8°C, 90% सापेक्ष आर्द्रता पर',
    mr: 'इन्फ्रारेड सेन्सर ३७.८° से. आणि ९०% आर्द्रतेवर',
    ta: 'அகச்சிவப்பு சென்சார் 37.8°C, 90% RH இல்'
  },
  '< 60 mg/kg food simulant A, B, C, D1': {
    hi: '< 60 मि.ग्रा./कि.ग्रा. खाद्य सिमुलेटर A, B, C, D1 में',
    mr: '< ६० मि.ग्रॅ./कि.ग्रॅ. अन्न सिम्युलेटर A, B, C, D1 मध्ये',
    ta: '< 60 மிகி/கிலோ உணவு சிமுலண்ட் A, B, C, D1'
  },
  'Vacuum chamber leak detection at -20 kPa': {
    hi: 'निर्वात कक्ष (वैक्यूम चैंबर) रिसाव परीक्षण -20 kPa पर',
    mr: 'व्हॅक्यूम चेंबर गळती शोध चाचणी -२० kPa वर',
    ta: 'வெற்றிட அறை கசிவு கண்டறிதல் -20 kPa இல்'
  },
  'NABL / ISO 17025 Accredited Laboratory': {
    hi: 'एनएबीएल / आईएसओ 17025 मान्यता प्राप्त राष्ट्रीय प्रयोगशाला',
    mr: 'एनएबीएल / आयएसओ १७०२५ मान्यताप्राप्त प्रयोगशाळा',
    ta: 'NABL / ISO 17025 அங்கீகரிக்கப்பட்ட ஆய்வகம்'
  },

  // Compliance & Reference Texts
  'FSSAI Packaging Regulations 2018': {
    hi: 'एफएसएसएआई पैकेजिंग विनियम २०१८ (खाद्य संपर्क सुरक्षा)',
    mr: 'एफएसएसएआय पॅकेजिंग नियम २०१८ (अन्न संपर्क सुरक्षा)',
    ta: 'FSSAI பேக்கேஜிங் விதிமுறைகள் 2018 (உணவு தொடர்பு பாதுகாப்பு)'
  },
  'Plastic Waste Management Rules 2022 (PWM)': {
    hi: 'प्लास्टिक अपशिष्ट प्रबंधन नियम २०२२ (पुनर्चक्रण एवं ईपीआर)',
    mr: 'प्लॅस्टिक कचरा व्यवस्थापन नियम २०२२ (पुनर्वापर आणि ईपीआर)',
    ta: 'பிளாஸ்டிக் கழிவு மேலாண்மை விதிகள் 2022'
  },
  'CEFLEX Class A Recyclable Mono-Material': {
    hi: 'सेफ्लेक्स क्लास ए पुनर्चक्रण योग्य एकल-सामग्री (मोनो-पॉलीमर)',
    mr: 'सेफ्लेक्स क्लास ए पुनर्वापरयोग्य सिंगल-मटेरियल (मोनो-पीई/पीपी)',
    ta: 'CEFLEX வகுப்பு A மறுசுழற்சி செய்யக்கூடிய ஒற்றை பொருள்'
  },

  // Common Phrases
  'Shelf Life': { hi: 'शेल्फ लाइफ (भंडारण अवधि)', mr: 'शेल्फ लाइफ (साठवणूक कालावधी)', ta: 'சேமிப்பு காலம் (ஷெல்ஃப் லைஃப்)' },
  'Days': { hi: 'दिन', mr: 'दिवस', ta: 'நாட்கள்' },
  'Hours': { hi: 'घंटे', mr: 'तास', ta: 'மணிநேரம்' },
  'Storage Temperature': { hi: 'भंडारण तापमान', mr: 'साठवणूक तापमान', ta: 'சேமிப்பு வெப்பநிலை' },
  'Relative Humidity': { hi: 'सापेक्ष आर्द्रता', mr: 'सापेक्ष आर्द्रता (RH)', ta: 'ஒப்பீட்டு ஈரப்பதம்' }
};

export function translatePhrase(text: string, targetLang: string): string {
  if (!text || targetLang === 'en' || !SUPPORTED_LANGUAGES[targetLang]) {
    return text;
  }
  const clean = text.trim();
  const match = TRANSLATIONS[clean];
  if (match && match[targetLang]) {
    return match[targetLang];
  }
  // Substring match
  for (const [engKey, langMap] of Object.entries(TRANSLATIONS)) {
    if (clean.toLowerCase().includes(engKey.toLowerCase()) && langMap[targetLang]) {
      return langMap[targetLang];
    }
  }
  return text;
}

export function localizeSpoilageDiagnosis(diagnosis: any, lang: string) {
  if (lang === 'en' || !SUPPORTED_LANGUAGES[lang]) {
    return { ...diagnosis, language: 'en' };
  }
  const loc = { ...diagnosis, language: lang };
  const rootCause = loc.primary_root_cause || loc.root_cause || '';
  loc.root_cause_localized = translatePhrase(rootCause, lang);

  if (Array.isArray(loc.mechanisms)) {
    loc.mechanisms_localized = loc.mechanisms.map((m: string) => translatePhrase(m, lang));
  }
  if (loc.corrective_actions && typeof loc.corrective_actions === 'object') {
    const actionsLoc: Record<string, string> = {};
    for (const [k, v] of Object.entries(loc.corrective_actions)) {
      actionsLoc[k] = translatePhrase(String(v), lang);
    }
    loc.corrective_actions_localized = actionsLoc;
  }
  return loc;
}

export function localizeLabTrialChecklist(checklist: any, lang: string) {
  if (lang === 'en' || !SUPPORTED_LANGUAGES[lang]) {
    return { ...checklist, language: 'en' };
  }
  const loc = { ...checklist, language: lang };
  if (loc.accreditation_requirement) {
    loc.accreditation_requirement_localized = translatePhrase(loc.accreditation_requirement, lang);
  }
  if (Array.isArray(loc.test_suite)) {
    loc.test_suite_localized = loc.test_suite.map((test: any) => ({
      ...test,
      parameter_localized: translatePhrase(test.parameter || '', lang),
      target_localized: translatePhrase(test.target || '', lang)
    }));
  }
  return loc;
}

export function getMultilingualReferenceText(category: string, lang = 'en') {
  const references: Record<string, Record<string, { title: string; rules: string[] }>> = {
    fssai_standards: {
      en: {
        title: 'FSSAI Food Contact Packaging Standards 2018',
        rules: [
          'All plastic films must conform to IS 9845 for overall migration limits (< 60 mg/kg).',
          'Recycled plastics are prohibited from direct food contact unless specially authorized by FSSAI.',
          'Printing inks must strictly avoid lead, toluene, and harmful solvent residues.'
        ]
      },
      hi: {
        title: 'एफएसएसएआई खाद्य संपर्क पैकेजिंग मानक २०१८',
        rules: [
          'सभी प्लास्टिक फिल्मों को समग्र प्रवासन सीमा (< 60 मिलीग्राम/किलोग्राम) हेतु IS 9845 का पालन करना अनिवार्य है।',
          'एफएसएसएआई की विशेष अनुमति के बिना पुनर्चक्रित प्लास्टिक का सीधे भोजन के संपर्क में उपयोग वर्जित है।',
          'प्रिंटिंग स्याही में लेड, टोल्यूनि और हानिकारक विलायक अवशेषों का उपयोग पूरी तरह प्रतिबंधित है।'
        ]
      },
      mr: {
        title: 'एफएसएसएआय अन्न संपर्क पॅकेजिंग मानके २०१८',
        rules: [
          'सर्व प्लॅस्टिक फिल्म्ससाठी IS 9845 अंतर्गत एकूण स्थलांतर मर्यादा (< ६० मिग्रॅ/किग्रॅ) पाळणे बंधनकारक आहे.',
          'एफएसएसएआयच्या विशेष मंजुरीशिवाय रिसायकल केलेल्या प्लास्टिकचा अन्नाशी थेट संपर्क वापरण्यास बंदी आहे.',
          'प्रिंटिंग शाईमध्ये शिसे, टोल्यूएन आणि विषारी रासायनिक अवशेष नसावेत.'
        ]
      },
      ta: {
        title: 'FSSAI உணவு தொடர்பு பேக்கேஜிங் தரநிலைகள் 2018',
        rules: [
          'அனைத்து பிளாஸ்டிக் படலங்களும் ஒட்டுமொத்த இடம்பெயர்வு வரம்புகளுக்கு (< 60 மி.கி/கி.கி) IS 9845 ஐ இணங்க வேண்டும்.',
          'FSSAI அனுமதியின்றி மறுசுழற்சி செய்யப்பட்ட பிளாஸ்டிக்கை நேரடி உணவு தொடர்புக்கு பயன்படுத்துவது தடைசெய்யப்பட்டுள்ளது.',
          'அச்சிடும் மைகளில் ஈயம், டோலுயீன் மற்றும் நச்சு கரைப்பான் எச்சங்கள் தவிர்க்கப்பட வேண்டும்.'
        ]
      }
    },
    pwm_recycling: {
      en: {
        title: 'Plastic Waste Management Rules 2022 (PWM) & CEFLEX',
        rules: [
          'Mono-material structures (Mono-PE or Mono-PP >90% polyolefin content) achieve CEFLEX Class A circularity.',
          'Multi-material laminates with aluminum foil face higher Extended Producer Responsibility (EPR) recycling fees.',
          'Compostable biopolymers must carry certified CPCB certificate under IS/ISO 17088.'
        ]
      },
      hi: {
        title: 'प्लास्टिक अपशिष्ट प्रबंधन नियम २०२२ एवं सेफ्लेक्स परिपत्रता',
        rules: [
          'एकल-सामग्री संरचनाएं (मोनो-पीई या मोनो-पीपी >९०% पॉलीओलेफिन) सेफ्लेक्स क्लास ए पुनर्चक्रण प्राप्त करती हैं।',
          'एल्युमिनियम फॉयल वाले बहु-सामग्री लेमिनेट्स पर अधिक ईपीआर पुनर्चक्रण शुल्क लागू होता है।',
          'कम्पोस्टेबल बायो-पॉलिमर के पास IS/ISO 17088 के तहत सीपीसीबी प्रमाण पत्र होना अनिवार्य है।'
        ]
      },
      mr: {
        title: 'प्लॅस्टिक कचरा व्यवस्थापन नियम २०२२ आणि सेफ्लेक्स परिपत्रता',
        rules: [
          'मोनो-मटेरियल संरचना (मोनो-पीई किंवा मोनो-पीपी >९०% प्रमाण) सेफ्लेक्स वर्ग अ अंतर्गत १००% पुनर्वापरयोग्य ठरतात.',
          'अ‍ॅल्युमिनियम फॉइल असलेल्या मल्टि-मटेरियल लॅमिनेट्सवर जास्त ईपीआर (विस्तारित उत्पादक जबाबदारी) कर लागू होतो.',
          'कंपोस्टेबल बायो-पॉलिमर्ससाठी IS/ISO 17088 अंतर्गत सीपीसीबी प्रमाणपत्र असणे आवश्यक आहे.'
        ]
      },
      ta: {
        title: 'பிளாஸ்டிக் கழிவு மேலாண்மை விதிகள் 2022 மற்றும் மறுசுழற்சி',
        rules: [
          'ஒற்றை பொருள் கட்டமைப்புகள் (>90% பாலியோலிஃபின்) CEFLEX வகுப்பு A மறுசுழற்சியை அடைகின்றன.',
          'அலுமினியம் படலம் கொண்ட பல அடுக்கு லேமினேட்டுகள் அதிக EPR மறுசுழற்சி கட்டணத்தை எதிர்கொள்கின்றன.',
          'மக்கும் பயோ-பாலிமர்கள் IS/ISO 17088 இன் கீழ் CPCB சான்றிதழைப் பெற்றிருக்க வேண்டும்.'
        ]
      }
    }
  };

  const catData = references[category] || references.fssai_standards;
  const selectedLang = catData[lang] ? lang : 'en';
  return {
    category,
    language: selectedLang,
    content: catData[selectedLang],
    available_languages: Object.keys(SUPPORTED_LANGUAGES)
  };
}

export const SUPPORTED_LANGUAGES_LIST = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'हिंदी' },
  { code: 'mr', name: 'मराठी' },
  { code: 'ta', name: 'தமிழ்' }
];

export const I18N_TEMPLATES: Record<string, Record<string, string>> = {
  'shap_explanation.high_respiration': {
    en: 'High respiration at {temp}°C means your film needs {x}x higher O2 permeability.',
    hi: '{temp}°C पर अधिक श्वसन दर का मतलब है कि आपकी फिल्म को {x} गुना अधिक O2 पारगम्यता चाहिए।',
    mr: '{temp}°C वर श्वसनाचा वेग जास्त असल्याने तुमच्या फिल्मला {x} पट जास्त O2 पारगम्यता आवश्यक आहे.',
    ta: '{temp}°C இல் அதிக சுவாசம் என்பது உங்கள் படலத்திற்கு {x} மடங்கு அதிக O2 ஊடுருவல் தேவை என்பதாகும்.'
  },
  'shap_explanation.moisture_barrier': {
    en: 'High moisture sensitivity requires WVTR below {target_wvtr} g/m²·day at {rh}% RH.',
    hi: 'उच्च नमी संवेदनशीलता के लिए {rh}% RH पर जलवाष्प संचरण दर {target_wvtr} g/m²·दिन से कम होनी चाहिए।',
    mr: 'जास्त आर्द्रता संवेदनशीलतेसाठी {rh}% RH वर पाण्याचे बाष्प वहन दर {target_wvtr} g/m²·दिवस पेक्षा कमी असणे आवश्यक आहे.',
    ta: '{rh}% RH இல் அதிக ஈரப்பதம் உணர்திறனுக்கு நீராவி பரிமாற்ற விகிதம் {target_wvtr} g/m²·நாளுக்கு குறைவாக இருக்க வேண்டும்.'
  },
  'shap_explanation.map_gas_retention': {
    en: 'Optimal MAP gas mix ({o2}% O2, {co2}% CO2) extends shelf life to {shelf_life} days.',
    hi: 'इष्टतम MAP गैस मिश्रण ({o2}% O2, {co2}% CO2) शेल्फ लाइफ को {shelf_life} दिनों तक बढ़ाता है।',
    mr: 'योग्य MAP वायू मिश्रण ({o2}% O2, {co2}% CO2) साठवणूक कालावधी {shelf_life} दिवसांपर्यंत वाढवते.',
    ta: 'உகந்த MAP வாயு கலவை ({o2}% O2, {co2}% CO2) சேமிப்பு காலத்தை {shelf_life} நாட்களாக நீட்டிக்கிறது.'
  },
  'checklist.confirm_otr': {
    en: 'Confirm Oxygen Transmission Rate (OTR) under ASTM D3985 at {temp}°C, target < {target} cc/m²·day.',
    hi: 'ASTM D3985 के तहत {temp}°C पर ऑक्सीजन संचरण दर (OTR) की पुष्टि करें, लक्ष्य < {target} cc/m²·दिन।',
    mr: 'ASTM D3985 अंतर्गत {temp}°C वर ऑक्सिजन वहन दर (OTR) तपासा, लक्ष्य < {target} cc/m²·दिवस.',
    ta: 'ASTM D3985 இன் கீழ் {temp}°C இல் ஆக்சிஜன் பரிமாற்ற விகிதத்தை (OTR) உறுதிப்படுத்தவும், இலக்கு < {target} cc/m²·நாள்.'
  },
  'checklist.confirm_wvtr': {
    en: 'Confirm Water Vapor Transmission Rate (WVTR) under ASTM F1249 at {temp}°C, {rh}% RH, target < {target} g/m²·day.',
    hi: 'ASTM F1249 के तहत {temp}°C, {rh}% RH पर जलवाष्प संचरण दर (WVTR) की पुष्टि करें, लक्ष्य < {target} g/m²·दिन।',
    mr: 'ASTM F1249 अंतर्गत {temp}°C, {rh}% RH वर जलबाष्प वहन दर (WVTR) तपासा, लक्ष्य < {target} g/m²·दिवस.',
    ta: 'ASTM F1249 இன் கீழ் {temp}°C, {rh}% RH இல் நீராவி பரிமாற்ற விகிதத்தை (WVTR) உறுதிப்படுத்தவும், இலக்கு < {target} g/m²·நாள்.'
  },
  'checklist.overall_migration': {
    en: 'Verify Overall Migration Limit (OML) conforms to IS 9845 (< 60 mg/kg food simulant).',
    hi: 'सत्यापित करें कि समग्र प्रवासन सीमा (OML) IS 9845 (< 60 मिग्रा/किग्रा खाद्य सिमुलेटर) के अनुरूप है।',
    mr: 'एकूण स्थलांतर मर्यादा (OML) IS 9845 (< ६० मिग्रॅ/किग्रॅ) नियमांनुसार असल्याची खात्री करा.',
    ta: 'ஒட்டுமொத்த இடம்பெயர்வு வரம்பு (OML) IS 9845 (< 60 மி.கி/கி.கி உணவு சிமுலண்ட்) உடன் இணங்குவதை உறுதிப்படுத்தவும்.'
  },
  'checklist.seal_integrity': {
    en: 'Execute vacuum decay bubble emission leak test at {pressure} kPa per ASTM D3078.',
    hi: 'ASTM D3078 के अनुसार {pressure} kPa पर वैक्यूम क्षय बबल उत्सर्जन रिसाव परीक्षण करें।',
    mr: 'ASTM D3078 नुसार {pressure} kPa वर व्हॅक्यूम लीक चाचणी पूर्ण करा.',
    ta: 'ASTM D3078 இன் படி {pressure} kPa இல் வெற்றிட குமிழி உமிழ்வு கசிவு சோதனையைச் செய்யவும்.'
  },
  'spoilage.diagnosis.anaerobic': {
    en: 'Anaerobic microbial fermentation detected due to oxygen depletion below {o2_threshold}%.',
    hi: '{o2_threshold}% से कम ऑक्सीजन होने के कारण अवायवीय सूक्ष्मजीव किण्वन पाया गया।',
    mr: '{o2_threshold}% पेक्षा कमी ऑक्सिजन पातळीमुळे विनॉक्सी सूक्ष्मजीव किण्वन आढळले.',
    ta: '{o2_threshold}% க்கும் குறைவான ஆக்சிஜன் குறைவால் காற்றில்லா நுண்ணுயிர் நொதித்தல் கண்டறியப்பட்டது.'
  },
  'spoilage.fix.anaerobic': {
    en: 'Switch to breathable micro-perforated film with {holes} holes/m² to prevent fermentation.',
    hi: 'किण्वन रोकने के लिए {holes} छिद्र/मी² वाली सांस लेने योग्य सूक्ष्म-छिद्रित फिल्म का उपयोग करें।',
    mr: 'किण्वन रोखण्यासाठी {holes} छिद्रे/मी² असणाऱ्या हवा खेळती ठेवणाऱ्या मायक्रो-परफोरेटेड फिल्मवर स्विच करा.',
    ta: 'நொதித்தலைத் தடுக்க {holes} துளைகள்/மீ² கொண்ட நுண் துளையிடப்பட்ட பிலிமுக்கு மாறவும்.'
  },
  'spoilage.diagnosis.condensation': {
    en: 'Moisture condensation and fungal spore germination observed at {rh}% relative humidity.',
    hi: '{rh}% सापेक्ष आर्द्रता पर नमी संक्षेपण एवं कवक बीजाणु अंकुरण देखा गया।',
    mr: '{rh}% सापेक्ष आर्द्रतेवर पाणी साचणे आणि बुरशी वाढणे आढळून आले.',
    ta: '{rh}% ஒப்பீட்டு ஈரப்பதத்தில் ஈரப்பதம் ஒடுக்கம் மற்றும் பூஞ்சை வித்து முளைத்தல் காணப்பட்டது.'
  },
  'spoilage.fix.condensation': {
    en: 'Apply anti-fog coating or insert active moisture scavenger to maintain headspace clarity.',
    hi: 'हेडस्पेस स्पष्टता बनाए रखने के लिए एंटी-फॉग कोटिंग लगाएं या सक्रिय नमी अवशोषक का उपयोग करें।',
    mr: 'पाऊचमधील स्पष्टतेसाठी अँटी-फॉग कोटिंग लावा किंवा आर्द्रता शोषक वापरा.',
    ta: 'ஹெட்ஸ்பேஸ் தெளிவை பராமரிக்க பனி எதிர்ப்பு பூச்சு அல்லது செயலில் உள்ள ஈரப்பதம் உறிஞ்சியைப் பயன்படுத்தவும்.'
  },
  'active_pack.ethylene_absorber': {
    en: 'Recommend potassium permanganate (KMnO4) ethylene scavenger sachet ({capacity} mg capacity) to delay climacteric ripening.',
    hi: 'क्लाइमेक्टेरिक पकने में देरी के लिए पोटेशियम परमैंगनेट (KMnO4) एथिलीन अवशोषक पाउच ({capacity} मिलीग्राम क्षमता) की सिफारिश की जाती है।',
    mr: 'फळे लवकर पिकणे रोखण्यासाठी पोटॅशियम परमँगनेट (KMnO4) इथिलीन शोषक पाऊच ({capacity} मिग्रॅ क्षमता) वापरा.',
    ta: 'பழம் பழுப்பதை தாமதப்படுத்த பொட்டாசியம் பெர்மாங்கனேட் (KMnO4) எத்திலீன் உறிஞ்சி பாக்கெட் ({capacity} மி.கி திறன்) பரிந்துரைக்கப்படுகிறது.'
  },
  'active_pack.oxygen_scavenger': {
    en: 'Recommend iron-based O2 scavenger sachet to maintain residual oxygen below {o2_pct}% throughout transit.',
    hi: 'परिवहन के दौरान अवशिष्ट ऑक्सीजन को {o2_pct}% से कम रखने के लिए लौह-आधारित O2 अवशोषक पाउच की सिफारिश की जाती है।',
    mr: 'वाहतुकीदरम्यान उर्वरित ऑक्सिजन {o2_pct}% पेक्षा कमी ठेवण्यासाठी लोह-आधारित O2 शोषक पाऊच वापरा.',
    ta: 'போக்குவரத்து முழுவதும் எஞ்சிய ஆக்சிஜனை {o2_pct}% க்குக் கீழே பராமரிக்க இரும்பு அடிப்படையிலான O2 உறிஞ்சி பாக்கெட்டைப் பரிந்துரைக்கவும்.'
  },
  'rural_mode.zero_energy_chamber': {
    en: 'Zero Energy Cool Chamber (ZECC) operates by evaporative cooling; limited efficiency during monsoon RH > {max_rh}%.',
    hi: 'जीरो एनर्जी कूल चैंबर (ZECC) वाष्पीकरण शीतलन द्वारा संचालित होता है; मानसून में {max_rh}% से अधिक RH पर प्रभावशीलता सीमित होती है।',
    mr: 'झिरो एनर्जी कूल चेंबर (ZECC) बाष्पीभवन शीतलीकरणावर काम करते; पावसाळ्यात आर्द्रता > {max_rh}% असल्यास कार्यक्षमता मर्यादित होते.',
    ta: 'ஜீரோ எனர்ஜி கூல் சேம்பர் (ZECC) ஆவியாதல் குளிர்விப்பால் இயங்குகிறது; பருவமழையின் போது RH > {max_rh}% ஆக இருந்தால் செயல்திறன் குறைவாக இருக்கும்.'
  },
  'rural_mode.hermetic_grain_bag': {
    en: 'Multi-layer hermetic grain bag protects against pest infestation; ensure seal is intact and rodent-protected.',
    hi: 'बहु-परत हर्मेटिक अनाज बैग कीट संक्रमण से बचाता है; सुनिश्चित करें कि सील अक्षुण्ण है और कृंतक सुरक्षित है।',
    mr: 'मल्टी-लेयर हर्मेटिक धान्य पिशवी कीटकांच्या प्रादुर्भावापासून संरक्षण करते; सील सुरक्षित असल्याची खात्री करा.',
    ta: 'பல அடுக்கு ஹெர்மீடிக் தானிய பை பூச்சி தொற்றிலிருந்து பாதுகாக்கிறது; சீல் சேதமடையாமல் இருப்பதை உறுதி செய்யவும்.'
  },
  'compliance.fssai_migration': {
    en: 'FSSAI 2018 Food Contact Safety: Overall migration limit must not exceed {limit} mg/kg.',
    hi: 'FSSAI 2018 खाद्य संपर्क सुरक्षा: समग्र प्रवासन सीमा {limit} मिग्रा/किग्रा से अधिक नहीं होनी चाहिए।',
    mr: 'FSSAI 2018 अन्न संपर्क सुरक्षितता: एकूण स्थलांतर मर्यादा {limit} मिग्रॅ/किग्रॅ पेक्षा जास्त नसावी.',
    ta: 'FSSAI 2018 உணவு தொடர்பு பாதுகாப்பு: ஒட்டுமொத்த இடம்பெயர்வு வரம்பு {limit} மி.கி/கி.கி ஐ தாண்டக்கூடாது.'
  },
  'compliance.pwm_thickness': {
    en: 'PWM 2022 Plastic Rules: Virgin and recyclable plastic carry bags and films must be at least {min_thickness} microns thick.',
    hi: 'PWM 2022 प्लास्टिक नियम: प्लास्टिक कैरी बैग और फिल्में कम से कम {min_thickness} माइक्रोन मोटी होनी चाहिए।',
    mr: 'PWM 2022 प्लॅस्टिक नियम: प्लॅस्टिक पिशव्या आणि फिल्म्स किमान {min_thickness} मायक्रॉन जाडीच्या असाव्यात.',
    ta: 'PWM 2022 பிளாஸ்டிக் விதிகள்: பிளாஸ்டிக் பைகள் மற்றும் படலங்கள் குறைந்தது {min_thickness} மைக்ரான் தடிமனாக இருக்க வேண்டும்.'
  },
  'gov_dashboard.mismatch_gap': {
    en: '{district_name}: Widespread use of non-breathable LDPE causing {loss_pct}% condensation spoilage in fresh produce.',
    hi: '{district_name}: सांस न लेने वाली LDPE के अत्यधिक उपयोग से ताजी उपज में {loss_pct}% संक्षेपण बर्बादी हो रही है।',
    mr: '{district_name}: हवा न खेळणाऱ्या LDPE चा जास्त वापर झाल्याने ताज्या शेतमाळात {loss_pct}% नुकसान होत आहे.',
    ta: '{district_name}: சுவாசிக்க முடியாத LDPE இன் பரவலான பயன்பாடு புதிய விளைபொருட்களில் {loss_pct}% அழுகல் இழப்பை ஏற்படுத்துகிறது.'
  },
  'gov_dashboard.cold_chain_gap': {
    en: '{district_name}: Lack of pre-cooling facilities elevates farm-gate transit losses to {loss_pct}%.',
    hi: '{district_name}: प्री-कूलिंग सुविधाओं की कमी के कारण खेत से परिवहन में {loss_pct}% नुकसान होता है।',
    mr: '{district_name}: प्री-कूलिंग सुविधांच्या अभावामुळे शेतातील वाहतूक नुकसान {loss_pct}% पर्यंत पोहोचते.',
    ta: '{district_name}: முன் குளிரூட்டும் வசதிகள் இல்லாததால் விளைநில போக்குவரத்து இழப்பு {loss_pct}% ஆக அதிகரிக்கிறது.'
  },
  'label_scan.fallback_message': {
    en: "Couldn't confidently match this label — please select your film manually.",
    hi: 'इस लेबल का विश्वासपूर्वक मिलान नहीं हो सका — कृपया अपनी फिल्म का मैन्युअल चयन करें।',
    mr: 'या लेबलची खात्रीशीर ओळख पटू शकली नाही — कृपया तुमची फिल्म मॅन्युअली निवडा.',
    ta: 'இந்த லேபிளை நம்பிக்கையுடன் பொருத்த முடியவில்லை — உங்கள் பிலிமை கைமுறையாகத் தேர்ந்தெடுக்கவும்.'
  }
};

export function renderI18nTemplate(templateKey: string, lang = 'en', variables: Record<string, any> = {}): string {
  const cleanLang = (lang || 'en').toLowerCase();
  const entry = I18N_TEMPLATES[templateKey];
  if (!entry) return templateKey;

  const rawTemplate = entry[cleanLang] || entry['en'] || templateKey;
  let result = rawTemplate;
  for (const [k, v] of Object.entries(variables)) {
    result = result.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
  }
  return result;
}

export function getLocalizedField(
  rowOrObj: any,
  fieldName: string,
  lang = 'en',
  fallbackDefault = ''
): string {
  const cleanLang = (lang || 'en').toLowerCase();
  const baseVal = rowOrObj ? String(rowOrObj[fieldName] || '') : '';
  const translations = rowOrObj ? rowOrObj[`${fieldName}_translations`] : null;

  if (cleanLang !== 'en' && translations && typeof translations === 'object') {
    const val = translations[cleanLang];
    if (val && String(val).trim()) return String(val).trim();
  }

  return baseVal.trim() || fallbackDefault;
}

