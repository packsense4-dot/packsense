/**
 * Rule-Based Product to Commodity & Food Knowledge Base Category Mapper
 * 
 * Maps commercial packaged product categories, tags, brands, or ingredient text
 * to the nearest engineering foods row (foods.category + foods.id).
 * 
 * If no confident mapping exists, returns null for food_id — signaling the
 * analyze endpoint to return needs_input asking for a one-tap commodity choice.
 */

export interface CategoryMappingResult {
  category: string;
  food_id: string | null;
  confidence: number; // 0.0 to 1.0
  matched_rule?: string;
}

interface CategoryRule {
  keywords: string[];
  category: string;
  food_id: string;
  minConfidence: number;
}

const CATEGORY_RULES: CategoryRule[] = [
  // Potato crisps & salty snacks / Indian dry sweets
  {
    keywords: ['chips', 'crisps', 'potato', 'wafer', 'wafers', 'namkeen', 'bhujia', 'sev', 'kurkure', 'snack', 'snacks', 'dry_snacks', 'ladoo', 'laddu', 'besan', 'mithai', 'sweet', 'sweets'],
    category: 'dry_snacks',
    food_id: 'potato_crisps',
    minConfidence: 0.85
  },
  // Biscuits & cookies
  {
    keywords: ['biscuit', 'cookie', 'cookies', 'parle-g', 'good day', 'rusk', 'crackers'],
    category: 'bakery',
    food_id: 'white_bread',
    minConfidence: 0.80
  },
  // Bread & bakery
  {
    keywords: ['bread', 'loaf', 'bun', 'cake', 'muffin', 'pastry'],
    category: 'bakery',
    food_id: 'white_bread',
    minConfidence: 0.90
  },
  // Paneer, cheese, dairy
  {
    keywords: ['paneer', 'cottage cheese', 'cheese', 'cheddar', 'mozzarella', 'dahi', 'curd', 'yogurt'],
    category: 'dairy_cheese',
    food_id: 'fresh_paneer',
    minConfidence: 0.90
  },
  // Milk & liquid dairy
  {
    keywords: ['milk', 'chaas', 'buttermilk', 'lassi'],
    category: 'dairy_cheese',
    food_id: 'fresh_paneer',
    minConfidence: 0.75
  },
  // Fresh Mango & fruits
  {
    keywords: ['mango', 'alphonso', 'kesar', 'dasheri', 'apple', 'banana', 'papaya', 'guava', 'orange', 'fruit'],
    category: 'fresh_produce',
    food_id: 'alphonso_mango',
    minConfidence: 0.88
  },
  // Leafy greens & fresh vegetables
  {
    keywords: ['spinach', 'palak', 'methi', 'coriander', 'lettuce', 'greens', 'cabbage', 'cauliflower', 'broccoli'],
    category: 'fresh_produce',
    food_id: 'fresh_spinach',
    minConfidence: 0.85
  },
  // Tomato puree & ready pastes
  {
    keywords: ['tomato puree', 'puree', 'paste', 'sauce', 'ketchup', 'curry paste', 'ready to eat', 'gravy'],
    category: 'ready_to_eat',
    food_id: 'tomato_puree',
    minConfidence: 0.85
  },
  // Fresh Meat & cuts
  {
    keywords: ['beef', 'mutton', 'lamb', 'steak', 'pork', 'meat'],
    category: 'fresh_meat',
    food_id: 'fresh_beef_steak',
    minConfidence: 0.85
  },
  // Poultry
  {
    keywords: ['chicken', 'turkey', 'poultry'],
    category: 'poultry',
    food_id: 'chicken_breast',
    minConfidence: 0.88
  },
  // Seafood & fish
  {
    keywords: ['fish', 'salmon', 'prawn', 'shrimp', 'crab', 'seafood'],
    category: 'seafood',
    food_id: 'salmon_fillet',
    minConfidence: 0.85
  },
  // Nuts & seeds
  {
    keywords: ['peanut', 'peanuts', 'cashew', 'almond', 'walnut', 'pistachio', 'groundnut'],
    category: 'dry_snacks',
    food_id: 'roasted_peanuts',
    minConfidence: 0.85
  },
  // Coffee & tea
  {
    keywords: ['coffee', 'tea', 'chai', 'espresso', 'cappuccino', 'nescafe'],
    category: 'coffee_tea',
    food_id: 'ground_coffee',
    minConfidence: 0.90
  }
];

/**
 * Maps a product's name, brand, category string, and ingredients list
 * to the engineering knowledge base foods row.
 */
export function mapProductToFoodCategory(product: {
  name: string;
  brand?: string;
  category?: string;
  ingredients?: string[];
}): CategoryMappingResult {
  const combinedText = [
    product.name || '',
    product.category || '',
    product.brand || '',
    ...(product.ingredients || [])
  ].join(' ').toLowerCase();

  for (const rule of CATEGORY_RULES) {
    for (const kw of rule.keywords) {
      const regex = new RegExp(`\\b${kw}\\b`, 'i');
      if (regex.test(combinedText)) {
        return {
          category: rule.category,
          food_id: rule.food_id,
          confidence: rule.minConfidence,
          matched_rule: kw
        };
      }
    }
  }

  // If no confident mapping found, category may be inferred or left generic, food_id is NULL
  let inferredCategory = 'packaged_food';
  if (/snack|namkeen|confection/i.test(combinedText)) {
    inferredCategory = 'dry_snacks';
  } else if (/dairy|milk|cheese/i.test(combinedText)) {
    inferredCategory = 'dairy_cheese';
  } else if (/produce|fruit|vegetable/i.test(combinedText)) {
    inferredCategory = 'fresh_produce';
  }

  return {
    category: inferredCategory,
    food_id: null, // Signals needs_input (one-tap commodity choice)
    confidence: 0.35,
    matched_rule: 'none'
  };
}
