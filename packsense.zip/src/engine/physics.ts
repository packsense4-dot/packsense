/**
 * PackSense Deterministic Physics & Preservation Simulation Engine
 * 
 * Implements:
 * 1. Multilayer series resistance permeation model (ASTM D3985 / ASTM F1249)
 * 2. Arrhenius temperature scaling of permeation coefficients
 * 3. Humidity sensitivity corrections for EVOH / hygroscopic polymers
 * 4. Package geometry & headspace volume calculation
 * 5. MAP headspace gas exchange kinetics (transient ODE solver)
 * 6. Produce Michaelis-Menten respiration equilibrium
 * 7. GAB sorption isotherm moisture sorption/desorption
 * 8. Modified Gompertz / Baranyi microbial growth with CO2 inhibition
 * 9. Lipid oxidation and quality decay tracking
 */

import { MATERIALS_DATABASE, PackagingMaterial, getMaterialById } from './materialsDb.ts';
import { FoodProduct } from './foodsDb.ts';

export interface LaminateLayerInput {
  material_id: string;
  thickness_um: number;
}

export interface LaminateBarrierResult {
  layers: Array<{
    material: PackagingMaterial;
    thickness_um: number;
    mass_fraction_percent: number;
    layer_cost_per_m2: number;
    layer_carbon_per_m2: number;
  }>;
  total_thickness_um: number;
  total_mass_gsm: number; // g / m²
  
  // Barrier permeation rates at target conditions
  otr_cc_m2_day_atm: number; // cm³ / (m² · day · atm)
  wvtr_g_m2_day: number; // g / (m² · day)
  ctr_cc_m2_day_atm: number; // cm³ / (m² · day · atm) for CO2

  // Standard reference rates (at 23°C, 0% RH for O2 / 38°C, 90% RH for WVTR)
  ref_otr_23c: number;
  ref_wvtr_38c: number;
  ref_ctr_23c: number;

  cost_per_m2: number; // USD / m²
  carbon_per_m2: number; // kg CO2e / m²

  // Recyclability assessment
  recyclability_class: 'Class A (Mono-PE)' | 'Class A (Mono-PP)' | 'Class B (Compatible Paper)' | 'Class C (Compostable)' | 'Class D (Multimaterial Non-recyclable)';
  recyclability_score: number; // 0 to 100
  dominant_polymer: string;
  is_monomaterial: boolean;
  ceflex_compliant: boolean;
}

export interface PackageGeometry {
  package_type: 'pillow_pouch' | 'stand_up_pouch' | 'thermoformed_tray' | 'flow_wrap';
  length_mm: number;
  width_mm: number;
  depth_mm?: number;
  net_weight_g: number;
  custom_surface_area_m2?: number;
  custom_headspace_cm3?: number;
}

export interface SimulationConditions {
  storage_temp_c: number;
  ambient_rh_percent: number; // e.g. 50% or 85%
  ambient_o2_percent?: number; // defaults to 20.9%
  ambient_co2_percent?: number; // defaults to 0.04%
}

export interface MapGasConfig {
  initial_o2_percent: number;
  initial_co2_percent: number;
  initial_n2_percent: number;
  gas_to_product_volume_ratio?: number; // Vg / Vp (default 1.5 to 2.5)
}

export interface SimulationDayDataPoint {
  day: number;
  headspace_o2_percent: number;
  headspace_co2_percent: number;
  headspace_n2_percent: number;
  product_moisture_g100g: number;
  product_aw: number;
  microbial_log_cfu_g: number;
  o2_absorbed_mg_kg: number;
  quality_retention_percent: number;
  status: 'Fresh' | 'Sub-optimal' | 'Expired';
  dominant_stressor: 'None' | 'Microbial' | 'Oxidation' | 'Moisture' | 'Fermentation' | 'Staling';
}

export interface ShelfLifeSimulationResult {
  predicted_shelf_life_days: number;
  limiting_factor: 'microbial' | 'oxidation' | 'moisture_gain' | 'moisture_loss' | 'respiration_fermentation' | 'none';
  limiting_description: string;
  cost_per_pack_usd: number;
  carbon_per_pack_g_co2e: number;
  packaging_weight_per_pack_g: number;
  barrier: LaminateBarrierResult;
  package_surface_area_m2: number;
  headspace_volume_cm3: number;
  food_weight_g: number;
  
  // Margins at target shelf life
  microbial_margin_cfu: number;
  moisture_margin_g100g: number;
  oxidation_margin_mg_kg: number;

  daily_trajectory: SimulationDayDataPoint[];
}

const GAS_CONSTANT_R = 8.314; // J / (mol · K)
const KELVIN_OFFSET = 273.15;

/**
 * Arrhenius rate scaling for permeability
 */
function arrheniusScale(
  p_ref: number,
  activation_energy_kj: number,
  temp_c: number,
  ref_temp_c: number
): number {
  const t_kelvin = temp_c + KELVIN_OFFSET;
  const t_ref_kelvin = ref_temp_c + KELVIN_OFFSET;
  const ep_joules = activation_energy_kj * 1000;
  return p_ref * Math.exp((-ep_joules / GAS_CONSTANT_R) * (1 / t_kelvin - 1 / t_ref_kelvin));
}

/**
 * Calculates total multilayer laminate barrier properties via series resistance
 */
export function calculateLaminateBarrier(
  layersInput: LaminateLayerInput[],
  temp_c: number = 23,
  ambient_rh: number = 50
): LaminateBarrierResult {
  if (!layersInput || layersInput.length === 0) {
    throw new Error('At least one layer must be specified.');
  }

  const layersWithMat = layersInput.map(l => {
    const mat = getMaterialById(l.material_id) || MATERIALS_DATABASE[0];
    const thickness = Math.max(0.5, l.thickness_um);
    return { material: mat, thickness_um: thickness };
  });

  const total_thickness_um = layersWithMat.reduce((acc, curr) => acc + curr.thickness_um, 0);

  // Calculate mass for each layer to compute mass fractions
  let total_mass_gsm = 0;
  const massPerLayer = layersWithMat.map(l => {
    // GSM = thickness (µm) * density (g/cm³) * 1 (since 1 µm * 1 m² = 1 cm³)
    const gsm = l.thickness_um * l.material.density;
    total_mass_gsm += gsm;
    return gsm;
  });

  // Series resistance calculation for O2, H2O, and CO2
  let resistance_o2 = 0;
  let resistance_wvtr = 0;
  let resistance_co2 = 0;

  let ref_resistance_o2 = 0;
  let ref_resistance_wvtr = 0;
  let ref_resistance_co2 = 0;

  let cost_per_m2 = 0;
  let carbon_per_m2 = 0;

  // Track polymer weights for recyclability
  const polymerMassMap: Record<string, number> = {};

  const layerResults = layersWithMat.map((l, idx) => {
    const mat = l.material;
    const thickness = l.thickness_um;
    const gsm = massPerLayer[idx];
    const mass_fraction = total_mass_gsm > 0 ? (gsm / total_mass_gsm) * 100 : 0;

    // Group for recyclability
    polymerMassMap[mat.code] = (polymerMassMap[mat.code] || 0) + gsm;
    if (mat.category === 'polyolefin') {
      if (mat.code.includes('PE')) {
        polymerMassMap['PE_STREAM'] = (polymerMassMap['PE_STREAM'] || 0) + gsm;
      } else if (mat.code.includes('PP')) {
        polymerMassMap['PP_STREAM'] = (polymerMassMap['PP_STREAM'] || 0) + gsm;
      }
    }

    // Material costs & LCA
    const kg_per_m2 = gsm / 1000;
    const layer_cost = kg_per_m2 * mat.cost_per_kg;
    const layer_carbon = kg_per_m2 * mat.carbon_per_kg;

    cost_per_m2 += layer_cost;
    carbon_per_m2 += layer_carbon;

    // Standard reference permeability (dry 23°C, 38°C WVTR)
    const p_o2_ref = mat.po2_23c;
    const p_wvtr_ref = mat.pwvtr_38c;
    const p_co2_ref = mat.pco2_23c;

    ref_resistance_o2 += thickness / p_o2_ref;
    ref_resistance_wvtr += thickness / p_wvtr_ref;
    ref_resistance_co2 += thickness / p_co2_ref;

    // Condition-adjusted permeability via Arrhenius
    let p_o2_scaled = arrheniusScale(mat.po2_23c, mat.ep_o2, temp_c, 23);
    let p_wvtr_scaled = arrheniusScale(mat.pwvtr_38c, mat.ep_h2o, temp_c, 38);
    let p_co2_scaled = arrheniusScale(mat.pco2_23c, mat.ep_o2 * 0.95, temp_c, 23);

    // RH sensitivity adjustment for EVOH: if EVOH is protected between polyolefins, effective internal RH is dampened
    if (mat.rh_sensitive && mat.id.includes('evoh')) {
      const hasOuterMoistureBarrier = idx > 0 && layersWithMat[0].material.category === 'polyolefin';
      const effectiveRH = hasOuterMoistureBarrier ? Math.min(ambient_rh, 60) : ambient_rh;
      if (effectiveRH > 65) {
        // Exponential increase in EVOH OTR in high humidity
        const rhFactor = Math.exp(0.045 * (effectiveRH - 65));
        p_o2_scaled *= rhFactor;
        p_co2_scaled *= rhFactor;
      }
    }

    resistance_o2 += thickness / p_o2_scaled;
    resistance_wvtr += thickness / p_wvtr_scaled;
    resistance_co2 += thickness / p_co2_scaled;

    return {
      material: mat,
      thickness_um: thickness,
      mass_fraction_percent: Number(mass_fraction.toFixed(1)),
      layer_cost_per_m2: Number(layer_cost.toFixed(4)),
      layer_carbon_per_m2: Number(layer_carbon.toFixed(4))
    };
  });

  // Adding conversion / lamination overhead: ~0.08 $/m² and 0.05 kg CO2e/m²
  cost_per_m2 += 0.08;
  carbon_per_m2 += 0.05;

  const otr = resistance_o2 > 0 ? 1 / resistance_o2 : 99999;
  const wvtr = resistance_wvtr > 0 ? 1 / resistance_wvtr : 99999;
  const ctr = resistance_co2 > 0 ? 1 / resistance_co2 : 99999;

  const ref_otr = ref_resistance_o2 > 0 ? 1 / ref_resistance_o2 : 99999;
  const ref_wvtr = ref_resistance_wvtr > 0 ? 1 / ref_resistance_wvtr : 99999;
  const ref_ctr = ref_resistance_co2 > 0 ? 1 / ref_resistance_co2 : 99999;

  // Recyclability assessment
  const pePercent = total_mass_gsm > 0 ? ((polymerMassMap['PE_STREAM'] || 0) / total_mass_gsm) * 100 : 0;
  const ppPercent = total_mass_gsm > 0 ? ((polymerMassMap['PP_STREAM'] || 0) / total_mass_gsm) * 100 : 0;
  const paperPercent = total_mass_gsm > 0 ? ((polymerMassMap['Kraft-Bio'] || 0) / total_mass_gsm) * 100 : 0;
  const compostablePercent = total_mass_gsm > 0 ?
    (((polymerMassMap['PLA'] || 0) + (polymerMassMap['Bio-PBS'] || 0)) / total_mass_gsm) * 100 : 0;

  let recyclability_class: LaminateBarrierResult['recyclability_class'] = 'Class D (Multimaterial Non-recyclable)';
  let recyclability_score = 25;
  let dominant_polymer = 'Mixed Laminate';
  let is_monomaterial = false;
  let ceflex_compliant = false;

  if (pePercent >= 90) {
    recyclability_class = 'Class A (Mono-PE)';
    recyclability_score = 95;
    dominant_polymer = 'Polyethylene (PE)';
    is_monomaterial = true;
    ceflex_compliant = true;
  } else if (ppPercent >= 90) {
    recyclability_class = 'Class A (Mono-PP)';
    recyclability_score = 92;
    dominant_polymer = 'Polypropylene (PP)';
    is_monomaterial = true;
    ceflex_compliant = true;
  } else if (paperPercent >= 85) {
    recyclability_class = 'Class B (Compatible Paper)';
    recyclability_score = 88;
    dominant_polymer = 'Paper / Fiber';
    is_monomaterial = false;
    ceflex_compliant = false;
  } else if (compostablePercent >= 90) {
    recyclability_class = 'Class C (Compostable)';
    recyclability_score = 80;
    dominant_polymer = 'Bio-Polyester (Compostable)';
    is_monomaterial = false;
    ceflex_compliant = false;
  } else if (pePercent >= 75 || ppPercent >= 75) {
    recyclability_class = 'Class D (Multimaterial Non-recyclable)';
    recyclability_score = 45;
    dominant_polymer = pePercent > ppPercent ? 'PE-rich Blend' : 'PP-rich Blend';
  }

  return {
    layers: layerResults,
    total_thickness_um: Number(total_thickness_um.toFixed(1)),
    total_mass_gsm: Number(total_mass_gsm.toFixed(2)),
    otr_cc_m2_day_atm: Number(otr.toFixed(3)),
    wvtr_g_m2_day: Number(wvtr.toFixed(3)),
    ctr_cc_m2_day_atm: Number(ctr.toFixed(3)),
    ref_otr_23c: Number(ref_otr.toFixed(3)),
    ref_wvtr_38c: Number(ref_wvtr.toFixed(3)),
    ref_ctr_23c: Number(ref_ctr.toFixed(3)),
    cost_per_m2: Number(cost_per_m2.toFixed(4)),
    carbon_per_m2: Number(carbon_per_m2.toFixed(4)),
    recyclability_class,
    recyclability_score,
    dominant_polymer,
    is_monomaterial,
    ceflex_compliant
  };
}

/**
 * Computes package surface area and headspace volume
 */
export function calculatePackageGeometry(
  geom: PackageGeometry,
  foodDensityKgM3: number = 1000
): { surface_area_m2: number; headspace_volume_cm3: number; food_volume_cm3: number } {
  if (geom.custom_surface_area_m2 && geom.custom_headspace_cm3) {
    const food_vol = (geom.net_weight_g / (foodDensityKgM3 / 1000));
    return {
      surface_area_m2: geom.custom_surface_area_m2,
      headspace_volume_cm3: geom.custom_headspace_cm3,
      food_volume_cm3: food_vol
    };
  }

  const length_m = geom.length_mm / 1000;
  const width_m = geom.width_mm / 1000;
  const depth_m = (geom.depth_mm || Math.min(geom.length_mm, geom.width_mm) * 0.35) / 1000;

  // Surface area calculation based on pack type
  let surface_area_m2 = 0;
  let total_internal_volume_cm3 = 0;

  if (geom.package_type === 'pillow_pouch' || geom.package_type === 'flow_wrap') {
    // 2 flat sides of L * W minus seal margins
    surface_area_m2 = 2 * length_m * width_m;
    // Pouch expanded volume approximation
    total_internal_volume_cm3 = (length_m * 100) * (width_m * 100) * 2.2;
  } else if (geom.package_type === 'stand_up_pouch') {
    surface_area_m2 = 2 * length_m * width_m + (width_m * depth_m * 1.5);
    total_internal_volume_cm3 = (length_m * 100) * (width_m * 100) * (depth_m * 100) * 0.75;
  } else {
    // Thermoformed tray
    const bottom_side_area = (length_m * width_m) + 2 * (length_m * depth_m) + 2 * (width_m * depth_m);
    const top_lidding_film_area = length_m * width_m;
    surface_area_m2 = bottom_side_area + top_lidding_film_area;
    total_internal_volume_cm3 = (length_m * 100) * (width_m * 100) * (depth_m * 100);
  }

  // Food volume displacement
  const food_volume_cm3 = geom.net_weight_g / (foodDensityKgM3 / 1000);
  const calculated_headspace = Math.max(30, total_internal_volume_cm3 - food_volume_cm3);

  return {
    surface_area_m2: Number(surface_area_m2.toFixed(4)),
    headspace_volume_cm3: Number(calculated_headspace.toFixed(1)),
    food_volume_cm3: Number(food_volume_cm3.toFixed(1))
  };
}

/**
 * GAB isotherm inverse: calculates water activity aw from moisture content X (g H2O / 100g dry solids)
 */
export function calculateAwFromMoisture(moisture_g100g: number, food: FoodProduct): number {
  const { gab_xm, gab_c, gab_k } = food;
  const X = Math.max(0.1, moisture_g100g);
  
  // Numerical root finding for GAB equation:
  // X = (Xm * C * K * aw) / ((1 - K * aw) * (1 - K * aw + C * K * aw))
  let low = 0.001;
  let high = 0.999;
  for (let iter = 0; iter < 25; iter++) {
    const mid = (low + high) / 2;
    const kaw = gab_k * mid;
    const calcX = (gab_xm * gab_c * kaw) / ((1 - kaw) * (1 - kaw + gab_c * kaw));
    if (calcX < X) {
      low = mid;
    } else {
      high = mid;
    }
  }
  return Number(((low + high) / 2).toFixed(4));
}

/**
 * Full deterministic time-stepping physics simulation of food shelf life
 */
export function simulateShelfLife(
  food: FoodProduct,
  barrier: LaminateBarrierResult,
  geometry: PackageGeometry,
  conditions: SimulationConditions,
  mapConfig?: MapGasConfig,
  max_simulation_days: number = 180
): ShelfLifeSimulationResult {
  const { surface_area_m2, headspace_volume_cm3 } = calculatePackageGeometry(
    geometry,
    food.density_kg_m3
  );

  const food_weight_kg = geometry.net_weight_g / 1000;
  const gas_ratio = mapConfig?.gas_to_product_volume_ratio || 1.8;
  const actual_headspace_cm3 = Math.max(headspace_volume_cm3, (geometry.net_weight_g / (food.density_kg_m3 / 1000)) * gas_ratio);

  // Initial headspace gas concentrations (%)
  let curr_o2_percent = mapConfig ? mapConfig.initial_o2_percent : (food.recommended_map?.o2_percent ?? 20.9);
  let curr_co2_percent = mapConfig ? mapConfig.initial_co2_percent : (food.recommended_map?.co2_percent ?? 0.04);
  let curr_n2_percent = 100 - curr_o2_percent - curr_co2_percent;

  const ambient_o2 = conditions.ambient_o2_percent ?? 20.9;
  const ambient_co2 = conditions.ambient_co2_percent ?? 0.04;
  const ambient_rh = conditions.ambient_rh_percent;

  // Initial food state
  let curr_moisture = food.initial_moisture_g100g;
  let curr_aw = food.initial_aw;
  let curr_log_cfu = food.initial_cfu_g;
  let cumulative_o2_absorbed_mg_kg = 0;

  let failure_day = max_simulation_days;
  let limiting_factor: ShelfLifeSimulationResult['limiting_factor'] = 'none';
  let limiting_description = 'Shelf life maintained through full target window.';

  const daily_trajectory: SimulationDayDataPoint[] = [];

  // Headspace volume in liters
  const v_h_liters = actual_headspace_cm3 / 1000;
  // Molar volume of gas at storage temp (ideal gas law V_m = RT / P)
  const molar_volume_l = (0.08206 * (conditions.storage_temp_c + KELVIN_OFFSET)) / 1.0;

  for (let day = 0; day <= max_simulation_days; day++) {
    // Determine status & stressors
    let day_status: SimulationDayDataPoint['status'] = 'Fresh';
    let dominant_stressor: SimulationDayDataPoint['dominant_stressor'] = 'None';

    // 1. Check microbial failure threshold
    if (curr_log_cfu >= food.crit_microbial_cfu_g) {
      day_status = 'Expired';
      dominant_stressor = 'Microbial';
      if (limiting_factor === 'none') {
        limiting_factor = 'microbial';
        failure_day = day;
        limiting_description = `Microbial spoilage threshold reached (${curr_log_cfu.toFixed(2)} log CFU/g exceeds limit ${food.crit_microbial_cfu_g} log CFU/g).`;
      }
    }

    // 2. Check moisture critical limits (sogginess or dehydration)
    if (food.crit_moisture_max_g100g && curr_moisture >= food.crit_moisture_max_g100g) {
      day_status = 'Expired';
      dominant_stressor = 'Moisture';
      if (limiting_factor === 'none') {
        limiting_factor = 'moisture_gain';
        failure_day = day;
        limiting_description = `Critical moisture absorption limit breached (${curr_moisture.toFixed(2)} g/100g exceeds maximum crispy limit ${food.crit_moisture_max_g100g} g/100g).`;
      }
    } else if (food.crit_moisture_min_g100g && curr_moisture <= food.crit_moisture_min_g100g) {
      day_status = 'Expired';
      dominant_stressor = 'Staling';
      if (limiting_factor === 'none') {
        limiting_factor = 'moisture_loss';
        failure_day = day;
        limiting_description = `Critical desiccation / staling moisture loss breached (${curr_moisture.toFixed(2)} g/100g dropped below ${food.crit_moisture_min_g100g} g/100g).`;
      }
    }

    // 3. Check lipid oxidation limit
    if (food.max_o2_uptake_mg_kg && cumulative_o2_absorbed_mg_kg >= food.max_o2_uptake_mg_kg) {
      day_status = 'Expired';
      dominant_stressor = 'Oxidation';
      if (limiting_factor === 'none') {
        limiting_factor = 'oxidation';
        failure_day = day;
        limiting_description = `Rancidity threshold reached (Oxygen uptake ${cumulative_o2_absorbed_mg_kg.toFixed(1)} mg/kg exceeds limit ${food.max_o2_uptake_mg_kg} mg/kg).`;
      }
    }

    // 4. Check produce anaerobic fermentation limit
    if (food.is_respiring_produce && food.produce_respiration) {
      if (curr_o2_percent < food.produce_respiration.extinction_o2_percent) {
        day_status = 'Expired';
        dominant_stressor = 'Fermentation';
        if (limiting_factor === 'none') {
          limiting_factor = 'respiration_fermentation';
          failure_day = day;
          limiting_description = `Anaerobic fermentation triggered (Headspace O2 dropped to ${curr_o2_percent.toFixed(2)}%, below extinction point ${food.produce_respiration.extinction_o2_percent}%).`;
        }
      }
    }

    // Calculate quality index (100% decaying down to 0%)
    const micro_ratio = Math.min(1.0, (curr_log_cfu - food.initial_cfu_g) / (food.crit_microbial_cfu_g - food.initial_cfu_g));
    const ox_ratio = food.max_o2_uptake_mg_kg ? Math.min(1.0, cumulative_o2_absorbed_mg_kg / food.max_o2_uptake_mg_kg) : 0;
    const moist_ratio = food.crit_moisture_max_g100g ?
      Math.min(1.0, Math.max(0, (curr_moisture - food.initial_moisture_g100g) / (food.crit_moisture_max_g100g - food.initial_moisture_g100g))) : 0;

    const worst_decay = Math.max(micro_ratio, ox_ratio, moist_ratio);
    const quality_retention = Math.max(0, Math.min(100, Math.round((1 - worst_decay) * 100)));

    if (quality_retention < 60 && day_status === 'Fresh') {
      day_status = 'Sub-optimal';
    }

    daily_trajectory.push({
      day,
      headspace_o2_percent: Number(curr_o2_percent.toFixed(2)),
      headspace_co2_percent: Number(curr_co2_percent.toFixed(2)),
      headspace_n2_percent: Number(curr_n2_percent.toFixed(2)),
      product_moisture_g100g: Number(curr_moisture.toFixed(2)),
      product_aw: Number(curr_aw.toFixed(3)),
      microbial_log_cfu_g: Number(curr_log_cfu.toFixed(2)),
      o2_absorbed_mg_kg: Number(cumulative_o2_absorbed_mg_kg.toFixed(2)),
      quality_retention_percent: quality_retention,
      status: day_status,
      dominant_stressor
    });

    if (limiting_factor !== 'none' && day > failure_day + 5) {
      // Continue for 5 days after failure to show post-shelf-life curve, then break
      break;
    }

    // --- Daily Numerical Physics Integration Step ---
    // A. Permeation Flux through barrier film
    // Permeation O2 (cm³/day) = OTR * Area * delta_P_O2 (atm)
    const delta_p_o2 = (ambient_o2 - curr_o2_percent) / 100;
    const delta_p_co2 = (ambient_co2 - curr_co2_percent) / 100;

    const flux_o2_cm3_day = barrier.otr_cc_m2_day_atm * surface_area_m2 * delta_p_o2;
    const flux_co2_cm3_day = barrier.ctr_cc_m2_day_atm * surface_area_m2 * delta_p_co2;

    // B. Produce Respiration (if living tissue)
    let resp_o2_consumed_cm3_day = 0;
    let resp_co2_produced_cm3_day = 0;

    if (food.is_respiring_produce && food.produce_respiration) {
      const resp = food.produce_respiration;
      // Arrhenius Q10 scaling
      const temp_factor = Math.pow(resp.q10, (conditions.storage_temp_c - resp.t_ref_c) / 10);
      const vm_actual = resp.vm_o2_ref * temp_factor; // mL / (kg · hr)
      
      // Michaelis-Menten rate with CO2 competitive inhibition
      const o2_term = Math.max(0.01, curr_o2_percent);
      const inhibition_term = 1 + Math.max(0, curr_co2_percent) / resp.ki_co2;
      const r_o2_ml_kg_hr = (vm_actual * o2_term) / (resp.km_o2 * inhibition_term + o2_term);
      
      resp_o2_consumed_cm3_day = r_o2_ml_kg_hr * food_weight_kg * 24;
      resp_co2_produced_cm3_day = resp_o2_consumed_cm3_day * resp.rq;
    }

    // C. Lipid Oxidation O2 uptake
    const k_ox = food.oxidation_rate_k || 0.1;
    const temp_ox_factor = Math.pow(1.8, (conditions.storage_temp_c - 20) / 10);
    // Rate in mg O2 / (kg · day)
    const daily_o2_uptake_mg_kg = k_ox * Math.sqrt(Math.max(0, curr_o2_percent)) * temp_ox_factor;
    cumulative_o2_absorbed_mg_kg += daily_o2_uptake_mg_kg;

    // Convert mg O2 absorbed into equivalent gas volume (32 mg O2 = 1 mmol = 22.4 mL gas at STP)
    const ox_o2_consumed_cm3_day = ((daily_o2_uptake_mg_kg * food_weight_kg) / 32) * (molar_volume_l * 1000 / 1000);

    // D. Update Headspace gas concentrations
    const net_d_o2_cm3 = flux_o2_cm3_day - resp_o2_consumed_cm3_day - ox_o2_consumed_cm3_day;
    const net_d_co2_cm3 = flux_co2_cm3_day + resp_co2_produced_cm3_day;

    // Dissolution effect: CO2 dissolves in moist/fatty food phase (Henry's law)
    const co2_solubility_factor = (food.initial_moisture_g100g / 100) * 0.15;
    const effective_d_co2_cm3 = net_d_co2_cm3 / (1 + co2_solubility_factor);

    // Update concentrations (% in headspace volume)
    const d_o2_pct = (net_d_o2_cm3 / actual_headspace_cm3) * 100;
    const d_co2_pct = (effective_d_co2_cm3 / actual_headspace_cm3) * 100;

    curr_o2_percent = Math.max(0, Math.min(99, curr_o2_percent + d_o2_pct));
    curr_co2_percent = Math.max(0, Math.min(99, curr_co2_percent + d_co2_pct));
    curr_n2_percent = Math.max(0, 100 - curr_o2_percent - curr_co2_percent);

    // E. Moisture Transmission (Water vapor flux)
    // WVTR flux is driven by gradient between ambient RH and food water activity (aw * 100)
    const driving_rh_gradient = (ambient_rh - curr_aw * 100) / 100;
    const water_flux_g_day = barrier.wvtr_g_m2_day * surface_area_m2 * driving_rh_gradient;
    
    // Update product moisture content (g water / 100g dry solid)
    const food_dry_matter_g = geometry.net_weight_g * (1 - food.initial_moisture_g100g / 100);
    const d_moisture_g100g = food_dry_matter_g > 0 ? (water_flux_g_day / food_dry_matter_g) * 100 : 0;
    curr_moisture = Math.max(0.5, curr_moisture + d_moisture_g100g);
    curr_aw = calculateAwFromMoisture(curr_moisture, food);

    // F. Microbial Growth (Modified Gompertz / Baranyi with CO2 inhibition & aw factor)
    if (day >= food.lag_phase_lambda_days) {
      // Temperature effect on bacterial growth
      const t_micro = Math.max(0, conditions.storage_temp_c);
      const temp_growth_factor = Math.pow(2.2, (t_micro - 4) / 10);
      
      // CO2 inhibition term
      const co2_inhibit = Math.max(0.1, 1 - (curr_co2_percent / 100) * food.co2_inhibition_factor);
      
      // Aw inhibition (growth drops below aw 0.85, minimal below 0.60)
      const aw_growth_factor = curr_aw > 0.85 ? 1.0 : Math.max(0, (curr_aw - 0.60) / 0.25);

      const daily_growth_rate = food.max_growth_rate_mu_max * temp_growth_factor * co2_inhibit * aw_growth_factor;
      
      // Logistic deceleration as population approaches saturation (~9.0 log CFU/g)
      const max_saturation_cfu = 9.0;
      const remaining_growth_capacity = Math.max(0, (max_saturation_cfu - curr_log_cfu) / (max_saturation_cfu - food.initial_cfu_g));
      
      curr_log_cfu = Math.min(max_saturation_cfu, curr_log_cfu + daily_growth_rate * remaining_growth_capacity);
    }
  }

  // Cost and carbon per pack
  const cost_per_pack_usd = barrier.cost_per_m2 * surface_area_m2;
  const carbon_per_pack_g_co2e = barrier.carbon_per_m2 * surface_area_m2 * 1000;
  const packaging_weight_per_pack_g = barrier.total_mass_gsm * surface_area_m2;

  // Margins at failure day or target shelf life
  const eval_day_idx = Math.min(failure_day, daily_trajectory.length - 1);
  const eval_point = daily_trajectory[eval_day_idx];

  const microbial_margin = food.crit_microbial_cfu_g - eval_point.microbial_log_cfu_g;
  const moisture_margin = food.crit_moisture_max_g100g ? (food.crit_moisture_max_g100g - eval_point.product_moisture_g100g) : 0;
  const ox_margin = food.max_o2_uptake_mg_kg ? (food.max_o2_uptake_mg_kg - eval_point.o2_absorbed_mg_kg) : 0;

  return {
    predicted_shelf_life_days: failure_day,
    limiting_factor,
    limiting_description,
    cost_per_pack_usd: Number(cost_per_pack_usd.toFixed(4)),
    carbon_per_pack_g_co2e: Number(carbon_per_pack_g_co2e.toFixed(2)),
    packaging_weight_per_pack_g: Number(packaging_weight_per_pack_g.toFixed(2)),
    barrier,
    package_surface_area_m2: surface_area_m2,
    headspace_volume_cm3: actual_headspace_cm3,
    food_weight_g: geometry.net_weight_g,
    microbial_margin_cfu: Number(microbial_margin.toFixed(2)),
    moisture_margin_g100g: Number(moisture_margin.toFixed(2)),
    oxidation_margin_mg_kg: Number(ox_margin.toFixed(2)),
    daily_trajectory
  };
}

// ==============================================================
// STAGE B: PHYSICS CORE (DIGITAL TWIN) — EXACT FORMULAS
// ==============================================================

/**
 * Respiration (Michaelis-Menten):
 * R_O2 = Vm * [O2] / (Km + [O2])
 */
export function respirationMichaelisMenten(vm: number, o2: number, km: number): number {
  if (o2 <= 0) return 0;
  return (vm * o2) / (km + o2);
}

/**
 * Temperature dependence (Arrhenius/Q10):
 * Rate(T2) = Rate(T1) * Q10 ^ ((T2 - T1) / 10)
 */
export function temperatureDependenceQ10(rateT1: number, t2: number, t1: number, q10: number): number {
  const deltaT = (t2 - t1) / 10.0;
  return rateT1 * Math.pow(q10, deltaT);
}

/**
 * Steady-state pack atmosphere:
 * OTR_film * Area * (0.21 - pO2_in) = R_O2(T, pO2_in) * Weight
 * Solved numerically via Brent's method.
 */
export function steadyStateO2Brent(
  otrFilm: number,
  area: number,
  weight: number,
  vm: number,
  km: number,
  tempC: number,
  refTempC: number = 20.0,
  q10: number = 2.0,
  ambientO2: number = 0.21
): number {
  if (otrFilm <= 0 || area <= 0 || weight <= 0) return 0;

  const tempFactor = Math.pow(q10, (tempC - refTempC) / 10.0);
  const vmT = vm * tempFactor;

  const f = (po2: number): number => {
    const rO2 = po2 > 0 ? (vmT * po2) / (km + po2) : 0;
    const permeation = otrFilm * area * (ambientO2 - po2);
    const consumption = rO2 * weight;
    return permeation - consumption;
  };

  let a = 0.0;
  let b = ambientO2;
  let fa = f(a);
  let fb = f(b);

  if (fa <= 0) return 0.0;
  if (fb >= 0) return ambientO2;

  // Brent's method
  let c = a;
  let fc = fa;
  let d = 0;
  let mflag = true;

  for (let i = 0; i < 100; i++) {
    if (Math.abs(fb) < 1e-7) return b;
    let s: number;
    if (fa !== fc && fb !== fc) {
      s = (a * fb * fc) / ((fa - fb) * (fa - fc)) +
          (b * fa * fc) / ((fb - fa) * (fb - fc)) +
          (c * fa * fb) / ((fc - fa) * (fc - fb));
    } else {
      s = b - fb * (b - a) / (fb - fa);
    }

    const cond1 = !((3 * a + b) / 4 < s && s < b);
    const cond2 = mflag && Math.abs(s - b) >= Math.abs(b - c) / 2;
    const cond3 = !mflag && Math.abs(s - b) >= Math.abs(c - d) / 2;
    const cond4 = mflag && Math.abs(b - c) < 1e-7;
    const cond5 = !mflag && Math.abs(c - d) < 1e-7;

    if (cond1 || cond2 || cond3 || cond4 || cond5) {
      s = (a + b) / 2.0;
      mflag = true;
    } else {
      mflag = false;
    }

    const fs = f(s);
    d = c;
    c = b;
    fc = fb;

    if (fa * fs < 0) {
      b = s;
      fb = fs;
    } else {
      a = s;
      fa = fs;
    }

    if (Math.abs(fa) < Math.abs(fb)) {
      const tempA = a;
      a = b;
      b = tempA;
      const tempFa = fa;
      fa = fb;
      fb = tempFa;
    }

    if (Math.abs(b - a) < 1e-7) return b;
  }
  return b;
}

/**
 * Shelf life vs temperature:
 * SL(T2) = SL(T1) / Q10 ^ ((T2 - T1) / 10)
 */
export function shelfLifeTemperatureQ10(slT1: number, t2: number, t1: number, q10: number): number {
  const deltaT = (t2 - t1) / 10.0;
  const divisor = Math.pow(q10, deltaT);
  return divisor > 0 ? slT1 / divisor : 0;
}

/**
 * Moisture gain — Labuza's equation (dry/snack foods):
 * ln[(Me - Mo) / (Me - Mc)] = -(WVTR * A * t) / (Wcp * b)
 */
export function labuzaCriticalTime(
  m0: number,
  mc: number,
  me: number,
  wvtr: number,
  area: number,
  wcp: number,
  b: number
): number {
  if (wvtr <= 0 || area <= 0) return Infinity;
  if (m0 >= mc) return 0;
  const num = me - m0;
  const den = me - mc;
  if (den <= 0 || num <= 0) return Infinity;
  const logRatio = Math.log(num / den);
  return (wcp * b / (wvtr * area)) * logRatio;
}

export interface HourlyDigitalTwinResult {
  hourly: Array<{
    hour: number;
    o2_pct: number;
    co2_pct: number;
    moisture_pct: number;
    temp_c: number;
  }>;
  predicted_shelf_life_hours: number;
  spoilage_trigger: string;
}

/**
 * Hourly Digital Twin Simulation loops hour-by-hour against climate stress profile
 */
export function simulateHourlyDigitalTwin(
  food: any,
  film: any,
  climate: any,
  geom: any,
  maxHours: number = 720
): HourlyDigitalTwinResult {
  const category = (food.category || 'snack').toLowerCase();
  const isRespiring = ['fruit', 'vegetable', 'fresh_produce', 'horticulture'].includes(category);

  const m0 = Number(food.moisture_pct ?? (isRespiring ? 83.5 : 12.1));
  const mc = Number(food.critical_moisture_content ?? (isRespiring ? 75.0 : 14.5));
  const vm = Number(food.respiration_vm ?? (isRespiring ? 48.5 : 0.0));
  const km = Number(food.respiration_km ?? 1.8);
  const q10 = Number(food.q10_value ?? food.q10 ?? 2.2);
  const refTemp = Number(food.optimal_storage_temp_c ?? (isRespiring ? 12.0 : 22.0));
  const safeO2Min = Number(food.safe_o2_min ?? 2.0);
  const safeCo2Max = Number(food.safe_co2_max ?? 8.0);
  const baselineShelfLifeDays = Number(food.target_shelf_life_days ?? 21.0);
  const baselineHours = baselineShelfLifeDays * 24.0;

  const otrDay = Number(film.otr_cc_m2_day ?? film.otr_cc_m2_day_atm ?? (isRespiring ? 2500.0 : 25.0));
  const wvtrDay = Number(film.wvtr_g_m2_day ?? (isRespiring ? 15.0 : 1.2));
  const ctrDay = Number(film.ctr_cc_m2_day ?? (otrDay * 4.0));

  const otrHr = otrDay / 24.0;
  const wvtrHr = wvtrDay / 24.0;
  const ctrHr = ctrDay / 24.0;

  const areaM2 = Number(geom.area_m2 ?? geom.pack_area_m2 ?? 0.045);
  const netWeightKg = Number(geom.net_weight_kg ?? geom.weight_kg ?? 0.20);
  const netWeightG = netWeightKg * 1000.0;
  const headspaceCm3 = Number(geom.headspace_cm3 ?? 120.0);

  const solidFraction = m0 < 100 ? (100 - m0) / 100 : 0.5;
  const wcpDryG = Math.max(10.0, netWeightG * solidFraction);
  const rawB = Number(food.sorption_isotherm_b ?? 18.0);
  const bPct = rawB > 1.0 ? rawB : rawB * 100.0;
  const bFrac = bPct / 100.0;

  const avgTemp = Number(climate.avg_temp_c ?? 28.5);
  const maxTemp = Number(climate.max_temp_c ?? (avgTemp + 5.0));
  const avgRh = Number(climate.avg_rh_pct ?? 75.0);

  let currentO2 = 21.0;
  let currentCo2 = 0.03;
  let currentMoisture = m0;
  let spoilageTrigger = 'max_simulation_limit';
  let predictedHours = maxHours;
  let cumulativeSenescence = 0;

  const hourly: Array<{ hour: number; o2_pct: number; co2_pct: number; moisture_pct: number; temp_c: number }> = [];

  for (let h = 0; h < maxHours; h++) {
    const dayHour = h % 24;
    const diurnalFactor = Math.sin(2.0 * Math.PI * dayHour / 24.0);
    const tempEnv = avgTemp + (maxTemp - avgTemp) * diurnalFactor;
    const rhEnv = Math.max(10, Math.min(98, avgRh - 12.0 * diurnalFactor));

    hourly.push({
      hour: h,
      o2_pct: Number(currentO2.toFixed(2)),
      co2_pct: Number(currentCo2.toFixed(2)),
      moisture_pct: Number(currentMoisture.toFixed(2)),
      temp_c: Number(tempEnv.toFixed(1))
    });

    if (!isRespiring) {
      // Labuza moisture gain
      const me = 2.0 + bPct * (rhEnv / 100.0);
      const exponent = -(wvtrHr * areaM2 * 1.0) / (wcpDryG * bFrac);
      const nextMoisture = me - (me - currentMoisture) * Math.exp(exponent);

      if (nextMoisture >= mc) {
        const denom = Math.max(1e-6, nextMoisture - currentMoisture);
        const frac = Math.max(0, Math.min(1, (mc - currentMoisture) / denom));
        predictedHours = Number((h + frac).toFixed(1));
        spoilageTrigger = 'moisture_exceeded_critical';

        hourly.push({
          hour: h + 1,
          o2_pct: Number(currentO2.toFixed(2)),
          co2_pct: Number(currentCo2.toFixed(2)),
          moisture_pct: Number(nextMoisture.toFixed(2)),
          temp_c: Number(tempEnv.toFixed(1))
        });
        break;
      }

      currentMoisture = nextMoisture;

      const hrSl = shelfLifeTemperatureQ10(baselineHours, tempEnv, refTemp, q10);
      cumulativeSenescence += 1.0 / Math.max(1.0, hrSl);
      if (cumulativeSenescence >= 1.0) {
        predictedHours = h + 1;
        spoilageTrigger = 'thermal_rancidity_oxidation';
        break;
      }
    } else {
      // Respiring produce
      const rO2 = respirationMichaelisMenten(vm, currentO2, km) * Math.pow(q10, (tempEnv - refTemp) / 10.0);
      const rCo2 = 1.0 * rO2;

      const o2Flux = otrHr * areaM2 * (20.9 - currentO2) / 100.0;
      const co2Flux = ctrHr * areaM2 * (currentCo2 - 0.04) / 100.0;

      const o2Consumed = rO2 * netWeightKg / 24.0;
      const co2Produced = rCo2 * netWeightKg / 24.0;

      const dO2 = ((o2Flux - o2Consumed) / Math.max(10, headspaceCm3)) * 100.0;
      const dCo2 = ((co2Produced - co2Flux) / Math.max(10, headspaceCm3)) * 100.0;

      const nextO2 = Math.max(0, Math.min(21.0, currentO2 + dO2));
      const nextCo2 = Math.max(0.03, currentCo2 + dCo2);

      const waterLoss = wvtrHr * areaM2 * 0.5;
      currentMoisture = Math.max(0, currentMoisture - (waterLoss / (netWeightG * 0.01)));

      if (nextO2 <= safeO2Min) {
        predictedHours = h + 1;
        spoilageTrigger = 'o2_depleted_anaerobic';
        hourly.push({
          hour: h + 1,
          o2_pct: Number(nextO2.toFixed(2)),
          co2_pct: Number(nextCo2.toFixed(2)),
          moisture_pct: Number(currentMoisture.toFixed(2)),
          temp_c: Number(tempEnv.toFixed(1))
        });
        break;
      }

      if (nextCo2 >= safeCo2Max) {
        predictedHours = h + 1;
        spoilageTrigger = 'co2_toxicity';
        hourly.push({
          hour: h + 1,
          o2_pct: Number(nextO2.toFixed(2)),
          co2_pct: Number(nextCo2.toFixed(2)),
          moisture_pct: Number(currentMoisture.toFixed(2)),
          temp_c: Number(tempEnv.toFixed(1))
        });
        break;
      }

      const hrSl = shelfLifeTemperatureQ10(baselineHours, tempEnv, refTemp, q10);
      cumulativeSenescence += 1.0 / Math.max(1.0, hrSl);
      if (cumulativeSenescence >= 1.0) {
        predictedHours = h + 1;
        spoilageTrigger = 'senescence_complete';
        break;
      }

      currentO2 = nextO2;
      currentCo2 = nextCo2;
    }
  }

  return {
    hourly,
    predicted_shelf_life_hours: Number(predictedHours.toFixed(1)),
    spoilage_trigger: spoilageTrigger
  };
}
