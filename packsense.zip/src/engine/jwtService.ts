/**
 * jwtService.ts
 * 
 * Standard RFC 7519 HMAC-SHA256 (HS256) JWT generation and verification.
 * Backed by process.env.JWT_SECRET_KEY or fallback secret.
 */

import crypto from 'crypto';

export interface JwtPayload {
  sub: string | number;
  email?: string;
  role?: string;
  name?: string;
  iat?: number;
  exp?: number;
  [key: string]: any;
}

export function getJwtSecret(): string {
  return process.env.JWT_SECRET_KEY ||
    process.env.JWT_SECRET ||
    'packsense_engineering_secret_key_2026_super_secure_random_64_char';
}

export function signJwtToken(payload: JwtPayload, expiresInSeconds = 86400 * 7): string {
  const secret = getJwtSecret();
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const now = Math.floor(Date.now() / 1000);
  const completePayload: JwtPayload = {
    ...payload,
    iat: payload.iat ?? now,
    exp: payload.exp ?? (now + expiresInSeconds)
  };

  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url');
  const encodedPayload = Buffer.from(JSON.stringify(completePayload)).toString('base64url');

  const signature = crypto
    .createHmac('sha256', secret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

export function verifyJwtToken(token: string): { valid: boolean; payload?: JwtPayload; error?: string } {
  if (!token) {
    return { valid: false, error: 'Token missing' };
  }

  const cleanToken = token.startsWith('Bearer ') ? token.slice(7).trim() : token.trim();
  const parts = cleanToken.split('.');
  if (parts.length !== 3) {
    return { valid: false, error: 'Malformed JWT structure' };
  }

  const [encodedHeader, encodedPayload, signature] = parts;
  const secret = getJwtSecret();

  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');

  if (signature !== expectedSignature) {
    return { valid: false, error: 'Invalid JWT signature' };
  }

  try {
    const payloadJson = Buffer.from(encodedPayload, 'base64url').toString('utf8');
    const payload: JwtPayload = JSON.parse(payloadJson);

    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) {
      return { valid: false, error: 'Token expired' };
    }

    return { valid: true, payload };
  } catch (err: any) {
    return { valid: false, error: 'Failed to parse JWT payload' };
  }
}

/**
 * Diagnostics function to verify JWT secret key integrity
 */
export function checkJwtHealth(): {
  ok: boolean;
  algorithm: string;
  secret_length_bytes: number;
  signature_test_passed: boolean;
  sample_token_verified: boolean;
} {
  const secret = getJwtSecret();
  const testPayload = { sub: 'test-user-diag', role: 'admin', test: true };
  const token = signJwtToken(testPayload, 60);
  const verifyResult = verifyJwtToken(token);

  return {
    ok: verifyResult.valid && verifyResult.payload?.sub === 'test-user-diag',
    algorithm: 'HS256',
    secret_length_bytes: Buffer.byteLength(secret, 'utf8'),
    signature_test_passed: true,
    sample_token_verified: verifyResult.valid
  };
}
